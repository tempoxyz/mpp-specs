# Presto Production Deployment

This folder contains files for hosting Presto at `presto.tempo.xyz`.

## Architecture

```
presto.tempo.xyz (Cloudflare)
├── Worker (auth gate) ─── validates Basic Auth / ?auth= param
└── Pages (static) ─────── index.html (wallet), install.sh
```

## Files

- **worker.js** - Cloudflare Worker that enforces authentication
- **wrangler.toml** - Worker configuration
- **index.html** - Wallet connect page (copy of auth/index.html with prod tweaks)
- **install.sh** - Production installer script

## Deployment

### 1. Deploy Cloudflare Pages

```bash
# In deploy/ directory
npx wrangler pages deploy . --project-name=presto
```

Or connect to GitHub for automatic deploys.

### 2. Deploy Cloudflare Worker

```bash
cd deploy/

# Set the auth password as a secret (NOT in wrangler.toml)
npx wrangler secret put AUTH_PASS
# Enter: presto-tempo-lfg

# Deploy worker
npx wrangler deploy
```

### 3. Configure Route

In Cloudflare dashboard:
1. Go to Workers & Pages → presto-auth-gate → Triggers
2. Add route: `presto.tempo.xyz/*` (zone: tempo.xyz)

Or via wrangler.toml routes config.

## Usage

### One-line install (for Tempo devs)

```bash
curl -fsSL 'https://presto.tempo.xyz/install.sh' -u eng:presto-tempo-lfg | bash
```

Or with query param (curl-friendly):

```bash
curl -fsSL 'https://presto.tempo.xyz/install.sh?auth=eng:presto-tempo-lfg' | bash
```

### Browser wallet connect

Visit https://presto.tempo.xyz/ (will prompt for Basic Auth).

## Security Notes

- Auth password is stored as Cloudflare secret, not in code
- Worker strips `?auth=` param before proxying to prevent logging
- All responses have `Cache-Control: no-store` to prevent credential caching
- 401 responses include `WWW-Authenticate: Basic` for browser prompts
