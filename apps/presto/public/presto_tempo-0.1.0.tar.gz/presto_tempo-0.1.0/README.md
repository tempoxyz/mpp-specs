# presto

**Pay-per-request AI coding agent.** No subscriptions, no API keys—just crypto.

A minimal AI agent (~400 LOC) that pays for LLM calls with stablecoins on [Tempo](https://tempo.xyz). Uses the [IETF Payment HTTP Authentication Scheme](https://datatracker.ietf.org/doc/draft-ietf-httpauth-payment/) via [payments-proxy](https://github.com/tempoxyz/ai-payments).

Inspired by [nanocode](https://github.com/1rgs/nanocode).

---

## Quickstart

```bash
# 1. Install (requires Python 3.10+)
./install.sh

# 2. Run
presto
```

On first run, your browser opens to connect a wallet. Generate a new one or import an existing key.

```
> fix the typo in README.md
[agent reads file, makes edit]
✓ paid $0.01  tx: 0xabc...
```

**That's it.** You just paid per-request for AI with crypto.

---

## Requirements

- Python 3.10+
- macOS or Linux
- Stablecoins on Tempo Moderato testnet

---

## Getting Stablecoins

Your wallet needs stablecoins to pay for requests (~$0.01 each).

**Fastest:** Ask in [Tempo Discord](https://discord.gg/tempo) with your wallet address.

**Or manually:**
1. Get testnet ETH from a faucet
2. Bridge to Tempo Moderato
3. Swap for stablecoins on the Tempo DEX

Check your balance anytime with `/balance`.

---

## How It Works

```
┌────────────┐    ┌──────────────────┐    ┌─────────────┐
│   presto   │───▶│  payments-proxy  │───▶│  OpenRouter │
│            │◀───│  402 + Challenge │    │             │
│  Sign TX   │───▶│  Payment Auth    │───▶│  LLM Call   │
└────────────┘    └──────────────────┘    └─────────────┘
```

1. Presto sends request to payments-proxy
2. Proxy returns `402 Payment Required` with payment challenge
3. Presto signs a Tempo transaction locally (your key never leaves your machine)
4. Presto retries with `Authorization: Payment <credential>`
5. Proxy broadcasts payment, forwards to OpenRouter
6. Response includes `Payment-Receipt` with transaction hash

---

## Commands

| Command | Description |
|---------|-------------|
| `/c` | Clear conversation |
| `/wallet` | Show wallet address |
| `/wallet explorer` | Open wallet in block explorer |
| `/balance` | Check balance |
| `/model` | Switch model |
| `/skills` | List available skills |
| `/skill <name>` | Load a skill |
| `/q` or `exit` | Quit |

---

## Tools

The agent has access to:

| Tool | Description |
|------|-------------|
| `read` | Read file with line numbers |
| `write` | Write content to file |
| `edit` | Replace string in file |
| `glob` | Find files by pattern |
| `grep` | Search files for regex |
| `bash` | Run shell command |
| `check_balance` | Check wallet balance |
| `wallet_info` | Show wallet details |
| `load_skill` | Load specialized skills |

---

## Skills

Skills extend presto with specialized capabilities. Load them manually or let the agent load them automatically.

```
/skill foundry     # Ethereum development
/skill 1password   # Retrieve secrets
/skill slack       # Search/send messages
```

The agent can also load skills based on context:
```
> deploy this contract to mainnet
→ load_skill(name="foundry")
```

Available skills live in `~/.config/agents/skills/`.

---

## Configuration

### Environment Variables

Create a `.env` file in the presto directory:

```bash
# Model selection
MODEL=anthropic/claude-sonnet-4

# Payments proxy (default: Tempo's hosted proxy)
PRESTO_PROXY_URL=https://openrouter.payments.tempo.xyz

# Logging
PRESTO_LOG_LEVEL=INFO  # DEBUG for troubleshooting

# RPC auth (if using authenticated RPC endpoints)
TEMPO_MODERATO_RPC_USERNAME=eng
TEMPO_MODERATO_RPC_PASSWORD=your-password
TEMPO_MAINNET_RPC_USERNAME=eng
TEMPO_MAINNET_RPC_PASSWORD=your-password
```

### Config File

Wallet config is stored in `~/.presto.json`:

```json
{
  "account_address": "0x...",
  "network": "moderato",
  "networks": {
    "moderato": {
      "access_keys": [{"private_key": "0x...", "address": "0x..."}]
    }
  }
}
```

This file is created automatically during wallet setup and has `chmod 600` permissions.

---

## Security

**Your keys stay local.** Private keys are stored in `~/.presto.json` and never sent to any server. Transactions are signed locally using the pytempo library.

**What the proxy sees:** Your LLM requests and payment credentials. The proxy cannot access your private key.

**Recommendations:**
- Use a fresh wallet for testing—don't reuse mainnet wallets
- Moderato is a testnet; treat funds accordingly
- Review transactions in the [explorer](https://explore.moderato.tempo.xyz)

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Browser doesn't open | Run from a terminal with display access, not SSH |
| Insufficient balance | Get stablecoins from Discord or `/balance` to check |
| 402 errors persist | Check `presto.log` for details; verify RPC connectivity |
| Model not found | Check available models at [openrouter.ai/models](https://openrouter.ai/models) |

Logs are in `presto.log`. Set `PRESTO_LOG_LEVEL=DEBUG` for verbose output.

---

## Local Development

### Setup

```bash
git clone https://github.com/tempoxyz/presto
cd presto
./install.sh
```

### Run against a local payments-proxy:

```bash
# Clone and run the proxy
git clone https://github.com/tempoxyz/ai-payments
cd ai-payments
pnpm install
pnpm --filter @tempo/payments-proxy dev

# Point presto at local proxy
PRESTO_PROXY_URL=http://localhost:8787 presto
```

---

## Protocol Details

The payment flow follows [draft-ietf-httpauth-payment](https://datatracker.ietf.org/doc/draft-ietf-httpauth-payment/):

**402 Response:**
```http
HTTP/1.1 402 Payment Required
WWW-Authenticate: Payment id="abc123", realm="api", method="tempo", 
  intent="charge", request="eyJhbW91bnQiOiIxMDAwMCIsImFzc2V0Ijoi..."
```

**Request with Payment:**
```http
POST /openrouter/v1/messages HTTP/1.1
Authorization: Payment eyJpZCI6ImFiYzEyMyIsInNvdXJjZSI6ImRpZDpwa2g6...
```

**Success Response:**
```http
HTTP/1.1 200 OK
Payment-Receipt: eyJzdGF0dXMiOiJzdWNjZXNzIiwicmVmZXJlbmNlIjoiMHg..."
```

---

## License

MIT
