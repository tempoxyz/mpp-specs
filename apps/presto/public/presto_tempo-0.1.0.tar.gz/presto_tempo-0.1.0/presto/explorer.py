"""Index Supply client for blockchain data queries.

This module provides explorer-like functionality using web3.py.
Uses Index Supply API for efficient queries of transfers, balances, and transactions.
"""

import json
import urllib.request
import urllib.error
from dataclasses import dataclass
from typing import Optional
from datetime import datetime

from . import logger
from .config import NETWORKS, DEFAULT_NETWORK
from .rpc import get_token_metadata


# Index Supply API endpoint
INDEX_SUPPLY_URL = "https://api.indexsupply.net/query"

# TIP-20 Transfer event signature
TRANSFER_SIGNATURE = "event Transfer(address indexed from, address indexed to, uint256 amount)"

# Token metadata cache (populated dynamically from chain)
_token_cache = {}


@dataclass
class TokenBalance:
    """Token balance with metadata."""
    token: str
    balance: int
    symbol: str = ""
    name: str = ""
    decimals: int = 6
    currency: str = ""
    
    @property
    def formatted_balance(self) -> str:
        """Format balance with proper decimals."""
        amount = self.balance / (10 ** self.decimals)
        if self.currency == "USD" or self.symbol in ("USD", "USDM", "USDC"):
            return f"${amount:,.2f}"
        return f"{amount:,.{min(self.decimals, 4)}f} {self.symbol or self.token[:10]}"


@dataclass
class Transfer:
    """Token transfer record."""
    tx_hash: str
    block_num: int
    timestamp: int
    token: str
    from_addr: str
    to_addr: str
    amount: int
    symbol: str = ""
    decimals: int = 6
    
    @property
    def formatted_amount(self) -> str:
        """Format amount with proper decimals."""
        val = self.amount / (10 ** self.decimals)
        if self.symbol in ("USD", "USDM", "USDC"):
            return f"${val:,.2f}"
        return f"{val:,.4f} {self.symbol or '???'}"
    
    @property
    def formatted_time(self) -> str:
        """Format timestamp as readable date."""
        if not self.timestamp:
            return "Unknown"
        return datetime.fromtimestamp(self.timestamp).strftime("%Y-%m-%d %H:%M")
    
    def direction(self, my_address: str) -> str:
        """Return 'sent' or 'received' based on address."""
        my = my_address.lower()
        if self.from_addr.lower() == my:
            return "sent"
        elif self.to_addr.lower() == my:
            return "received"
        return "unknown"


@dataclass
class Transaction:
    """Transaction record."""
    hash: str
    block_num: int
    timestamp: int
    from_addr: str
    to_addr: str
    value: int
    gas_used: int = 0
    status: bool = True
    
    @property
    def formatted_time(self) -> str:
        """Format timestamp as readable date."""
        if not self.timestamp:
            return "Unknown"
        return datetime.fromtimestamp(self.timestamp).strftime("%Y-%m-%d %H:%M")


class IndexSupplyClient:
    """Client for Index Supply blockchain data queries."""
    
    def __init__(self, chain_id: int = None, api_key: str = None, rpc_url: str = None):
        self.chain_id = chain_id or NETWORKS[DEFAULT_NETWORK]["chain_id"]
        self.api_key = api_key
        self.rpc_url = rpc_url
        self._token_cache: dict[str, dict] = {}
    
    def _get_token_info(self, token_address: str) -> dict:
        """Get token metadata, using cache or fetching from contract."""
        token_lower = token_address.lower()
        
        # Check instance cache
        if token_lower in self._token_cache:
            return self._token_cache[token_lower]
        
        # Check global cache
        if token_lower in _token_cache:
            return _token_cache[token_lower]
        
        # Fetch from chain if we have an RPC URL
        if self.rpc_url:
            metadata = get_token_metadata(token_address, self.rpc_url)
            if metadata.get("symbol") or metadata.get("name"):
                self._token_cache[token_lower] = metadata
                _token_cache[token_lower] = metadata  # Also cache globally
                return metadata
        
        return {}
    
    def _query(self, sql: str, event_signatures: list[str] = None) -> list[dict]:
        """Execute a SQL query against Index Supply."""
        # API requires array of queries, each with event_signatures (can be empty)
        payload = [{"query": sql, "event_signatures": event_signatures or []}]
        
        headers = {
            "Content-Type": "application/json",
            "Chain": str(self.chain_id),
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        try:
            req = urllib.request.Request(
                INDEX_SUPPLY_URL,
                data=json.dumps(payload).encode("utf-8"),
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                # Response format: {"result": [[[col_names], [row1], [row2], ...]]}
                rows_data = result.get("result", [[]])[0] if result.get("result") else []
                if len(rows_data) < 2:
                    return []
                columns = rows_data[0]
                return [dict(zip(columns, row)) for row in rows_data[1:]]
        except urllib.error.HTTPError as e:
            logger.error(f"Index Supply query failed: {e.code} {e.reason}")
            return []
        except Exception as e:
            logger.error(f"Index Supply query error: {e}")
            return []
    
    def get_balances(self, address: str) -> list[TokenBalance]:
        """Get all TIP-20 token balances for an address.
        
        Uses Index Supply to aggregate incoming/outgoing transfers.
        """
        address = address.lower()
        
        # Query incoming transfers
        incoming_sql = f"""
            SELECT address as token, SUM(amount) as received
            FROM transfer
            WHERE chain = {self.chain_id} AND "to" = '{address}'
            GROUP BY address
        """
        
        # Query outgoing transfers
        outgoing_sql = f"""
            SELECT address as token, SUM(amount) as sent
            FROM transfer
            WHERE chain = {self.chain_id} AND "from" = '{address}'
            GROUP BY address
        """
        
        incoming = self._query(incoming_sql, [TRANSFER_SIGNATURE])
        outgoing = self._query(outgoing_sql, [TRANSFER_SIGNATURE])
        
        # Merge to calculate balances
        balances: dict[str, int] = {}
        for row in incoming:
            token = str(row.get("token", "")).lower()
            received = int(row.get("received", 0))
            balances[token] = balances.get(token, 0) + received
        
        for row in outgoing:
            token = str(row.get("token", "")).lower()
            sent = int(row.get("sent", 0))
            balances[token] = balances.get(token, 0) - sent
        
        # Filter non-zero and build result
        result = []
        
        for token, balance in balances.items():
            if balance <= 0:
                continue
            
            metadata = self._get_token_info(token)
            result.append(TokenBalance(
                token=token,
                balance=balance,
                symbol=metadata.get("symbol", ""),
                name=metadata.get("name", ""),
                decimals=metadata.get("decimals", 6),
                currency="USD" if metadata.get("symbol", "").startswith("USD") else "",
            ))
        
        # Sort by USD tokens first, then by balance
        result.sort(key=lambda x: (
            0 if x.currency == "USD" else 1,
            -x.balance
        ))
        
        return result
    
    def get_transfers(
        self,
        address: str,
        direction: str = "all",
        limit: int = 50,
        offset: int = 0,
    ) -> list[Transfer]:
        """Get TIP-20 transfer history for an address.
        
        Args:
            address: Wallet address
            direction: 'all', 'sent', or 'received'
            limit: Max results
            offset: Pagination offset
        """
        address = address.lower()
        
        where_clause = f"chain = {self.chain_id}"
        if direction == "sent":
            where_clause += f" AND \"from\" = '{address}'"
        elif direction == "received":
            where_clause += f" AND \"to\" = '{address}'"
        else:
            where_clause += f" AND (\"from\" = '{address}' OR \"to\" = '{address}')"
        
        sql = f"""
            SELECT 
                tx_hash,
                block_num,
                block_timestamp,
                address as token,
                "from",
                "to",
                amount
            FROM transfer
            WHERE {where_clause}
            ORDER BY block_num DESC
            LIMIT {limit}
            OFFSET {offset}
        """
        
        rows = self._query(sql, [TRANSFER_SIGNATURE])
        
        result = []
        for row in rows:
            token = str(row.get("token", "")).lower()
            metadata = self._get_token_info(token)
            
            # Parse timestamp - can be unix int or ISO string
            ts_raw = row.get("block_timestamp", 0)
            if isinstance(ts_raw, str):
                try:
                    dt = datetime.fromisoformat(ts_raw.replace(" +00:00:00", "+00:00").replace(".0 ", " "))
                    ts = int(dt.timestamp())
                except:
                    ts = 0
            else:
                ts = int(ts_raw) if ts_raw else 0
            
            result.append(Transfer(
                tx_hash=str(row.get("tx_hash", "")),
                block_num=int(row.get("block_num", 0)),
                timestamp=ts,
                token=token,
                from_addr=str(row.get("from", "")),
                to_addr=str(row.get("to", "")),
                amount=int(row.get("amount", 0)),
                symbol=metadata.get("symbol", ""),
                decimals=metadata.get("decimals", 6),
            ))
        
        return result
    
    def get_transactions(
        self,
        address: str,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Transaction]:
        """Get transaction history for an address."""
        address = address.lower()
        
        sql = f"""
            SELECT 
                hash,
                block_num,
                block_timestamp,
                "from",
                "to",
                value
            FROM txs
            WHERE chain = {self.chain_id}
              AND ("from" = '{address}' OR "to" = '{address}')
            ORDER BY block_num DESC
            LIMIT {limit}
            OFFSET {offset}
        """
        
        rows = self._query(sql)
        
        result = []
        for row in rows:
            # Parse timestamp - can be unix int or ISO string
            ts_raw = row.get("block_timestamp", 0)
            if isinstance(ts_raw, str):
                try:
                    dt = datetime.fromisoformat(ts_raw.replace(" +00:00:00", "+00:00").replace(".0 ", " "))
                    ts = int(dt.timestamp())
                except:
                    ts = 0
            else:
                ts = int(ts_raw) if ts_raw else 0
            
            result.append(Transaction(
                hash=str(row.get("hash", "")),
                block_num=int(row.get("block_num", 0)),
                timestamp=ts,
                from_addr=str(row.get("from", "")),
                to_addr=str(row.get("to", "")),
                value=int(row.get("value", 0)),
                gas_used=0,  # Not available in Index Supply
                status=True,  # Not available in Index Supply
            ))
        
        return result
    
    def get_transfer_count(self, address: str) -> int:
        """Get total transfer count for an address."""
        address = address.lower()
        
        sql = f"""
            SELECT COUNT(*) as cnt
            FROM transfer
            WHERE chain = {self.chain_id}
              AND ("from" = '{address}' OR "to" = '{address}')
        """
        
        rows = self._query(sql, [TRANSFER_SIGNATURE])
        if rows:
            return int(rows[0].get("cnt", 0))
        return 0
    
    def get_tx_count(self, address: str) -> int:
        """Get total transaction count for an address."""
        address = address.lower()
        
        sql = f"""
            SELECT COUNT(*) as cnt
            FROM txs
            WHERE chain = {self.chain_id}
              AND ("from" = '{address}' OR "to" = '{address}')
        """
        
        rows = self._query(sql)
        if rows:
            return int(rows[0].get("cnt", 0))
        return 0


# Global client instance
_client: Optional[IndexSupplyClient] = None


def get_explorer_client(chain_id: int = None, rpc_url: str = None) -> IndexSupplyClient:
    """Get or create the explorer client.
    
    Args:
        chain_id: Blockchain chain ID
        rpc_url: RPC URL for on-chain token metadata lookups
    """
    global _client
    if _client is None or (chain_id and _client.chain_id != chain_id):
        # Try to get RPC URL from network config if not provided
        if not rpc_url and chain_id:
            for net_info in NETWORKS.values():
                if net_info.get("chain_id") == chain_id:
                    rpc_url = net_info.get("rpc")
                    break
        if not rpc_url:
            rpc_url = NETWORKS.get(DEFAULT_NETWORK, {}).get("rpc")
        _client = IndexSupplyClient(chain_id=chain_id, rpc_url=rpc_url)
    return _client


# Convenience functions for agent tools
def wallet_balance(address: str = None, network: str = None) -> str:
    """Get wallet token balances with total. Returns formatted string for display.
    
    This is a tool the agent can use to check token balances.
    """
    from .wallet import load_wallet_config
    
    if not address:
        config = load_wallet_config()
        address = config.account_address if config else None
    
    if not address:
        return "No wallet configured. Run /wallet setup first."
    
    chain_id = NETWORKS.get(network or DEFAULT_NETWORK, {}).get("chain_id")
    client = get_explorer_client(chain_id)
    
    balances = client.get_balances(address)
    
    if not balances:
        return f"No token balances found for {address}"
    
    # Calculate total (assume all stablecoins are ~$1)
    total_usd = 0.0
    lines = []
    for b in balances:
        amount = b.balance / (10 ** b.decimals)
        total_usd += amount
        lines.append(f"  ${amount:,.2f} {b.name or b.symbol or b.token[:10]}")
    
    header = f"Total: ${total_usd:,.2f} across {len(balances)} token{'s' if len(balances) != 1 else ''}"
    
    return header + "\n" + "\n".join(lines)


def wallet_transfers(
    address: str = None,
    direction: str = "all",
    limit: int = 20,
    network: str = None,
) -> str:
    """Get wallet transfer history. Returns formatted string for display.
    
    This is a tool the agent can use instead of manually querying.
    """
    from .wallet import load_wallet_config
    
    if not address:
        config = load_wallet_config()
        address = config.account_address if config else None
    
    if not address:
        return "No wallet configured. Run /wallet setup first."
    
    chain_id = NETWORKS.get(network or DEFAULT_NETWORK, {}).get("chain_id")
    client = get_explorer_client(chain_id)
    
    transfers = client.get_transfers(address, direction=direction, limit=limit)
    
    if not transfers:
        return f"No transfers found for {address}"
    
    lines = [f"Recent Transfers ({direction}) for {address}:", ""]
    for t in transfers:
        d = t.direction(address)
        arrow = "←" if d == "received" else "→"
        other = t.from_addr if d == "received" else t.to_addr
        lines.append(f"  {t.formatted_time}  {arrow} {t.formatted_amount:>15}  {other}")
    
    return "\n".join(lines)


def wallet_txs(
    address: str = None,
    limit: int = 20,
    network: str = None,
) -> str:
    """Get wallet transaction history. Returns formatted string for display.
    
    This is a tool the agent can use instead of manually querying.
    """
    from .wallet import load_wallet_config
    
    if not address:
        config = load_wallet_config()
        address = config.account_address if config else None
    
    if not address:
        return "No wallet configured. Run /wallet setup first."
    
    chain_id = NETWORKS.get(network or DEFAULT_NETWORK, {}).get("chain_id")
    client = get_explorer_client(chain_id)
    
    txs = client.get_transactions(address, limit=limit)
    
    if not txs:
        return f"No transactions found for {address}"
    
    lines = [f"Recent Transactions for {address}:", ""]
    for tx in txs:
        to_addr = tx.to_addr if tx.to_addr else "Contract Creation"
        lines.append(f"  {tx.formatted_time}  {tx.hash}  → {to_addr}")
    
    return "\n".join(lines)
