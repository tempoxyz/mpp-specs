"""Streaming payment channel support for efficient micropayments.

Instead of signing an on-chain transaction for every API call, streaming channels allow:
1. Open a channel once with a deposit
2. Sign off-chain vouchers for each payment (instant, no gas)
3. Server settles periodically (batches many payments into one tx)

This reduces gas costs by ~98% and latency from ~2.5s to ~5ms per payment.
"""
import json
import os
import time
from dataclasses import dataclass
from typing import Optional

from eth_account import Account
from eth_account.messages import encode_typed_data
from eth_utils import to_bytes
from presto._vendor.pytempo import create_tempo_transaction, sign_tx_access_key
from web3 import Web3

from . import logger
from .config import NETWORKS, DEFAULT_NETWORK
from .payment import base64url_encode, base64url_decode
from .rpc import (
    get_web3, estimate_gas, get_tx_count, get_2d_nonce, get_gas_price,
    broadcast_tx, wait_for_receipt, keccak256,
)
from .transactions import TransactionSender, TxMeta, get_transaction_sender


# sign_tx_access_key is now imported from pytempo


# EIP-712 domain for voucher signing (per draft-tempo-stream-extension.md §7.2)
VOUCHER_DOMAIN_NAME = "Tempo Stream Channel"
VOUCHER_DOMAIN_VERSION = "1"

# EIP-712 Voucher type (per spec §7.1)
# Note: cumulativeAmount is uint128, validUntil is uint64 (not uint256)
VOUCHER_TYPE = [
    {"name": "channelId", "type": "bytes32"},
    {"name": "cumulativeAmount", "type": "uint128"},
    {"name": "validUntil", "type": "uint64"},
]


@dataclass
class StreamChannel:
    """Represents an open streaming payment channel.
    
    Per draft-stream-channel-authorized-signer.md, channels support an optional
    authorized_signer field that allows a different key (e.g., access key) to
    sign vouchers on behalf of the payer.
    """
    channel_id: str
    escrow_contract: str
    payer: str  # Root wallet address (funds source)
    payee: str  # Server's address
    token: str
    deposit: int  # In base units
    expiry: int  # Unix timestamp
    salt: str
    chain_id: int
    authorized_signer: str = ""  # Access key address that signs vouchers (empty = payer signs)
    
    # Running state
    cumulative_amount: int = 0  # Total amount authorized via vouchers
    voucher_count: int = 0
    
    # Server endpoints
    voucher_endpoint: Optional[str] = None
    min_voucher_delta: int = 0
    
    # On-chain tx hash from channel opening (needed to prove to server)
    open_tx_hash: Optional[str] = None
    
    # When channel was opened (unix timestamp)
    opened_at: int = 0
    
    # When close was requested (0 = not requested)
    close_requested_at: int = 0
    
    # Whether channel has been finalized (withdrawn)
    finalized: bool = False
    
    @property
    def effective_signer(self) -> str:
        """Return the address that should sign vouchers."""
        return self.authorized_signer if self.authorized_signer else self.payer
    
    def remaining_balance(self) -> int:
        """Return remaining spendable balance."""
        return self.deposit - self.cumulative_amount
    
    def can_afford(self, amount: int) -> bool:
        """Check if we can afford a payment."""
        return self.remaining_balance() >= amount
    
    def to_dict(self) -> dict:
        """Serialize channel for persistence.
        
        Minimal persistence: only fields needed for voucher signing and not
        easily fetchable from chain. Channel terms (payer, payee, token, etc.)
        are included because they're needed for EIP-712 voucher signing and
        the escrow contract doesn't have a getChannel() view function.
        """
        return {
            # Core identifiers
            "channel_id": self.channel_id,
            "escrow_contract": self.escrow_contract,
            "chain_id": self.chain_id,
            # Voucher signing requires these (EIP-712 domain/message)
            "payer": self.payer,
            "payee": self.payee,
            "token": self.token,
            "deposit": self.deposit,
            "expiry": self.expiry,
            "authorized_signer": self.authorized_signer,
            # Critical local state: latest voucher amount signed
            "cumulative_amount": self.cumulative_amount,
            # Metadata (optional, for UX)
            "salt": self.salt,
            "opened_at": self.opened_at,
            "finalized": self.finalized,
            # Server association (needed for channel reuse)
            "voucher_endpoint": self.voucher_endpoint,
            "min_voucher_delta": self.min_voucher_delta,
            "open_tx_hash": self.open_tx_hash,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "StreamChannel":
        """Deserialize channel from persistence.
        
        Loads persisted fields including server association (voucher_endpoint,
        min_voucher_delta, open_tx_hash). Runtime-only fields (voucher_count,
        close_requested_at) are not persisted and will use defaults.
        """
        ch = cls(
            channel_id=data["channel_id"],
            escrow_contract=data["escrow_contract"],
            payer=data["payer"],
            payee=data["payee"],
            token=data["token"],
            deposit=data["deposit"],
            expiry=data["expiry"],
            salt=data.get("salt", ""),
            chain_id=data["chain_id"],
            authorized_signer=data.get("authorized_signer", ""),
            opened_at=data.get("opened_at", 0),
        )
        ch.cumulative_amount = data.get("cumulative_amount", 0)
        ch.finalized = data.get("finalized", False)
        # Restore server association fields
        ch.voucher_endpoint = data.get("voucher_endpoint")
        ch.min_voucher_delta = data.get("min_voucher_delta", 0)
        ch.open_tx_hash = data.get("open_tx_hash")
        return ch


class StreamChannelManager:
    """Manages streaming payment channels for a wallet."""
    
    def __init__(self, private_key: str, wallet_address: str, chain_id: int = None, rpc_url: str = None):
        self.private_key = private_key
        self.wallet_address = wallet_address
        self.chain_id = chain_id or NETWORKS[DEFAULT_NETWORK]["chain_id"]
        self.rpc_url = rpc_url or NETWORKS[DEFAULT_NETWORK]["rpc"]
        
        # Use 2D nonces to avoid blocking on other transactions
        # Generate a random nonce key for this manager instance
        import random
        self._nonce_key = random.randint(1, 2**32 - 1)
        
        # Active channels by channel_id -> StreamChannel
        # We track all channels to show history, but only use non-depleted ones for payments
        self._channels: dict[str, StreamChannel] = {}
        
        # Load persisted channels
        self._load_channels()
    
    def _get_channels_file(self) -> str:
        """Get path to channels persistence file."""
        from pathlib import Path
        config_dir = Path.home() / ".config" / "presto"
        config_dir.mkdir(parents=True, exist_ok=True)
        return str(config_dir / "channels.json")
    
    def _load_channels(self):
        """Load channels from disk.
        
        We load ALL channels for this chain (including expired/depleted) for display purposes.
        Only non-expired channels with remaining balance can be used for payments.
        """
        try:
            path = self._get_channels_file()
            logger.debug(f"Loading channels from {path}, chain_id={self.chain_id}")
            if os.path.exists(path):
                with open(path, "r") as f:
                    data = json.load(f)
                logger.debug(f"Found {len(data.get('channels', []))} channels in file")
                for ch_data in data.get("channels", []):
                    try:
                        ch = StreamChannel.from_dict(ch_data)
                        # Only load channels for this chain
                        if ch.chain_id != self.chain_id:
                            logger.debug(f"Skipping channel {ch.channel_id[:18]}... wrong chain ({ch.chain_id} != {self.chain_id})")
                            continue
                        # Load all channels (even expired) for display purposes
                        self._channels[ch.channel_id] = ch
                        status = "active"
                        if ch.expiry <= int(time.time()):
                            status = "expired"
                        elif ch.remaining_balance() <= 0:
                            status = "depleted"
                        logger.info(f"Loaded channel {ch.channel_id[:18]}... (${ch.cumulative_amount/1_000_000:.2f} spent, {status})")
                    except Exception as e:
                        logger.warning(f"Failed to load channel: {e}")
            else:
                logger.debug(f"No channels file found at {path}")
        except Exception as e:
            logger.debug(f"No channels to load: {e}")
    
    def _save_channels(self):
        """Persist channels to disk."""
        try:
            path = self._get_channels_file()
            channels_data = [ch.to_dict() for ch in self._channels.values()]
            logger.debug(f"Saving {len(channels_data)} channels to {path}")
            with open(path, "w") as f:
                json.dump({"channels": channels_data}, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save channels: {e}")
    
    def get_active_channel(self, escrow_contract: str, payee: str, voucher_endpoint: str = None) -> Optional[StreamChannel]:
        """Get an active channel for the given escrow and payee.
        
        Channel matching is based on ON-CHAIN IDENTITY (escrow + payee), not URL.
        A channel is an agreement with a specific payee address - the URL is just
        routing metadata that can change.
        
        Returns the channel with the most remaining balance that matches escrow/payee.
        Prefers channels already registered with the current endpoint.
        Expired/depleted/finalized/closing channels are kept for history but not returned.
        
        Args:
            escrow_contract: Address of the escrow contract
            payee: Address of the payment recipient (server's on-chain identity)
            voucher_endpoint: Current server endpoint (for preference, not filtering)
        
        Returns:
            Best matching channel, or None. If the channel's stored endpoint differs
            from voucher_endpoint, it may need re-registration with the server.
        """
        escrow_lower = escrow_contract.lower()
        payee_lower = payee.lower()
        
        # Collect valid candidates, preferring endpoint matches
        candidates_matching_endpoint = []
        candidates_any = []
        
        def normalize_endpoint(url):
            """Normalize endpoint for comparison.
            
            Only normalizes scheme (https->http for localhost) and trailing slashes.
            Ports are preserved since different ports = different servers.
            """
            if not url:
                return ""
            url = url.rstrip("/")
            # Only normalize https->http for localhost (common dev config)
            if "localhost" in url or "127.0.0.1" in url:
                url = url.replace("https://", "http://")
            return url.lower()
        
        wanted_endpoint = normalize_endpoint(voucher_endpoint) if voucher_endpoint else ""
        
        for channel_id, channel in self._channels.items():
            # Match on ON-CHAIN IDENTITY: escrow + payee
            if channel.escrow_contract.lower() != escrow_lower:
                continue
            if channel.payee.lower() != payee_lower:
                continue
            
            # Skip finalized channels
            if channel.finalized:
                continue
            
            # Skip channels with pending close request (in grace period)
            if channel.close_requested_at > 0:
                continue
            
            # Skip expired channels (but keep in history)
            if channel.expiry <= int(time.time()):
                continue
            
            # Skip depleted channels
            remaining = channel.remaining_balance()
            if remaining <= 0:
                continue
            
            # Skip channels where authorized_signer doesn't match current access key
            # This prevents using channels opened by a different (possibly revoked) key
            try:
                current_signer = self.access_key_address.lower()
                channel_signer = channel.effective_signer.lower()
                if channel_signer != current_signer:
                    logger.debug(f"Skipping channel {channel_id[:18]}... - authorized_signer mismatch "
                               f"(channel: {channel_signer[:10]}..., current: {current_signer[:10]}...)")
                    continue
            except (AttributeError, ValueError):
                # Can't determine current signer - skip check (for tests with mocked managers)
                pass
            
            # Valid candidate - check if endpoint matches
            stored_endpoint = normalize_endpoint(channel.voucher_endpoint) if channel.voucher_endpoint else ""
            
            if wanted_endpoint and stored_endpoint == wanted_endpoint:
                candidates_matching_endpoint.append((channel, remaining))
            else:
                candidates_any.append((channel, remaining))
        
        # Prefer channels already registered with this endpoint
        if candidates_matching_endpoint:
            best = max(candidates_matching_endpoint, key=lambda x: x[1])
            logger.debug(f"Found channel {best[0].channel_id[:18]}... with matching endpoint")
            return best[0]
        
        # Fall back to any valid channel (may need re-registration)
        if candidates_any:
            best = max(candidates_any, key=lambda x: x[1])
            logger.info(f"Found channel {best[0].channel_id[:18]}... with different endpoint - may need re-registration")
            return best[0]
        
        return None
    
    def get_orphaned_channels(self) -> list[StreamChannel]:
        """Get channels that can't be used with the current access key.
        
        These are channels where authorized_signer doesn't match the current key.
        Typically happens when user switches to a new access key after the old one
        was revoked. These channels have locked funds until expiry or server finalization.
        
        Returns:
            List of orphaned channels with remaining balance.
        """
        orphaned = []
        current_signer = self.access_key_address.lower()
        now = int(time.time())
        
        for channel in self._channels.values():
            # Skip finalized or expired channels
            if channel.finalized:
                continue
            if channel.expiry <= now:
                continue
            # Skip depleted channels
            if channel.remaining_balance() <= 0:
                continue
            # Skip closing channels
            if channel.close_requested_at > 0:
                continue
            
            # Check if signer mismatch
            channel_signer = channel.effective_signer.lower()
            if channel_signer != current_signer:
                orphaned.append(channel)
        
        return orphaned
    
    def parse_stream_challenge(self, www_auth: str) -> Optional[dict]:
        """Parse WWW-Authenticate header for stream challenge.
        
        Returns dict with stream params if intent="stream", else None.
        """
        if "intent=\"stream\"" not in www_auth and "intent=stream" not in www_auth:
            return None
        
        # Parse parameters
        import re
        params = {}
        
        # Match both quoted and unquoted values
        for match in re.finditer(r'(\w+)="([^"]*)"', www_auth):
            params[match.group(1)] = match.group(2)
        for match in re.finditer(r'(\w+)=([^\s,]+)', www_auth):
            if match.group(1) not in params:
                params[match.group(1)] = match.group(2).strip('"')
        
        # Decode request if present
        if "request" in params:
            try:
                params["request"] = json.loads(base64url_decode(params["request"]))
            except:
                pass
        
        return params
    
    @property
    def access_key_address(self) -> str:
        """Derive the access key address from the private key."""
        return Account.from_key(self.private_key).address
    
    def open_channel(
        self,
        escrow_contract: str,
        payee: str,
        token: str,
        deposit: int,
        expiry: int,
        salt: str,
        voucher_endpoint: str = None,
        min_voucher_delta: int = 0,
        on_step=None,
        use_direct_signing: bool = False,
        authorized_signer: str = None,
    ) -> StreamChannel:
        """Open a new streaming payment channel on-chain.
        
        Per draft-stream-channel-authorized-signer.md, the channel opener can
        specify an authorized_signer (typically an access key) to sign vouchers.
        
        Args:
            escrow_contract: Address of the TempoStreamChannel contract
            payee: Server's address to receive payments
            token: Token address (TIP-20 stablecoin)
            deposit: Amount to deposit (in base units)
            expiry: Unix timestamp when channel expires
            salt: Random salt for channel ID uniqueness
            voucher_endpoint: Optional URL to submit vouchers
            min_voucher_delta: Minimum amount increase per voucher
            on_step: callback(step, status) for progress
            use_direct_signing: If True, sign directly (EOA mode)
            authorized_signer: Address that will sign vouchers (default: access key)
        
        Returns:
            StreamChannel object
        """
        # Default authorized_signer to the access key address (derived from private_key)
        if authorized_signer is None:
            authorized_signer = self.access_key_address
        
        # Check balance before attempting to open channel
        try:
            from .rpc import get_token_balance_raw
            balance = get_token_balance_raw(self.wallet_address, token, self.rpc_url)
            if balance < deposit:
                balance_usd = balance / 1_000_000
                deposit_usd = deposit / 1_000_000
                raise ValueError(
                    f"Insufficient balance: have ${balance_usd:.2f}, need ${deposit_usd:.2f} for channel deposit"
                )
        except ImportError:
            pass  # Skip balance check if rpc module not available
        except ValueError:
            raise  # Re-raise our balance error
        except Exception as e:
            logger.warning(f"Could not check balance before opening channel: {e}")
        
        if on_step:
            on_step('opening', 'pending', None)
        
        # Build calldata for both calls
        approve_calldata = self._build_approve_calldata(escrow_contract, deposit)
        open_calldata = self._build_open_calldata(payee, token, deposit, expiry, salt, authorized_signer)
        
        # Send approve first, then open (separate txs because batched validation fails)
        approve_hash = self._send_batched_tx(
            calls=[{"to": token, "value": 0, "data": approve_calldata}],
            fee_token=token,
            use_direct_signing=use_direct_signing,
            tx_kind="channel_approve",
            wait_for_confirm=True,
        )
        tx_hash = self._send_batched_tx(
            calls=[{"to": escrow_contract, "value": 0, "data": open_calldata}],
            fee_token=token,
            use_direct_signing=use_direct_signing,
            tx_kind="channel_open",
            wait_for_confirm=True,
        )
        
        # Wait for confirmation if not already done by TransactionSender
        if not get_transaction_sender():
            wait_for_receipt(tx_hash, self.rpc_url)
        
        if on_step:
            on_step('opening', 'done', tx_hash)
        
        # Compute channel ID (includes authorized_signer per draft spec)
        channel_id = self._compute_channel_id(
            self.wallet_address, payee, token, deposit, expiry, salt, authorized_signer, escrow_contract
        )
        
        channel = StreamChannel(
            channel_id=channel_id,
            escrow_contract=escrow_contract,
            payer=self.wallet_address,
            payee=payee,
            token=token,
            deposit=deposit,
            expiry=expiry,
            salt=salt,
            chain_id=self.chain_id,
            authorized_signer=authorized_signer,
            voucher_endpoint=voucher_endpoint,
            min_voucher_delta=min_voucher_delta,
            open_tx_hash=tx_hash,
            opened_at=int(time.time()),
        )
        
        # Cache the channel by its ID (allows multiple channels per payee)
        self._channels[channel_id] = channel
        
        # Persist to disk
        self._save_channels()
        
        logger.info(f"Channel opened: {channel_id}, tx: {tx_hash}")
        return channel
    
    def request_close(
        self,
        channel: StreamChannel,
        on_step=None,
        use_direct_signing: bool = False,
        nonce: int = None,
        skip_wait: bool = False,
    ) -> str:
        """Request early channel closure.
        
        Starts a 15-minute grace period for the server to settle outstanding vouchers.
        After the grace period, withdraw() can be called to get refund.
        
        Returns:
            Transaction hash
        """
        if channel.finalized:
            raise ValueError("Channel is already finalized")
        if channel.close_requested_at > 0:
            raise ValueError("Close already requested")
        
        logger.info(f"Requesting close for channel {channel.channel_id[:18]}...")
        
        if on_step:
            on_step('requesting_close', 'pending', None)
        
        # requestClose(bytes32 channelId) - selector: keccak256("requestClose(bytes32)")[:4]
        selector = "0xf5fe6fb2"
        channel_id_padded = channel.channel_id[2:].lower().zfill(64) if channel.channel_id.startswith("0x") else channel.channel_id.zfill(64)
        calldata = f"{selector}{channel_id_padded}"
        
        tx_hash = self._send_batched_tx(
            calls=[{"to": channel.escrow_contract, "value": 0, "data": calldata}],
            fee_token=channel.token,
            use_direct_signing=use_direct_signing,
            tx_kind="channel_request_close",
            wait_for_confirm=not skip_wait,
            channel_id=channel.channel_id,
            nonce=nonce,
        )
        
        if not skip_wait and not get_transaction_sender():
            wait_for_receipt(tx_hash, self.rpc_url)
        
        channel.close_requested_at = int(time.time())
        self._save_channels()
        
        if on_step:
            on_step('requesting_close', 'done', tx_hash)
        
        logger.info(f"Close requested for channel {channel.channel_id[:18]}..., grace period ends in 15 min")
        return tx_hash
    
    def withdraw(
        self,
        channel: StreamChannel,
        on_step=None,
        use_direct_signing: bool = False,
        nonce: int = None,
        skip_wait: bool = False,
    ) -> tuple[str, int]:
        """Withdraw remaining funds after expiry or close grace period.
        
        Returns:
            (tx_hash, refund_amount) - Transaction hash and amount refunded
        """
        if channel.finalized:
            raise ValueError("Channel is already finalized")
        
        now = int(time.time())
        expired_normally = now >= channel.expiry
        grace_period = 15 * 60  # 15 minutes
        close_grace_passed = channel.close_requested_at > 0 and now >= channel.close_requested_at + grace_period
        
        if not expired_normally and not close_grace_passed:
            if channel.close_requested_at > 0:
                remaining = (channel.close_requested_at + grace_period) - now
                raise ValueError(f"Grace period not passed, {remaining}s remaining")
            else:
                raise ValueError("Channel not expired and close not requested")
        
        refund = channel.deposit - channel.cumulative_amount
        logger.info(f"Withdrawing from channel {channel.channel_id[:18]}..., refund=${refund/1_000_000:.2f}")
        
        if on_step:
            on_step('withdrawing', 'pending', None)
        
        # withdraw(bytes32 channelId) - selector: keccak256("withdraw(bytes32)")[:4]
        selector = "0x19899e46"
        channel_id_padded = channel.channel_id[2:].lower().zfill(64) if channel.channel_id.startswith("0x") else channel.channel_id.zfill(64)
        calldata = f"{selector}{channel_id_padded}"
        
        tx_hash = self._send_batched_tx(
            calls=[{"to": channel.escrow_contract, "value": 0, "data": calldata}],
            fee_token=channel.token,
            use_direct_signing=use_direct_signing,
            tx_kind="channel_withdraw",
            wait_for_confirm=not skip_wait,
            channel_id=channel.channel_id,
            nonce=nonce,
        )
        
        if not skip_wait and not get_transaction_sender():
            wait_for_receipt(tx_hash, self.rpc_url)
        
        channel.finalized = True
        self._save_channels()
        
        if on_step:
            on_step('withdrawing', 'done', tx_hash)
        
        logger.info(f"Withdrawn ${refund/1_000_000:.2f} from channel {channel.channel_id[:18]}..., tx: {tx_hash}")
        return tx_hash, refund
    
    def close_channel(
        self,
        channel: StreamChannel,
        on_step=None,
        use_direct_signing: bool = False,
        force_wait: bool = False,
    ) -> tuple[str, int]:
        """Close a channel and withdraw remaining funds.
        
        If channel is expired, withdraws immediately.
        If not expired and close not requested, requests close and waits for grace period.
        If close already requested and grace period passed, withdraws.
        
        Args:
            channel: The channel to close
            on_step: Progress callback
            use_direct_signing: EOA mode
            force_wait: If True, wait for grace period before withdrawing
        
        Returns:
            (tx_hash, refund_amount)
        """
        now = int(time.time())
        grace_period = 15 * 60
        
        # Check if we can withdraw immediately
        can_withdraw = (
            now >= channel.expiry or
            (channel.close_requested_at > 0 and now >= channel.close_requested_at + grace_period)
        )
        
        if can_withdraw and not channel.finalized:
            return self.withdraw(channel, on_step, use_direct_signing)
        
        # Need to request close first
        if channel.close_requested_at == 0:
            self.request_close(channel, on_step, use_direct_signing)
        
        # If force_wait, wait for grace period
        if force_wait:
            wait_until = channel.close_requested_at + grace_period
            wait_time = wait_until - int(time.time())
            if wait_time > 0:
                logger.info(f"Waiting {wait_time}s for grace period...")
                time.sleep(wait_time + 5)  # Add 5s buffer
            return self.withdraw(channel, on_step, use_direct_signing)
        
        # Return info about when withdraw will be available
        wait_until = channel.close_requested_at + grace_period
        remaining = wait_until - int(time.time())
        raise ValueError(f"Close requested. Withdraw available in {remaining}s. Run again after grace period.")
    
    def sign_voucher(
        self,
        channel: StreamChannel,
        amount: int,
        valid_until: int = None,
    ) -> dict:
        """Sign a voucher authorizing cumulative payment.
        
        Args:
            channel: The StreamChannel to authorize payment from
            amount: Amount for this specific payment (added to cumulative)
            valid_until: Unix timestamp for voucher expiry (default: channel expiry)
        
        Returns:
            Signed voucher dict ready for Authorization header
        """
        if valid_until is None:
            valid_until = channel.expiry
        
        new_cumulative = channel.cumulative_amount + amount
        
        if new_cumulative > channel.deposit:
            raise ValueError(f"Voucher amount {new_cumulative} exceeds deposit {channel.deposit}")
        
        # Build EIP-712 typed data per spec §7
        # Note: cumulativeAmount is uint128, validUntil is uint64 (not uint256)
        # channelId must be bytes(32), not hex string
        channel_id_hex = channel.channel_id
        if not channel_id_hex.startswith("0x"):
            channel_id_hex = "0x" + channel_id_hex
        channel_id_bytes = to_bytes(hexstr=channel_id_hex)
        
        typed_data = {
            "types": {
                "EIP712Domain": [
                    {"name": "name", "type": "string"},
                    {"name": "version", "type": "string"},
                    {"name": "chainId", "type": "uint256"},
                    {"name": "verifyingContract", "type": "address"},
                ],
                "Voucher": VOUCHER_TYPE,
            },
            "primaryType": "Voucher",
            "domain": {
                "name": VOUCHER_DOMAIN_NAME,
                "version": VOUCHER_DOMAIN_VERSION,
                "chainId": channel.chain_id,
                "verifyingContract": channel.escrow_contract,
            },
            "message": {
                "channelId": channel_id_bytes,  # bytes32, not hex string
                "cumulativeAmount": new_cumulative,  # int, not string (per spec)
                "validUntil": valid_until,  # int, not string (per spec)
            },
        }
        
        # Sign using eth_account
        signature = self._sign_typed_data(typed_data)
        
        # Update channel state
        channel.cumulative_amount = new_cumulative
        channel.voucher_count += 1
        
        # Build serializable payload for JSON (per spec: stringify numeric fields)
        # Note: channelId must be hex string, cumulativeAmount/validUntil must be stringified
        serializable_typed_data = {
            "types": typed_data["types"],
            "primaryType": typed_data["primaryType"],
            "domain": typed_data["domain"],
            "message": {
                "channelId": channel_id_hex,  # hex string for JSON
                "cumulativeAmount": str(new_cumulative),  # stringified per spec
                "validUntil": str(valid_until),  # stringified per spec
            },
        }
        
        # Return voucher in format expected by server:
        # voucher.payload.message contains the signed data (with stringified values)
        # voucher.signature is the EIP-712 signature (with 0x prefix)
        voucher = {
            "payload": serializable_typed_data,
            "signature": signature if signature.startswith("0x") else f"0x{signature}",
        }
        
        logger.info(
            f"Voucher #{channel.voucher_count} signed: "
            f"cumulative={new_cumulative}, remaining={channel.remaining_balance()}"
        )
        
        # Persist updated state
        self._save_channels()
        
        return voucher
    
    def build_stream_credential(
        self,
        channel: StreamChannel,
        voucher: dict,
        challenge_id: str,
        action: str = "voucher",
        open_tx_hash: str = None,
    ) -> str:
        """Build Authorization header value for stream payment.
        
        Per draft-tempo-stream-extension.md §6, the credential envelope contains:
        - id: challenge ID from server's WWW-Authenticate
        - source: payer DID (did:pkh:eip155:chainId:address)
        - payload: stream-specific credential
        
        Args:
            channel: The stream channel
            voucher: Signed voucher from sign_voucher()
            challenge_id: Challenge ID from server's WWW-Authenticate header
            action: "open" for first use, "voucher" for subsequent
            open_tx_hash: Required for action="open" - the tx hash that opened the channel
        
        Returns:
            Authorization header value: "Payment <base64url-encoded credential>"
        """
        # Build stream-specific payload (per draft-stream-channel-authorized-signer.md)
        payload = {
            "type": "stream",
            "action": action,
            "channelId": channel.channel_id,
            "authorizedSigner": channel.authorized_signer,  # NEW: include signer in payload
            "voucher": voucher,
        }
        
        if action == "open":
            if not open_tx_hash:
                raise ValueError("openTxHash is REQUIRED for action='open' per spec §6.1")
            payload["openTxHash"] = open_tx_hash
        
        # Build full credential envelope (spec examples)
        credential = {
            "id": challenge_id,
            "source": f"did:pkh:eip155:{channel.chain_id}:{channel.payer}",
            "payload": payload,
        }
        
        return f"Payment {base64url_encode(json.dumps(credential))}"
    
    def _build_approve_calldata(self, spender: str, amount: int) -> str:
        """Build ERC20 approve calldata."""
        # approve(address,uint256) selector: 0x095ea7b3
        spender_padded = spender[2:].lower().zfill(64)
        amount_hex = hex(amount)[2:].zfill(64)
        return f"0x095ea7b3{spender_padded}{amount_hex}"
    
    def _build_open_calldata(
        self, payee: str, token: str, deposit: int, expiry: int, salt: str,
        authorized_signer: str
    ) -> str:
        """Build TempoStreamChannel.open() calldata.
        
        Per draft-stream-channel-authorized-signer.md:
        Function: open(address payee, address token, uint128 deposit, uint64 expiry, bytes32 salt, address authorizedSigner)
        Selector: keccak256("open(address,address,uint128,uint64,bytes32,address)")[:4]
        
        Note: deposit is uint128 (16 bytes) and expiry is uint64 (8 bytes), but in ABI encoding
        they are still padded to 32 bytes each.
        """
        # Updated selector for new function signature with authorizedSigner
        # keccak256("open(address,address,uint128,uint64,bytes32,address)")[:4] = 0xdae6bb52
        selector = "0xdae6bb52"
        
        payee_padded = payee[2:].lower().zfill(64)
        token_padded = token[2:].lower().zfill(64)
        deposit_hex = hex(deposit)[2:].zfill(64)  # uint128 still padded to 32 bytes
        expiry_hex = hex(expiry)[2:].zfill(64)    # uint64 still padded to 32 bytes
        salt_padded = salt[2:].lower().zfill(64) if salt.startswith("0x") else salt.zfill(64)
        signer_padded = authorized_signer[2:].lower().zfill(64)
        
        return f"{selector}{payee_padded}{token_padded}{deposit_hex}{expiry_hex}{salt_padded}{signer_padded}"
    
    def _compute_channel_id(
        self, payer: str, payee: str, token: str, deposit: int, expiry: int, salt: str,
        authorized_signer: str, escrow_contract: str
    ) -> str:
        """Compute channel ID as keccak256(abi.encode(...)).
        
        Per draft-stream-channel-authorized-signer.md:
        channelId = keccak256(abi.encode(
            payer, payee, token, deposit, expiry, salt, authorizedSigner, contractAddress, chainId
        ))
        """
        # Format all parameters as 32-byte abi.encode values
        payer_enc = payer[2:].lower().zfill(64)
        payee_enc = payee[2:].lower().zfill(64)
        token_enc = token[2:].lower().zfill(64)
        deposit_enc = hex(deposit)[2:].zfill(64)
        expiry_enc = hex(expiry)[2:].zfill(64)
        salt_enc = salt[2:].lower().zfill(64) if salt.startswith('0x') else salt.zfill(64)
        signer_enc = authorized_signer[2:].lower().zfill(64)  # NEW: included in hash
        contract_enc = escrow_contract[2:].lower().zfill(64)
        chain_enc = hex(self.chain_id)[2:].zfill(64)
        
        encoded = f"0x{payer_enc}{payee_enc}{token_enc}{deposit_enc}{expiry_enc}{salt_enc}{signer_enc}{contract_enc}{chain_enc}"
        
        return keccak256(encoded)
    
    def _sign_typed_data(self, typed_data: dict) -> str:
        """Sign EIP-712 typed data using eth_account.
        
        Returns signature as hex string.
        """
        # Extract domain and message for eth_account's encode_typed_data
        full_message = {
            "domain": typed_data["domain"],
            "types": typed_data["types"],
            "primaryType": typed_data["primaryType"],
            "message": typed_data["message"],
        }
        
        account = Account.from_key(self.private_key)
        
        # Use the newer encode_typed_data API
        signable = encode_typed_data(full_message=full_message)
        signed = account.sign_message(signable)
        
        return signed.signature.hex()
    
    def _send_batched_tx(
        self,
        calls: list[dict],
        fee_token: str = None,
        use_direct_signing: bool = False,
        tx_kind: str = "batched_tx",
        wait_for_confirm: bool = False,
        channel_id: str = "",
        nonce: int = None,
    ) -> str:
        """Sign and send a batched transaction using pytempo.
        
        Args:
            calls: List of {"to": address, "value": int, "data": hex_calldata}
            fee_token: Token address to pay fees with (must be 0x address)
            use_direct_signing: If True, sign directly with private key (EOA mode)
            tx_kind: Type of transaction for event metadata
            wait_for_confirm: If True and TransactionSender available, wait for receipt
            channel_id: Optional channel ID for metadata
            nonce: Optional nonce override (for sending multiple txs without waiting)
        
        Returns:
            Transaction hash
        """
        # fee_token must be provided (no hardcoded fallback)
        if not (isinstance(fee_token, str) and fee_token.startswith("0x") and len(fee_token) == 42):
            raise ValueError(f"Invalid or missing fee_token address: {fee_token}. Select a fee token with /wallet limits.")
        
        # Get gas estimate and nonce via web3
        total_gas = self._estimate_gas_for_calls(calls)
        min_gas = 300000 if len(calls) > 1 else 100000
        gas_limit = max(int(total_gas * 2.0), min_gas)
        
        if nonce is None:
            nonce = get_2d_nonce(self.wallet_address, self._nonce_key, self.rpc_url)
        max_fee, priority_fee = get_gas_price(self.rpc_url)
        
        # Create batched Tempo transaction with 2D nonce
        tx = create_tempo_transaction(
            to="",
            calls=calls,
            gas=gas_limit,
            max_fee_per_gas=max_fee,
            max_priority_fee_per_gas=priority_fee,
            nonce=nonce,
            nonce_key=self._nonce_key,
            chain_id=self.chain_id,
            fee_token=fee_token,
        )
        
        # Sign the transaction
        if use_direct_signing:
            tx.sign(self.private_key)
        else:
            sign_tx_access_key(tx, self.private_key, self.wallet_address)
        
        # Encode and broadcast
        raw_tx = "0x" + tx.encode().hex()
        
        # Use TransactionSender if available for event emission
        tx_sender = get_transaction_sender()
        if tx_sender:
            meta = TxMeta(
                kind=tx_kind,
                chain_id=self.chain_id,
                channel_id=channel_id,
            )
            if wait_for_confirm:
                tx_hash = tx_sender.send_and_confirm(raw_tx, meta=meta)
            else:
                tx_hash = tx_sender.send_only(raw_tx, meta=meta)
        else:
            tx_hash = broadcast_tx(raw_tx, self.rpc_url)
        
        return tx_hash
    
    def _estimate_gas_for_calls(self, calls: list[dict]) -> int:
        """Estimate gas for a list of calls.
        
        Note: For batched approve+open, the open call estimate will fail with
        InsufficientAllowance since the approve hasn't happened yet. We use
        fallback gas values in this case.
        """
        total_gas = 0
        for i, call in enumerate(calls):
            try:
                gas = estimate_gas(
                    self.wallet_address,
                    call["to"],
                    call.get("data", "0x"),
                    self.rpc_url,
                    call.get("value", 0),
                )
                total_gas += gas
            except Exception as e:
                # Fallback gas estimates based on call type
                # approve() is ~50k, open() is ~200k
                fallback = 200000 if i > 0 else 100000
                logger.debug(f"Gas estimate failed for call {i}, using fallback {fallback}: {e}")
                total_gas += fallback
        return total_gas


# Global manager instance (initialized when wallet is set up)
_manager: Optional[StreamChannelManager] = None


def get_stream_manager() -> Optional[StreamChannelManager]:
    """Get the global stream channel manager."""
    return _manager


def reset_stream_manager() -> None:
    """Reset the global stream channel manager.
    
    Call this when RPC URL or chain changes to ensure new payments use the new endpoint.
    """
    global _manager
    _manager = None
    logger.info("Stream manager reset")


def init_stream_manager(private_key: str, wallet_address: str, chain_id: int = None, rpc_url: str = None, force: bool = False):
    """Initialize the global stream channel manager.
    
    Args:
        private_key: Private key for signing vouchers
        wallet_address: Wallet address
        chain_id: Chain ID (defaults to DEFAULT_NETWORK chain)
        rpc_url: RPC URL (defaults to DEFAULT_NETWORK RPC)
        force: If True, reinitialize even if already initialized
    """
    global _manager
    if _manager is not None and not force:
        logger.debug("Stream manager already initialized, skipping (use force=True to reinit)")
        return _manager
    _manager = StreamChannelManager(private_key, wallet_address, chain_id, rpc_url)
    logger.info(f"Stream manager initialized with {len(_manager._channels)} channels loaded")
    return _manager


def update_stream_manager_rpc(rpc_url: str, chain_id: int) -> None:
    """Update the stream manager's RPC URL and chain ID.
    
    This reinitializes the manager with new settings while preserving the wallet.
    """
    global _manager
    if _manager is None:
        logger.debug("No stream manager to update")
        return
    
    old_rpc = _manager.rpc_url
    old_chain = _manager.chain_id
    
    # Reinitialize with new settings
    _manager = StreamChannelManager(
        private_key=_manager.private_key,
        wallet_address=_manager.wallet_address,
        chain_id=chain_id,
        rpc_url=rpc_url,
    )
    logger.info(f"Stream manager RPC updated: {old_rpc[:30]}... -> {rpc_url[:30]}..., chain {old_chain} -> {chain_id}")
