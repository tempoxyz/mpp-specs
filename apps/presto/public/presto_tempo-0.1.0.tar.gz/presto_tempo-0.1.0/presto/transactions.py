"""Centralized transaction sending with event callbacks.

This module provides a TransactionSender that ensures all on-chain transactions
go through a single point, enabling automatic balance refresh and other post-tx
actions via event listeners.
"""
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from . import logger
from .rpc import broadcast_tx, wait_for_receipt


@dataclass
class TxMeta:
    """Metadata about a transaction for event handlers."""
    kind: str
    chain_id: int
    network: str = ""
    amount_usd: float = 0.0
    channel_id: str = ""
    note: str = ""


TxListener = Callable[[str, dict], None]

_global_sender: Optional["TransactionSender"] = None


class TransactionSender:
    """Centralized transaction broadcaster with event emission.
    
    All on-chain transactions should go through this class to ensure
    consistent handling and automatic post-tx actions like balance refresh.
    
    Events emitted:
    - "submitted": When tx is broadcast to network (has tx_hash)
    - "confirmed": When tx receipt is received (tx succeeded)
    - "failed": When tx fails (broadcast or confirmation error)
    """
    
    def __init__(self, rpc_url: str):
        self.rpc_url = rpc_url
        self._listeners: list[TxListener] = []
    
    def add_listener(self, listener: TxListener) -> None:
        """Register a callback for transaction events.
        
        Callback signature: (event_type: str, payload: dict) -> None
        event_type is one of: "submitted", "confirmed", "failed"
        """
        if listener not in self._listeners:
            self._listeners.append(listener)
    
    def remove_listener(self, listener: TxListener) -> None:
        """Unregister a callback."""
        if listener in self._listeners:
            self._listeners.remove(listener)
    
    def _emit(self, event_type: str, payload: dict) -> None:
        """Emit an event to all registered listeners."""
        for listener in list(self._listeners):
            try:
                listener(event_type, payload)
            except Exception as e:
                logger.error(f"TransactionSender listener error: {e}")
    
    def send_and_confirm(
        self,
        raw_tx: str,
        *,
        meta: TxMeta,
        timeout_s: int = 180,
    ) -> str:
        """Broadcast a signed transaction and wait for confirmation.
        
        Emits events throughout the lifecycle:
        - "submitted" when tx is broadcast
        - "confirmed" when receipt is received
        - "failed" if any step fails
        
        Args:
            raw_tx: Hex-encoded signed transaction (0x-prefixed)
            meta: Transaction metadata for event handlers
            timeout_s: How long to wait for confirmation
        
        Returns:
            Transaction hash
        
        Raises:
            Exception: If broadcast or confirmation fails
        """
        tx_hash = None
        try:
            tx_hash = broadcast_tx(raw_tx, self.rpc_url)
            logger.info(f"TransactionSender: broadcast tx_hash={tx_hash}, kind={meta.kind}")
            
            self._emit("submitted", {
                "tx_hash": tx_hash,
                "meta": meta,
                "timestamp": int(time.time()),
            })
            
            receipt = wait_for_receipt(tx_hash, self.rpc_url, timeout=timeout_s)
            logger.info(f"TransactionSender: confirmed tx_hash={tx_hash}")
            
            self._emit("confirmed", {
                "tx_hash": tx_hash,
                "receipt": receipt,
                "meta": meta,
                "timestamp": int(time.time()),
            })
            
            return tx_hash
            
        except Exception as e:
            logger.error(f"TransactionSender: failed tx_hash={tx_hash}, error={e}")
            self._emit("failed", {
                "tx_hash": tx_hash,
                "error": str(e),
                "meta": meta,
                "timestamp": int(time.time()),
            })
            raise
    
    def send_only(
        self,
        raw_tx: str,
        *,
        meta: TxMeta,
    ) -> str:
        """Broadcast a transaction without waiting for confirmation.
        
        Use for fire-and-forget scenarios. Still emits "submitted" event.
        
        Args:
            raw_tx: Hex-encoded signed transaction
            meta: Transaction metadata
        
        Returns:
            Transaction hash
        """
        try:
            tx_hash = broadcast_tx(raw_tx, self.rpc_url)
            logger.info(f"TransactionSender: broadcast (no wait) tx_hash={tx_hash}, kind={meta.kind}")
            
            self._emit("submitted", {
                "tx_hash": tx_hash,
                "meta": meta,
                "timestamp": int(time.time()),
            })
            
            return tx_hash
            
        except Exception as e:
            logger.error(f"TransactionSender: broadcast failed, error={e}")
            self._emit("failed", {
                "tx_hash": None,
                "error": str(e),
                "meta": meta,
                "timestamp": int(time.time()),
            })
            raise


def get_transaction_sender() -> Optional[TransactionSender]:
    """Get the global TransactionSender instance."""
    return _global_sender


def set_transaction_sender(sender: TransactionSender) -> None:
    """Set the global TransactionSender instance."""
    global _global_sender
    _global_sender = sender


def init_transaction_sender(rpc_url: str) -> TransactionSender:
    """Initialize and set the global TransactionSender.
    
    This should be called once during app startup.
    """
    sender = TransactionSender(rpc_url)
    set_transaction_sender(sender)
    return sender
