"""Runtime-configurable settings for proxy URL and RPC URL.

These settings can be changed mid-execution via command palette.
They override the defaults from config.py and environment variables.
"""
from dataclasses import dataclass, field
from typing import Optional, Callable, List

from . import config


@dataclass
class RuntimeSettings:
    """Runtime-configurable settings that can be changed during execution."""
    proxy_url: str
    network: str
    rpc_url_override: Optional[str] = None
    
    def get_proxy_url(self) -> str:
        """Get the current proxy URL."""
        return self.proxy_url
    
    def get_network(self) -> str:
        """Get the current network name."""
        return self.network
    
    def get_chain_id(self) -> int:
        """Get the chain ID for the current network."""
        return config.NETWORKS[self.network]["chain_id"]
    
    def get_rpc_url(self) -> str:
        """Get the current RPC URL (override or network default)."""
        if self.rpc_url_override:
            return self.rpc_url_override
        return config.NETWORKS[self.network]["rpc"]
    
    def get_network_info(self) -> dict:
        """Get the full network configuration dict."""
        return config.NETWORKS.get(self.network, config.NETWORKS[config.DEFAULT_NETWORK])


# Global singleton
_settings: Optional[RuntimeSettings] = None

# Callbacks for when settings change (UI can register to update displays)
_on_proxy_change: List[Callable[[str], None]] = []
_on_rpc_change: List[Callable[[str, int], None]] = []


def get_settings() -> RuntimeSettings:
    """Get the global runtime settings instance."""
    global _settings
    if _settings is None:
        _settings = RuntimeSettings(
            proxy_url=config.get_proxy_url(),
            network=config.DEFAULT_NETWORK,
            rpc_url_override=None,
        )
    return _settings


def update_proxy_url(url: str) -> None:
    """Update the proxy URL at runtime."""
    settings = get_settings()
    old_url = settings.proxy_url
    settings.proxy_url = url
    
    # Notify listeners
    for callback in _on_proxy_change:
        try:
            callback(url)
        except Exception:
            pass


def update_network(network: str, reinit_stream_manager: bool = True) -> None:
    """Update the network at runtime.
    
    Args:
        network: Network name (e.g., "moderato", "mainnet")
        reinit_stream_manager: If True, reinitialize the stream manager for the new chain
    """
    if network not in config.NETWORKS:
        raise ValueError(f"Unknown network: {network}")
    
    settings = get_settings()
    old_network = settings.network
    settings.network = network
    settings.rpc_url_override = None  # Clear override when switching networks
    
    new_rpc = settings.get_rpc_url()
    new_chain_id = settings.get_chain_id()
    
    # Notify listeners
    for callback in _on_rpc_change:
        try:
            callback(new_rpc, new_chain_id)
        except Exception:
            pass


def update_rpc_url_override(url: Optional[str]) -> None:
    """Set a custom RPC URL override.
    
    Args:
        url: Custom RPC URL, or None to use network default
    """
    settings = get_settings()
    settings.rpc_url_override = url
    
    new_rpc = settings.get_rpc_url()
    new_chain_id = settings.get_chain_id()
    
    # Notify listeners
    for callback in _on_rpc_change:
        try:
            callback(new_rpc, new_chain_id)
        except Exception:
            pass


def clear_rpc_url_override() -> None:
    """Clear the custom RPC URL override, returning to network default."""
    update_rpc_url_override(None)


def register_proxy_change_callback(callback: Callable[[str], None]) -> None:
    """Register a callback to be called when proxy URL changes."""
    _on_proxy_change.append(callback)


def register_rpc_change_callback(callback: Callable[[str, int], None]) -> None:
    """Register a callback to be called when RPC URL changes.
    
    Callback receives (rpc_url, chain_id).
    """
    _on_rpc_change.append(callback)


def reset_settings() -> None:
    """Reset settings to defaults (for testing)."""
    global _settings
    _settings = None
