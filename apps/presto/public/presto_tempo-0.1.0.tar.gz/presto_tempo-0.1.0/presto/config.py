"""Configuration constants and logo definitions."""
import os
from pathlib import Path
from datetime import datetime

# Load .env file if present (check cwd first, then package dir)
for env_path in [Path.cwd() / ".env", Path(__file__).parent.parent / ".env"]:
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                key, _, value = line.partition("=")
                os.environ.setdefault(key.strip(), value.strip())
        break

# Configuration
# Default to OpenRouter payments proxy
PROXY_URL = os.environ.get("PRESTO_PROXY_URL", "https://openrouter.payments.tempo.xyz")
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = os.environ.get("MODEL", "anthropic/claude-sonnet-4")
PROVIDER = os.environ.get("PRESTO_PROVIDER", "openrouter")

def get_provider() -> str:
    """Get provider for localhost Host header (checked at runtime so --provider flag works)."""
    return os.environ.get("PRESTO_PROVIDER", "openrouter")

def get_proxy_url() -> str:
    """Get proxy URL (checked at runtime so --proxy-server flag works)."""
    return os.environ.get("PRESTO_PROXY_URL", "https://openrouter.payments.tempo.xyz")

# Auth URL for browser wallet setup
# Production: https://presto.tempo.xyz/
# Local dev: set PRESTO_AUTH_URL=http://localhost:8000 or run with --dev
def get_auth_url() -> str:
    """Get auth URL (checked at runtime so --dev flag works)."""
    return os.environ.get("PRESTO_AUTH_URL", "https://presto.tempo.xyz/")

# Available models for selection
AVAILABLE_MODELS = [
    ("anthropic/claude-sonnet-4", "Claude Sonnet 4"),
    ("anthropic/claude-opus-4", "Claude Opus 4"),
    ("anthropic/claude-opus-4.5", "Claude Opus 4.5"),
    ("openai/gpt-4.1", "GPT-4.1"),
    ("openai/gpt-4.1-mini", "GPT-4.1 Mini"),
    ("openai/gpt-4o-mini", "GPT-4o Mini"),
    ("google/gemini-2.5-pro", "Gemini 2.5 Pro"),
    ("google/gemini-2.5-flash", "Gemini 2.5 Flash"),
    ("deepseek/deepseek-r1", "DeepSeek R1"),
]

# Config file locations (in order of precedence)
# 0. PRESTO_CONFIG_FILE env var (for testing isolation)
# 1. ~/.config/presto/config.json (user-level, production install)
# 2. ~/.presto.json (legacy/fallback)
# 3. .presto.json in cwd (dev mode)
def _find_config_file() -> str:
    """Find the config file to use, in order of precedence."""
    # Allow override via environment variable (for testing isolation)
    env_config = os.environ.get("PRESTO_CONFIG_FILE")
    if env_config:
        return env_config
    
    candidates = [
        Path.home() / ".config" / "presto" / "config.json",
        Path.home() / ".presto.json",
        Path.cwd() / ".presto.json",
    ]
    for path in candidates:
        if path.exists():
            return str(path)
    # Default to user-level config for new installs
    return str(candidates[0])

CONFIG_FILE = _find_config_file()

# Logging is configured in presto/logger.py
# Import the unified logger for backwards compatibility
from .logger import LOG_FILE, get_logger, configure_logging

LOG_LEVEL = os.environ.get("PRESTO_LOG_LEVEL", "INFO")

# Initialize logging and get the logger instance
configure_logging(level=LOG_LEVEL)
log = get_logger("config")


def load_config(config_file: str = None) -> dict:
    """Load configuration from JSON file."""
    import json
    config_file = config_file or CONFIG_FILE
    if os.path.exists(config_file):
        with open(config_file) as f:
            return json.load(f)
    return {}


def save_config(config: dict, config_file: str = None):
    """Save configuration to JSON file with secure permissions."""
    import json
    config_file = config_file or CONFIG_FILE
    # Create parent directory if needed
    Path(config_file).parent.mkdir(parents=True, exist_ok=True)
    with open(config_file, "w") as f:
        json.dump(config, f, indent=2)
    os.chmod(config_file, 0o600)

def _build_rpc_url(base_url: str, network: str) -> str:
    """Build RPC URL with optional auth from environment."""
    # Try network-specific credentials first, then fall back to generic
    username = os.environ.get(f"TEMPO_{network.upper()}_RPC_USERNAME", "")
    password = os.environ.get(f"TEMPO_{network.upper()}_RPC_PASSWORD", "")
    if not username:
        username = os.environ.get("TEMPO_RPC_USERNAME", "")
        password = os.environ.get("TEMPO_RPC_PASSWORD", "")
    if username and password:
        return base_url.replace("https://", f"https://{username}:{password}@")
    return base_url

NETWORKS = {
    "mainnet": {
        "rpc": _build_rpc_url("https://rpc.mainnet.tempo.xyz", "mainnet"),
        "name": "Tempo Mainnet",
        "chain_id": 4217,
        "explorer": "https://explore.tempo.xyz",
        "faucet": "",  # No faucet on mainnet
        # fee_token is selected by user in wallet config
    },
    "moderato": {
        "rpc": "https://gracious-blackwell:magical-noyce@rpc.moderato.tempo.xyz",
        "name": "Tempo Moderato (testnet)",
        "chain_id": 42431,
        "explorer": "https://explore.moderato.tempo.xyz",
        "faucet": "",  # Faucet via RPC tempo_fundAddress
        # fee_token is selected by user in wallet config
    },
}

DEFAULT_NETWORK = "moderato"  # Use moderato testnet by default

# Mainnet is currently blocked due to high access key storage costs
MAINNET_BLOCKED = True

# ANSI colors for non-curses output
RESET, BOLD, DIM = "\033[0m", "\033[1m", "\033[2m"
GREEN, RED, CYAN = "\033[32m", "\033[31m", "\033[36m"

PRESTO_LOGO_LARGE = [
    "              · · · · ·                ",
    "          · · · · · · · · ·            ",
    "      · · · · · · · · · · · · ·        ",
    "    · · · - - - - - - - · · · · · ·    ",
    "  · · · - - = = = = = = - - - · · · · · · · ·",
    "  · · - - = = = = = = = = - - · · · · · · · · ·",
    "  · - - = = = = + = = = = = - - · · · · · · · · ·",
    "· · - - = = = = + + + = = = = = - - · · · · · · · · ·",
    "· · · - - = = = = = = = = = = - - - · · · · · · · · · · ·",
    "  · · · - - = = = = = = = = - - - - · · · · · · · · · · ·",
    "    · · · - - = = = = = - - - · · · · · · · · · · · · ·",
    "      · · · · · - - - · · · · · · · · · · · · · ·",
    "          · · · · · - - · · · · · · · · · ·",
    "              · · · · · · · · · · · ·",
    "                  · · · · · · · ·",
    "                      · · · ·",
]

PRESTO_LOGO_SMALL = [
    "      · · · ·      ",
    "    · · · · · ·    ",
    "  · · - = = - · ·  ",
    "  · - = + + = - · ·",
    "  · · - = = - · · ·",
    "    · · · · · · ·  ",
    "      · · · ·      ",
]

PRESTO_LOGO_TINY = [
    "  · · ·  ",
    " · = + · ",
    "  · · ·  ",
]


def get_logo(height, width):
    """Return appropriate logo based on terminal size."""
    if height >= 30 and width >= 80:
        return PRESTO_LOGO_LARGE
    elif height >= 15 and width >= 40:
        return PRESTO_LOGO_SMALL
    else:
        return PRESTO_LOGO_TINY
