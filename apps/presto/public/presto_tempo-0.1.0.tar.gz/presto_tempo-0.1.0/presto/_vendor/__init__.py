"""Vendored dependencies."""
