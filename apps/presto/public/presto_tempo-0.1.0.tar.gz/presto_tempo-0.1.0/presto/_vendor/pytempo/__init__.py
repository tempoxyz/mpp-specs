"""
PyTempo - Web3.py extension for Tempo blockchain

Extends web3.py with native support for Tempo transactions (Type 0x76)
and other Tempo-specific features.
"""

from .keychain import (
    ACCOUNT_KEYCHAIN_ADDRESS,
    GET_KEY_SELECTOR,
    GET_REMAINING_LIMIT_SELECTOR,
    INNER_SIGNATURE_LENGTH,
    KEY_AUTHORIZED_TOPIC,
    KEY_REVOKED_TOPIC,
    KEYCHAIN_SIGNATURE_LENGTH,
    KEYCHAIN_SIGNATURE_TYPE,
    build_keychain_signature,
    encode_get_remaining_limit_calldata,
    get_access_key_info,
    get_remaining_spending_limit,
    list_access_keys,
    sign_tx_access_key,
)
from .transaction import (
    TempoAATransaction,  # Backwards compatibility alias
    TempoTransaction,
    create_tempo_transaction,
    patch_web3_for_tempo,
)

__version__ = "0.2.0"

__all__ = [
    # Transaction
    "TempoTransaction",
    "TempoAATransaction",  # Backwards compatibility alias
    "create_tempo_transaction",
    "patch_web3_for_tempo",
    # Keychain precompile
    "ACCOUNT_KEYCHAIN_ADDRESS",
    "GET_KEY_SELECTOR",
    "GET_REMAINING_LIMIT_SELECTOR",
    "KEY_AUTHORIZED_TOPIC",
    "KEY_REVOKED_TOPIC",
    "encode_get_remaining_limit_calldata",
    "get_access_key_info",
    "get_remaining_spending_limit",
    "list_access_keys",
    # Keychain signing
    "KEYCHAIN_SIGNATURE_TYPE",
    "KEYCHAIN_SIGNATURE_LENGTH",
    "INNER_SIGNATURE_LENGTH",
    "build_keychain_signature",
    "sign_tx_access_key",
]
