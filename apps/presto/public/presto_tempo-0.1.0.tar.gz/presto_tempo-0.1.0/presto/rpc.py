"""Shared RPC utilities for Presto.

This module contains common RPC operations using web3.py (no subprocess/curl).
"""
import json
from functools import lru_cache
from typing import Optional

from eth_utils import to_checksum_address
from presto._vendor.pytempo import patch_web3_for_tempo, ACCOUNT_KEYCHAIN_ADDRESS
from presto._vendor.pytempo.keychain import encode_get_remaining_limit_calldata, get_remaining_spending_limit as pytempo_get_remaining_limit
from web3 import Web3

from . import logger

# Ensure pytempo patches are applied for Tempo transaction support
patch_web3_for_tempo()


@lru_cache(maxsize=8)
def get_web3(rpc_url: str) -> Web3:
    """Get a cached Web3 instance for the given RPC URL.
    
    Uses LRU cache to avoid creating new connections for every call.
    """
    return Web3(Web3.HTTPProvider(rpc_url))


def get_token_balance(address: str, token_address: str, rpc_url: str, decimals: int = 6) -> float:
    """Fetch ERC20 token balance for an address.
    
    Args:
        address: The wallet address to check
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
        decimals: Token decimals (default 6 for USDC-style tokens)
    
    Returns:
        Balance as a float (already divided by 10^decimals)
    """
    if not address or not token_address or not rpc_url:
        return 0.0
    
    try:
        w3 = get_web3(rpc_url)
        address = to_checksum_address(address)
        token_address = to_checksum_address(token_address)
        
        # Build balanceOf call data: 0x70a08231 + padded address
        addr_no_prefix = address[2:].lower()
        call_data = f"0x70a08231000000000000000000000000{addr_no_prefix}"
        
        result = w3.eth.call({"to": token_address, "data": call_data})
        balance_wei = int.from_bytes(result, 'big')
        balance = balance_wei / (10 ** decimals)
        logger.debug(f"Token balance for {address[:10]}...: raw={balance_wei}, formatted=${balance:.2f}")
        return balance
    except Exception as e:
        logger.error(f"RPC balance check error: {e}")
        return 0.0


def get_token_balance_raw(address: str, token_address: str, rpc_url: str) -> int:
    """Fetch raw ERC20 token balance (in wei/smallest unit).
    
    Args:
        address: The wallet address to check
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
    
    Returns:
        Raw balance as integer
    """
    if not address or not token_address or not rpc_url:
        return 0
    
    try:
        w3 = get_web3(rpc_url)
        address = to_checksum_address(address)
        token_address = to_checksum_address(token_address)
        
        addr_no_prefix = address[2:].lower()
        call_data = f"0x70a08231000000000000000000000000{addr_no_prefix}"
        
        result = w3.eth.call({"to": token_address, "data": call_data})
        return int.from_bytes(result, 'big')
    except Exception as e:
        logger.error(f"RPC balance check error: {e}")
        return 0


def get_token_name(token_address: str, rpc_url: str) -> str:
    """Fetch ERC20 token name from contract.
    
    Args:
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
    
    Returns:
        Token name string, or empty string on failure
    """
    if not token_address or not rpc_url:
        return ""
    
    try:
        w3 = get_web3(rpc_url)
        token_address = to_checksum_address(token_address)
        
        # name() selector: 0x06fdde03
        result = w3.eth.call({"to": token_address, "data": "0x06fdde03"})
        if len(result) >= 64:
            # ABI-encoded string: first 32 bytes = offset, next 32 = length, then data
            offset = int.from_bytes(result[:32], 'big')
            length = int.from_bytes(result[offset:offset+32], 'big')
            name_bytes = result[offset+32:offset+32+length]
            return name_bytes.decode('utf-8', errors='ignore').strip()
        return ""
    except Exception as e:
        logger.debug(f"Token name fetch error for {token_address}: {e}")
        return ""


def get_token_symbol(token_address: str, rpc_url: str) -> str:
    """Fetch ERC20 token symbol from contract.
    
    Args:
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
    
    Returns:
        Token symbol string, or empty string on failure
    """
    if not token_address or not rpc_url:
        return ""
    
    try:
        w3 = get_web3(rpc_url)
        token_address = to_checksum_address(token_address)
        
        # symbol() selector: 0x95d89b41
        result = w3.eth.call({"to": token_address, "data": "0x95d89b41"})
        if len(result) >= 64:
            offset = int.from_bytes(result[:32], 'big')
            length = int.from_bytes(result[offset:offset+32], 'big')
            symbol_bytes = result[offset+32:offset+32+length]
            return symbol_bytes.decode('utf-8', errors='ignore').strip()
        return ""
    except Exception as e:
        logger.debug(f"Token symbol fetch error for {token_address}: {e}")
        return ""


def get_token_decimals(token_address: str, rpc_url: str) -> int:
    """Fetch ERC20 token decimals from contract.
    
    Args:
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
    
    Returns:
        Token decimals (default 6 on failure)
    """
    if not token_address or not rpc_url:
        return 6
    
    try:
        w3 = get_web3(rpc_url)
        token_address = to_checksum_address(token_address)
        
        # decimals() selector: 0x313ce567
        result = w3.eth.call({"to": token_address, "data": "0x313ce567"})
        if len(result) >= 32:
            return int.from_bytes(result, 'big')
        return 6
    except Exception as e:
        logger.debug(f"Token decimals fetch error for {token_address}: {e}")
        return 6


def get_token_metadata(token_address: str, rpc_url: str) -> dict:
    """Fetch complete ERC20 token metadata from contract.
    
    Args:
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
    
    Returns:
        Dict with 'name', 'symbol', 'decimals' keys
    """
    return {
        "name": get_token_name(token_address, rpc_url),
        "symbol": get_token_symbol(token_address, rpc_url),
        "decimals": get_token_decimals(token_address, rpc_url),
    }


def get_tx_count(address: str, rpc_url: str, pending: bool = True) -> int:
    """Get transaction count (nonce) for an address.
    
    Args:
        address: The wallet address
        rpc_url: The RPC endpoint URL
        pending: If True, include pending txs (avoids "replacement underpriced" errors)
    
    Returns:
        Transaction count
    """
    if not address or not rpc_url:
        return 0
    
    try:
        w3 = get_web3(rpc_url)
        address = to_checksum_address(address)
        block_id = 'pending' if pending else 'latest'
        return w3.eth.get_transaction_count(address, block_id)
    except Exception as e:
        logger.error(f"RPC tx count error: {e}")
        return 0


def get_2d_nonce(address: str, nonce_key: int, rpc_url: str) -> int:
    """Get 2D nonce for parallel transaction support.
    
    Uses the Nonce precompile at 0x4E4F4E4345000000000000000000000000000000
    Function: getNonce(address account, uint256 nonceKey) returns (uint64)
    
    Args:
        address: The wallet address
        nonce_key: The nonce key for parallel transactions
        rpc_url: The RPC endpoint URL
    
    Returns:
        Nonce value for the given key
    """
    if not address or not rpc_url:
        return 0
    
    try:
        w3 = get_web3(rpc_url)
        nonce_precompile = to_checksum_address("0x4E4F4E4345000000000000000000000000000000")
        
        # Build calldata for getNonce(address, uint256)
        # Function selector: 0x89535803
        account_padded = address[2:].lower().zfill(64)
        nonce_key_hex = hex(nonce_key)[2:].zfill(64)
        call_data = f"0x89535803{account_padded}{nonce_key_hex}"
        
        result = w3.eth.call({"to": nonce_precompile, "data": call_data})
        return int.from_bytes(result, 'big')
    except Exception as e:
        logger.error(f"RPC 2D nonce error: {e}")
        return 0


def get_gas_price(rpc_url: str) -> tuple[int, int]:
    """Get gas price (max_fee, priority_fee).
    
    Args:
        rpc_url: The RPC endpoint URL
    
    Returns:
        Tuple of (max_fee_per_gas, max_priority_fee_per_gas)
    """
    try:
        w3 = get_web3(rpc_url)
        gas_price = w3.eth.gas_price
        return gas_price * 2, gas_price
    except Exception as e:
        logger.error(f"RPC gas price error: {e}")
        return 2_000_000_000, 1_000_000_000


def estimate_gas(from_address: str, to_address: str, data: str, rpc_url: str, value: int = 0) -> int:
    """Estimate gas for a transaction.
    
    Args:
        from_address: Sender address
        to_address: Contract/recipient address
        data: Calldata hex string
        rpc_url: The RPC endpoint URL
        value: Value in wei (default 0)
    
    Returns:
        Gas estimate
    """
    try:
        w3 = get_web3(rpc_url)
        from_address = to_checksum_address(from_address)
        to_address = to_checksum_address(to_address)
        
        tx = {
            "from": from_address,
            "to": to_address,
            "data": data,
            "value": value,
        }
        return w3.eth.estimate_gas(tx)
    except Exception as e:
        # Use debug level since this is expected for batched txs (e.g., open before approve)
        logger.debug(f"RPC gas estimate error: {e}")
        raise


def broadcast_tx(raw_tx: str, rpc_url: str) -> str:
    """Broadcast a raw signed transaction.
    
    Args:
        raw_tx: Hex-encoded signed transaction
        rpc_url: The RPC endpoint URL
    
    Returns:
        Transaction hash
    """
    try:
        w3 = get_web3(rpc_url)
        tx_hash = w3.eth.send_raw_transaction(raw_tx)
        return tx_hash.hex()
    except Exception as e:
        logger.error(f"RPC broadcast error: {e}")
        raise


def wait_for_receipt(tx_hash: str, rpc_url: str, timeout: int = 60, check_status: bool = True) -> dict:
    """Wait for a transaction receipt and optionally verify success.
    
    Args:
        tx_hash: Transaction hash
        rpc_url: The RPC endpoint URL
        timeout: Timeout in seconds
        check_status: If True, raise error if tx reverted (status=0)
    
    Returns:
        Transaction receipt dict
    
    Raises:
        RuntimeError: If check_status=True and transaction reverted
    """
    try:
        w3 = get_web3(rpc_url)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=timeout)
        receipt_dict = dict(receipt)
        
        # Check transaction status (0 = reverted, 1 = success)
        if check_status:
            status = receipt_dict.get('status', 1)
            if status == 0:
                logger.error(f"Transaction reverted on-chain: {tx_hash}")
                raise RuntimeError(f"Transaction reverted: {tx_hash}")
        
        return receipt_dict
    except Exception as e:
        logger.error(f"RPC receipt wait error: {e}")
        raise


def get_recent_transfers(address: str, rpc_url: str, limit: int = 10) -> list[str]:
    """Get recent ERC20 transfers for an address using eth_getLogs.
    
    Args:
        address: The wallet address
        rpc_url: The RPC endpoint URL
        limit: Max transfers to return
    
    Returns:
        List of formatted transfer strings
    """
    if not address or not rpc_url:
        return []
    
    w3 = get_web3(rpc_url)
    
    # Transfer event signature: Transfer(address,address,uint256)
    transfer_topic = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
    
    # Pad address to 32 bytes for topic filter
    addr_padded = "0x" + "0" * 24 + address[2:].lower()
    
    transfers = []
    
    # Query transfers TO this address (received)
    try:
        logs = w3.eth.get_logs({
            "fromBlock": "earliest",
            "toBlock": "latest",
            "topics": [transfer_topic, None, addr_padded],
        })
        
        for log in logs[-limit:]:
            amount = int.from_bytes(log["data"], 'big') / 1e6  # Assume 6 decimals
            from_addr = "0x" + log["topics"][1].hex()[-40:] if len(log["topics"]) > 1 else "?"
            transfers.append(f"← ${amount:.2f} from {from_addr[:10]}...")
    except Exception as e:
        logger.error(f"RPC getLogs (received) error: {e}")
    
    # Query transfers FROM this address (sent)
    try:
        logs = w3.eth.get_logs({
            "fromBlock": "earliest",
            "toBlock": "latest",
            "topics": [transfer_topic, addr_padded, None],
        })
        
        for log in logs[-limit:]:
            amount = int.from_bytes(log["data"], 'big') / 1e6  # Assume 6 decimals
            to_addr = "0x" + log["topics"][2].hex()[-40:] if len(log["topics"]) > 2 else "?"
            transfers.append(f"→ ${amount:.2f} to {to_addr[:10]}...")
    except Exception as e:
        logger.error(f"RPC getLogs (sent) error: {e}")
    
    # Return most recent transfers
    return transfers[-limit:] if transfers else []


def format_balance(balance: float, token_name: str = "tokens") -> str:
    """Format a balance for display.
    
    Args:
        balance: The numeric balance
        token_name: Token name/symbol to append
    
    Returns:
        Formatted string like "$10.50 mUSDC"
    """
    return f"${balance:,.2f} {token_name}"


def get_formatted_balance(address: str, token_address: str, rpc_url: str, 
                          token_name: str = "tokens", decimals: int = 6) -> str:
    """Fetch and format token balance in one call.
    
    Args:
        address: The wallet address to check
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
        token_name: Token name for display
        decimals: Token decimals
    
    Returns:
        Formatted string like "$10.50 mUSDC"
    """
    balance = get_token_balance(address, token_address, rpc_url, decimals)
    return format_balance(balance, token_name)


def eth_call(to: str, data: str, rpc_url: str) -> bytes:
    """Make a raw eth_call.
    
    Args:
        to: Contract address
        data: Calldata hex string
        rpc_url: The RPC endpoint URL
    
    Returns:
        Raw bytes result
    """
    try:
        w3 = get_web3(rpc_url)
        to = to_checksum_address(to)
        return w3.eth.call({"to": to, "data": data})
    except Exception as e:
        logger.error(f"RPC eth_call error: {e}")
        raise


def keccak256(data: str) -> str:
    """Compute keccak256 hash.
    
    Args:
        data: Hex string to hash
    
    Returns:
        Hex-encoded hash with 0x prefix
    """
    from web3 import Web3
    if data.startswith("0x"):
        data_bytes = bytes.fromhex(data[2:])
    else:
        data_bytes = bytes.fromhex(data)
    result = Web3.keccak(data_bytes).hex()
    # Ensure 0x prefix
    return result if result.startswith("0x") else f"0x{result}"


def format_spending_limit(limit_base_units: int, decimals: int = 6) -> str:
    """Format spending limit for display.
    
    Args:
        limit_base_units: Limit in base units
        decimals: Token decimals (default 6 for USDM)
    
    Returns:
        Formatted string like "$10.00" or "∞" for unlimited
    
    Note: A return of 0 from getRemainingLimit means either:
        - The key has enforceLimits=false (unlimited spending)
        - The limit has been fully depleted
    Since we can't distinguish these, 0 is shown as "∞" (unlimited).
    """
    if limit_base_units == 0:
        return "∞"  # 0 means no limit set (enforceLimits=false) or error
    if limit_base_units >= 2**128:  # Effectively unlimited
        return "∞"
    amount = limit_base_units / (10 ** decimals)
    return f"${amount:.2f}"


def get_remaining_spending_limit(
    account_address: str, 
    key_id: str, 
    token_address: str, 
    rpc_url: str
) -> int:
    """Query remaining spending limit for an access key from the AccountKeychain precompile.
    
    Uses pytempo's get_remaining_spending_limit internally.
    
    Args:
        account_address: The root wallet address
        key_id: The access key ID (address)
        token_address: The token to check limit for
        rpc_url: The RPC endpoint URL
    
    Returns:
        Remaining spending limit in base units (0 if error or no limit)
    """
    if not account_address or not key_id or not token_address or not rpc_url:
        return 0
    
    try:
        w3 = get_web3(rpc_url)
        return pytempo_get_remaining_limit(w3, account_address, key_id, token_address)
    except Exception as e:
        logger.error(f"RPC spending limit query error: {e}")
        return 0


# Function selector for getKey(address,address)
GET_KEY_SELECTOR = "0xbc298553"


def get_access_key_info(
    account_address: str,
    key_id: str,
    rpc_url: str
) -> dict:
    """Query access key info from the AccountKeychain precompile.
    
    Args:
        account_address: The root wallet address
        key_id: The access key ID (address)
        rpc_url: The RPC endpoint URL
    
    Returns:
        Dict with key info:
        - signature_type: 0=Secp256k1, 1=P256, 2=WebAuthn
        - expiry: Unix timestamp when key expires (0 = no expiry)
        - enforce_limits: Whether spending limits are enforced
        - is_revoked: Whether key has been revoked
        
        Returns empty dict on error.
    """
    if not account_address or not key_id or not rpc_url:
        return {}
    
    # Validate: account_address must differ from key_id (can't query a key against itself)
    if account_address.lower() == key_id.lower():
        return {}
    
    # Validate address lengths (should be 42 chars: 0x + 40 hex chars)
    if len(account_address) != 42 or len(key_id) != 42:
        logger.error(f"Invalid address length: account={len(account_address)}, key={len(key_id)}")
        return {}
    
    try:
        w3 = get_web3(rpc_url)
        keychain = to_checksum_address(ACCOUNT_KEYCHAIN_ADDRESS)
        
        # Encode calldata: selector + padded account + padded keyId
        account_padded = account_address[2:].lower().zfill(64)
        key_padded = key_id[2:].lower().zfill(64)
        call_data = f"{GET_KEY_SELECTOR}{account_padded}{key_padded}"
        
        result = w3.eth.call({"to": keychain, "data": call_data})
        
        # Decode result: (uint8 signatureType, address keyId, uint64 expiry, bool enforceLimits, bool isRevoked)
        # ABI encoding: each field is 32 bytes padded
        if len(result) < 160:  # 5 * 32 bytes
            return {}
        
        signature_type = int.from_bytes(result[0:32], 'big')
        # key_id is at offset 32, but we already have it
        expiry = int.from_bytes(result[64:96], 'big')
        enforce_limits = int.from_bytes(result[96:128], 'big') != 0
        is_revoked = int.from_bytes(result[128:160], 'big') != 0
        
        return {
            'signature_type': signature_type,
            'expiry': expiry,
            'enforce_limits': enforce_limits,
            'is_revoked': is_revoked,
        }
    except Exception as e:
        logger.error(f"RPC access key info query error: {e}")
        return {}
