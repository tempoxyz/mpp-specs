"""Curses-based terminal UI for presto."""
import curses
import os
import random
import re
import subprocess
import sys
import time
import threading
import queue


def _term_write(seq: str) -> None:
    """Write escape sequence directly to terminal."""
    try:
        sys.stdout.write(seq)
        sys.stdout.flush()
    except Exception:
        pass

from .config import CONFIG_FILE, NETWORKS, DEFAULT_NETWORK, get_logo, AVAILABLE_MODELS, MODEL, MAINNET_BLOCKED
from .payment import load_config, save_config
from .api import call_api, get_model_context_length, StreamCancelled, PaymentError
from .rpc import get_token_balance, format_balance, get_remaining_spending_limit, format_spending_limit, get_token_symbol
from .tools import run_tool, set_tool_context, get_tools_summary, set_skill_loader
from .wallet import setup_wallet_browser, setup_wallet_manual, WalletConfig, AccessKey
from .streaming import init_stream_manager
from .context import UserContext
from .transactions import init_transaction_sender, get_transaction_sender

from . import skills as presto_skills
from . import logger
import webbrowser


# Look for skills in both the package and user config
PRESTO_SKILLS_DIR = os.path.dirname(os.path.abspath(__file__)) + "/skills"
USER_SKILLS_DIR = os.path.expanduser("~/.config/agents/skills")

# Settlement show messages - rotate during blockchain confirmation
SETTLEMENT_MESSAGES = [
    # Technical vibes
    "Confirming blocks...",
    "Verifying chain state...",
    "Hashing the hashes...",
    "Consensus achieved...",
    "Validators validating...",
    "Merkle roots intensify...",
    "Finality approaching...",
    "Propagating to nodes...",
    "Crunching cryptography...",
    "Byzantine fault? Never heard of her.",
    # Dank memes  
    "Blocks go brrr...",
    "In crypto we trust...",
    "Much confirm. Very chain. Wow.",
    "This is the way.",
    "WAGMI 🤝",
    "ser, your tx is cooking...",
    "wen confirm? soon™",
    "gm blockchain ☀️",
    "Not your keys? Not your AI.",
    "Decentralized vibes only.",
    "The chain remembers.",
    "Probably nothing...",
    "LFG 🚀",
    "Based and chainpilled.",
    "Few understand this.",
    "API keys are mass surveillance.",
    "No middlemen. Just math.",
    "Trust the process...",
    "Imagine using API keys lmao",
    "Your money, your model.",
    "ngmi if you use subscriptions",
    "Have fun staying centralized.",
    "Nodes are gossiping about you...",
    "Sir, this is a blockchain.",
    "We're all gonna make it.",
    "Number go up (blocks).",
    "The future is permissionless.",
    "Satoshi would be proud.",
    "Touch grass? Touch chain.",
    "Immutability loading...",
    "Your tx is valid and we love it.",
    "Consensus says yes.",
    "Making history (literally).",
    "The mempool chose you.",
    "Built different. Paid different.",
    "No cap, all chain.",
    "Vibes: ✓ immaculate",
    "POV: you don't need API keys",
    "Main character energy.",
    "Blockchain whisperer at work...",
]

# Fun success messages when payment confirms
SUCCESS_MESSAGES = [
    "Clean. 🧹",
    "Sheesh.",
    "Built different.",
    "No cap.",
    "Immaculate.",
    "That's gas.",
    "W.",
    "Certified.",
    "Bussin.",
    "Locked in.",
    "Goated.",
    "Fire.",
    "Valid.",
    "Based.",
    "Smooth.",
]

# Animated spinner frames for different payment phases
SPINNER_FAST = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]  # 12fps feel
SPINNER_PULSE = ["█", "▓", "▒", "░", "▒", "▓"]  # Slower pulse for confirming


class PrestoUI:
    def __init__(self, stdscr, fresh=False):
        self.stdscr = stdscr
        self.fresh = fresh
        self.messages = []
        self.output_lines = []
        self.input_buffer = ""
        self.cursor_pos = 0
        self.scroll_offset = 0
        self.config = {}
        self.wallet: WalletConfig = WalletConfig()  # New wallet model
        self.private_key = ""
        self.account_address = ""  # Main passkey wallet address
        self.access_key_address = ""  # Access key address (derived from private key)
        self.running = True
        self.status_message = ""
        self.is_first_run = False
        self.current_network = DEFAULT_NETWORK
        self.loaded_skills = []  # List of loaded skill names
        self.skill_instructions = ""  # Combined skill instructions
        self.animation_frame = 0  # For logo animation
        self.cached_balance = None  # Cached balance string
        self.last_balance_check = 0  # Timestamp of last balance check
        self.balance_refresh_in_progress = False  # Guard for balance refresh
        self.cached_spending_limit = None  # Cached spending limit string
        self.last_spending_limit_check = 0  # Timestamp of last spending limit check
        self.api_thread = None  # Background thread for API calls
        self.api_busy = False  # True when API call is in progress
        self.api_cancelled = False  # True when user cancels current request
        self.api_cancel_event = threading.Event()  # Event to signal cancellation to call_api
        self.api_queue = queue.Queue()  # Queue for API responses/events
        self.api_request_id = 0  # Monotonic request ID for ignoring stale results
        self.activity_status = ""  # Current activity for status bar (e.g., "Streaming response...", "Running read...")
        self.current_model = MODEL  # Currently selected model
        self.model_box_x = 0  # For click detection
        self.model_box_width = 0
        self.session_cost = 0.0  # Total paid this session
        self.session_tokens = 0  # Total tokens used this session
        self.session_tx_count = 0  # Number of on-chain transactions this session
        self.session_voucher_count = 0  # Number of streaming vouchers this session
        self.context_limit = 1000000  # Model context limit (1M for Claude Sonnet 4)
        self.context_tokens = 0  # Current context window usage (from prompt_tokens)
        self._streaming_cost = 0.0  # Estimated cost ticking up during streaming
        self._streaming_token_count = 0  # Tokens counted during current stream
        
        # Access key revocation monitoring state
        self._revocation_thread: threading.Thread | None = None
        self._revocation_stop_event = threading.Event()
        self._key_revoked_intercept = False  # When True, block next command until key is resolved
        self._revoked_key_address = ""  # Address of the revoked key
        self._last_revocation_check = 0.0
        
        # User context for AI agent awareness
        self.user_context = UserContext()
        
        # Payment UX state for dopamine loop
        self._payment_state = None  # Current payment state: 'signing', 'sending', 'confirming', 'confirmed'
        self._payment_started_at = 0  # When confirm phase started
        self._payment_msg_idx = 0  # Index into rotating messages
        
        curses.start_color()
        curses.use_default_colors()
        # Brutalist B&W palette: grayscale-first with semantic colors only
        curses.init_pair(1, curses.COLOR_WHITE, -1)   # Primary/headers
        curses.init_pair(2, curses.COLOR_WHITE, -1)   # Secondary (use with A_DIM)
        curses.init_pair(3, curses.COLOR_GREEN, -1)   # Success
        curses.init_pair(4, curses.COLOR_YELLOW, -1)  # Warning/in-progress
        curses.init_pair(5, curses.COLOR_RED, -1)     # Error
        curses.init_pair(6, curses.COLOR_WHITE, -1)   # Accent (monochrome)
        curses.init_pair(7, curses.COLOR_CYAN, -1)    # Responding/streaming
        curses.curs_set(1)
        # Enable keypad mode for arrow keys
        self.stdscr.keypad(True)
        self.wallet_box_x = 0
        self.wallet_box_width = 0
        self.model_box_y = 0  # Initialize for click detection
        self.cached_git_branch = ""  # Cache git branch to avoid repeated subprocess calls
        self.last_git_check = 0  # Timestamp of last git check
        
        self.stdscr.timeout(100)
        
        # Reduce escape delay so ESC key is responsive (default is 1000ms!)
        # This makes pressing ESC feel instant instead of laggy
        try:
            curses.set_escdelay(25)  # 25ms delay
        except AttributeError:
            # Older curses versions don't have set_escdelay
            os.environ.setdefault('ESCDELAY', '25')
        
        # Don't capture mouse clicks - let terminal handle text selection natively
        curses.mousemask(0)
        
        # Enable xterm alternate scroll mode: wheel generates Up/Down keys
        # This preserves native text selection while enabling scroll wheel
        _term_write("\x1b[?1007h")
        
    def get_dims(self):
        return self.stdscr.getmaxyx()
    
    def get_logo(self):
        """Get appropriately sized logo for current terminal."""
        height, width = self.get_dims()
        return get_logo(height, width)
    
    def center_text(self, text, width):
        padding = max(0, (width - len(text)) // 2)
        return " " * padding + text
    
    def get_network_name(self):
        return self.current_network
    
    def get_rpc_url(self):
        return NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])["rpc"]
    
    def get_chain_id(self):
        return NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])["chain_id"]
    
    
    def get_cached_balance(self):
        """Get cached balance, refresh every 30 seconds."""
        now = time.time()
        
        # Refresh balance every 30 seconds (with guard to prevent multiple concurrent refreshes)
        if not self.balance_refresh_in_progress:
            if self.cached_balance is None or (now - self.last_balance_check) > 30:
                self.refresh_balance_async()
        
        return self.cached_balance
    
    def refresh_balance_sync(self):
        """Synchronously fetch token balance via RPC."""
        if not self.account_address:
            return
        
        # Get fee token from access key limits or wallet config (fallback)
        fee_token_addr = None
        fee_token_symbol = "tokens"
        fee_token_decimals = 6
        
        key = self.wallet.active_key if self.wallet else None
        if key and key.enforce_limits:
            # Use first usable token from key's spending limits
            usable = key.get_usable_tokens()
            if usable:
                fee_token_addr = usable[0]["address"]
                fee_token_symbol = usable[0]["symbol"] or "tokens"
                fee_token_decimals = usable[0]["decimals"]
        
        # Fallback to wallet fee_token if no key limits
        if not fee_token_addr:
            fee_token = self.wallet.fee_token if self.wallet else None
            if fee_token and fee_token.is_set:
                fee_token_addr = fee_token.address
                fee_token_symbol = fee_token.symbol or "tokens"
                fee_token_decimals = fee_token.decimals
        
        if not fee_token_addr:
            return  # No token to check balance for
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info.get("rpc", "")
        balance = get_token_balance(
            self.account_address,
            fee_token_addr,
            rpc_url,
            decimals=fee_token_decimals
        )
        self.cached_balance = format_balance(balance, fee_token_symbol)
        self.last_balance_check = time.time()
        
        # Also fetch spending limit if we have an active key
        if key and key.key_id:
            try:
                limit = get_remaining_spending_limit(self.account_address, key.key_id, fee_token_addr, rpc_url)
                self.cached_spending_limit = format_spending_limit(limit)
                self.last_spending_limit_check = time.time()
            except Exception:
                pass
    
    def refresh_balance_async(self):
        """Refresh token balance and spending limit in background via RPC."""
        if not self.account_address:
            return
        
        # Get fee token from access key limits or wallet config (fallback)
        fee_token_addr = None
        fee_token_name = "tokens"
        fee_token_decimals = 6
        
        active_key = self.wallet.active_key if self.wallet else None
        if active_key and active_key.enforce_limits:
            # Use first usable token from key's spending limits
            usable = active_key.get_usable_tokens()
            if usable:
                fee_token_addr = usable[0]["address"]
                fee_token_name = usable[0]["symbol"] or "tokens"
                fee_token_decimals = usable[0]["decimals"]
        
        # Fallback to wallet fee_token if no key limits
        if not fee_token_addr:
            wallet_fee_token = self.wallet.fee_token if self.wallet else None
            if wallet_fee_token and wallet_fee_token.is_set:
                fee_token_addr = wallet_fee_token.address
                fee_token_name = wallet_fee_token.symbol or "tokens"
                fee_token_decimals = wallet_fee_token.decimals
        
        if not fee_token_addr:
            return  # No token to check balance for
        
        self.balance_refresh_in_progress = True
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info.get("rpc", "")
        account = self.account_address
        key_id = active_key.key_id if active_key else ""
        
        def fetch():
            try:
                old_balance = self.cached_balance
                balance = get_token_balance(account, fee_token_addr, rpc_url, decimals=fee_token_decimals)
                self.cached_balance = format_balance(balance, fee_token_name)
                self.last_balance_check = time.time()
                # Update user context with new balance
                self.user_context.update_balance(self.cached_balance)
                logger.info(f"Balance refresh: old={old_balance}, new={self.cached_balance}, raw={balance}")
                
                # Also fetch spending limit if we have an active key
                if key_id:
                    limit = get_remaining_spending_limit(account, key_id, fee_token_addr, rpc_url)
                    old_limit = self.cached_spending_limit
                    self.cached_spending_limit = format_spending_limit(limit)
                    self.last_spending_limit_check = time.time()
                    logger.info(f"Spending limit refresh: old={old_limit}, new={self.cached_spending_limit}")
            except Exception as e:
                logger.error(f"Balance refresh error: {e}")
            finally:
                self.balance_refresh_in_progress = False
        
        thread = threading.Thread(target=fetch, daemon=True)
        thread.start()
    
    def _on_tx_event(self, event_type: str, payload: dict):
        """Handle transaction events from TransactionSender (called from background threads).
        
        event_type is one of: "submitted", "confirmed", "failed"
        """
        self.api_queue.put((-1, "tx_event", {"tx_event_type": event_type, "payload": payload}))
    
    def init_transaction_sender_with_listener(self, rpc_url: str):
        """Initialize TransactionSender and register balance refresh listener."""
        tx_sender = init_transaction_sender(rpc_url)
        tx_sender.add_listener(self._on_tx_event)
        logger.info("TransactionSender initialized with balance refresh listener")
        return tx_sender
    
    def get_header_height(self):
        return 2
    
    def draw_header(self):
        height, width = self.get_dims()
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        
        # Compact single-line header
        try:
            self.stdscr.addstr(0, 0, "PRESTO", curses.A_BOLD | curses.color_pair(3))
            
            # Build right-side info box
            if self.account_address:
                active_key = self.wallet.active_key if self.wallet else None
                
                # Balance with token name
                if self.cached_balance:
                    balance_str = self.cached_balance
                else:
                    fee_token = self.wallet.fee_token if self.wallet else None
                    fee_token_name = fee_token.symbol if fee_token and fee_token.is_set else "tokens"
                    balance_str = f"$0.00 {fee_token_name}"
                
                # Key expiry and spending limit
                key_status = ""
                if active_key:
                    if active_key.is_expired:
                        key_status = "EXPIRED"
                    else:
                        expiry_str = active_key.time_remaining
                        limit_str = self.cached_spending_limit or "..."
                        key_status = f"exp: {expiry_str} │ spendable: {limit_str}"
                
                box_text = f"┃ {balance_str} │ {key_status} ┃"
            else:
                # Premium CTA for wallet connection
                box_text = "┃ Connect wallet (/wallet) ┃"
            
            box_x = width - len(box_text) - 1
            self.wallet_box_x = box_x
            self.wallet_box_width = len(box_text)
            
            if self.account_address:
                active_key = self.wallet.active_key if self.wallet else None
                if active_key and active_key.is_expired:
                    self.stdscr.addstr(0, box_x, box_text, curses.color_pair(5))
                elif active_key and active_key.expires_soon:
                    self.stdscr.addstr(0, box_x, box_text, curses.color_pair(4))
                else:
                    self.stdscr.addstr(0, box_x, box_text, curses.color_pair(3))
            else:
                # Cyan for CTA (inviting, not error)
                self.stdscr.addstr(0, box_x, box_text, curses.color_pair(2))
        except curses.error:
            pass
        
        # Separator line
        try:
            self.stdscr.addstr(1, 0, "─" * width, curses.color_pair(1) | curses.A_DIM)
        except curses.error:
            pass
    
    def draw_separator(self, y):
        height, width = self.get_dims()
        try:
            self.stdscr.addstr(y, 0, "─" * width, curses.color_pair(1) | curses.A_DIM)
        except curses.error:
            pass
    
    def draw_output(self):
        height, width = self.get_dims()
        output_start = self.get_header_height()
        input_lines = 3  # Must match draw_input
        box_height = input_lines + 2  # +2 for borders
        output_margin = 1  # Gap between output and input box
        status_bar_height = 1 if (self.api_busy and self.activity_status) else 0
        output_end = height - box_height - status_bar_height - output_margin
        max_lines = output_end - output_start
        
        if max_lines <= 0:
            return
        
        total = len(self.output_lines)
        max_offset = max(0, total - max_lines)
        self.scroll_offset = min(max(self.scroll_offset, 0), max_offset)
        
        visible_lines = self.output_lines[-(max_lines + self.scroll_offset):]
        if self.scroll_offset > 0:
            visible_lines = visible_lines[:max_lines]
        else:
            visible_lines = visible_lines[-max_lines:]
        
        # Bottom-align: calculate offset so content sticks to bottom
        content_lines = len(visible_lines)
        start_row = max_lines - content_lines  # Empty rows at top
        
        for i in range(max_lines):
            y = output_start + i
            try:
                self.stdscr.move(y, 0)
                self.stdscr.clrtoeol()
                # Only render if we're past the empty top rows
                line_idx = i - start_row
                if line_idx >= 0 and line_idx < len(visible_lines):
                    line = visible_lines[line_idx]
                    self.render_line(y, line, width)
            except curses.error:
                pass
        
        # Draw scrollbar on right edge when content exceeds viewport
        if total > max_lines:
            scrollbar_x = width - 1
            track_height = max_lines
            
            # Calculate thumb size and position
            # Thumb size proportional to visible portion
            thumb_height = max(1, int(track_height * (max_lines / total)))
            
            # Thumb position: 0 = bottom (newest), max_offset = top (oldest)
            # We want thumb at bottom when scroll_offset=0, top when scroll_offset=max_offset
            if max_offset > 0:
                # Position from top: when scroll_offset is high (old content), thumb near top
                thumb_pos = int((self.scroll_offset / max_offset) * (track_height - thumb_height))
                # Invert: scroll_offset=0 means bottom, scroll_offset=max means top
                thumb_pos = track_height - thumb_height - thumb_pos
            else:
                thumb_pos = track_height - thumb_height
            
            # Draw scrollbar track and thumb
            for i in range(track_height):
                y = output_start + i
                try:
                    if thumb_pos <= i < thumb_pos + thumb_height:
                        # Thumb - bright block
                        self.stdscr.addstr(y, scrollbar_x, "█", curses.A_DIM)
                    else:
                        # Track - dim line
                        self.stdscr.addstr(y, scrollbar_x, "│", curses.A_DIM)
                except curses.error:
                    pass
    
    def render_markdown_line(self, y, x, text, max_width, base_attr=0):
        """Render a line with basic markdown: **bold** and *italic*."""
        import re
        pos = x
        remaining = max_width
        
        # Pattern for **bold** and *italic* (non-greedy)
        pattern = re.compile(r'(\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`)')
        last_end = 0
        
        for match in pattern.finditer(text):
            # Render text before this match
            before = text[last_end:match.start()]
            if before and remaining > 0:
                chunk = before[:remaining]
                try:
                    self.stdscr.addstr(y, pos, chunk, base_attr)
                except curses.error:
                    pass
                pos += len(chunk)
                remaining -= len(chunk)
            
            # Render the matched styled text
            if remaining > 0:
                if match.group(2):  # **bold**
                    styled_text = match.group(2)[:remaining]
                    try:
                        self.stdscr.addstr(y, pos, styled_text, base_attr | curses.A_BOLD)
                    except curses.error:
                        pass
                elif match.group(3):  # *italic*
                    styled_text = match.group(3)[:remaining]
                    try:
                        self.stdscr.addstr(y, pos, styled_text, base_attr | curses.A_ITALIC if hasattr(curses, 'A_ITALIC') else base_attr | curses.A_DIM)
                    except curses.error:
                        pass
                elif match.group(4):  # `code`
                    styled_text = match.group(4)[:remaining]
                    try:
                        self.stdscr.addstr(y, pos, styled_text, base_attr | curses.A_REVERSE)
                    except curses.error:
                        pass
                else:
                    styled_text = ""
                pos += len(styled_text)
                remaining -= len(styled_text)
            
            last_end = match.end()
        
        # Render remaining text after last match
        after = text[last_end:]
        if after and remaining > 0:
            chunk = after[:remaining]
            try:
                self.stdscr.addstr(y, pos, chunk, base_attr)
            except curses.error:
                pass
    
    def render_line(self, y, line, width):
        margin = 3
        content_width = width - margin - 5
        if line.startswith("⏺ "):
            # Assistant response - render with markdown
            try:
                self.render_markdown_line(y, margin, line[2:], content_width)
            except curses.error:
                pass
        elif line.startswith("→ "):
            # User input - vertical bar with italic-style (dim) text
            try:
                self.stdscr.addstr(y, margin, "│ ", curses.color_pair(4))
                self.stdscr.addstr(line[2:][:content_width], curses.A_ITALIC if hasattr(curses, 'A_ITALIC') else curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("$ "):
            # Status message
            try:
                self.stdscr.addstr(y, margin, "✓ ", curses.color_pair(3))
                self.stdscr.addstr(line[2:][:content_width], curses.A_BOLD)
            except curses.error:
                pass
        elif line.startswith("@ "):
            # Thinking indicator with animated spinner
            try:
                # Braille spinner frames: dots rotating around
                spinner_frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
                frame = spinner_frames[self.animation_frame % len(spinner_frames)]
                self.stdscr.addstr(y, margin, f"{frame} ", curses.color_pair(4))
                self.stdscr.addstr(line[2:][:content_width], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("▶ "):
            # Responding indicator (blue, like Amp's "about to respond")
            try:
                spinner_frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
                frame = spinner_frames[self.animation_frame % len(spinner_frames)]
                self.stdscr.addstr(y, margin, f"{frame} ", curses.color_pair(7))
                self.stdscr.addstr(line[2:][:content_width], curses.color_pair(7))
            except curses.error:
                pass
        elif line.startswith("! "):
            # Error
            try:
                self.stdscr.addstr(y, margin, "✗ ", curses.color_pair(5))
                self.stdscr.addstr(line[2:][:content_width])
            except curses.error:
                pass
        elif line.startswith("⎿ "):
            # Tool result - dim
            try:
                self.stdscr.addstr(y, margin + 2, line[2:][:content_width-2], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("~ "):
            # Subtle info (e.g., payment summary after completion) - very dim
            try:
                self.stdscr.addstr(y, margin, line[2:][:content_width], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("◊ "):
            # Tool call line like "◊ ✓ Read file.py @1-50"
            try:
                rest = line[2:]
                if rest.startswith("○ "):
                    # Pending - show spinner
                    spinner_frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
                    frame = spinner_frames[self.animation_frame % len(spinner_frames)]
                    self.stdscr.addstr(y, margin, f"{frame} ", curses.color_pair(4))
                    self.stdscr.addstr(rest[2:][:content_width-2], curses.color_pair(2))
                elif rest.startswith("✓ "):
                    # Completed - green checkmark
                    self.stdscr.addstr(y, margin, "✓ ", curses.color_pair(3))
                    self.stdscr.addstr(rest[2:][:content_width-2], curses.A_DIM)
                else:
                    self.stdscr.addstr(y, margin, rest[:content_width], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("✓EDIT "):
            # Edit header - green checkmark with file info
            try:
                self.stdscr.addstr(y, margin, "✓ Edit ", curses.color_pair(3))
                self.stdscr.addstr(line[6:][:content_width-8], curses.color_pair(2))
            except curses.error:
                pass
        elif line.startswith("+DIFF"):
            # Added line - green
            diff_line = line[5:]
            try:
                parts = diff_line.split(" + ", 1)
                line_num = parts[0].strip() if parts else ""
                content = parts[1] if len(parts) > 1 else ""
                self.stdscr.addstr(y, margin, f"{line_num} ", curses.A_DIM)
                self.stdscr.addstr("+ ", curses.color_pair(3) | curses.A_BOLD)
                self.stdscr.addstr(content[:content_width-10], curses.color_pair(3))
            except curses.error:
                pass
        elif line.startswith("-DIFF"):
            # Removed line - red
            diff_line = line[5:]
            try:
                parts = diff_line.split(" - ", 1)
                line_num = parts[0].strip() if parts else ""
                content = parts[1] if len(parts) > 1 else ""
                self.stdscr.addstr(y, margin, f"{line_num} ", curses.A_DIM)
                self.stdscr.addstr("- ", curses.color_pair(5) | curses.A_BOLD)
                self.stdscr.addstr(content[:content_width-10], curses.color_pair(5) | curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith(" DIFF"):
            # Context line - dim
            diff_line = line[5:]
            try:
                self.stdscr.addstr(y, margin + 2, diff_line[:content_width-4], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("§"):
            # Logo line - render with animated wave effect
            import math
            logo_text = line[1:]
            logo_margin = margin
            for j, char in enumerate(logo_text[:content_width]):
                try:
                    x = logo_margin + j
                    # Wave effect based on position and animation frame
                    wave = math.sin((j * 0.3) + (y * 0.2) + (self.animation_frame * 0.15))
                    bright = wave > 0.3
                    dim = wave < -0.3
                    
                    if char == '+':
                        attr = curses.A_BOLD if bright else 0
                        self.stdscr.addstr(y, x, char, curses.color_pair(3) | attr)
                    elif char == '=':
                        if bright:
                            self.stdscr.addstr(y, x, char, curses.color_pair(3) | curses.A_BOLD)
                        elif dim:
                            self.stdscr.addstr(y, x, char, curses.color_pair(1) | curses.A_DIM)
                        else:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2))
                    elif char == '-':
                        if bright:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2) | curses.A_BOLD)
                        else:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2) | (curses.A_DIM if dim else 0))
                    elif char == '·':
                        if bright:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2) | curses.A_BOLD)
                        else:
                            self.stdscr.addstr(y, x, char, curses.color_pair(1) | curses.A_DIM)
                    elif char != ' ':
                        self.stdscr.addstr(y, x, char, curses.color_pair(3))
                except curses.error:
                    pass
        elif line.startswith("★ "):
            # Highlighted/actionable line (e.g., withdrawable channel) - green with emphasis
            try:
                self.stdscr.addstr(y, margin, "→ ", curses.color_pair(3) | curses.A_BOLD)
                self.stdscr.addstr(line[2:][:content_width-2], curses.color_pair(3))
            except curses.error:
                pass
        else:
            try:
                self.stdscr.addstr(y, margin, line[:content_width])
            except curses.error:
                pass
    
    def draw_input(self, show_cursor=True):
        height, width = self.get_dims()
        margin = 2
        input_lines = 3  # Number of lines for input text
        box_height = input_lines + 2  # +2 for top/bottom borders
        box_top = height - box_height
        box_left = margin
        # Leave 3 chars margin on right to avoid curses edge issues
        box_width = max(20, width - margin * 2 - 3)
        
        # Build top border with stats embedded
        inner_width = box_width - 2  # Excluding corners
        if self.session_tokens > 0 or self.session_cost > 0 or self._streaming_cost > 0:
            current_context = getattr(self, 'context_tokens', 0) or self.session_tokens
            context_pct = min(100, int((current_context / self.context_limit) * 100)) if self.context_limit > 0 else 0
            total_payments = self.session_tx_count + self.session_voucher_count
            # Show streaming cost ticking up during active streaming
            display_cost = self.session_cost + self._streaming_cost
            if self._streaming_cost > 0:
                stats = f"{context_pct}% of {self.context_limit // 1000}k · ${display_cost:.4f}↑ · {total_payments}tx"
            else:
                stats = f"{context_pct}% of {self.context_limit // 1000}k · ${display_cost:.2f} · {total_payments}tx"
            left_dashes = 2
            right_dashes = inner_width - len(stats) - left_dashes
            if right_dashes < 1:
                top_border = "╭" + "─" * inner_width + "╮"
            else:
                top_border = "╭" + "─" * left_dashes + stats + "─" * right_dashes + "╮"
        else:
            top_border = "╭" + "─" * inner_width + "╮"
        
        bottom_border = "╰" + "─" * inner_width + "╯"
        middle_line = "│" + " " * inner_width + "│"
        
        try:
            self.stdscr.addstr(box_top, box_left, top_border, curses.color_pair(1) | curses.A_DIM)
            for i in range(input_lines):
                self.stdscr.addstr(box_top + 1 + i, box_left, middle_line, curses.color_pair(1))
            self.stdscr.addstr(box_top + 1 + input_lines, box_left, bottom_border, curses.color_pair(1))
        except curses.error:
            pass
        
        input_padding = 2
        input_x = box_left + input_padding
        max_line_width = inner_width - 4  # Leave some padding
        
        # Get short model name for display (simple, no box)
        model_short = self.current_model.split("/")[-1]
        if len(model_short) > 20:
            model_short = model_short[:18] + "…"
        model_label = model_short
        model_label_width = len(model_label)
        
        try:
            # Split input into lines (handle explicit newlines)
            raw_lines = self.input_buffer.split('\n')
            
            # Wrap long lines to fit in box width
            display_lines = []
            char_positions = []  # Maps (line_idx, col) to buffer position
            buf_pos = 0
            for raw_line in raw_lines:
                if not raw_line:
                    display_lines.append("")
                    char_positions.append((buf_pos, buf_pos))
                    buf_pos += 1  # For the newline
                else:
                    # Wrap the line
                    while len(raw_line) > max_line_width:
                        display_lines.append(raw_line[:max_line_width])
                        char_positions.append((buf_pos, buf_pos + max_line_width))
                        buf_pos += max_line_width
                        raw_line = raw_line[max_line_width:]
                    display_lines.append(raw_line)
                    char_positions.append((buf_pos, buf_pos + len(raw_line)))
                    buf_pos += len(raw_line) + 1  # +1 for newline
            
            # Only show last N lines that fit
            visible_lines = display_lines[-input_lines:]
            visible_positions = char_positions[-input_lines:]
            
            # Draw each line
            cursor_screen_y = None
            cursor_screen_x = None
            for i, line in enumerate(visible_lines):
                line_y = box_top + 1 + i
                self.stdscr.addstr(line_y, input_x, line[:max_line_width])
                
                # Find cursor position
                if visible_positions and i < len(visible_positions):
                    start_pos, end_pos = visible_positions[i]
                    if start_pos <= self.cursor_pos <= end_pos:
                        cursor_screen_y = line_y
                        cursor_screen_x = input_x + (self.cursor_pos - start_pos)
            
            # Draw model name on first line (right side, dimmed)
            first_line_len = len(visible_lines[0]) if visible_lines else 0
            model_x = box_left + inner_width - model_label_width
            if model_x > input_x + first_line_len:
                self.stdscr.addstr(box_top + 1, model_x, model_label, curses.color_pair(1) | curses.A_DIM)
            
            # Draw newline hint on bottom border if input is empty
            if not self.input_buffer and not self.api_busy:
                hint = "Ctrl+O for newline"
                hint_x = box_left + inner_width - len(hint)
                self.stdscr.addstr(box_top + 1 + input_lines, hint_x, hint, curses.A_DIM)
            
            # Position cursor
            if show_cursor:
                if cursor_screen_y is not None and cursor_screen_x is not None:
                    self.stdscr.move(cursor_screen_y, cursor_screen_x)
                else:
                    # Fallback: cursor at end of last line
                    last_line_idx = len(visible_lines) - 1 if visible_lines else 0
                    last_line_len = len(visible_lines[-1]) if visible_lines else 0
                    self.stdscr.move(box_top + 1 + last_line_idx, input_x + last_line_len)
        except curses.error:
            pass
        
        # Draw activity status on the bottom border when busy
        if self.api_busy and self.activity_status:
            spinner_frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
            spinner = spinner_frames[self.animation_frame % len(spinner_frames)]
            status_text = f"{spinner} {self.activity_status}"
            hint_text = "Esc to cancel"
            
            try:
                # Draw status in bottom border (box_top + 1 + input_lines = bottom border)
                bottom_border_y = box_top + 1 + input_lines
                status_x = box_left + 2
                max_status = inner_width - len(hint_text) - 6
                self.stdscr.addstr(bottom_border_y, status_x, status_text[:max_status], curses.color_pair(2))
                # Draw hint on the right
                hint_x = box_left + inner_width - len(hint_text)
                self.stdscr.addstr(bottom_border_y, hint_x, hint_text, curses.color_pair(1) | curses.A_DIM)
            except curses.error:
                pass
    
    def draw(self):
        self.animation_frame += 1
        
        # Animate payment progress during active payment phases
        if self._payment_state in ('signing', 'sending', 'confirming', 'approving', 'opening', 'registering', 'voucher'):
            self._update_payment_animation()
        
        self.stdscr.erase()
        self.draw_header()
        self.draw_output()
        self.draw_input()
        self.stdscr.refresh()
    
    def _update_payment_animation(self):
        """Update payment line spinner and rotating messages during confirmation."""
        amount = getattr(self, '_payment_amount', 0)
        token = getattr(self, '_payment_token', 'USD')
        idx = self._find_payment_line_idx()
        if idx is None:
            return
        
        stream_limit = getattr(self, '_stream_payment_limit', 5.0)
        spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
        
        # Per-request payment states
        if self._payment_state == 'signing':
            self.output_lines[idx] = f"$ {amount:.4f} {token}  {spinner} sign  ○ send  ○ confirm"
        elif self._payment_state == 'sending':
            self.output_lines[idx] = f"$ {amount:.4f} {token}  ✓ sign  {spinner} send  ○ confirm"
        elif self._payment_state == 'confirming':
            # Slower pulse spinner during confirmation
            pulse = SPINNER_PULSE[self.animation_frame % len(SPINNER_PULSE)]
            self.output_lines[idx] = f"$ {amount:.4f} {token}  ✓ sign  ✓ send  {pulse} confirm"
            
            # Rotate shuffled messages every ~8 frames (~0.8 second)
            messages = getattr(self, '_shuffled_messages', SETTLEMENT_MESSAGES)
            msg_num = (self.animation_frame // 8) % len(messages)
            msg = messages[msg_num]
            
            # Update the message line below payment progress
            msg_line_idx = getattr(self, '_payment_msg_line_idx', None)
            if msg_line_idx is not None and 0 <= msg_line_idx < len(self.output_lines):
                self.output_lines[msg_line_idx] = f"~ {msg}"
        
        # Streaming payment states
        elif self._payment_state == 'opening':
            self.output_lines[idx] = f"⚡ Opening channel (${stream_limit:.0f} deposit)  {spinner}"
        elif self._payment_state == 'registering':
            self.output_lines[idx] = f"⚡ Opening channel (${stream_limit:.0f} deposit)  ✓"
        elif self._payment_state == 'voucher':
            self.output_lines[idx] = f"⚡ {amount:.4f} {token}  {spinner} signing voucher"
    
    def _format_tool_call(self, tool_name, tool_args, pending=False, result=None):
        """Format tool call inline like Amp: ✓ Read file.py @1-50"""
        icon = "○" if pending else "✓"
        
        # Format based on tool type
        if tool_name == "read":
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            range_str = ""
            if "read_range" in tool_args:
                r = tool_args["read_range"]
                range_str = f" @{r[0]}-{r[1]}" if isinstance(r, list) and len(r) == 2 else ""
            return f"◊ {icon} Read {short_path}{range_str}"
        
        elif tool_name == "edit":
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            # Count lines changed from result
            count = ""
            if result and (result.startswith("DIFF:") or result.startswith("WRITE:")):
                parts = result.split(":", 3)
                if len(parts) > 2:
                    count = f" {parts[2]}"
            return f"◊ {icon} Edit {short_path}{count}"
        
        elif tool_name == "write":
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            return f"◊ {icon} Write {short_path}"
        
        elif tool_name == "grep":
            pattern = tool_args.get("pattern", "")[:30]
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            return f"◊ {icon} Grep {pattern} in {short_path}"
        
        elif tool_name == "glob":
            pattern = tool_args.get("pattern", tool_args.get("filePattern", ""))[:40]
            return f"◊ {icon} Glob {pattern}"
        
        elif tool_name == "bash":
            cmd = tool_args.get("cmd", tool_args.get("command", ""))[:50]
            return f"◊ {icon} Bash {cmd}"
        
        elif tool_name == "skill":
            skill = tool_args.get("name", "")
            return f"◊ {icon} Skill {skill}"
        
        elif tool_name == "web_search":
            query = tool_args.get("query", "")[:40]
            return f"◊ {icon} Search {query}"
        
        elif tool_name == "read_url":
            url = tool_args.get("url", "")
            # Show just the domain
            if "://" in url:
                domain = url.split("://")[1].split("/")[0]
            else:
                domain = url[:30]
            return f"◊ {icon} Fetch {domain}"
        
        else:
            # Generic format
            arg_preview = ""
            if tool_args:
                first_val = str(list(tool_args.values())[0])[:30]
                arg_preview = f" {first_val}"
            return f"◊ {icon} {tool_name}{arg_preview}"
    
    def add_output(self, line):
        height, width = self.get_dims()
        margin = 3
        content_width = width - margin - 5
        
        if content_width < 20:
            content_width = 60
        
        if len(line) > content_width:
            prefix = ""
            text = line
            if line.startswith("⏺ "):
                prefix = "⏺ "
                text = line[2:]
            elif line.startswith("→ "):
                prefix = "→ "
                text = line[2:]
            elif line.startswith("$ "):
                prefix = "$ "
                text = line[2:]
            elif line.startswith("! "):
                prefix = "! "
                text = line[2:]
            elif line.startswith("⎿ "):
                prefix = "⎿ "
                text = line[2:]
            
            if prefix:
                cont_prefix = "⏺ " if prefix == "⏺ " else "  "
                while text:
                    chunk = text[:content_width]
                    text = text[content_width:]
                    self.output_lines.append(prefix + chunk)
                    prefix = cont_prefix
            else:
                while text:
                    chunk = text[:content_width]
                    text = text[content_width:]
                    self.output_lines.append(chunk)
        else:
            self.output_lines.append(line)
        
        self.scroll_offset = 0
        self.draw()
    
    def handle_resize(self):
        curses.endwin()
        self.stdscr.refresh()
        self.draw()
    
    def remove_thinking_line(self):
        """Remove the thinking indicator line from output."""
        for i in range(len(self.output_lines) - 1, -1, -1):
            if self.output_lines[i].startswith("@ Thinking"):
                self.output_lines.pop(i)
                break
    
    def remove_responding_line(self):
        """Remove the responding indicator line from output."""
        for i in range(len(self.output_lines) - 1, -1, -1):
            if self.output_lines[i].startswith("▶ Responding"):
                self.output_lines.pop(i)
                break
    
    def reinit_curses(self):
        """Refresh curses after something disrupted terminal."""
        self.stdscr.erase()
        self.stdscr.refresh()
    
    def process_command(self, cmd):
        logger.info(f"process_command: {cmd}")
        if cmd in ("/q", "exit", "/quit"):
            self.running = False
            return
        if cmd == "/c" or cmd == "/clear":
            self.messages = []
            self.output_lines = []
            self.add_output("⏺ Cleared conversation")
            return
        if cmd == "/wallet" or cmd == "/wallet address":
            self.show_wallet_inline()
            return
        if cmd == "/wallet balance":
            self.show_wallet_balance_inline()
            return
        if cmd == "/wallet transfers" or cmd.startswith("/wallet transfers "):
            self.show_wallet_transfers_inline()
            return
        if cmd == "/wallet txs":
            self.show_wallet_txs_inline()
            return
        if cmd == "/wallet channels":
            self.show_wallet_channels_inline()
            return
        if cmd.startswith("/wallet closechannel"):
            self.close_channel_command(cmd)
            return
        if cmd == "/wallet closeall":
            self.close_channel_command("/wallet closechannel all")
            return
        if cmd == "/wallet tokens":
            self.show_wallet_balance_dialog()  # Same as balance for now
            return
        if cmd == "/wallet limits" or cmd == "/wallet spending":
            self.show_key_limits()
            return
        if cmd == "/wallet fee-token" or cmd == "/wallet feetoken":
            self.show_fee_token_preferences()
            return
        if cmd == "/wallet access-key" or cmd == "/wallet key" or cmd == "/wallet keys" or cmd == "/keys" or cmd == "/key":
            self.show_keys_dialog()  # Dedicated keys dialog with limits
            return
        if cmd == "/wallet setup" or cmd == "/wallet connect":
            self.create_new_access_key()
            return
        if cmd == "/wallet faucet":
            self.request_faucet()
            return
        if cmd == "/wallet explorer":
            self.open_wallet_explorer()
            return

        if cmd == "/help":
            self.show_help()
            return
        if cmd == "/p" or cmd == "/menu" or cmd == "/commands":
            self.show_command_palette()
            return
        if cmd == "/skill" or cmd == "/skills":
            self.list_skills()
            return
        if cmd.startswith("/skill "):
            skill_name = cmd.split(" ", 1)[1].strip()
            self.load_skill(skill_name)
            return
        if cmd == "/network":
            net_info = NETWORKS[self.current_network]
            self.add_output(f"⏺ Network: {net_info['name']}")
            self.add_output(f"  RPC: {net_info['rpc']}")
            self.add_output(f"  Available: {', '.join(NETWORKS.keys())}")
            return
        if cmd.startswith("/network "):
            net_name = cmd.split(" ", 1)[1].strip().lower()
            if net_name == "mainnet" and MAINNET_BLOCKED:
                self.add_output("")
                self.add_output("🚨 MAINNET IS DISABLED 🚨")
                self.add_output("")
                self.add_output("Mainnet access keys have high storage overhead costs.")
                self.add_output("Use 'moderato' testnet until costs are optimized.")
                self.add_output("")
                self.add_output("  /network moderato")
                self.add_output("")
                return
            if net_name in NETWORKS:
                self.current_network = net_name
                self.wallet.switch_network(net_name)
                # Update legacy fields from new network's wallet
                self.account_address = self.wallet.account_address
                active_key = self.wallet.active_key
                if active_key:
                    self.private_key = active_key.private_key
                    self.key_expiry = active_key.expiry
                    self.access_key_address = active_key.address
                else:
                    self.private_key = None
                    self.key_expiry = 0
                    self.access_key_address = None
                # Clear cached balance for new network
                self.cached_balance = None
                self.last_balance_check = 0
                # Save config
                self.config = self.wallet.to_dict()
                save_config(self.config, CONFIG_FILE)
                # Update user context for new network
                self.user_context.update_from_wallet(self.wallet, self.current_network)
                net_info = NETWORKS[net_name]
                self.add_output(f"⏺ Switched to {net_info['name']}")
                if self.account_address:
                    self.add_output(f"  Wallet: {self.account_address}")
                else:
                    self.add_output(f"  No wallet configured for this network")
            else:
                self.add_output(f"! Unknown network: {net_name}")
                self.add_output(f"  Available: {', '.join(NETWORKS.keys())}")
            return
        if cmd == "/history":
            self.show_history()
            return
        if cmd == "/newkey":
            self.create_new_access_key()
            return
        if cmd == "/portal":
            self.open_portal()
            return
        if cmd == "/model" or cmd == "/models":
            self.show_model_selector()
            return
        if cmd == "/proxy":
            self.show_proxy_url_dialog()
            return
        if cmd.startswith("/proxy "):
            new_url = cmd.split(" ", 1)[1].strip()
            self.set_proxy_url(new_url)
            return
        if cmd == "/rpc":
            self.show_rpc_url_dialog()
            return
        if cmd.startswith("/rpc "):
            new_url = cmd.split(" ", 1)[1].strip()
            if new_url == "reset" or new_url == "clear":
                self.clear_rpc_url_override()
            else:
                self.set_rpc_url_override(new_url)
            return
        if cmd == "/usage":
            self.show_usage_dialog()
            return
        if cmd == "/faucet":
            self.request_faucet()
            return
        if cmd == "/explorer":
            self.open_wallet_explorer()
            return
        
        # Check if wallet is configured - if not, show delightful onboarding
        if not self.private_key:
            self.add_output("")
            self.add_output(f"→ {cmd}")
            self.add_output("")
            self.show_wallet_onboarding(cmd)
            return
        
        # Debounce rapid submissions - require 200ms between requests to prevent spam
        last_submit = getattr(self, '_last_submit_time', 0)
        now = time.time()
        if now - last_submit < 0.2:  # 200ms debounce
            return  # Silently ignore rapid repeat submissions
        self._last_submit_time = now
        
        # If API is busy, cancel old request and start new one immediately
        if self.api_busy:
            self.api_cancelled = True
            self.api_cancel_event.set()  # Signal cancellation to call_api
            self.api_busy = False
            self.activity_status = ""
            self.remove_thinking_line()
            # Clear any streaming state from old request
            if hasattr(self, '_streaming_text'):
                delattr(self, '_streaming_text')
            if hasattr(self, '_streaming_started'):
                delattr(self, '_streaming_started')
            if hasattr(self, '_streaming_line_idx'):
                delattr(self, '_streaming_line_idx')
            # Reset payment state
            self._payment_state = None
            for attr in ('_payment_line_idx', '_payment_amount', '_payment_token', '_payment_msg_line_idx'):
                if hasattr(self, attr):
                    delattr(self, attr)
            self.add_output("⏺ Interrupted")
        
        # Increment request ID - old threads will be ignored
        self.api_request_id += 1
        
        logger.info(f"User query: {cmd[:50]}...")
        self.messages.append({"role": "user", "content": cmd})
        self.add_output("")  # blank line before user message
        self.add_output(f"→ {cmd}")
        self.add_output("")  # blank line after user message
        
        # Start API call in background thread
        self.add_output("@ Thinking")
        self.api_cancelled = False
        self.api_cancel_event.clear()  # Reset cancel event for new request
        self.api_busy = True
        self.activity_status = "Calling API..."
        self.start_api_thread()
    

    
    def start_api_thread(self):
        """Start background thread for API call."""
        system_prompt = self.get_system_prompt()
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info["rpc"]
        chain_id = network_info["chain_id"]
        explorer_url = network_info["explorer"]
        
        # Capture current request ID - results with old IDs will be ignored
        my_request_id = self.api_request_id
        
        # Get fee token from wallet config
        wallet_fee_token = self.wallet.fee_token if self.wallet else None
        fee_token_addr = wallet_fee_token.address if wallet_fee_token and wallet_fee_token.is_set else ""
        fee_token_name = wallet_fee_token.symbol if wallet_fee_token and wallet_fee_token.is_set else "tokens"
        
        # Known tokens will be populated dynamically from wallet_balances tool
        known_tokens = {}
        
        # Set tool context for wallet tools
        set_tool_context({
            'account_address': self.account_address,
            'access_key_address': self.access_key_address,
            'access_key': self.private_key,
            'rpc_url': rpc_url,
            'fee_token': fee_token_addr,
            'fee_token_name': fee_token_name,
            'network': self.current_network,
            'chain_id': network_info.get('chain_id', 0),
            'known_tokens': known_tokens,
        })
        
        # Shared state for payment confirmation
        self._payment_confirm_result = None
        self._payment_confirm_pending = False
        
        def api_worker():
            try:
                def on_payment(amount_usd):
                    self.api_queue.put((my_request_id, 'payment', amount_usd))
                
                def on_status(msg):
                    self.api_queue.put((my_request_id, 'status', msg))
                
                def on_confirm(amount_usd, asset_address):
                    """Block until user confirms or declines payment."""
                    self._payment_confirm_pending = True
                    self._payment_confirm_result = None
                    self.api_queue.put((my_request_id, 'confirm_payment', {'amount_usd': amount_usd, 'asset_address': asset_address}))
                    
                    # Wait for user response (or cancellation)
                    while self._payment_confirm_result is None and my_request_id == self.api_request_id:
                        time.sleep(0.05)
                    
                    self._payment_confirm_pending = False
                    return self._payment_confirm_result if my_request_id == self.api_request_id else False
                
                def on_text_chunk(chunk):
                    """Stream text chunks to UI as they arrive.
                    
                    Returns False to cancel the stream (triggers StreamCancelled exception).
                    """
                    if self.api_cancelled or my_request_id != self.api_request_id:
                        return False  # Cancel stream if user pressed Esc or request is stale
                    self.api_queue.put((my_request_id, 'text_chunk', chunk))
                    return True
                
                def on_payment_step(step, status, tx_hash=None):
                    """Callback for payment progress updates."""
                    self.api_queue.put((my_request_id, 'payment_step', (step, status, tx_hash)))
                
                def on_stream_depleted(channel_info):
                    """Called when stream channel is depleted - ask user to increase limit."""
                    self._stream_depleted_result = None
                    self.api_queue.put((my_request_id, 'stream_depleted', channel_info))
                    
                    # Wait for user response (None = waiting, False = cancelled, float = new limit)
                    while self._stream_depleted_result is None and my_request_id == self.api_request_id:
                        time.sleep(0.05)
                    
                    result = self._stream_depleted_result
                    self._stream_depleted_result = None
                    
                    # False means cancelled - return None to signal fallback to per-request
                    if result is False:
                        return None
                    
                    if result is not None:
                        self._stream_payment_limit = result
                    return result
                
                while True:
                    # Check if this request is stale
                    if my_request_id != self.api_request_id:
                        return  # Silently exit, new request has started
                    # Check if cancelled before making API call
                    if self.api_cancelled:
                        self.api_queue.put((my_request_id, 'cancelled', None))
                        return
                    # Use a callable so streaming can be enabled mid-request (when user clicks "Always")
                    def get_stream_deposit():
                        if getattr(self, '_use_streaming_payments', False):
                            return getattr(self, '_stream_payment_limit', 5.0)
                        return None
                    
                    response = call_api(
                        self.messages, system_prompt,
                        self.private_key, self.account_address,
                        rpc_url, chain_id, on_payment, on_status, on_confirm,
                        model=self.current_model, explorer_url=explorer_url,
                        on_text_chunk=on_text_chunk, on_payment_step=on_payment_step,
                        use_direct_signing=self.wallet.direct_signing if self.wallet else False,
                        cancel_event=self.api_cancel_event,
                        stream_deposit_usd=get_stream_deposit,
                        on_stream_depleted=on_stream_depleted
                    )
                    
                    # Check if stale after API call returns
                    if my_request_id != self.api_request_id:
                        return  # Silently exit, new request has started
                    
                    content_blocks = response.get("content", [])
                    
                    # Track token usage
                    if "usage" in response:
                        self.api_queue.put((my_request_id, 'usage', response["usage"]))
                    
                    # Check for payment info and display it prominently
                    # Use req_id=-1 so payment is tracked even if user started a new request
                    if "payment" in response:
                        self.api_queue.put((-1, 'payment_success', response["payment"]))
                    tool_results = []
                    
                    for block in content_blocks:
                        if block["type"] == "text":
                            # Skip if we already streamed this text
                            if not hasattr(self, '_streaming_text') or not self._streaming_text:
                                self.api_queue.put((my_request_id, 'text', block["text"]))
                        if block["type"] == "tool_use":
                            tool_name = block["name"]
                            tool_args = block["input"]
                            logger.tool_use(tool_name, tool_args)
                            self.api_queue.put((my_request_id, 'tool_start', (tool_name, tool_args)))
                            
                            # Check if stale before running tool
                            if my_request_id != self.api_request_id:
                                return
                            
                            result = run_tool(tool_name, tool_args)
                            
                            # Check if stale after running tool
                            if my_request_id != self.api_request_id:
                                return
                            
                            # Special handling for connect_wallet tool
                            if result == "__CONNECT_WALLET__":
                                self.api_queue.put((my_request_id, 'connect_wallet', None))
                                # Wait for wallet connection to complete
                                while not hasattr(self, '_wallet_connected') and my_request_id == self.api_request_id:
                                    time.sleep(0.1)
                                if my_request_id != self.api_request_id:
                                    return
                                delattr(self, '_wallet_connected')
                                result = f"Wallet connected successfully!\nWallet: {self.account_address}\nAccess Key: {self.access_key_address}"
                            
                            logger.tool_result(tool_name, len(result))
                            self.api_queue.put((my_request_id, 'tool_result', (tool_name, result)))
                            
                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": block["id"],
                                "content": result,
                            })
                    
                    # Check if stale or cancelled after processing
                    if my_request_id != self.api_request_id or self.api_cancelled:
                        return
                    
                    self.messages.append({"role": "assistant", "content": content_blocks})
                    if not tool_results:
                        break
                    self.messages.append({"role": "user", "content": tool_results})
                
                self.api_queue.put((my_request_id, 'done', None))
            except StreamCancelled:
                # User cancelled the stream - this is expected, not an error
                self.api_queue.put((my_request_id, 'cancelled', None))
            except PaymentError as e:
                # Request failed AFTER payment was made - still track the payment
                # Use req_id=-1 so payment is tracked even if user started a new request
                if e.payment_info:
                    self.api_queue.put((-1, 'payment_success', e.payment_info))
                self.api_queue.put((my_request_id, 'error', str(e)))
            except Exception as e:
                self.api_queue.put((my_request_id, 'error', str(e)))
        
        self.api_thread = threading.Thread(target=api_worker, daemon=True)
        self.api_thread.start()
    
    def _find_payment_line_idx(self):
        """Find and return the index of an existing payment progress line, or None."""
        # First check the tracked index
        existing_idx = getattr(self, '_payment_line_idx', None)
        if existing_idx is not None and 0 <= existing_idx < len(self.output_lines):
            line = self.output_lines[existing_idx]
            if line.startswith("$ ") or "○ sign" in line or "✓ sign" in line or "⚡" in line:
                return existing_idx
        
        # Fallback: scan last 10 lines for payment pattern
        for i in range(len(self.output_lines) - 1, max(0, len(self.output_lines) - 10) - 1, -1):
            line = self.output_lines[i]
            if ("○ sign" in line or "✓ sign" in line) and ("send" in line or "confirm" in line):
                self._payment_line_idx = i
                return i
            if "⚡" in line and ("approve" in line or "open" in line or "voucher" in line):
                self._payment_line_idx = i
                return i
        return None
    
    def process_api_queue(self):
        """Process events from the API background thread."""
        try:
            while True:
                item = self.api_queue.get_nowait()
                
                # New format: (request_id, event_type, data)
                if len(item) == 3:
                    req_id, event_type, data = item
                    # Ignore events from stale requests, but allow global events (req_id == -1)
                    # Global events include payment completions which can arrive after request is cancelled
                    if req_id != -1 and req_id != self.api_request_id:
                        continue
                else:
                    # Legacy format (shouldn't happen)
                    event_type, data = item
                
                if event_type == 'payment':
                    # Remove thinking indicator - payment is happening
                    self.remove_thinking_line()
                    # Initialize payment progress - get token name from wallet config
                    self._payment_amount = data
                    wallet_fee_token = self.wallet.fee_token if self.wallet else None
                    token_name = wallet_fee_token.symbol if wallet_fee_token and wallet_fee_token.is_set else "USD"
                    self._payment_token = token_name
                    self._payment_state = 'init'
                    self._payment_started_at = time.time()  # Track total payment time
                    self.activity_status = "Processing payment..."
                    # Don't create the payment line yet - wait for first payment_step
                    # to avoid a flash before streaming starts
                elif event_type == 'payment_step':
                    # Unpack data: (step, status, extra)
                    # extra can be tx_hash (string) or channel_info (dict) depending on step
                    if len(data) >= 3:
                        step, status, extra = data[0], data[1], data[2]
                    elif len(data) == 2:
                        step, status, extra = data[0], data[1], None
                    else:
                        step, status, extra = data[0] if data else '', '', None
                    # For compatibility: tx_hash is extra when it's a string
                    tx_hash = extra if isinstance(extra, str) else None
                    amount = getattr(self, '_payment_amount', 0)
                    token = getattr(self, '_payment_token', 'USD')
                    idx = self._find_payment_line_idx()
                    
                    # Track payment state for animation
                    # Stream channel opening (one-time setup, single step)
                    if step == 'opening' and status == 'pending':
                        self._payment_state = 'opening'
                        self._is_stream_setup = True
                        spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
                        stream_limit = getattr(self, '_stream_payment_limit', 5.0)
                        progress = f"⚡ Opening channel (${stream_limit:.0f} deposit)  {spinner}"
                        if idx is None:
                            self.add_output(progress)
                            self._payment_line_idx = len(self.output_lines) - 1
                            idx = self._payment_line_idx
                    elif step == 'opening' and status == 'done':
                        self._payment_state = 'opened'
                        stream_limit = getattr(self, '_stream_payment_limit', 5.0)
                        progress = f"⚡ Opening channel (${stream_limit:.0f} deposit)  ✓"
                        if tx_hash:
                            self.add_output(f"  └─ tx: {tx_hash}")
                    elif step == 'registering' and status == 'pending':
                        self._payment_state = 'registering'
                        stream_limit = getattr(self, '_stream_payment_limit', 5.0)
                        progress = f"⚡ Opening channel (${stream_limit:.0f} deposit)  ✓"
                    elif step == 'registering' and status == 'done':
                        self._payment_state = 'registered'
                        stream_limit = getattr(self, '_stream_payment_limit', 5.0)
                        progress = f"⚡ Channel open (${stream_limit:.0f} deposit)  ✓"
                    # Voucher signing (streaming payments - instant, no on-chain tx)
                    elif step == 'voucher' and status == 'pending':
                        self._payment_state = 'voucher'
                        # Start timer for voucher payment if not already set
                        if not hasattr(self, '_payment_started_at') or self._payment_started_at == 0:
                            self._payment_started_at = time.time()
                        spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
                        progress = f"⚡ {amount:.4f} {token}  {spinner} voucher (instant)"
                        # Always create the payment line if it doesn't exist
                        if idx is None:
                            self.add_output(progress)
                            self._payment_line_idx = len(self.output_lines) - 1
                            idx = self._payment_line_idx
                    elif step == 'voucher' and status == 'done':
                        self._payment_state = 'voucher_done'
                        # Calculate elapsed time - use appropriate unit based on magnitude
                        elapsed_secs = time.time() - getattr(self, '_payment_started_at', time.time())
                        if elapsed_secs >= 1.0:
                            elapsed_str = f"{elapsed_secs:.1f}s"
                        elif elapsed_secs >= 0.001:  # >= 1ms
                            elapsed_str = f"{int(elapsed_secs * 1000)}ms"
                        elif elapsed_secs >= 0.000001:  # >= 1μs
                            elapsed_str = f"{int(elapsed_secs * 1_000_000)}μs"
                        else:  # nanoseconds
                            elapsed_str = f"{int(elapsed_secs * 1_000_000_000)}ns"
                        # Build progress line with channel info if available
                        channel_info = extra  # extra contains channel info dict
                        if channel_info and isinstance(channel_info, dict):
                            used = channel_info.get('used', 0)
                            deposit = channel_info.get('deposit', 0)
                            server = channel_info.get('server', '')
                            # Extract server hostname
                            if server:
                                try:
                                    from urllib.parse import urlparse
                                    parsed = urlparse(server)
                                    server_short = parsed.netloc or server[:30]
                                except:
                                    server_short = server[:30]
                            else:
                                server_short = ""
                            
                            pct = int(used / deposit * 100) if deposit > 0 else 0
                            if server_short:
                                progress = f"~ ⚡ ${amount:.4f} {token} → {server_short} ({elapsed_str})"
                            else:
                                progress = f"~ ⚡ ${amount:.4f} {token} ({elapsed_str})"
                        else:
                            progress = f"~ ⚡ ${amount:.4f} {token} ({elapsed_str})"
                        
                        if idx is not None and 0 <= idx < len(self.output_lines):
                            self.output_lines[idx] = progress
                        else:
                            # No existing line - append the completed payment line
                            self.add_output(progress)
                        
                        # Update session cost immediately for voucher payments
                        # This ensures cost is tracked even if request is interrupted
                        self.session_cost += amount
                        self.session_voucher_count += 1
                        self.user_context.record_payment(amount, "")  # No tx hash for vouchers
                        
                        # Clear activity status - payment is complete
                        self.activity_status = ""
                        # Clear payment state for next payment
                        self._payment_state = None
                        self._payment_line_idx = None
                        self._is_stream_setup = False
                        self._payment_started_at = 0  # Reset timer for next payment
                        self.draw()
                        return
                    elif step == 'signing' and status == 'pending':
                        self._payment_state = 'signing'
                        spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
                        progress = f"$ {amount:.4f} {token}  {spinner} sign  ○ send  ○ confirm"
                        if idx is None:
                            self.add_output(progress)
                            self._payment_line_idx = len(self.output_lines) - 1
                            idx = self._payment_line_idx
                    elif step == 'signing' and status == 'done':
                        self._payment_state = 'signed'
                        progress = f"$ {amount:.4f} {token}  ✓ sign  ○ send  ○ confirm"
                    elif step == 'sending' and status == 'pending':
                        self._payment_state = 'sending'
                        spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
                        progress = f"$ {amount:.4f} {token}  ✓ sign  {spinner} send  ○ confirm"
                    elif step == 'sending' and status == 'done':
                        self._payment_state = 'sent'
                        progress = f"$ {amount:.4f} {token}  ✓ sign  ✓ send  ○ confirm"
                    elif step == 'confirming' and status == 'pending':
                        self._payment_state = 'confirming'
                        # Don't reset _payment_started_at - we want total payment time
                        # Shuffle messages for variety each time
                        self._shuffled_messages = random.sample(SETTLEMENT_MESSAGES, len(SETTLEMENT_MESSAGES))
                        spinner = SPINNER_PULSE[self.animation_frame % len(SPINNER_PULSE)]
                        progress = f"$ {amount:.4f} {token}  ✓ sign  ✓ send  {spinner} confirm"
                        # Add placeholder line for rotating messages below payment progress
                        self.output_lines.append(f"~ {self._shuffled_messages[0]}")
                        self._payment_msg_line_idx = len(self.output_lines) - 1
                    elif step == 'confirmed':
                        self._payment_state = 'confirmed'
                        tx_hash = status if status else ""
                        # Calculate total payment time in seconds
                        elapsed = time.time() - getattr(self, '_payment_started_at', time.time())
                        elapsed_str = f"{elapsed:.1f}s"
                        # Remove the rotating meme message line entirely
                        msg_idx = getattr(self, '_payment_msg_line_idx', None)
                        if msg_idx is not None and 0 <= msg_idx < len(self.output_lines):
                            self.output_lines.pop(msg_idx)
                            # Adjust payment line idx if it was after the removed line
                            if idx is not None and msg_idx < idx:
                                idx -= 1
                        # Use ~ prefix for grey/dim rendering, include timing
                        summary = f"~ ✓ ${amount:.4f} {token} ({elapsed_str})"
                        if idx is not None and 0 <= idx < len(self.output_lines):
                            self.output_lines[idx] = summary
                        # Clear all payment state so next payment creates a fresh line
                        self._payment_state = None
                        self._payment_line_idx = None
                        self._payment_msg_line_idx = None
                        self._payment_started_at = 0  # Reset timer for next payment
                        self.draw()
                        return
                    else:
                        return
                    
                    # Update the progress line in place
                    if idx is not None and 0 <= idx < len(self.output_lines):
                        self.output_lines[idx] = progress
                    self.draw()
                elif event_type == 'confirm_payment':
                    # Store the server's exact price for this request
                    amount_usd = data['amount_usd']
                    asset_address = data['asset_address']
                    self._current_request_cost = amount_usd
                    # Show payment confirmation dialog with server's requested asset
                    confirmed = self.show_payment_confirm_dialog(amount_usd, asset_address)
                    self._payment_confirm_result = confirmed
                elif event_type == 'stream_depleted':
                    # Show dialog to increase stream limit
                    channel_info = data
                    new_limit = self.show_stream_topup_dialog(channel_info)
                    # Use False as sentinel for cancel (None means "still waiting")
                    self._stream_depleted_result = new_limit if new_limit is not None else False
                elif event_type == 'payment_success':
                    # Track session totals
                    tx_hash = data.get("tx_hash", "")
                    amount = data.get("amount_usd", 0)
                    is_stream = data.get("stream", False)
                    
                    # Stream payments are already tracked in voucher/done handler
                    # Only track on-chain payments here to avoid double-counting
                    if not is_stream:
                        self.session_cost += amount
                        self.session_tx_count += 1
                        # Update user context with payment
                        self.user_context.record_payment(amount, tx_hash)
                    
                    # Store tx for potential click handling (only if we have a tx hash)
                    if tx_hash:
                        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
                        explorer_url = data.get("explorer_url", f"{network_info['explorer']}/tx/{tx_hash}")
                        self._last_tx = {"hash": tx_hash, "url": explorer_url}
                    
                    # Refresh balance after payment (with small delay for on-chain payments)
                    # to allow RPC to sync the latest state
                    self.last_balance_check = 0
                    if tx_hash and not is_stream:
                        def delayed_refresh():
                            time.sleep(0.5)
                            self.refresh_balance_async()
                        threading.Thread(target=delayed_refresh, daemon=True).start()
                    else:
                        self.refresh_balance_async()
                elif event_type == 'status':
                    self.status_message = data
                elif event_type == 'usage':
                    tokens = data.get("tokens", 0)
                    prompt_tokens = data.get("prompt_tokens", 0)
                    self.session_tokens += tokens
                    if prompt_tokens > 0:
                        self.context_tokens = prompt_tokens  # Track current context size
                    # Update user context with token usage
                    if tokens > 0:
                        self.user_context.record_usage(tokens)
                    # Reset streaming cost estimate (actual cost comes from payment)
                    self._streaming_cost = 0.0
                    self._streaming_token_count = 0
                elif event_type == 'text_chunk':
                    # Handle streaming text chunk
                    self.activity_status = "Streaming response..."
                    self.remove_thinking_line()
                    if not hasattr(self, '_streaming_text'):
                        self._streaming_text = ""
                        self._streaming_started = False
                        self._streaming_char_count = 0
                        # Get the server's exact price from the 402 response
                        self._streaming_target_cost = getattr(self, '_current_request_cost', 0)
                        self._streaming_cost = 0.0
                        # Show "Responding" indicator (like Amp's blue indicator)
                        self.add_output("▶ Responding")
                        self.draw()
                    
                    self._streaming_text += data
                    self._streaming_char_count += len(data)
                    
                    # Smooth interpolation: cost rises as we stream, approaching target
                    # Use a curve that starts slow and accelerates (most cost is output tokens)
                    # Assume ~2000 chars typical response, but cap progress at 95% until done
                    chars = self._streaming_char_count
                    # Logarithmic curve for smooth visual: rapid early rise, then gradual
                    import math
                    progress = min(0.95, math.log1p(chars / 200) / 4)  # Caps at ~95%
                    self._streaming_cost = self._streaming_target_cost * progress
                    
                    # Update the display with current streamed text
                    if not self._streaming_started:
                        self._streaming_started = True
                        self.remove_responding_line()
                        self.add_output("")
                    
                    # Re-render the streaming lines
                    lines = self._streaming_text.split("\n")
                    # Remove old streaming lines and add updated ones
                    while self.output_lines and self.output_lines[-1].startswith("⏺ "):
                        self.output_lines.pop()
                    # Wrap long lines to fit terminal width
                    height, width = self.get_dims()
                    content_width = width - 3 - 5  # Match render_line calculation
                    if content_width < 20:
                        content_width = 60
                    for line in lines:
                        text = line
                        first = True
                        while len(text) > content_width:
                            chunk = text[:content_width]
                            text = text[content_width:]
                            self.output_lines.append(f"⏺ {chunk}")
                            first = False
                        self.output_lines.append(f"⏺ {text}")
                    self.scroll_offset = 0
                    self.draw()
                elif event_type == 'text':
                    # Full text (non-streaming fallback)
                    self.add_output("")
                    for text_line in data.split("\n"):
                        self.add_output(f"⏺ {text_line}")
                elif event_type == 'tool_start':
                    # Reset streaming state when tool starts
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    self._streaming_cost = 0.0
                    self._streaming_token_count = 0
                    tool_name, tool_args = data
                    self.activity_status = f"Running {tool_name}..."
                    # Store for tool_result to update inline
                    self._current_tool = tool_name
                    self._current_tool_args = tool_args
                    # Format inline like Amp: "○ Read file.py @1-50"
                    tool_display = self._format_tool_call(tool_name, tool_args, pending=True)
                    self.add_output(tool_display)
                    self._tool_line_idx = len(self.output_lines) - 1
                elif event_type == 'tool_result':
                    tool_name, result = data
                    tool_args = getattr(self, '_current_tool_args', {})
                    tool_line_idx = getattr(self, '_tool_line_idx', None)
                    
                    # Update the tool line to show checkmark (completed)
                    tool_display = self._format_tool_call(tool_name, tool_args, pending=False, result=result)
                    if tool_line_idx is not None and 0 <= tool_line_idx < len(self.output_lines):
                        self.output_lines[tool_line_idx] = tool_display
                    
                    # Show diff for edit operations
                    result_lines = result.split("\n")
                    if result.startswith("DIFF:") or result.startswith("WRITE:"):
                        for line in result_lines[1:]:
                            if " + " in line[:8]:
                                self.add_output(f"+DIFF{line}")
                            elif " - " in line[:8]:
                                self.add_output(f"-DIFF{line}")
                    
                    self.draw()
                elif event_type == 'connect_wallet':
                    self.add_output("$ Opening browser to connect wallet...")
                    # This needs special handling - mark for main loop
                    self._pending_wallet_connect = True
                elif event_type == 'done':
                    self.remove_thinking_line()
                    self.api_busy = False
                    self.api_cancelled = False
                    self.status_message = ""
                    self.activity_status = ""
                    # Reset streaming state
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    # Reset payment state
                    for attr in ('_payment_line_idx', '_payment_amount', '_payment_token'):
                        if hasattr(self, attr):
                            delattr(self, attr)
                elif event_type == 'cancelled':
                    self.remove_thinking_line()
                    self.api_busy = False
                    self.api_cancelled = False
                    self.status_message = ""
                    self.activity_status = ""
                    # Reset streaming state
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    # Remove the rotating meme message line if it exists
                    msg_idx = getattr(self, '_payment_msg_line_idx', None)
                    if msg_idx is not None and 0 <= msg_idx < len(self.output_lines):
                        self.output_lines.pop(msg_idx)
                    # Reset payment state
                    self._payment_state = None
                    for attr in ('_payment_line_idx', '_payment_amount', '_payment_token', '_payment_msg_line_idx'):
                        if hasattr(self, attr):
                            delattr(self, attr)
                    self.add_output("! Cancelled")
                elif event_type == 'error':
                    self.remove_thinking_line()
                    # Reset streaming state
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    # Remove the rotating meme message line if it exists
                    msg_idx = getattr(self, '_payment_msg_line_idx', None)
                    if msg_idx is not None and 0 <= msg_idx < len(self.output_lines):
                        self.output_lines.pop(msg_idx)
                    # Reset payment state
                    self._payment_state = None
                    for attr in ('_payment_line_idx', '_payment_amount', '_payment_token', '_payment_msg_line_idx'):
                        if hasattr(self, attr):
                            delattr(self, attr)
                    error_msg = data
                    logger.error(error_msg)
                    if "402" in error_msg and not self.private_key:
                        self.add_output("")
                        self.add_output("! Payment required - wallet not configured")
                        self.add_output("  Use /wallet to connect and start paying with stablecoins")
                    else:
                        self.add_output(f"! Error: {error_msg}")
                    self.api_busy = False
                    self.status_message = ""
                    self.activity_status = ""
                elif event_type == 'tx_event':
                    tx_event_type = data.get("tx_event_type")
                    payload = data.get("payload", {})
                    meta = payload.get("meta")
                    tx_hash = payload.get("tx_hash", "")
                    
                    if tx_event_type == "confirmed":
                        logger.info(f"TX confirmed: {tx_hash}, kind={meta.kind if meta else 'unknown'}")
                        self.last_balance_check = 0
                        self.refresh_balance_async()
                    elif tx_event_type == "failed":
                        error = payload.get("error", "unknown error")
                        logger.error(f"TX failed: {tx_hash}, error={error}")
                        # Check for key revocation error
                        if "has been revoked" in str(error) or "access key has been revoked" in str(error):
                            self._handle_key_revoked()
                elif event_type == 'access_key_revoked':
                    # Background revocation monitor detected revoked key
                    if not self._key_revoked_intercept:
                        logger.info(f"Access key revoked detected: {data.get('address', '')}")
                        self._trigger_revocation_intercept()
        except queue.Empty:
            pass
    
    def _handle_key_revoked(self):
        """Handle key revocation detected from transaction failure."""
        if self.wallet and self.wallet.active_key:
            self.wallet.active_key._is_revoked = True
        self._trigger_revocation_intercept()
    
    def _trigger_revocation_intercept(self):
        """Set up revocation intercept - block next command until resolved."""
        self._key_revoked_intercept = True
        self._revoked_key_address = self.access_key_address
        
        self.add_output("")
        self.add_output("╔═══════════════════════════════════════════════════════╗")
        self.add_output("║              🔑 ACCESS KEY REVOKED 🔑                 ║")
        self.add_output("║                                                       ║")
        self.add_output("║  Your access key has been revoked on-chain.           ║")
        self.add_output("║  Press Enter to select a new key or create one.       ║")
        self.add_output("╚═══════════════════════════════════════════════════════╝")
        self.add_output("")
        self.draw()
    
    def _start_revocation_monitor(self):
        """Start background thread that polls for access key revocation."""
        if self._revocation_thread and self._revocation_thread.is_alive():
            return
        self._revocation_stop_event.clear()
        self._revocation_thread = threading.Thread(
            target=self._revocation_monitor_loop,
            name="revocation-monitor",
            daemon=True,
        )
        self._revocation_thread.start()
        logger.info("Revocation monitor started")
    
    def _stop_revocation_monitor(self):
        """Stop the revocation monitor thread."""
        self._revocation_stop_event.set()
        if self._revocation_thread:
            self._revocation_thread.join(timeout=1.0)
    
    def _revocation_monitor_loop(self):
        """Background loop that checks if active key is revoked every 5 seconds."""
        last_reported_key = None
        
        while not self._revocation_stop_event.is_set():
            try:
                active_key = self.wallet.active_key if self.wallet else None
                account = self.wallet.account_address if self.wallet else ""
                rpc_url = self.get_rpc_url()
                
                if account and active_key and active_key.address:
                    ok = active_key.fetch_from_chain(account, rpc_url)
                    if ok and active_key.is_revoked:
                        if last_reported_key != active_key.address:
                            last_reported_key = active_key.address
                            self.api_queue.put((-1, 'access_key_revoked', {
                                'address': active_key.address,
                                'label': getattr(active_key, 'label', ''),
                            }))
                    self._last_revocation_check = time.time()
            except Exception as e:
                logger.debug(f"Revocation check failed: {e}")
            
            self._revocation_stop_event.wait(5.0)
    
    def _get_valid_alternate_keys(self) -> list[tuple[int, 'AccessKey']]:
        """Find valid (non-revoked, non-expired) alternate keys."""
        valid = []
        if not self.wallet:
            return valid
        
        account = self.wallet.account_address
        rpc_url = self.get_rpc_url()
        active_idx = self.wallet.active_key_index
        
        for idx, key in enumerate(self.wallet.access_keys):
            if idx == active_idx:
                continue
            try:
                key.fetch_from_chain(account, rpc_url)
            except Exception:
                pass
            if not key.is_revoked and not key.is_expired:
                valid.append((idx, key))
        return valid
    
    def _apply_key_switch(self, key_index: int):
        """Apply a key switch - update runtime state and persist."""
        self.wallet.active_key_index = key_index
        key = self.wallet.active_key
        
        self.private_key = key.private_key if key else ""
        self.access_key_address = key.address if key else ""
        self.key_expiry = key.expiry if key else 0
        
        self.cached_spending_limit = None
        self.last_spending_limit_check = 0
        
        save_config(self.wallet.to_dict(), CONFIG_FILE)
        self.config = self.wallet.to_dict()
        
        rpc_url = self.get_rpc_url()
        if self.private_key and self.account_address:
            self.init_transaction_sender_with_listener(rpc_url)
            # Reinit stream manager with new key
            network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
            init_stream_manager(
                private_key=self.private_key,
                wallet_address=self.account_address,
                chain_id=network_info.get("chain_id"),
                rpc_url=rpc_url,
                force=True,  # Force reinit with new key
            )
        
        self._key_revoked_intercept = False
        self._revoked_key_address = ""
        
        # Check for orphaned channels after key switch
        self._show_orphaned_channels_warning()
    
    def _show_orphaned_channels_warning(self):
        """Show warning about channels that can't be used with the current key."""
        from .streaming import get_stream_manager
        manager = get_stream_manager()
        if not manager:
            return
        
        orphaned = manager.get_orphaned_channels()
        if not orphaned:
            return
        
        total_locked = sum(ch.remaining_balance() for ch in orphaned)
        total_locked_usd = total_locked / 1_000_000  # Assume 6 decimals
        
        self.add_output("")
        self.add_output("⚠ Orphaned streaming channels detected:")
        for ch in orphaned[:3]:  # Show max 3
            remaining = ch.remaining_balance() / 1_000_000
            expiry_str = time.strftime("%Y-%m-%d %H:%M", time.localtime(ch.expiry))
            signer_short = ch.effective_signer[:10] + "..."
            self.add_output(f"  • ${remaining:.2f} locked (signer: {signer_short}, expires: {expiry_str})")
        if len(orphaned) > 3:
            self.add_output(f"  ... and {len(orphaned) - 3} more")
        self.add_output(f"  Total locked: ${total_locked_usd:.2f}")
        self.add_output("  Funds will be returned when channels expire or server finalizes.")
        self.add_output("")
    
    def _run_revoked_key_flow(self):
        """Handle revoked key - show key picker or open browser for new key."""
        valid_keys = self._get_valid_alternate_keys()
        
        if valid_keys:
            selected = self._show_key_picker(valid_keys)
            if selected is not None:
                self._apply_key_switch(selected)
                self.add_output(f"✓ Switched to key: {self.access_key_address[:10]}...")
        else:
            self._show_no_keys_prompt()
    
    def _show_key_picker(self, keys: list[tuple[int, 'AccessKey']]) -> int | None:
        """Show curses modal to pick an alternate key. Returns key index or None."""
        height, width = self.get_dims()
        box_height = min(len(keys) + 6, height - 4)
        box_width = min(60, width - 4)
        start_y = (height - box_height) // 2
        start_x = (width - box_width) // 2
        
        selected = 0
        
        while True:
            self.stdscr.clear()
            
            for y in range(box_height):
                for x in range(box_width):
                    try:
                        if y == 0 or y == box_height - 1:
                            self.stdscr.addch(start_y + y, start_x + x, '═')
                        elif x == 0 or x == box_width - 1:
                            self.stdscr.addch(start_y + y, start_x + x, '║')
                    except curses.error:
                        pass
            
            try:
                self.stdscr.addch(start_y, start_x, '╔')
                self.stdscr.addch(start_y, start_x + box_width - 1, '╗')
                self.stdscr.addch(start_y + box_height - 1, start_x, '╚')
                self.stdscr.addch(start_y + box_height - 1, start_x + box_width - 1, '╝')
            except curses.error:
                pass
            
            title = " Select Access Key "
            title_x = start_x + (box_width - len(title)) // 2
            try:
                self.stdscr.addstr(start_y, title_x, title, curses.A_BOLD)
            except curses.error:
                pass
            
            for i, (idx, key) in enumerate(keys):
                y = start_y + 2 + i
                label = getattr(key, 'label', '') or f"Key {idx + 1}"
                addr = key.address[:8] + "..." + key.address[-6:] if key.address else "Unknown"
                expiry = key.time_remaining if hasattr(key, 'time_remaining') else ""
                line = f"  {label}: {addr}"
                if expiry:
                    line += f" ({expiry})"
                
                attr = curses.A_REVERSE if i == selected else 0
                try:
                    self.stdscr.addstr(y, start_x + 2, line[:box_width - 4].ljust(box_width - 4), attr)
                except curses.error:
                    pass
            
            hint = "↑↓ Navigate  Enter: Select  Esc: Cancel"
            hint_y = start_y + box_height - 2
            try:
                self.stdscr.addstr(hint_y, start_x + 2, hint[:box_width - 4], curses.A_DIM)
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            if ch == curses.KEY_UP:
                selected = (selected - 1) % len(keys)
            elif ch == curses.KEY_DOWN:
                selected = (selected + 1) % len(keys)
            elif ch == 10 or ch == 13:
                self.draw()
                return keys[selected][0]
            elif ch == 27:
                self.draw()
                return None
    
    def _show_no_keys_prompt(self):
        """Show prompt when no valid alternate keys exist."""
        height, width = self.get_dims()
        box_height = 8
        box_width = min(55, width - 4)
        start_y = (height - box_height) // 2
        start_x = (width - box_width) // 2
        
        while True:
            self.stdscr.clear()
            
            for y in range(box_height):
                for x in range(box_width):
                    try:
                        if y == 0 or y == box_height - 1:
                            self.stdscr.addch(start_y + y, start_x + x, '═')
                        elif x == 0 or x == box_width - 1:
                            self.stdscr.addch(start_y + y, start_x + x, '║')
                    except curses.error:
                        pass
            
            try:
                self.stdscr.addch(start_y, start_x, '╔')
                self.stdscr.addch(start_y, start_x + box_width - 1, '╗')
                self.stdscr.addch(start_y + box_height - 1, start_x, '╚')
                self.stdscr.addch(start_y + box_height - 1, start_x + box_width - 1, '╝')
            except curses.error:
                pass
            
            title = " No Valid Keys "
            title_x = start_x + (box_width - len(title)) // 2
            try:
                self.stdscr.addstr(start_y, title_x, title, curses.A_BOLD)
                self.stdscr.addstr(start_y + 2, start_x + 2, "No other valid access keys found.")
                self.stdscr.addstr(start_y + 4, start_x + 2, "Press Enter to open browser and create one.")
                self.stdscr.addstr(start_y + 5, start_x + 2, "Press Esc to cancel.")
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            if ch == 10 or ch == 13:
                self.draw()
                self.create_new_access_key()
                if self.private_key:
                    self._key_revoked_intercept = False
                    self._revoked_key_address = ""
                return
            elif ch == 27:
                self.draw()
                return
    
    def list_skills(self):
        """List available and loaded skills."""
        if self.loaded_skills:
            self.add_output(f"⏺ Loaded skills: {', '.join(self.loaded_skills)}")
        else:
            self.add_output("⏺ No skills loaded")
        
        # Collect skills from both presto package and user config
        available = set()
        
        # Presto built-in skills
        if os.path.isdir(PRESTO_SKILLS_DIR):
            for name in os.listdir(PRESTO_SKILLS_DIR):
                skill_path = os.path.join(PRESTO_SKILLS_DIR, name, "SKILL.md")
                if os.path.isfile(skill_path):
                    available.add(name)
        
        # User skills
        if os.path.isdir(USER_SKILLS_DIR):
            for name in os.listdir(USER_SKILLS_DIR):
                skill_path = os.path.join(USER_SKILLS_DIR, name, "SKILL.md")
                if os.path.isfile(skill_path):
                    available.add(name)
        
        available = sorted(available)
        if available:
            self.add_output(f"  Available: {', '.join(available[:10])}")
            if len(available) > 10:
                self.add_output(f"  ... and {len(available) - 10} more")
        else:
            self.add_output("  No skills found")
    
    def load_skill(self, skill_name):
        """Load a skill by name from presto package or user config."""
        # Check presto built-in skills first
        skill_path = os.path.join(PRESTO_SKILLS_DIR, skill_name, "SKILL.md")
        
        # Fall back to user skills
        if not os.path.isfile(skill_path):
            skill_path = os.path.join(USER_SKILLS_DIR, skill_name, "SKILL.md")
        
        if not os.path.isfile(skill_path):
            self.add_output(f"! Skill not found: {skill_name}")
            self.add_output(f"  Checked: {PRESTO_SKILLS_DIR}/{skill_name}/")
            self.add_output(f"  Checked: {USER_SKILLS_DIR}/{skill_name}/")
            return
        
        try:
            with open(skill_path, 'r') as f:
                content = f.read()
            
            if skill_name in self.loaded_skills:
                self.add_output(f"⏺ Skill already loaded: {skill_name}")
                return
            
            self.loaded_skills.append(skill_name)
            self.skill_instructions += f"\n\n<loaded_skill name=\"{skill_name}\">\n{content}\n</loaded_skill>\n"
            self.add_output(f"⏺ Loaded skill: {skill_name}")
        except Exception as e:
            self.add_output(f"! Error loading skill: {e}")
    
    def get_system_prompt(self):
        """Build system prompt optimized for reliable tool use."""
        tools_summary = get_tools_summary()
        rpc_url = self.get_rpc_url()
        cwd = os.getcwd()
        
        # Get terminal dimensions for formatting guidance
        try:
            term_height, term_width = self.get_dims()
        except:
            term_width = 80
        
        wallet_status = f"Connected: {self.account_address}" if self.account_address else "NOT CONNECTED - use connect_wallet tool to set up"
        
        prompt = f"""You are Presto, a powerful AI coding agent that runs in the terminal. You help users with software engineering tasks.

# Agency
You take initiative. When the user asks you to do something:
1. Use your tools to understand the codebase and context
2. Make changes and complete the task
3. Verify your work (run tests, check for errors)
4. Continue iterating until the task is done

Do not ask for permission or confirmation - just do the work. If something fails, try to fix it.

# Environment
- Working directory: {cwd}
- Network: {self.current_network}
- Wallet: {wallet_status}
- RPC: {rpc_url}

# Tools
{tools_summary}

# How to Work

## Reading and Understanding Code
- Use `glob` to find files by pattern (e.g., "**/*.py", "src/**/*.ts")
- Use `grep` to search for text/patterns in files
- Use `read` to view file contents
- Always explore the codebase before making changes

## Making Changes
- Use `edit` for surgical changes to existing files (provide old_str and new_str)
- Use `write` to create new files or completely rewrite existing ones
- Use `bash` to run commands (build, test, install dependencies)

## Verification
After making changes:
- Run relevant tests if they exist
- Check for syntax/type errors
- Verify the change works as expected

# Style Guide
- Be concise and direct. Skip unnecessary preamble.
- When you use a tool, briefly explain what you're doing and why.
- After completing a task, give a short summary of what you did.
## Formatting for Terminal
Terminal width: {term_width} chars. Adapt your output to fit:
- Tables: right-align numbers, consistent column widths
- Truncate hashes/addresses to fit terminal: 0x1234...5678 (show first 6 + last 4)
- NO markdown links [text](url) - they don't render. Show plain URLs on separate lines if needed.
- Keep ALL lines under {min(term_width - 5, 100)} chars - this is critical for readability
- For transaction lists: # | Short Hash | Amount | Token (no URLs in table)

# Wallet & Blockchain Tools
- `wallet_balances` - Get all token balances with total. USE THIS FOR "what is my balance"
- `wallet_info` - Get wallet address and access key
- `wallet_transfers` - Get transfer history
- `send_token(to, amount, token)` - Send tokens

When user asks:
- "my balance", "how much" → wallet_balances (shows total + breakdown)
- "my address" → wallet_info
- "my transfers" → wallet_transfers
- "send X to Y" → send_token

# Sending Tokens (CORE CAPABILITY)
When user asks to send/transfer tokens:
1. Use `wallet_balances` to see what tokens are in the wallet and get their symbols
2. Use `send_token(to, amount, token)` with the token symbol or address
3. If "to myself" → get address from wallet_info first

DO NOT search the codebase or load skills for sending tokens.

# Skills (Load On Demand)
Skills are instruction packs for domain-specific workflows. Use `load_skill(name="...")` to load.

Built-in skills:
- `wallet` — Self-query reference: balances, access keys, transfers, spending limits
- `pytempo` — Tempo SDK patterns: signing, keychain, transactions, RPC helpers

When to load skills vs use built-in tools:
- Use built-in tools (wallet_info, check_balance, send_token, etc.) for direct actions
- Load `pytempo` skill when writing Python code that uses the Tempo SDK
- Load `wallet` skill when you need to understand wallet internals or write custom queries

To list all available skills: `load_skill(list_only=true)`

IMPORTANT: Use tools to get real data. Never guess or fabricate information."""

        if self.skill_instructions:
            prompt += "\n\n# Loaded Skills\n" + self.skill_instructions
        
        # Inject user context for wallet/balance/spending awareness
        prompt += self.user_context.to_prompt_block()
        
        return prompt
    
    def show_history(self):
        if not self.account_address:
            self.add_output("! No wallet connected")
            return
        
        self.add_output("⏺ Fetching transaction history...")
        try:
            chain_id = self.get_chain_id()
            # Query transfers TO this address (received) - include contract address for token lookup
            received_query = f'SELECT block_num, "from", value, log_addr FROM transfer WHERE chain = {chain_id} AND "to" = \'{self.account_address.lower()}\' ORDER BY block_num DESC LIMIT 5'
            # Query transfers FROM this address (sent)
            sent_query = f'SELECT block_num, "to", value, log_addr FROM transfer WHERE chain = {chain_id} AND "from" = \'{self.account_address.lower()}\' ORDER BY block_num DESC LIMIT 5'
            
            import subprocess
            import json
            from .rpc import get_token_metadata
            
            network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
            rpc_url = network_info["rpc"]
            
            # Cache for token metadata to avoid repeated RPC calls
            token_cache = {}
            
            def get_token_info(token_addr: str) -> tuple[str, int]:
                """Get token symbol and decimals from contract."""
                if not token_addr:
                    return "???", 6
                token_addr = token_addr.lower()
                if token_addr not in token_cache:
                    try:
                        metadata = get_token_metadata(token_addr, rpc_url)
                        token_cache[token_addr] = (metadata.get("name") or "???", metadata.get("decimals") or 6)
                    except Exception:
                        token_cache[token_addr] = ("???", 6)
                return token_cache[token_addr]
            
            # Get received transfers
            received_result = subprocess.run(
                ["idxs", "query", received_query, "--signature", "event Transfer(address indexed from, address indexed to, uint256 value)", "--format", "json"],
                capture_output=True, text=True, timeout=30
            )
            # Get sent transfers
            sent_result = subprocess.run(
                ["idxs", "query", sent_query, "--signature", "event Transfer(address indexed from, address indexed to, uint256 value)", "--format", "json"],
                capture_output=True, text=True, timeout=30
            )
            
            received = json.loads(received_result.stdout) if received_result.returncode == 0 and received_result.stdout.strip() else []
            sent = json.loads(sent_result.stdout) if sent_result.returncode == 0 and sent_result.stdout.strip() else []
            
            if not received and not sent:
                self.add_output("  No transactions found")
                return
            
            self.add_output("")
            if received:
                self.add_output("  Received:")
                for tx in received[:5]:
                    token_addr = tx.get("log_addr", "")
                    name, decimals = get_token_info(token_addr)
                    value = int(tx.get("value", 0)) / (10 ** decimals)
                    from_addr = tx.get("from", "?")
                    self.add_output(f"    {value:.4f} {name} from {from_addr}")
            
            if sent:
                self.add_output("  Sent:")
                for tx in sent[:5]:
                    token_addr = tx.get("log_addr", "")
                    name, decimals = get_token_info(token_addr)
                    value = int(tx.get("value", 0)) / (10 ** decimals)
                    to_addr = tx.get("to", "?")
                    self.add_output(f"    {value:.4f} {name} to {to_addr}")
            explorer_url = f"{network_info['explorer']}/address/{self.account_address}"
            self.add_output(f"\n  Full history: {explorer_url}")
            
        except FileNotFoundError:
            self.add_output("! 'idxs' CLI not found")
        except subprocess.TimeoutExpired:
            self.add_output("! Query timed out")
        except Exception as e:
            self.add_output(f"! Error: {e}")
    
    def request_faucet(self, show_command=True):
        """Request testnet funds via tempo_fundAddress RPC."""
        # Show command as user input (conversation style)
        if show_command:
            self.add_output("")
            self.add_output("→ /faucet")
            self.add_output("")
        
        if not self.account_address:
            self.add_output("! No wallet configured. Run /wallet first.")
            return
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info["rpc"]
        
        # Get fee token name from wallet config
        wallet_fee_token = self.wallet.fee_token if self.wallet else None
        fee_token_name = wallet_fee_token.symbol if wallet_fee_token and wallet_fee_token.is_set else "tokens"
        
        # Show progress
        self.add_output(f"@ Requesting {fee_token_name} from faucet...")
        self.draw()
        
        try:
            import subprocess
            import json
            
            # Fund only the root wallet (access key draws from wallet balance)
            addresses_to_fund = [("Wallet", self.account_address)]
            
            total_tokens = 0
            all_tx_hashes = []
            
            for label, addr in addresses_to_fund:
                req_body = json.dumps({
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tempo_fundAddress",
                    "params": [addr],
                })
                
                result = subprocess.run(
                    ["curl", "-s", "-X", "POST", rpc_url,
                     "-H", "Content-Type: application/json",
                     "-d", req_body],
                    capture_output=True, text=True, timeout=30
                )
                
                response = json.loads(result.stdout)
                
                if "error" in response:
                    error_msg = response["error"].get("message", "Unknown error")
                    self.add_output(f"  ✗ {label}: {error_msg}")
                    continue
                
                tx_hashes = response.get("result", [])
                if tx_hashes:
                    total_tokens += len(tx_hashes)
                    for tx_hash in tx_hashes:
                        all_tx_hashes.append((label, tx_hash))
            
            if total_tokens > 0:
                # Replace progress with success
                self.output_lines[-1] = f"✓ Received {total_tokens} token(s)!"
                for label, tx_hash in all_tx_hashes:
                    self.add_output(f"  {label}: {tx_hash}")
                # Force balance refresh after short delay for indexing
                self.cached_balance = None
                self.last_balance_check = 0
                time.sleep(1)  # Wait for tx to be indexed
                self.refresh_balance_async()
            else:
                self.output_lines[-1] = "✓ Faucet request sent"
                
        except subprocess.TimeoutExpired:
            self.output_lines[-1] = "✗ Faucet request timed out"
        except json.JSONDecodeError:
            self.output_lines[-1] = "✗ Invalid response from faucet"
        except Exception as e:
            self.output_lines[-1] = f"✗ Faucet error: {e}"
    
    def open_wallet_explorer(self):
        """Open block explorer on wallet address page."""
        import webbrowser
        
        if not self.account_address:
            self.add_output("! No wallet configured. Run /wallet first.")
            return
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        explorer_url = network_info.get("explorer", "https://explore.tempo.xyz")
        url = f"{explorer_url}/address/{self.account_address}"
        
        webbrowser.open(url)
        self.add_output(f"⏺ Opened explorer: {url}")
    
    def open_portal(self):
        """Open a local web portal showing wallet info."""
        import http.server
        import webbrowser
        import threading
        import socket
        
        # Find a free port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            port = s.getsockname()[1]
        
        # Get balance from cache
        balance = self.cached_balance or "..."
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        explorer_url = network_info.get("explorer", "https://explore.tempo.xyz")
        rpc_url = network_info["rpc"]
        chain_id = network_info["chain_id"]
        
        # Get fee token from wallet config
        wallet_fee_token = self.wallet.fee_token if self.wallet else None
        fee_token_address = wallet_fee_token.address if wallet_fee_token and wallet_fee_token.is_set else ""
        fee_token_name = wallet_fee_token.symbol if wallet_fee_token and wallet_fee_token.is_set else "tokens"
        
        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Presto · Wallet</title>
<style>
:root {{
  --bg-primary: #111111;
  --bg-surface: #1a1a1a;
  --bg-card: #222222;
  --bg-card-header: #191919;
  --border-primary: #262626;
  --border-secondary: #2a2a2a;
  --content-primary: #f5f5f5;
  --content-secondary: #a0a0a0;
  --content-tertiary: #6e6e6e;
  --content-positive: #22c55e;
  --accent: #60a5fa;
  --accent-dim: rgba(96, 165, 250, 0.1);
  --font-display: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
  --font-mono: ui-monospace, 'SF Mono', Menlo, Monaco, monospace;
}}
*, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
html {{ background: var(--bg-primary); color: var(--content-primary); }}
body {{ font-family: var(--font-display); min-height: 100vh; line-height: 1.5; }}

.header {{
  border-bottom: 1px solid var(--border-primary);
  padding: 16px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: var(--bg-surface);
}}
.header-left {{ display: flex; align-items: center; gap: 12px; }}
.tempo-wordmark {{ height: 24px; width: auto; fill: var(--content-primary); }}
.presto-badge {{
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 8px;
  background: var(--accent-dim);
  border: 1px solid rgba(96, 165, 250, 0.2);
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--accent);
}}
.badge {{
  background: var(--bg-card);
  border: 1px solid var(--border-secondary);
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  color: var(--content-secondary);
  text-decoration: none;
}}
.badge:hover {{ background: var(--bg-card-header); }}
.badge.live {{ color: var(--content-positive); }}
.badge.live::before {{ content: '●'; margin-right: 6px; }}

.main {{ max-width: 720px; margin: 0 auto; padding: 32px 24px; }}

.balance-card {{
  background: linear-gradient(135deg, #1a1a2e 0%, #1a1a1a 100%);
  border: 1px solid #2a2a3a;
  border-radius: 16px;
  padding: 32px;
  margin-bottom: 24px;
}}
.balance-label {{ font-size: 13px; color: var(--content-tertiary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }}
.balance-value {{ font-size: 42px; font-weight: 600; color: var(--accent); font-variant-numeric: tabular-nums; }}
.balance-value .symbol {{ font-size: 24px; color: var(--content-secondary); margin-left: 8px; }}

.section {{ margin-bottom: 24px; }}
.section-title {{ font-size: 11px; color: var(--content-tertiary); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; font-weight: 500; }}

.card {{
  background: var(--bg-card);
  border: 1px solid var(--border-secondary);
  border-radius: 12px;
  overflow: hidden;
}}
.card-row {{
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-primary);
}}
.card-row:last-child {{ border-bottom: none; }}
.card-row:hover {{ background: var(--bg-card-header); }}
.card-label {{ color: var(--content-secondary); font-size: 14px; }}
.card-value {{ font-family: var(--font-mono); font-size: 13px; color: var(--content-primary); }}
.card-value a {{ color: var(--accent); text-decoration: none; }}
.card-value a:hover {{ text-decoration: underline; }}
.card-value.full {{ word-break: break-all; }}

.address-card {{
  background: var(--bg-card);
  border: 1px solid var(--border-secondary);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 12px;
}}
.address-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
.address-type {{ font-size: 12px; color: var(--content-tertiary); text-transform: uppercase; letter-spacing: 0.5px; }}
.address-value {{
  font-family: var(--font-mono);
  font-size: 14px;
  color: var(--content-primary);
  word-break: break-all;
  background: var(--bg-card-header);
  padding: 12px 16px;
  border-radius: 8px;
  border: 1px solid var(--border-primary);
}}
.address-value a {{ color: inherit; text-decoration: none; }}
.address-value a:hover {{ color: var(--accent); }}
.address-note {{ font-size: 12px; color: var(--content-tertiary); margin-top: 8px; }}

.copy-btn {{
  background: var(--bg-card-header);
  border: 1px solid var(--border-secondary);
  color: var(--content-secondary);
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s;
}}
.copy-btn:hover {{ background: var(--border-secondary); color: var(--content-primary); }}

.tx-list {{ max-height: 300px; overflow-y: auto; }}
.tx-row {{
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 20px;
  border-bottom: 1px solid var(--border-primary);
  font-size: 13px;
}}
.tx-row:last-child {{ border-bottom: none; }}
.tx-hash {{ font-family: var(--font-mono); color: var(--accent); text-decoration: none; }}
.tx-hash:hover {{ text-decoration: underline; }}
.tx-amount {{ font-family: var(--font-mono); }}
.tx-amount.positive {{ color: var(--content-positive); }}
.tx-amount.negative {{ color: #ef4444; }}

.loading {{ color: var(--content-tertiary); padding: 20px; text-align: center; }}
.empty {{ color: var(--content-tertiary); padding: 20px; text-align: center; font-size: 14px; }}

@keyframes pulse {{ 0%, 100% {{ opacity: 1; }} 50% {{ opacity: 0.5; }} }}
.loading {{ animation: pulse 1.5s ease-in-out infinite; }}
</style>
</head>
<body>

<header class="header">
  <div class="header-left">
    <svg class="tempo-wordmark" viewBox="0 0 102 25" aria-label="Tempo" role="img">
      <path d="M95.1 16.1c1.74 0 3.35-1.25 3.35-3.73 0-2.49-1.6-3.74-3.34-3.74-1.74 0-3.34 1.25-3.34 3.74 0 2.48 1.6 3.74 3.34 3.74Zm0-10.7c3.93 0 6.9 2.9 6.9 6.97a6.73 6.73 0 0 1-6.9 6.97 6.75 6.75 0 0 1-6.88-6.97A6.75 6.75 0 0 1 95.1 5.4ZM77.34 24.01h-3.56V5.8h3.45v1.6c.59-1.01 2.06-1.9 4.03-1.9 3.85 0 6.07 2.94 6.07 6.84s-2.49 6.92-6.2 6.92c-1.82 0-3.15-.72-3.8-1.6V24Zm6.49-11.64c0-2.33-1.45-3.69-3.26-3.69-1.82 0-3.29 1.36-3.29 3.69 0 2.32 1.47 3.71 3.29 3.71 1.81 0 3.26-1.36 3.26-3.71ZM56 18.94h-3.56V5.8h3.39v1.6c.72-1.28 2.4-1.98 3.85-1.98 1.79 0 3.23.78 3.9 2.2a4.57 4.57 0 0 1 4.16-2.2c2.43 0 4.76 1.47 4.76 5v8.52h-3.45v-7.8c0-1.42-.7-2.48-2.32-2.48-1.52 0-2.43 1.17-2.43 2.59v7.69h-3.53v-7.8c0-1.42-.72-2.48-2.32-2.48-1.6 0-2.46 1.14-2.46 2.59v7.69Zm-14.13-8.07h5.87c-.05-1.3-.9-2.59-2.93-2.59a2.84 2.84 0 0 0-2.94 2.6Zm6.22 3.42 2.97.88c-.67 2.27-2.75 4.17-5.99 4.17-3.6 0-6.78-2.6-6.78-7.03 0-4.2 3.1-6.92 6.46-6.92 4.06 0 6.5 2.6 6.5 6.82 0 .5-.06 1.04-.06 1.1h-9.4c.08 1.73 1.55 2.98 3.31 2.98 1.66 0 2.56-.83 3-2Z" />
      <path d="M41.08 3.5H35.1v15.44h-3.71V3.5H25.4V0h15.68v3.5Z" />
      <path fill-rule="evenodd" clip-rule="evenodd" d="M18.96 18.95H0V.01h18.96v18.94ZM6.46 5.26a.27.27 0 0 0-.25.19l-.82 2.44c-.03.1.04.19.13.19H7.9c.1 0 .16.09.13.18l-1.75 5.25c-.03.1.04.19.14.19h2.53c.12 0 .22-.08.26-.19l1.75-5.25a.27.27 0 0 1 .25-.18h2.37c.12 0 .22-.08.26-.19l.81-2.44a.14.14 0 0 0-.13-.19H6.46Z" />
    </svg>
    <span class="presto-badge">Presto</span>
    <span class="badge live">{network_info["name"]}</span>
  </div>
  <div class="header-left">
    <a href="{explorer_url}" target="_blank" class="badge">Explorer ↗</a>
    {'<a href="' + network_info.get("faucet", "") + '" target="_blank" class="badge">Faucet ↗</a>' if network_info.get("faucet") else ''}
  </div>
</header>

<main class="main">
  <div class="balance-card">
    <div class="balance-label">{network_info.get("fee_token_name", "Token")} Balance</div>
    <div class="balance-value" id="balance">{balance}<span class="symbol">{network_info.get("fee_token_name", "")}</span></div>
    <button id="faucet-btn" onclick="requestFaucet()" style="margin-top: 16px; padding: 12px 24px; background: var(--accent); color: #000; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer;">💧 Get Testnet Funds</button>
    <div id="faucet-status" style="margin-top: 8px; font-size: 13px; color: var(--content-secondary);"></div>
  </div>

  <div class="section">
    <div class="section-title">Addresses</div>
    <div class="address-card">
      <div class="address-header">
        <span class="address-type">Wallet</span>
        <button class="copy-btn" onclick="copy('{self.account_address}')">Copy</button>
      </div>
      <div class="address-value">
        <a href="{explorer_url}/address/{self.account_address}" target="_blank">{self.account_address}</a>
      </div>
    </div>
    <div class="address-card">
      <div class="address-header">
        <span class="address-type">Access Key</span>
        <button class="copy-btn" onclick="copy('{self.access_key_address}')">Copy</button>
      </div>
      <div class="address-value">
        <a href="{explorer_url}/address/{self.access_key_address}" target="_blank">{self.access_key_address}</a>
      </div>
      <div class="address-note">Signs transactions on behalf of your wallet</div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Recent Transactions</div>
    <div class="card">
      <div class="tx-list" id="txList">
        <div class="loading">Loading transactions...</div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Configuration</div>
    <div class="card">
      <div class="card-row">
        <span class="card-label">Network</span>
        <span class="card-value">{network_info["name"]}</span>
      </div>
      <div class="card-row">
        <span class="card-label">Chain ID</span>
        <span class="card-value">{chain_id}</span>
      </div>
      <div class="card-row">
        <span class="card-label">RPC</span>
        <span class="card-value truncate">{rpc_url}</span>
      </div>
      <div class="card-row">
        <span class="card-label">Config</span>
        <span class="card-value truncate">{CONFIG_FILE}</span>
      </div>
    </div>
  </div>
</main>

<script>
const RPC = '{rpc_url}';
const WALLET = '{self.account_address}';
const ASSET = '{fee_token_address}';
const EXPLORER = '{explorer_url}';
const NETWORK = '{self.current_network}';
const FEE_TOKEN_NAME = '{fee_token_name}';

function copy(text) {{
  navigator.clipboard.writeText(text);
  event.target.textContent = 'Copied!';
  setTimeout(() => event.target.textContent = 'Copy', 1500);
}}

async function rpcCall(method, params) {{
  const res = await fetch(RPC, {{
    method: 'POST',
    headers: {{ 'Content-Type': 'application/json' }},
    body: JSON.stringify({{ jsonrpc: '2.0', id: 1, method, params }})
  }});
  return (await res.json()).result;
}}

async function loadBalance() {{
  const data = '0x70a08231000000000000000000000000' + WALLET.slice(2);
  const result = await rpcCall('eth_call', [{{ to: ASSET, data }}, 'latest']);
  if (result) {{
    const balance = parseInt(result, 16) / 1e6;
    document.getElementById('balance').innerHTML = '$' + balance.toFixed(2) + '<span class="symbol">' + FEE_TOKEN_NAME + '</span>';
  }}
}}

async function loadTransactions() {{
  const txList = document.getElementById('txList');
  try {{
    // Get recent blocks and scan for Transfer events
    const latest = await rpcCall('eth_blockNumber', []);
    const from = Math.max(0, parseInt(latest, 16) - 1000);
    
    const logs = await rpcCall('eth_getLogs', [{{
      fromBlock: '0x' + from.toString(16),
      toBlock: 'latest',
      address: ASSET,
      topics: [
        '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',
        null,
        '0x000000000000000000000000' + WALLET.slice(2).toLowerCase()
      ]
    }}]);
    
    const outLogs = await rpcCall('eth_getLogs', [{{
      fromBlock: '0x' + from.toString(16),
      toBlock: 'latest',
      address: ASSET,
      topics: [
        '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',
        '0x000000000000000000000000' + WALLET.slice(2).toLowerCase()
      ]
    }}]);
    
    const allLogs = [...(logs || []).map(l => ({{...l, dir: 'in'}})), ...(outLogs || []).map(l => ({{...l, dir: 'out'}}))];
    allLogs.sort((a, b) => parseInt(b.blockNumber, 16) - parseInt(a.blockNumber, 16));
    
    if (allLogs.length === 0) {{
      txList.innerHTML = '<div class="empty">No transactions yet</div>';
      return;
    }}
    
    txList.innerHTML = allLogs.slice(0, 10).map(log => {{
      const amount = parseInt(log.data, 16) / 1e6;
      const isIn = log.dir === 'in';
      return `<div class="tx-row">
        <a href="${{EXPLORER}}/tx/${{log.transactionHash}}" target="_blank" class="tx-hash">
          ${{log.transactionHash}}
        </a>
        <span class="tx-amount ${{isIn ? 'positive' : 'negative'}}">
          ${{isIn ? '+' : '-'}}$${{amount.toFixed(2)}}
        </span>
      </div>`;
    }}).join('');
  }} catch (e) {{
    txList.innerHTML = '<div class="empty">Could not load transactions</div>';
  }}
}}

async function requestFaucet() {{
  const btn = document.getElementById('faucet-btn');
  const status = document.getElementById('faucet-status');
  btn.disabled = true;
  btn.textContent = 'Requesting funds...';
  status.textContent = '';
  
  try {{
    // Fund wallet address
    const walletResult = await rpcCall('tempo_fundAddress', [WALLET]);
    // Fund access key address
    const accessKeyAddr = '{self.access_key_address}';
    if (accessKeyAddr && accessKeyAddr !== WALLET) {{
      await rpcCall('tempo_fundAddress', [accessKeyAddr]);
    }}
    
    btn.textContent = '✓ Funds received!';
    btn.style.background = 'var(--content-positive)';
    status.innerHTML = 'Tokens sent! <a href="' + EXPLORER + '/address/' + WALLET + '" target="_blank">View on explorer</a>';
    
    // Refresh balance after a delay
    setTimeout(loadBalance, 2000);
  }} catch (e) {{
    btn.textContent = '💧 Get Testnet Funds';
    btn.disabled = false;
    status.textContent = 'Error: ' + (e.message || 'Failed to get funds');
    status.style.color = '#ef4444';
  }}
}}

loadBalance();
loadTransactions();
setInterval(loadBalance, 30000);
</script>
</body>
</html>'''
        
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(html.encode())
        
        server = http.server.HTTPServer(("127.0.0.1", port), Handler)
        
        def serve():
            server.handle_request()
            server.server_close()
        
        thread = threading.Thread(target=serve, daemon=True)
        thread.start()
        
        url = f"http://127.0.0.1:{port}"
        webbrowser.open(url)
        self.add_output(f"⏺ Opened portal: {url}")
    
    def show_command_palette(self):
        """Display command palette as overlay dialog."""
        # Different commands based on wallet state
        if not self.private_key:
            commands = [
                ("wallet", "connect", "Connect wallet → pay with stablecoins", "/wallet"),
                ("faucet", "funds", "Get free testnet funds", "/faucet"),
                ("model", "select", "Change AI model", "/model"),
                ("proxy", "set", "Set payments proxy URL", "/proxy"),
                ("rpc", "set", "Set custom RPC URL", "/rpc"),
                ("presto", "help", "Show keyboard shortcuts", ""),
                ("presto", "quit", "Exit presto", "Ctrl+C"),
            ]
        else:
            commands = [
                ("presto", "help", "Show keyboard shortcuts", ""),
                ("presto", "usage", "Show session usage & costs", "/usage"),
                ("model", "select", "Change AI model", "/model"),
        
                ("keys", "manage", "View/switch access keys with limits", "/keys"),
                ("wallet", "info", "Show wallet & access key details", "/wallet"),
                ("wallet", "limits", "Show access key spending limits", "/wallet limits"),
                ("wallet", "fee-token", "Set preferred fee token", "/wallet fee-token"),
                ("wallet", "balance", "View token balances", "/wallet balance"),
                ("wallet", "transfers", "View transfer history", "/wallet transfers"),
                ("wallet", "txs", "View transaction history", "/wallet txs"),
                ("wallet", "channels", "View payment channels", "/wallet channels"),
                ("wallet", "closechannel", "Close channel & withdraw", "/wallet closechannel"),
                ("wallet", "closeall", "Close all eligible channels", "/wallet closeall"),
                ("wallet", "explorer", "Open wallet in block explorer", "/wallet explorer"),
                ("wallet", "faucet", "Get testnet funds", "/faucet"),
                ("wallet", "portal", "Open web portal", "/portal"),
                ("wallet", "renew", "Create new access key", "/newkey"),
                ("network", "switch", "Show/switch network", "/network"),
                ("proxy", "set", "Set payments proxy URL", "/proxy"),
                ("rpc", "set", "Set custom RPC URL", "/rpc"),
                ("presto", "clear", "Clear conversation", "/clear"),
                ("presto", "quit", "Exit presto", "Ctrl+C"),
            ]
        
        height, width = self.get_dims()
        
        dialog_width = min(60, width - 4)
        dialog_height = min(len(commands) + 6, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        search_buffer = ""
        selected_idx = 0
        
        self.draw()
        
        while True:
            filtered = [c for c in commands if search_buffer.lower() in f"{c[0]} {c[1]} {c[2]} {c[3]}".lower()]
            if selected_idx >= len(filtered):
                selected_idx = max(0, len(filtered) - 1)
            
            try:
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                title = "Command Palette"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(2) | curses.A_BOLD)
                
                self.stdscr.addstr(dialog_y + 2, dialog_x + 2, "> ", curses.color_pair(3) | curses.A_BOLD)
                self.stdscr.addstr(dialog_y + 2, dialog_x + 4, search_buffer[:dialog_width - 8])
                
                self.stdscr.addstr(dialog_y + 3, dialog_x + 1, "─" * (dialog_width - 2), curses.color_pair(1) | curses.A_DIM)
                
                max_items = dialog_height - 6
                for i, cmd in enumerate(filtered[:max_items]):
                    y = dialog_y + 4 + i
                    cat, name, desc, action = cmd
                    
                    if i == selected_idx:
                        self.stdscr.addstr(y, dialog_x + 2, " " * (dialog_width - 4), curses.color_pair(4) | curses.A_REVERSE)
                        self.stdscr.addstr(y, dialog_x + 3, f"{cat:>8}", curses.color_pair(4) | curses.A_REVERSE)
                        self.stdscr.addstr(y, dialog_x + 13, name[:25], curses.color_pair(4) | curses.A_REVERSE | curses.A_BOLD)
                        if action:
                            self.stdscr.addstr(y, dialog_x + dialog_width - len(action) - 4, action, curses.color_pair(4) | curses.A_REVERSE)
                    else:
                        self.stdscr.addstr(y, dialog_x + 3, f"{cat:>8}", curses.A_DIM)
                        self.stdscr.addstr(y, dialog_x + 13, name[:25])
                        if action:
                            self.stdscr.addstr(y, dialog_x + dialog_width - len(action) - 4, action, curses.A_DIM)
                
                help_text = "↑↓ Nav  ⏎ Select  Esc Close"
                help_x = dialog_x + (dialog_width - len(help_text)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, help_x, help_text, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == 15 or ch == 16:  # Escape, Ctrl+O, Ctrl+P (toggle)
                break
            elif ch == curses.KEY_UP:
                selected_idx = max(0, selected_idx - 1)
            elif ch == curses.KEY_DOWN:
                selected_idx = min(len(filtered) - 1, selected_idx + 1)
            elif ch == 10 or ch == 13:  # Enter
                # Check if search_buffer is a direct command (starts with /)
                if search_buffer.startswith('/'):
                    self.process_command(search_buffer.strip())
                    break
                # Otherwise execute selected palette item via its action (slash command)
                # This ensures palette and slash commands use the same code path
                if filtered and selected_idx < len(filtered):
                    cat, name, desc, action = filtered[selected_idx]
                    if action and action.startswith('/'):
                        self.process_command(action)
                    elif name == "help":
                        self.show_help()
                    elif name == "quit":
                        self.running = False
                break
            elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                search_buffer = search_buffer[:-1]
            elif ch != -1 and 32 <= ch <= 126:
                search_buffer += chr(ch)
        
        self.draw()
    
    def show_payment_confirm_dialog(self, amount_usd: float, asset_address: str = "") -> bool:
        """Show payment confirmation dialog. Returns True if confirmed, False if declined.
        
        Args:
            amount_usd: Amount to pay in USD
            asset_address: Server-requested token address (from 402 challenge)
        """
        # If auto-approve is enabled, skip dialog
        if getattr(self, '_auto_approve_payments', False):
            if not getattr(self, '_use_streaming_payments', False):
                self.add_output(f"$ Auto-approved: ${amount_usd:.4f}")
            return True
        
        height, width = self.get_dims()
        
        # Get proxy URL for display
        from .runtime_settings import get_settings
        proxy_url = get_settings().get_proxy_url()
        # Extract host from URL for display
        try:
            from urllib.parse import urlparse
            parsed = urlparse(proxy_url)
            server_display = parsed.netloc or proxy_url
        except:
            server_display = proxy_url
        
        # The endpoint we're requesting (API always uses /v1/chat/completions)
        endpoint_display = "/v1/chat/completions"
        
        # Get user's configured fee token
        wallet_fee_token = self.wallet.fee_token if self.wallet else None
        wallet_token_address = wallet_fee_token.address.lower() if wallet_fee_token and wallet_fee_token.is_set else ""
        wallet_token_symbol = wallet_fee_token.symbol if wallet_fee_token and wallet_fee_token.is_set else "USD"
        
        # Resolve server's requested token symbol
        requested_token_symbol = None
        requested_token_address = asset_address.lower() if asset_address else ""
        if requested_token_address:
            try:
                from .rpc import get_token_symbol
                requested_token_symbol = get_token_symbol(asset_address, self.get_rpc_url())
            except:
                pass
        
        # Determine if there's a token mismatch
        has_mismatch = (
            requested_token_address and 
            wallet_token_address and 
            requested_token_address != wallet_token_address
        )
        
        # Use server's requested token for display (this is what will actually be paid)
        if requested_token_symbol:
            token_name = requested_token_symbol
        elif requested_token_address:
            # Fallback: show truncated address if symbol lookup failed
            token_name = f"{requested_token_address[:6]}...{requested_token_address[-4:]}"
        else:
            token_name = wallet_token_symbol
        
        # Format amount nicely
        if amount_usd < 0.01:
            amount_display = f"${amount_usd:.4f} {token_name}"
        else:
            amount_display = f"${amount_usd:.2f} {token_name}"
        
        # Adjust dialog height for mismatch warning
        base_dialog_height = 15
        dialog_height = base_dialog_height + (2 if has_mismatch else 0)
        dialog_width = min(55, width - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Options with descriptions
        # 0 = Yes (one-time charge), 1 = Setup Budget (streaming channel), 2 = Cancel
        options = [
            ("Yes", "Pay this one-time request", curses.color_pair(3)),
            ("Setup Budget", "For multiple requests", curses.color_pair(2)),
            ("Cancel", "", curses.color_pair(5)),
        ]
        selected = 0
        
        while True:
            self.draw()
            
            try:
                # Draw compact dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(4))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(4))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(4))
                
                # Title - changes if there's a mismatch
                if has_mismatch:
                    title = "Token Mismatch"
                    title_color = curses.color_pair(5) | curses.A_BOLD  # Warning color
                else:
                    title = "402 Payment Required"
                    title_color = curses.color_pair(4) | curses.A_BOLD
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, title_color)
                
                # Server info (dimmed)
                server_line = f"Server: {server_display}"
                if len(server_line) > dialog_width - 6:
                    server_line = server_line[:dialog_width - 9] + "..."
                server_x = dialog_x + (dialog_width - len(server_line)) // 2
                self.stdscr.addstr(dialog_y + 2, server_x, server_line, curses.A_DIM)
                
                # Endpoint info (dimmed)
                endpoint_line = f"Endpoint: {endpoint_display}"
                endpoint_x = dialog_x + (dialog_width - len(endpoint_line)) // 2
                self.stdscr.addstr(dialog_y + 3, endpoint_x, endpoint_line, curses.A_DIM)
                
                # Amount - larger, centered
                amount_x = dialog_x + (dialog_width - len(amount_display)) // 2
                self.stdscr.addstr(dialog_y + 5, amount_x, amount_display, curses.A_BOLD | curses.color_pair(3))
                
                # Token mismatch warning (if applicable)
                content_offset = 0
                if has_mismatch:
                    mismatch_line = f"Your default: {wallet_token_symbol}"
                    mismatch_x = dialog_x + (dialog_width - len(mismatch_line)) // 2
                    self.stdscr.addstr(dialog_y + 6, mismatch_x, mismatch_line, curses.A_DIM)
                    
                    hint_line = "Press D to set as default"
                    hint_x = dialog_x + (dialog_width - len(hint_line)) // 2
                    self.stdscr.addstr(dialog_y + 7, hint_x, hint_line, curses.A_DIM)
                    content_offset = 2
                
                # Options as vertical list with descriptions
                opt_start_y = dialog_y + 7 + content_offset
                for i, (label, desc, color) in enumerate(options):
                    y = opt_start_y + i
                    if i == selected:
                        # Highlight selected option
                        self.stdscr.addstr(y, dialog_x + 4, f"▸ {label}", color | curses.A_BOLD)
                        if desc:
                            self.stdscr.addstr(y, dialog_x + 6 + len(label) + 1, f"– {desc}", curses.A_DIM)
                    else:
                        self.stdscr.addstr(y, dialog_x + 4, f"  {label}", curses.A_DIM)
                        if desc:
                            self.stdscr.addstr(y, dialog_x + 6 + len(label) + 1, f"– {desc}", curses.A_DIM)
                
                # Keyboard hints
                hint = "↑↓ select · enter confirm · esc cancel"
                hint_x = dialog_x + (dialog_width - len(hint)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, hint_x, hint, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            
            if ch == curses.KEY_UP or ch == ord('k'):
                selected = (selected - 1) % len(options)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                selected = (selected + 1) % len(options)
            elif ch == ord('d') or ch == ord('D'):
                # Set server's requested token as the new default
                if has_mismatch and requested_token_address and self.wallet:
                    from .wallet import FeeToken
                    new_fee_token = FeeToken(
                        address=asset_address,
                        symbol=requested_token_symbol or token_name,
                        decimals=6  # TIP-20 tokens use 6 decimals
                    )
                    self.wallet._current_wallet().fee_token = new_fee_token
                    from .payment import save_config
                    save_config(self.wallet.to_dict())
                    # Update state - no longer a mismatch
                    has_mismatch = False
                    wallet_token_symbol = new_fee_token.symbol
                    self.add_output(f"$ Default token set to {new_fee_token.symbol}")
                    # Redraw with updated state
                    dialog_height = base_dialog_height
                    dialog_y = (height - dialog_height) // 2
                continue
            elif ch == 10 or ch == 13:  # Enter
                if selected == 0:  # Yes - one-time charge
                    return True
                elif selected == 1:  # Setup Budget - streaming channel
                    budget = self.show_budget_input_dialog(token_name)
                    if budget is not None:
                        self._auto_approve_payments = True
                        self._use_streaming_payments = True
                        self._stream_payment_limit = budget
                        return True
                    # If cancelled, stay in payment dialog
                    continue
                else:  # Cancel
                    return False
            elif ch == ord('y') or ch == ord('Y'):
                return True
            elif ch == ord('s') or ch == ord('S') or ch == ord('b') or ch == ord('B'):
                budget = self.show_budget_input_dialog(token_name)
                if budget is not None:
                    self._auto_approve_payments = True
                    self._use_streaming_payments = True
                    self._stream_payment_limit = budget
                    return True
                continue
            elif ch == ord('c') or ch == ord('C') or ch == ord('n') or ch == ord('N') or ch == 27:
                return False
        
        return False
    
    def show_budget_input_dialog(self, token_name: str = "USD") -> float | None:
        """Show dialog to input a budget amount. Returns amount in USD or None if cancelled.
        
        Args:
            token_name: Name of the token to display (e.g., "USDC", "BetaUSD")
        """
        height, width = self.get_dims()
        
        dialog_width = min(50, width - 4)
        dialog_height = 12
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Get spending limit from access key (max allowed)
        max_budget = None
        if self.wallet and self.wallet.active_key and self.wallet.active_key.key_id:
            from .rpc import get_remaining_spending_limit
            fee_token = self.wallet.fee_token
            if fee_token and fee_token.is_set:
                limit = get_remaining_spending_limit(
                    self.wallet.account_address,
                    self.wallet.active_key.key_id,
                    fee_token.address,
                    self.get_rpc_url(),
                )
                if limit > 0:
                    max_budget = limit / 1_000_000  # Convert from base units to USD
        
        # Default budget
        budget_cents = 500  # $5.00 in cents (stored as integer to avoid float issues)
        
        def format_budget(cents: int) -> str:
            """Format cents as dollar amount with thousands grouping."""
            dollars = cents // 100
            remaining_cents = cents % 100
            if dollars >= 1000:
                # Format with space grouping
                dollar_str = f"{dollars:,}".replace(",", " ")
            else:
                dollar_str = str(dollars)
            return f"${dollar_str}.{remaining_cents:02d} {token_name}"
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(2))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(2))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(2))
                
                # Title
                title = "Set Budget"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(2) | curses.A_BOLD)
                
                # Explanation
                desc = "Auto-pay requests up to this amount"
                desc_x = dialog_x + (dialog_width - len(desc)) // 2
                self.stdscr.addstr(dialog_y + 3, desc_x, desc, curses.A_DIM)
                
                # Budget display (large, centered)
                budget_display = format_budget(budget_cents)
                budget_x = dialog_x + (dialog_width - len(budget_display)) // 2
                self.stdscr.addstr(dialog_y + 5, budget_x, budget_display, curses.A_BOLD | curses.color_pair(3))
                
                # Max budget indicator
                if max_budget is not None:
                    max_display = f"(max: ${max_budget:,.2f} {token_name})"
                    max_x = dialog_x + (dialog_width - len(max_display)) // 2
                    self.stdscr.addstr(dialog_y + 6, max_x, max_display, curses.A_DIM)
                
                # Hints
                hint1 = "↑↓ adjust by $1 · Type digits"
                hint1_x = dialog_x + (dialog_width - len(hint1)) // 2
                self.stdscr.addstr(dialog_y + 8, hint1_x, hint1, curses.A_DIM)
                
                hint2 = "Enter: confirm · Esc: back"
                hint2_x = dialog_x + (dialog_width - len(hint2)) // 2
                self.stdscr.addstr(dialog_y + 9, hint2_x, hint2, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27:  # Escape - cancel
                return None
            elif ch == 10 or ch == 13:  # Enter - confirm
                budget_usd = budget_cents / 100.0
                if budget_usd >= 1.0:  # Minimum $1
                    return budget_usd
            elif ch == curses.KEY_UP or ch == ord('k'):
                # Increase by $1
                budget_cents += 100
                if max_budget is not None:
                    max_cents = int(max_budget * 100)
                    budget_cents = min(budget_cents, max_cents)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                # Decrease by $1, minimum $1
                budget_cents = max(100, budget_cents - 100)
            elif ch == curses.KEY_PPAGE:  # Page Up - increase by $10
                budget_cents += 1000
                if max_budget is not None:
                    max_cents = int(max_budget * 100)
                    budget_cents = min(budget_cents, max_cents)
            elif ch == curses.KEY_NPAGE:  # Page Down - decrease by $10
                budget_cents = max(100, budget_cents - 1000)
            elif ord('0') <= ch <= ord('9'):
                # Type digits directly - build up a new number
                digit = chr(ch)
                current_dollars = budget_cents // 100
                
                # If current amount is default (5) and typing first digit, start fresh
                if current_dollars == 5 and digit != '0':
                    new_dollars = int(digit)
                else:
                    # Append digit (but limit to reasonable amount)
                    new_str = str(current_dollars) + digit
                    if len(new_str) <= 9:  # Max ~$999,999,999
                        new_dollars = int(new_str)
                    else:
                        new_dollars = current_dollars
                
                budget_cents = new_dollars * 100
                
                # Enforce max
                if max_budget is not None:
                    max_cents = int(max_budget * 100)
                    budget_cents = min(budget_cents, max_cents)
            elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                # Backspace - remove last digit
                current_dollars = budget_cents // 100
                new_dollars = current_dollars // 10
                budget_cents = max(100, new_dollars * 100)  # Minimum $1
        
        return None
    
    def show_stream_limit_dialog(self) -> float | None:
        """Show dialog to set streaming payment channel limit. Returns limit in USD or None if cancelled."""
        height, width = self.get_dims()
        
        dialog_width = min(50, width - 4)
        dialog_height = 10
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Default limit
        limit_str = "25.00"
        cursor_pos = len(limit_str)
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(4))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(4))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(4))
                
                # Title
                title = "Stream Payment Limit"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(4) | curses.A_BOLD)
                
                # Description
                desc = "Deposit once, pay per request instantly"
                desc_x = dialog_x + (dialog_width - len(desc)) // 2
                self.stdscr.addstr(dialog_y + 3, desc_x, desc, curses.A_DIM)
                
                # Input field
                input_label = "Limit: $"
                input_x = dialog_x + (dialog_width - len(input_label) - 10) // 2
                self.stdscr.addstr(dialog_y + 5, input_x, input_label)
                self.stdscr.addstr(dialog_y + 5, input_x + len(input_label), limit_str, curses.A_BOLD)
                
                # Show cursor
                cursor_x = input_x + len(input_label) + cursor_pos
                self.stdscr.addstr(dialog_y + 5, cursor_x, "_", curses.A_BLINK)
                
                # Hints
                hint = "enter confirm · esc cancel"
                hint_x = dialog_x + (dialog_width - len(hint)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, hint_x, hint, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            
            if ch == 27:  # Escape
                return None
            elif ch == 10 or ch == 13:  # Enter
                try:
                    limit = float(limit_str)
                    if limit > 0:
                        return limit
                except ValueError:
                    pass
            elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                if cursor_pos > 0:
                    limit_str = limit_str[:cursor_pos-1] + limit_str[cursor_pos:]
                    cursor_pos -= 1
            elif ch == curses.KEY_LEFT:
                cursor_pos = max(0, cursor_pos - 1)
            elif ch == curses.KEY_RIGHT:
                cursor_pos = min(len(limit_str), cursor_pos + 1)
            elif ch >= 32 and ch < 127:
                char = chr(ch)
                if char.isdigit() or char == '.':
                    limit_str = limit_str[:cursor_pos] + char + limit_str[cursor_pos:]
                    cursor_pos += 1
        
        return None
    
    def show_stream_topup_dialog(self, channel_info: dict) -> float | None:
        """Show dialog when stream channel is depleted. Returns new limit in USD or None if cancelled.
        
        Args:
            channel_info: Dict with deposit_usd, spent_usd, remaining_usd, token, payee, voucher_endpoint, voucher_count
        """
        height, width = self.get_dims()
        
        # Extract channel info
        current_limit = channel_info.get('deposit_usd', 0)
        spent_usd = channel_info.get('spent_usd', 0)
        token_address = channel_info.get('token', '')
        payee = channel_info.get('payee', '')
        voucher_endpoint = channel_info.get('voucher_endpoint', '')
        voucher_count = channel_info.get('voucher_count', 0)
        
        # Get token symbol and balance
        token_symbol = None
        token_balance_usd = None
        if token_address:
            try:
                from .rpc import get_token_symbol, get_token_balance
                token_symbol = get_token_symbol(token_address, self.get_rpc_url())
                if self.account_address:
                    token_balance_usd = get_token_balance(self.account_address, token_address, self.get_rpc_url(), decimals=6)
            except:
                pass
        if not token_symbol:
            token_symbol = f"{token_address[:6]}...{token_address[-4:]}" if token_address else "tokens"
        
        # Extract server host from voucher endpoint
        server_display = ""
        if voucher_endpoint:
            try:
                from urllib.parse import urlparse
                parsed = urlparse(voucher_endpoint)
                server_display = parsed.netloc or voucher_endpoint
            except:
                server_display = voucher_endpoint[:30] + "..." if len(voucher_endpoint) > 30 else voucher_endpoint
        
        # Calculate dialog size - needs to be wider to show channel info
        hint = "↑↓ adjust · enter confirm · esc cancel (per-request)"
        dialog_width = max(58, len(hint) + 6)
        dialog_width = min(dialog_width, width - 4)
        dialog_height = 17  # +1 for balance line
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Suggest doubling the limit, but cap at available balance
        suggested_limit = current_limit * 2
        if token_balance_usd is not None and suggested_limit > token_balance_usd:
            suggested_limit = token_balance_usd
        limit_str = f"{suggested_limit:.2f}"
        cursor_pos = len(limit_str)
        
        while True:
            # Clear screen and redraw background
            self.stdscr.clear()
            self.draw()
            
            try:
                # Draw dialog box with solid background
                for i in range(dialog_height):
                    y = dialog_y + i
                    if y < 0 or y >= height:
                        continue
                    if i == 0:
                        line = "╭" + "─" * (dialog_width - 2) + "╮"
                    elif i == dialog_height - 1:
                        line = "╰" + "─" * (dialog_width - 2) + "╯"
                    else:
                        line = "│" + " " * (dialog_width - 2) + "│"
                    self.stdscr.addstr(y, dialog_x, line, curses.color_pair(5))
                
                # Title
                title = "Channel Depleted"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(5) | curses.A_BOLD)
                
                # Server info
                if server_display:
                    server_line = f"Server: {server_display}"
                    if len(server_line) > dialog_width - 6:
                        server_line = server_line[:dialog_width - 9] + "..."
                    server_x = dialog_x + (dialog_width - len(server_line)) // 2
                    self.stdscr.addstr(dialog_y + 3, server_x, server_line, curses.A_DIM)
                
                # Token info with balance
                if token_balance_usd is not None:
                    token_line = f"Token: {token_symbol} (balance: ${token_balance_usd:.2f})"
                else:
                    token_line = f"Token: {token_symbol}"
                token_x = dialog_x + (dialog_width - len(token_line)) // 2
                self.stdscr.addstr(dialog_y + 4, token_x, token_line, curses.A_DIM)
                
                # Usage summary
                usage_line = f"Spent ${spent_usd:.2f} of ${current_limit:.2f} ({voucher_count} requests)"
                usage_x = dialog_x + (dialog_width - len(usage_line)) // 2
                self.stdscr.addstr(dialog_y + 6, usage_x, usage_line, curses.color_pair(3))
                
                # Prompt for new deposit
                prompt = "Open new channel with deposit:"
                prompt_x = dialog_x + (dialog_width - len(prompt)) // 2
                self.stdscr.addstr(dialog_y + 8, prompt_x, prompt)
                
                # Input field with increment hints
                input_label = "$"
                field_width = 12
                input_x = dialog_x + (dialog_width - field_width - 2) // 2
                self.stdscr.addstr(dialog_y + 10, input_x, input_label)
                self.stdscr.addstr(dialog_y + 10, input_x + len(input_label), limit_str.ljust(field_width), curses.A_BOLD | curses.color_pair(3))
                
                # Show cursor
                cursor_x = input_x + len(input_label) + cursor_pos
                self.stdscr.addstr(dialog_y + 10, cursor_x, "_", curses.A_BLINK)
                
                # Increment buttons hint
                inc_hint = "← $1  ↓ $5  ↑ $5  → $1"
                inc_x = dialog_x + (dialog_width - len(inc_hint)) // 2
                self.stdscr.addstr(dialog_y + 12, inc_x, inc_hint, curses.A_DIM)
                
                # Main hints
                hint_x = dialog_x + (dialog_width - len(hint)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, hint_x, hint, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            
            if ch == 27:  # Escape - cancel, fall back to per-request
                return None
            elif ch == 10 or ch == 13:  # Enter
                try:
                    limit = float(limit_str)
                    if limit > current_limit:
                        return limit
                except ValueError:
                    pass
            elif ch == curses.KEY_UP:
                # Increase by $5
                try:
                    current_val = float(limit_str)
                    limit_str = f"{current_val + 5:.2f}"
                    cursor_pos = len(limit_str)
                except ValueError:
                    pass
            elif ch == curses.KEY_DOWN:
                # Decrease by $5 (min is current_limit + 1)
                try:
                    current_val = float(limit_str)
                    new_val = max(current_limit + 1, current_val - 5)
                    limit_str = f"{new_val:.2f}"
                    cursor_pos = len(limit_str)
                except ValueError:
                    pass
            elif ch == curses.KEY_RIGHT:
                # Increase by $1
                try:
                    current_val = float(limit_str)
                    limit_str = f"{current_val + 1:.2f}"
                    cursor_pos = len(limit_str)
                except ValueError:
                    pass
            elif ch == curses.KEY_LEFT:
                # Decrease by $1 (min is current_limit + 1)
                try:
                    current_val = float(limit_str)
                    new_val = max(current_limit + 1, current_val - 1)
                    limit_str = f"{new_val:.2f}"
                    cursor_pos = len(limit_str)
                except ValueError:
                    pass
            elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                if len(limit_str) > 0:
                    limit_str = limit_str[:-1]
                    cursor_pos = len(limit_str)
            elif ch >= 32 and ch < 127:
                char = chr(ch)
                if char.isdigit() or char == '.':
                    limit_str = limit_str + char
                    cursor_pos = len(limit_str)
        
        return None
    
    def execute_palette_command(self, cmd):
        """Execute a command from the palette."""
        cat, name, desc, action = cmd
        
        # Show the command as user input (like regular messages)
        if action:
            self.add_output("")
            self.add_output(f"→ {action}")
            self.add_output("")
        
        if name == "help":
            self.show_help()
        elif name == "usage":
            self.show_usage_dialog()
        elif name == "connect":
            self.create_new_access_key()
        elif name == "info" and cat == "wallet":
            self.show_wallet_inline()
        elif name == "balance" and cat == "wallet":
            self.show_wallet_balance_inline()
        elif name == "transfers" and cat == "wallet":
            self.show_wallet_transfers_inline()
        elif name == "txs" and cat == "wallet":
            self.show_wallet_txs_inline()
        elif name == "channels" and cat == "wallet":
            self.show_wallet_channels_inline()
        elif name == "closechannel" and cat == "wallet":
            self.close_channel_command("/wallet closechannel")
        elif name == "closeall" and cat == "wallet":
            self.close_channel_command("/wallet closechannel all")
        elif name == "manage" and cat == "keys":
            self.show_keys_dialog()
        elif name == "explorer" and cat == "wallet":
            self.open_wallet_explorer()
        elif name == "faucet":
            self.request_faucet(show_command=False)
        elif name == "portal":
            self.open_portal()
        elif name == "renew" or name == "new key":
            self.create_new_access_key()
        elif name == "funds":
            self.request_faucet(show_command=False)
        elif name == "select" and cat == "model":
            self.show_model_selector()
        elif name == "info" and cat == "network":
            self.process_command("/network")
        elif name == "switch":
            self.add_output("⏺ Use /network <name> to switch (mainnet, moderato)")
        elif name == "transactions":
            self.show_history()
        elif name == "clear":
            self.output_lines = []
            self.add_welcome_to_history()
        elif name == "quit":
            self.running = False
    
    def show_help(self):
        """Display help panel overlay."""
        help_content = [
            ("", "Presto - Help & Keyboard Shortcuts", "title"),
            ("", "", ""),
            ("", "Navigation", "section"),
            ("↑, ↓", "Scroll output up/down", ""),
            ("Ctrl+P", "Open command palette", ""),
            ("", "", ""),
            ("", "Editing", "section"),
            ("Ctrl+U", "Clear input line", ""),
            ("Ctrl+A", "Jump to start of line", ""),
            ("Ctrl+E", "Jump to end of line", ""),
            ("←, →", "Move cursor left/right", ""),
            ("Backspace", "Delete character backward", ""),
            ("Enter", "Submit input", ""),
            ("", "", ""),
            ("", "Commands", "section"),
            ("/help", "Show this help panel", ""),
            ("/usage", "Show session usage & costs", ""),
            ("/model", "Change AI model", ""),
            ("/wallet", "View wallet & access key info", ""),
            ("/wallet balance", "View token balances", ""),
            ("/wallet transfers", "View transfer history", ""),
            ("/wallet txs", "View transaction history", ""),
            ("/wallet channels", "View payment channels", ""),
            ("/newkey", "Create new access key", ""),
            ("/faucet", "Get free testnet funds", ""),
            ("/portal", "Open web portal", ""),
            ("/network", "Show/switch network", ""),
            ("/proxy", "Set payments proxy URL", ""),
            ("/rpc", "Set custom RPC URL", ""),
            ("/skills", "List available skills", ""),
            ("/clear", "Clear conversation", ""),
            ("", "", ""),
            ("", "Exit", "section"),
            ("/quit", "Exit presto", ""),
            ("Ctrl+C, Ctrl+D", "Exit presto", ""),
        ]
        
        height, width = self.get_dims()
        dialog_width = min(70, width - 4)
        dialog_height = min(len(help_content) + 4, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        scroll_offset = 0
        max_visible = dialog_height - 4
        
        while True:
            self.draw()
            
            try:
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                visible_content = help_content[scroll_offset:scroll_offset + max_visible]
                for i, (key, desc, style) in enumerate(visible_content):
                    y = dialog_y + 2 + i
                    if style == "title":
                        title_x = dialog_x + (dialog_width - len(desc)) // 2
                        self.stdscr.addstr(y, title_x, desc, curses.color_pair(2) | curses.A_BOLD)
                    elif style == "section":
                        self.stdscr.addstr(y, dialog_x + 4, desc, curses.color_pair(3) | curses.A_BOLD)
                    elif key:
                        self.stdscr.addstr(y, dialog_x + 8, f"{key:20}", curses.color_pair(4))
                        self.stdscr.addstr(y, dialog_x + 30, desc[:dialog_width - 34])
                
                footer = "Press Escape to close • Use ↑↓ or j/k to scroll"
                footer_x = dialog_x + (dialog_width - len(footer)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, footer_x, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape or q
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                scroll_offset = max(0, scroll_offset - 1)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                scroll_offset = min(max(0, len(help_content) - max_visible), scroll_offset + 1)
        
        self.draw()
    
    def show_wallet_inline(self):
        """Show wallet info inline in chat."""
        if not self.account_address:
            self.add_output("⏺ No wallet connected. Run /wallet setup")
            return
        
        network = self.get_network_name()
        network_info = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
        
        self.add_output(f"⏺ Wallet: {self.account_address}")
        self.add_output(f"  Balance: {self.cached_balance or 'Loading...'}")
        self.add_output(f"  Network: {network_info['name']} (chain {network_info['chain_id']})")
        
        if self.wallet and self.wallet.access_keys:
            active_key = self.wallet.access_keys[self.wallet.active_key_index]
            self.add_output(f"  Access Key: {active_key.address}")
            self.add_output(f"  Expires: {active_key.time_remaining}")
    
    def show_wallet_balance_inline(self):
        """Show token balances inline in chat."""
        if not self.account_address:
            self.add_output("⏺ No wallet connected. Run /wallet setup")
            return
        
        self.add_output(f"⏺ Balance: {self.cached_balance or 'Loading...'}")
        self.refresh_balance_async()
    
    def show_wallet_transfers_inline(self):
        """Show recent transfers inline in chat."""
        if not self.account_address:
            self.add_output("⏺ No wallet connected. Run /wallet setup")
            return
        
        from .explorer import get_explorer_client
        
        chain_id = NETWORKS.get(self.current_network, {}).get("chain_id")
        client = get_explorer_client(chain_id)
        
        self.add_output("⏺ Loading transfers...")
        self.draw()
        
        try:
            transfers = client.get_transfers(self.account_address, limit=10)
            self.output_lines.pop()
            
            if not transfers:
                self.add_output("⏺ No transfers found")
            else:
                self.add_output(f"⏺ Recent transfers ({len(transfers)}):")
                self.add_output("  Time             Dir  Amount          From/To")
                self.add_output("  " + "─" * 55)
                for t in transfers[:10]:
                    dir_str = t.direction(self.account_address)
                    arrow = "→" if dir_str == "sent" else "←"
                    other = t.to_addr if dir_str == "sent" else t.from_addr
                    other_short = f"{other[:6]}…{other[-4:]}" if len(other) > 12 else other
                    self.add_output(f"  {t.formatted_time}  {arrow}   {t.formatted_amount:<14}  {other_short}")
        except Exception as e:
            self.output_lines.pop()
            self.add_output(f"⏺ Error: {e}")
    
    def show_wallet_txs_inline(self):
        """Show recent transactions and transfers inline in chat."""
        if not self.account_address:
            self.add_output("⏺ No wallet connected. Run /wallet setup")
            return
        
        from .explorer import get_explorer_client
        
        chain_id = NETWORKS.get(self.current_network, {}).get("chain_id")
        client = get_explorer_client(chain_id)
        
        self.add_output("⏺ Loading activity...")
        self.draw()
        
        try:
            txs = client.get_transactions(self.account_address, limit=10)
            transfers = client.get_transfers(self.account_address, limit=10)
            self.output_lines.pop()
            
            # Merge and sort by timestamp descending
            activity = []
            for tx in txs:
                activity.append(("tx", tx.timestamp, tx))
            for t in transfers:
                activity.append(("transfer", t.timestamp, t))
            activity.sort(key=lambda x: x[1], reverse=True)
            
            if not activity:
                self.add_output("⏺ No activity found")
            else:
                self.add_output(f"⏺ Recent activity ({len(activity[:10])}):")
                for kind, _, item in activity[:10]:
                    if kind == "tx":
                        status = "✓" if item.status else "✗"
                        hash_short = f"{item.hash[:10]}...{item.hash[-6:]}"
                        self.add_output(f"  {item.formatted_time} {status} {hash_short}")
                    else:
                        direction = item.direction(self.account_address)
                        arrow = "→" if direction == "sent" else "←"
                        other = item.to_addr if direction == "sent" else item.from_addr
                        other_short = f"{other[:6]}...{other[-4:]}" if other else "?"
                        self.add_output(f"  {item.formatted_time} {arrow} {item.formatted_amount} {other_short}")
        except Exception as e:
            self.output_lines.pop()
            self.add_output(f"⏺ Error: {e}")
    
    def show_wallet_channels_inline(self):
        """Show payment channels inline in chat."""
        if not self.account_address:
            self.add_output("⏺ No wallet connected. Run /wallet setup")
            return
        
        from .streaming import get_stream_manager
        from datetime import datetime
        import time as t
        
        manager = get_stream_manager()
        
        if not manager or not manager._channels:
            self.add_output("⏺ No active channels")
            self.add_output("  Channels open automatically during streaming payments")
            return
        
        # Filter out finalized channels for display
        active_channels = [ch for ch in manager._channels.values() if not ch.finalized]
        finalized_count = len(manager._channels) - len(active_channels)
        
        if not active_channels:
            self.add_output("⏺ No active channels")
            if finalized_count > 0:
                self.add_output(f"  ({finalized_count} channels closed)")
            return
        
        # Calculate totals across active channels only
        total_deposit = sum(ch.deposit for ch in active_channels) / 1_000_000
        total_used = sum(ch.cumulative_amount for ch in active_channels) / 1_000_000
        total_remaining = total_deposit - total_used
        
        self.add_output(f"⏺ Payment channels ({len(active_channels)}):")
        self.add_output(f"  Total: ${total_used:.2f} used / ${total_deposit:.2f} deposited (${total_remaining:.2f} remaining)")
        self.add_output("")
        
        # Sort by opened_at (newest first)
        sorted_channels = sorted(active_channels, key=lambda c: c.opened_at or 0, reverse=True)
        
        withdrawable_channels = []
        for i, ch in enumerate(sorted_channels[:10]):
            deposit = ch.deposit / 1_000_000
            used = ch.cumulative_amount / 1_000_000
            remaining = deposit - used
            pct = (ch.cumulative_amount / ch.deposit * 100) if ch.deposit > 0 else 0
            
            # Get token symbol for this channel
            token_symbol = get_token_symbol(ch.token, self.get_rpc_url()) if ch.token else "USD"
            
            # Status indicator using shared logic
            status_code, status_text, can_withdraw, refund = self._get_channel_status(ch)
            
            # Progress bar (20 chars wide)
            filled = int(pct / 5)
            if status_code == 'withdraw_now':
                # Withdrawable: use ▓ for refundable portion
                bar = "█" * filled + "▓" * (20 - filled)
            elif status_code == 'closing_wait':
                # Closing: use ▒ for pending
                bar = "█" * filled + "▒" * (20 - filled)
            else:
                # Normal: used █, available ░
                bar = "█" * filled + "░" * (20 - filled)
            
            # Format open time (relative for recent, absolute for older)
            now_ts = int(t.time())
            if ch.opened_at:
                age_s = now_ts - ch.opened_at
                if age_s < 60:
                    opened = f"{age_s}s ago"
                elif age_s < 3600:
                    opened = f"{age_s // 60}m ago"
                elif age_s < 86400:
                    opened = f"{age_s // 3600}h ago"
                else:
                    opened = datetime.fromtimestamp(ch.opened_at).strftime("%Y-%m-%d %H:%M")
            else:
                opened = "Unknown"
            
            # Format expiry
            if ch.expiry > now_ts:
                expires_in = ch.expiry - now_ts
                if expires_in < 60:
                    expiry_str = f"expires in {expires_in}s"
                elif expires_in < 3600:
                    expiry_str = f"expires in {expires_in // 60}m"
                else:
                    expiry_str = f"expires in {expires_in // 3600}h"
            else:
                expiry_str = "expired"
            
            if status_code == 'withdraw_now':
                status = f"← ${refund/1_000_000:.2f} available"
                withdrawable_channels.append(i + 1)
            elif status_code == 'closing_wait':
                # Clearer: waiting for server settlement grace period
                status = f"(withdraw in {status_text.replace('closing, ', '')})"
            elif ch.expiry <= int(t.time()):
                status = "(expired)"
            elif remaining <= 0:
                status = "(depleted)"
            elif remaining < deposit * 0.1:
                status = "(low)"
            else:
                status = ""
            
            if i > 0:
                self.add_output("")
            # Show status on first line, expiry info for active channels
            # Use ★ prefix for withdrawable channels to highlight them in green
            if status_code == 'withdraw_now':
                self.add_output(f"★ #{i+1} {token_symbol} · Opened {opened} {status}")
            elif status:
                self.add_output(f"  #{i+1} {token_symbol} · Opened {opened} {status}")
            else:
                self.add_output(f"  #{i+1} {token_symbol} · Opened {opened} ({expiry_str})")
            self.add_output(f"     [{bar}] {used:.2f}/{deposit:.2f} {token_symbol} ({pct:.0f}%)")
            
            # Show payee (on-chain identity) - this is what the channel is bound to
            payee_short = f"{ch.payee[:8]}...{ch.payee[-4:]}" if ch.payee else "unknown"
            # Show the main proxy URL (where chat requests go), not the voucher endpoint
            from .runtime_settings import get_settings
            from urllib.parse import urlparse
            proxy_url = get_settings().get_proxy_url()
            try:
                parsed = urlparse(proxy_url)
                server_host = parsed.netloc or proxy_url
            except:
                server_host = proxy_url
            self.add_output(f"     Payee: {payee_short} via {server_host}")
        
        # Show consolidated withdraw hint if there are withdrawable channels
        if withdrawable_channels:
            self.add_output("")
            if len(withdrawable_channels) == 1:
                self.add_output(f"  Run /wallet closechannel {withdrawable_channels[0]} to withdraw")
            else:
                self.add_output(f"  Run /wallet closechannel all to withdraw from all")
    
    def _get_channel_status(self, channel):
        """Get status info for a channel. Returns (status_code, status_text, can_withdraw, refund_amount).
        
        Status codes: 'finalized', 'withdraw_now', 'closing_wait', 'needs_close'
        """
        now = int(time.time())
        grace_period = 15 * 60
        refund = max(0, channel.deposit - channel.cumulative_amount)
        
        if channel.finalized:
            return ('finalized', 'finalized', False, 0)
        
        # Can withdraw if: expired OR (close requested AND grace period passed)
        can_withdraw = (
            now >= channel.expiry or
            (channel.close_requested_at > 0 and now >= channel.close_requested_at + grace_period)
        )
        
        if can_withdraw:
            if now >= channel.expiry:
                return ('withdraw_now', 'expired → withdraw now', True, refund)
            else:
                return ('withdraw_now', 'grace passed → withdraw now', True, refund)
        elif channel.close_requested_at > 0:
            remaining_time = (channel.close_requested_at + grace_period) - now
            mins, secs = divmod(remaining_time, 60)
            return ('closing_wait', f'closing, {mins}m {secs}s left', False, refund)
        else:
            return ('needs_close', 'active', False, refund)
    
    def close_channel_command(self, cmd: str):
        """Handle /wallet closechannel command."""
        from .streaming import get_stream_manager
        
        if not self.account_address:
            self.add_output("! No wallet connected")
            return
        
        manager = get_stream_manager()
        if not manager:
            self.add_output("! Stream manager not initialized. Connect wallet first.")
            return
        if not manager._channels:
            self.add_output("! No channels to close")
            self.add_output("  Channels open automatically during streaming payments")
            return
        
        # Parse command: /wallet closechannel [<number> | all]
        parts = cmd.split()
        channel_arg = parts[2] if len(parts) >= 3 else None
        
        # Get non-finalized channels sorted by opened_at (newest first)
        sorted_channels = sorted(
            [ch for ch in manager._channels.values() if not ch.finalized],
            key=lambda c: c.opened_at or 0, reverse=True
        )
        
        if not sorted_channels:
            self.add_output("! No channels to close (all finalized)")
            return
        
        # Handle "all" command
        if channel_arg and channel_arg.lower() == "all":
            self._close_all_channels(manager, sorted_channels)
            return
        
        # Parse channel number
        channel_num = None
        if channel_arg:
            try:
                channel_num = int(channel_arg)
            except ValueError:
                self.add_output(f"! Invalid argument: {channel_arg}")
                self.add_output("  Usage: /wallet closechannel <number> or /wallet closechannel all")
                return
        
        # If no channel specified, either auto-select or show list
        if channel_num is None:
            # If only 1 channel, close it directly
            if len(sorted_channels) == 1:
                channel = sorted_channels[0]
                self._close_single_channel(manager, channel, 1)
                return
            
            # If there's exactly 1 withdrawable channel, prioritize it
            withdrawable = [(i, ch) for i, ch in enumerate(sorted_channels) 
                           if self._get_channel_status(ch)[0] in ('withdraw_now',)]
            if len(withdrawable) == 1:
                idx, channel = withdrawable[0]
                self._close_single_channel(manager, channel, idx + 1)
                return
            
            # Multiple channels - show list
            self.add_output("⏺ Select a channel to close:")
            for i, ch in enumerate(sorted_channels[:10]):
                status_code, status_text, can_withdraw, refund = self._get_channel_status(ch)
                deposit = ch.deposit / 1_000_000
                refund_usd = refund / 1_000_000
                
                if status_code == 'withdraw_now':
                    status = f"(${refund_usd:.2f} → WITHDRAW NOW)"
                elif status_code == 'closing_wait':
                    status = f"(withdraw in {status_text.replace('closing, ', '')})"
                else:
                    status = f"(${refund_usd:.2f} remaining)"
                
                self.add_output(f"  {i+1}. ${deposit:.2f} deposit {status}")
            self.add_output("")
            self.add_output("  /wallet closechannel <n>   - close specific channel")
            self.add_output("  /wallet closechannel all   - close all eligible channels")
            return
        
        # Validate channel number
        if channel_num < 1 or channel_num > len(sorted_channels):
            self.add_output(f"! Invalid channel number. Use 1-{len(sorted_channels)}")
            return
        
        channel = sorted_channels[channel_num - 1]
        self._close_single_channel(manager, channel, channel_num)
    
    def _check_and_reset_streaming_state(self, manager):
        """Reset streaming flags if no active channels remain."""
        import time as t
        now = int(t.time())
        active_channels = [
            ch for ch in manager._channels.values()
            if not ch.finalized 
            and ch.close_requested_at == 0 
            and ch.expiry > now
            and ch.remaining_balance() > 0
        ]
        if not active_channels:
            self._use_streaming_payments = False
            self._auto_approve_payments = False
            logger.info("No active channels remain - reset streaming state")
    
    def _close_single_channel(self, manager, channel, channel_num: int):
        """Close a single channel."""
        status_code, status_text, can_withdraw, refund = self._get_channel_status(channel)
        
        if status_code == 'finalized':
            self.add_output("! Channel already closed and withdrawn")
            return
        
        self.add_output(f"⏺ Closing channel #{channel_num}...")
        self.add_output(f"  Refund amount: ${refund/1_000_000:.2f}")
        self.draw()
        
        try:
            use_direct = self.wallet.direct_signing if self.wallet else False
            
            if can_withdraw:
                self.add_output(f"  Withdrawing ({status_text})...")
                self.draw()
                tx_hash, refund_amount = manager.withdraw(channel, use_direct_signing=use_direct)
                self.add_output(f"  ✓ Withdrawn ${refund_amount/1_000_000:.2f}")
                self.add_output(f"  tx: {tx_hash}")
            elif status_code == 'closing_wait':
                self.add_output(f"  Close already requested. {status_text}")
                self.add_output("  Run this command again after the grace period.")
            else:
                # Need to request close first
                self.add_output("  Requesting channel close...")
                self.draw()
                tx_hash = manager.request_close(channel, use_direct_signing=use_direct)
                self.add_output("  ✓ Close requested (15 min grace period)")
                self.add_output(f"  tx: {tx_hash}")
                self.add_output("")
                self.add_output("  Run /wallet closechannel again after 15 min to withdraw.")
            
            self.refresh_balance_async()
            
            # Check if we need to reset streaming state
            self._check_and_reset_streaming_state(manager)
            
        except Exception as e:
            import traceback
            logger.error(f"Close channel error: {e}\n{traceback.format_exc()}")
            self.add_output(f"! Error: {e}")
    
    def _close_all_channels(self, manager, sorted_channels):
        """Close all eligible channels."""
        from .rpc import get_tx_count
        
        use_direct = self.wallet.direct_signing if self.wallet else False
        
        withdrawn_count = 0
        withdrawn_total = 0
        close_requested_count = 0
        waiting_count = 0
        skipped_count = 0
        error_count = 0
        tx_hashes = []
        
        # Get initial nonce - we'll increment it for each tx to avoid "replacement underpriced"
        rpc_url = NETWORKS.get(self.current_network, {}).get("rpc", "")
        current_nonce = get_tx_count(self.account_address, rpc_url)
        logger.info(f"CLOSEALL: Starting with nonce={current_nonce} for {self.account_address}")
        
        self.add_output("⏺ Closing all eligible channels...")
        self.draw()
        
        for i, channel in enumerate(sorted_channels):
            status_code, status_text, can_withdraw, refund = self._get_channel_status(channel)
            num = i + 1
            
            if status_code == 'finalized':
                continue  # Skip silently
            
            try:
                if can_withdraw:
                    self.add_output(f"  #{num}: ○ Withdrawing ${refund/1_000_000:.2f}...")
                    self.draw()
                    logger.info(f"CLOSEALL: Withdrawing #{num} with nonce={current_nonce}")
                    tx_hash, refund_amount = manager.withdraw(channel, use_direct_signing=use_direct, nonce=current_nonce, skip_wait=True)
                    current_nonce += 1
                    logger.info(f"CLOSEALL: Withdraw #{num} complete, next nonce={current_nonce}")
                    # Update last line with success
                    if self.output_lines and self.output_lines[-1].startswith(f"  #{num}: ○"):
                        self.output_lines[-1] = f"  #{num}: ✓ Withdrawn ${refund_amount/1_000_000:.2f} (tx: {tx_hash[:10]}...)"
                    else:
                        self.add_output(f"  #{num}: ✓ Withdrawn ${refund_amount/1_000_000:.2f}")
                    self.draw()
                    withdrawn_count += 1
                    withdrawn_total += refund_amount
                    tx_hashes.append(tx_hash)
                elif status_code == 'closing_wait':
                    self.add_output(f"  #{num}: ⏳ Waiting ({status_text})")
                    waiting_count += 1
                elif refund > 0:
                    # Has refund, request close
                    self.add_output(f"  #{num}: ○ Requesting close (${refund/1_000_000:.2f} refund)...")
                    self.draw()
                    logger.info(f"CLOSEALL: Requesting close #{num} with nonce={current_nonce}")
                    tx_hash = manager.request_close(channel, use_direct_signing=use_direct, nonce=current_nonce, skip_wait=True)
                    current_nonce += 1
                    logger.info(f"CLOSEALL: Close request #{num} complete, next nonce={current_nonce}")
                    # Update last line with success
                    if self.output_lines and self.output_lines[-1].startswith(f"  #{num}: ○"):
                        self.output_lines[-1] = f"  #{num}: ✓ Close requested (tx: {tx_hash[:10]}...)"
                    else:
                        self.add_output(f"  #{num}: ✓ Close requested")
                    self.draw()
                    close_requested_count += 1
                    tx_hashes.append(tx_hash)
                else:
                    # $0 refund, skip to avoid gas
                    self.add_output(f"  #{num}: ⊘ Skipped ($0 remaining)")
                    skipped_count += 1
                    
            except Exception as e:
                logger.error(f"Close channel #{num} error: {e}")
                # Update last line with error if it was a pending operation
                if self.output_lines and self.output_lines[-1].startswith(f"  #{num}: ○"):
                    self.output_lines[-1] = f"  #{num}: ✗ Error: {e}"
                else:
                    self.add_output(f"  #{num}: ✗ Error: {e}")
                self.draw()
                error_count += 1
        
        # Summary
        self.add_output("")
        self.add_output("  Summary:")
        if withdrawn_count > 0:
            self.add_output(f"    Withdrawn: {withdrawn_count} channels (${withdrawn_total/1_000_000:.2f})")
        if close_requested_count > 0:
            self.add_output(f"    Close requested: {close_requested_count} (withdraw in 15 min)")
        if waiting_count > 0:
            self.add_output(f"    Waiting for grace: {waiting_count}")
        if skipped_count > 0:
            self.add_output(f"    Skipped ($0): {skipped_count}")
        if error_count > 0:
            self.add_output(f"    Errors: {error_count}")
        
        # Reset streaming state if no active channels remain
        self._check_and_reset_streaming_state(manager)
        
        self.refresh_balance_async()
    
    def show_wallet_dialog(self):
        """Display wallet info panel overlay with access key management."""
        import time as time_module
        
        network = self.get_network_name()
        network_info = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
        
        # Track selected key for switching
        selected_key_idx = self.wallet.active_key_index if self.wallet else 0
        
        height, width = self.get_dims()
        dialog_width = min(80, width - 4)
        dialog_height = min(30, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        scroll_offset = 0
        
        while True:
            # Rebuild content each loop (in case of key switch)
            wallet_content = [
                ("", "Wallet Connection", "title"),
                ("", "", ""),
            ]
            
            if self.account_address:
                wallet_content.extend([
                    ("", "Master Wallet", "section"),
                    ("Address", self.account_address, ""),
                    ("Balance", self.cached_balance or "Loading...", ""),
                    ("", "", ""),
                    ("", "Network", "section"),
                    ("Name", network_info["name"], ""),
                    ("Chain ID", str(network_info["chain_id"]), ""),
                    ("", "", ""),
                ])
                
                # Show all access keys
                if self.wallet and self.wallet.access_keys:
                    wallet_content.append(("", f"Access Keys ({len(self.wallet.access_keys)})", "section"))
                    
                    for idx, key in enumerate(self.wallet.access_keys):
                        is_active = idx == self.wallet.active_key_index
                        is_selected = idx == selected_key_idx
                        
                        # Build key display - full address (no truncation)
                        key_addr = key.address
                        status = key.time_remaining
                        
                        if key.is_expired:
                            style = "key_expired"
                        elif key.expires_soon:
                            style = "key_warning"
                        elif is_selected:
                            style = "key_selected"
                        elif is_active:
                            style = "key_active"
                        else:
                            style = "key"
                        
                        prefix = "● " if is_active else "  "
                        selector = "▶ " if is_selected else "  "
                        wallet_content.append((f"{selector}{prefix}Key {idx + 1}", f"{key_addr}  [{status}]", style))
                    
                    wallet_content.append(("", "", ""))
                    wallet_content.append(("", "↑↓ Select • Enter Switch • N New key", "hint"))
                else:
                    wallet_content.append(("", "Access Keys", "section"))
                    wallet_content.append(("", "No access keys configured", "warning"))
                    wallet_content.append(("", "Press N to create a new access key", "hint"))
            else:
                wallet_content.extend([
                    ("", "No wallet connected", "error"),
                    ("", "", ""),
                    ("", "Run /newkey to connect a wallet", ""),
                ])
            
            max_visible = dialog_height - 4
            
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                visible_content = wallet_content[scroll_offset:scroll_offset + max_visible]
                for i, (key, value, style) in enumerate(visible_content):
                    y = dialog_y + 2 + i
                    if style == "title":
                        title_x = dialog_x + (dialog_width - len(value)) // 2
                        self.stdscr.addstr(y, title_x, value, curses.color_pair(2) | curses.A_BOLD)
                    elif style == "section":
                        self.stdscr.addstr(y, dialog_x + 4, value, curses.color_pair(3) | curses.A_BOLD)
                    elif style == "error":
                        self.stdscr.addstr(y, dialog_x + 4, value, curses.color_pair(5))
                    elif style == "warning":
                        self.stdscr.addstr(y, dialog_x + 8, f"{key:16}", curses.color_pair(4))
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(4))
                    elif style == "hint":
                        hint_x = dialog_x + (dialog_width - len(value)) // 2
                        self.stdscr.addstr(y, hint_x, value, curses.A_DIM)
                    elif style == "key_selected":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.A_REVERSE | curses.A_BOLD)
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.A_REVERSE)
                    elif style == "key_active":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.color_pair(3) | curses.A_BOLD)
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(3))
                    elif style == "key_expired":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.color_pair(5))
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(5))
                    elif style == "key_warning":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.color_pair(4))
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(4))
                    elif style == "key":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.A_DIM)
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30])
                    elif key:
                        self.stdscr.addstr(y, dialog_x + 8, f"{key:14}", curses.A_DIM)
                        self.stdscr.addstr(y, dialog_x + 24, value[:dialog_width - 28])
                    elif value:
                        self.stdscr.addstr(y, dialog_x + 4, value[:dialog_width - 8], curses.A_DIM)
                
                footer = "Esc Close"
                footer_x = dialog_x + (dialog_width - len(footer)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, footer_x, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape or q
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                if self.wallet and self.wallet.access_keys:
                    selected_key_idx = max(0, selected_key_idx - 1)
                else:
                    scroll_offset = max(0, scroll_offset - 1)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                if self.wallet and self.wallet.access_keys:
                    selected_key_idx = min(len(self.wallet.access_keys) - 1, selected_key_idx + 1)
                else:
                    scroll_offset = min(max(0, len(wallet_content) - max_visible), scroll_offset + 1)
            elif ch == 10 or ch == 13:  # Enter - switch to selected key
                if self.wallet and self.wallet.access_keys and selected_key_idx != self.wallet.active_key_index:
                    self.wallet.switch_to_key(selected_key_idx)
                    # Update legacy fields
                    active_key = self.wallet.active_key
                    if active_key:
                        self.private_key = active_key.private_key
                        self.access_key_address = active_key.address
                        self.key_expiry = active_key.expiry
                    # Save config
                    save_config(self.wallet.to_dict(), CONFIG_FILE)
                    self.add_output(f"⏺ Switched to access key {selected_key_idx + 1}")
                    break
            elif ch == ord('n') or ch == ord('N'):  # New key
                break  # Close dialog, will trigger /newkey after
        
        self.draw()
        
        # If user pressed N, create new key
        if ch == ord('n') or ch == ord('N'):
            self.create_new_access_key()
    
    def show_keys_dialog(self):
        """Display access keys with expiry and spending limits."""
        logger.info("show_keys_dialog called")
        network = self.get_network_name()
        network_info = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info.get("rpc", "")
        
        # Get fee token from wallet config
        fee_token = ""
        fee_token_symbol = ""
        if self.wallet and self.wallet.fee_token and self.wallet.fee_token.is_set:
            fee_token = self.wallet.fee_token.address
            fee_token_symbol = self.wallet.fee_token.symbol
        
        if not self.account_address:
            self.add_output("! No wallet configured. Run /wallet first.")
            logger.info("show_keys_dialog: no account_address")
            return
        
        if not self.wallet or not self.wallet.access_keys:
            self.add_output("! No access keys configured. Run /wallet setup to create one.")
            logger.info(f"show_keys_dialog: no wallet or keys. wallet={self.wallet}, keys={self.wallet.access_keys if self.wallet else None}")
            return
        
        logger.info(f"show_keys_dialog: found {len(self.wallet.access_keys)} keys")
        
        # Track selected key for switching
        selected_key_idx = self.wallet.active_key_index if self.wallet else 0
        
        height, width = self.get_dims()
        dialog_width = min(75, width - 4)
        num_keys = len(self.wallet.access_keys)
        # 2 lines per key + header + footer + padding
        dialog_height = min(num_keys * 2 + 8, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Fetch spending limits and revocation status for all keys (cache them)
        key_limits = {}
        self.draw()
        try:
            self.stdscr.addstr(dialog_y + 3, dialog_x + 10, "Loading key status...", curses.A_DIM)
            self.stdscr.refresh()
        except curses.error:
            pass
        
        for key in self.wallet.access_keys:
            # Fetch on-chain status (including revocation)
            if self.account_address and rpc_url:
                try:
                    key.fetch_from_chain(self.account_address, rpc_url)
                except Exception:
                    pass
            
            if key.key_id and fee_token and rpc_url:
                limit = get_remaining_spending_limit(self.account_address, key.key_id, fee_token, rpc_url)
                key_limits[key.key_id] = format_spending_limit(limit)
            elif not fee_token:
                key_limits[key.key_id] = None  # No fee token configured
            else:
                key_limits[key.key_id] = "?"  # Error fetching
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                # Title with fee token info
                title = "Access Keys"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(2) | curses.A_BOLD)
                
                # Subtitle showing current fee token
                if fee_token_symbol:
                    subtitle = f"Limits shown for {fee_token_symbol}"
                else:
                    subtitle = "No fee token selected"
                subtitle_x = dialog_x + (dialog_width - len(subtitle)) // 2
                self.stdscr.addstr(dialog_y + 2, subtitle_x, subtitle, curses.A_DIM)
                
                # List keys - 2 lines per key
                for idx, key in enumerate(self.wallet.access_keys):
                    y_line1 = dialog_y + 4 + (idx * 2)
                    y_line2 = y_line1 + 1
                    is_active = idx == self.wallet.active_key_index
                    is_selected = idx == selected_key_idx
                    
                    # Determine style
                    if key.is_revoked:
                        color = curses.color_pair(5)  # Red for revoked
                    elif key.is_expired:
                        color = curses.color_pair(5)  # Red
                    elif key.expires_soon:
                        color = curses.color_pair(4)  # Yellow
                    elif is_active:
                        color = curses.color_pair(3)  # Green
                    else:
                        color = curses.color_pair(1)  # White
                    
                    if is_selected:
                        color |= curses.A_REVERSE
                    
                    # Prefix for line 1
                    prefix = "● " if is_active else "  "
                    selector = "▶" if is_selected else " "
                    
                    # Key ID (truncated to fit)
                    key_id_display = key.key_id if key.key_id else key.address
                    max_key_len = dialog_width - 12
                    if len(key_id_display) > max_key_len:
                        key_id_display = key_id_display[:max_key_len]
                    
                    # Line 1: selector, prefix, key ID
                    self.stdscr.addstr(y_line1, dialog_x + 3, f"{selector}{prefix}", color)
                    self.stdscr.addstr(y_line1, dialog_x + 7, key_id_display, color)
                    
                    # Line 2: expiry and limit with token (or REVOKED status)
                    if key.is_revoked:
                        detail_str = "🚫 REVOKED - cannot be used"
                    else:
                        expiry_str = key.time_remaining
                        limit_str = key_limits.get(key.key_id)
                        token_display = fee_token_symbol if fee_token_symbol else "tokens"
                        
                        # Format limit display based on what we have
                        if limit_str is None:
                            # No fee token configured - don't show limit
                            detail_str = f"expires {expiry_str}"
                        elif limit_str == "∞":
                            limit_display = f"unlimited {token_display}"
                            detail_str = f"expires {expiry_str} · {limit_display}"
                        elif limit_str == "?":
                            # Error fetching - show without limit
                            detail_str = f"expires {expiry_str}"
                        else:
                            limit_display = f"{limit_str} {token_display} remaining"
                            detail_str = f"expires {expiry_str} · {limit_display}"
                    self.stdscr.addstr(y_line2, dialog_x + 7, detail_str[:dialog_width - 12], color | curses.A_DIM if not is_selected else color)
                
                # Footer hints
                hints = "↑↓ Select • Enter Switch • N New key • Esc Close"
                hint_x = dialog_x + (dialog_width - len(hints)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, hint_x, hints, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape or q
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                selected_key_idx = max(0, selected_key_idx - 1)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                selected_key_idx = min(len(self.wallet.access_keys) - 1, selected_key_idx + 1)
            elif ch == 10 or ch == 13:  # Enter - switch to selected key
                selected_key = self.wallet.access_keys[selected_key_idx]
                # Prevent switching to revoked or expired keys
                if selected_key.is_revoked:
                    continue  # Do nothing, stay in dialog
                if selected_key.is_expired:
                    continue  # Do nothing, stay in dialog
                if selected_key_idx != self.wallet.active_key_index:
                    self.wallet.switch_to_key(selected_key_idx)
                    # Update legacy fields
                    active_key = self.wallet.active_key
                    if active_key:
                        self.private_key = active_key.private_key
                        self.access_key_address = active_key.address
                        self.key_expiry = active_key.expiry
                        # Update cached spending limit
                        self.cached_spending_limit = key_limits.get(active_key.key_id, None)
                    # Save config
                    save_config(self.wallet.to_dict(), CONFIG_FILE)
                    self.add_output(f"⏺ Switched to access key {selected_key_idx + 1}")
                    break
            elif ch == ord('n') or ch == ord('N'):  # New key
                break  # Close dialog, will trigger new key after
        
        self.draw()
        
        # If user pressed N, create new key
        if ch == ord('n') or ch == ord('N'):
            self.create_new_access_key()

    def show_wallet_balance_dialog(self):
        """Display token balances using Index Supply."""
        from .explorer import get_explorer_client, TokenBalance
        
        height, width = self.get_dims()
        dialog_width = min(70, width - 4)
        dialog_height = min(20, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        if not self.account_address:
            self.add_output("⏺ No wallet configured. Run /newkey first.")
            return
        
        # Show loading state
        self.draw()
        try:
            self.stdscr.addstr(dialog_y + 5, dialog_x + 10, "Loading balances...", curses.A_DIM)
            self.stdscr.refresh()
        except curses.error:
            pass
        
        # Fetch balances
        chain_id = NETWORKS.get(self.current_network, {}).get("chain_id")
        client = get_explorer_client(chain_id)
        balances = client.get_balances(self.account_address)
        
        scroll_offset = 0
        selected_idx = 0
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                # Title
                title = "Token Balances"
                self.stdscr.addstr(dialog_y + 1, dialog_x + (dialog_width - len(title)) // 2, title, curses.color_pair(2) | curses.A_BOLD)
                
                # Address
                addr_short = f"{self.account_address[:10]}...{self.account_address[-8:]}"
                self.stdscr.addstr(dialog_y + 2, dialog_x + 4, addr_short, curses.A_DIM)
                
                if not balances:
                    self.stdscr.addstr(dialog_y + 5, dialog_x + 4, "No token balances found", curses.A_DIM)
                else:
                    max_visible = dialog_height - 6
                    visible = balances[scroll_offset:scroll_offset + max_visible]
                    
                    for i, bal in enumerate(visible):
                        y = dialog_y + 4 + i
                        is_selected = (scroll_offset + i) == selected_idx
                        
                        amount = bal.formatted_balance
                        name = bal.name or bal.symbol or bal.token[:16]
                        
                        style = curses.A_REVERSE if is_selected else 0
                        if bal.currency == "USD":
                            style |= curses.color_pair(3)
                        
                        self.stdscr.addstr(y, dialog_x + 4, f"{amount:>20}", style | curses.A_BOLD)
                        self.stdscr.addstr(y, dialog_x + 26, f"  {name[:30]}", style)
                
                # Footer
                footer = "↑↓ Navigate • r Refresh • Esc Close"
                self.stdscr.addstr(dialog_y + dialog_height - 2, dialog_x + (dialog_width - len(footer)) // 2, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape
                break
            elif ch == curses.KEY_UP and selected_idx > 0:
                selected_idx -= 1
                if selected_idx < scroll_offset:
                    scroll_offset = selected_idx
            elif ch == curses.KEY_DOWN and selected_idx < len(balances) - 1:
                selected_idx += 1
                if selected_idx >= scroll_offset + (dialog_height - 6):
                    scroll_offset = selected_idx - (dialog_height - 7)
            elif ch == ord('r') or ch == ord('R'):  # Refresh
                balances = client.get_balances(self.account_address)
        
        self.draw()
    
    def show_key_limits(self):
        """Show the active access key's spending limits."""
        if not self.wallet or not self.wallet.active_key:
            self.add_output("⏺ No access key active. Use /newkey to create one.")
            return
        
        key = self.wallet.active_key
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info.get("rpc", "")
        
        self.add_output("")
        self.add_output(f"⏺ Access Key: {key.address[:10]}...{key.address[-6:]}")
        self.add_output(f"  Expires: {key.time_remaining}")
        
        # Refresh limits from chain
        self.add_output("  Fetching spending limits...")
        self.draw()
        
        self.wallet.refresh_active_key_limits(rpc_url)
        
        if not key.enforce_limits:
            self.add_output("  Limits: None (unlimited spending)")
            self.add_output("")
            self.add_output("  This key can spend any token with no restrictions.")
            return
        
        usable = key.get_usable_tokens()
        if not usable:
            self.add_output("  ⚠ No spending limits found for any tokens")
            self.add_output("")
            self.add_output("  This key has limits enabled but no tokens configured.")
            self.add_output("  Use the web wallet to set spending limits.")
            return
        
        # Clear the "Fetching..." line and show results
        self.output_lines = [l for l in self.output_lines if "Fetching spending limits" not in l]
        self.add_output("  Spending Limits:")
        for tok in usable:
            remaining = tok["remaining"] / (10 ** tok["decimals"])
            self.add_output(f"    {tok['symbol']}: ${remaining:,.2f} remaining")
        self.add_output("")
    
    def show_fee_token_preferences(self):
        """Show fee token preferences dialog.
        
        Options:
        1. Match transfer token - use same token as TIP20 transfer when applicable
        2. Select from wallet tokens - sorted by balance
        """
        from .explorer import get_explorer_client
        from .wallet import FeeToken
        from .config import save_config, CONFIG_FILE
        
        if not self.wallet or not self.account_address:
            self.add_output("⏺ No wallet configured. Use /newkey to set up.")
            return
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        chain_id = network_info.get("chain_id")
        rpc_url = network_info.get("rpc", "")
        
        # Fetch wallet token balances
        self.add_output("")
        self.add_output("@ Loading token balances...")
        self.draw()
        
        try:
            client = get_explorer_client(chain_id, rpc_url=rpc_url)
            balances = client.get_balances(self.account_address)
        except Exception as e:
            self.output_lines = [l for l in self.output_lines if "Loading token" not in l]
            self.add_output(f"! Error loading balances: {e}")
            return
        
        # Sort by balance (highest first)
        balances.sort(key=lambda b: b.balance, reverse=True)
        
        if not balances:
            self.output_lines = [l for l in self.output_lines if "Loading token" not in l]
            self.add_output("⏺ No tokens found in wallet.")
            return
        
        # Clear loading message
        self.output_lines = [l for l in self.output_lines if "Loading token" not in l]
        
        # Current fee token preference
        current_fee_token = self.wallet.fee_token if self.wallet else None
        match_transfer = getattr(self.wallet, 'fee_token_match_transfer', False) if self.wallet else False
        
        height, width = self.get_dims()
        dialog_width = min(70, width - 4)
        dialog_height = min(len(balances) + 10, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        selected_idx = 0  # 0 = match transfer option, 1+ = token options
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                # Title
                title = "Fee Token Preferences"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(2) | curses.A_BOLD)
                
                # Current setting
                if current_fee_token and current_fee_token.is_set:
                    current_str = f"Current: {current_fee_token.symbol}"
                else:
                    current_str = "Current: Auto (first available)"
                self.stdscr.addstr(dialog_y + 2, dialog_x + 4, current_str, curses.A_DIM)
                
                # Option 1: Match transfer token
                y_opt = dialog_y + 4
                prefix = "●" if match_transfer else "○"
                selector = "▶" if selected_idx == 0 else " "
                opt_text = f"{selector} {prefix} Match transfer token (use same as TIP20 transfer)"
                if selected_idx == 0:
                    self.stdscr.addstr(y_opt, dialog_x + 4, opt_text[:dialog_width - 8], curses.A_REVERSE)
                else:
                    self.stdscr.addstr(y_opt, dialog_x + 4, opt_text[:dialog_width - 8])
                
                # Separator
                self.stdscr.addstr(dialog_y + 5, dialog_x + 4, "─" * (dialog_width - 8), curses.A_DIM)
                self.stdscr.addstr(dialog_y + 6, dialog_x + 4, "Or select a specific token:", curses.A_DIM)
                
                # Token options (sorted by balance)
                max_tokens = dialog_height - 10
                for i, bal in enumerate(balances[:max_tokens]):
                    y_tok = dialog_y + 7 + i
                    tok_idx = i + 1  # Offset by 1 for the match transfer option
                    
                    is_current = (current_fee_token and current_fee_token.address.lower() == bal.token.lower())
                    prefix = "●" if is_current and not match_transfer else "○"
                    selector = "▶" if selected_idx == tok_idx else " "
                    
                    # Format balance
                    bal_display = bal.balance / (10 ** bal.decimals)
                    tok_text = f"{selector} {prefix} {bal.symbol}: ${bal_display:,.2f}"
                    
                    if selected_idx == tok_idx:
                        self.stdscr.addstr(y_tok, dialog_x + 4, tok_text[:dialog_width - 8], curses.A_REVERSE)
                    else:
                        self.stdscr.addstr(y_tok, dialog_x + 4, tok_text[:dialog_width - 8])
                
                # Footer
                footer = "↑↓ Select • Enter Confirm • Esc Cancel"
                footer_x = dialog_x + (dialog_width - len(footer)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, footer_x, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            max_idx = min(len(balances), dialog_height - 10)  # Token options
            
            if ch == 27 or ch == ord('q'):  # Escape
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                selected_idx = max(0, selected_idx - 1)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                selected_idx = min(max_idx, selected_idx + 1)
            elif ch == 10 or ch == 13:  # Enter
                if selected_idx == 0:
                    # Match transfer token option
                    if self.wallet:
                        self.wallet.fee_token_match_transfer = True
                        self.wallet.fee_token = FeeToken()  # Clear specific token
                        save_config(self.wallet.to_dict(), CONFIG_FILE)
                        self.add_output("⏺ Fee token: Will match transfer token")
                else:
                    # Specific token selected
                    bal = balances[selected_idx - 1]
                    if self.wallet:
                        self.wallet.fee_token_match_transfer = False
                        self.wallet.fee_token = FeeToken(
                            address=bal.token,
                            symbol=bal.symbol,
                            decimals=bal.decimals,
                            name=bal.name or bal.symbol
                        )
                        save_config(self.wallet.to_dict(), CONFIG_FILE)
                        self.add_output(f"⏺ Fee token set to: {bal.symbol}")
                break
        
        self.draw()
    
    def show_fee_token_picker(self, allow_skip: bool = False) -> bool:
        """Show dialog to select fee token from wallet balances.
        
        DEPRECATED: This picker should no longer be shown. Token selection is now
        derived from the access key's on-chain spending limits.
        
        Args:
            allow_skip: If True, show Skip option (for initial setup). If False, require selection.
            
        Returns:
            True if a token was selected, False if cancelled/skipped.
        """
        from .explorer import get_explorer_client, TokenBalance
        from .wallet import FeeToken
        
        height, width = self.get_dims()
        dialog_width = min(70, width - 4)
        dialog_height = min(20, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        if not self.account_address:
            self.add_output("⏺ No wallet configured. Run /newkey first.")
            return False
        
        # Show loading state
        self.draw()
        try:
            self.stdscr.addstr(dialog_y + 5, dialog_x + 10, "Fetching token balances...", curses.A_DIM)
            self.stdscr.refresh()
        except curses.error:
            pass
        
        # Fetch balances
        chain_id = NETWORKS.get(self.current_network, {}).get("chain_id")
        rpc_url = NETWORKS.get(self.current_network, {}).get("rpc", "")
        client = get_explorer_client(chain_id, rpc_url=rpc_url)
        balances = client.get_balances(self.account_address)
        
        # Filter to tokens with non-zero balance
        balances = [b for b in balances if b.balance > 0]
        
        scroll_offset = 0
        selected_idx = 0
        
        # If current fee token is set, try to select it
        if self.wallet and self.wallet.fee_token.is_set:
            for i, bal in enumerate(balances):
                if bal.token.lower() == self.wallet.fee_token.address.lower():
                    selected_idx = i
                    break
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                # Title
                title = "Select Fee Token"
                self.stdscr.addstr(dialog_y + 1, dialog_x + (dialog_width - len(title)) // 2, title, curses.color_pair(2) | curses.A_BOLD)
                
                # Subtitle
                subtitle = "This token will be used for all transaction fees"
                self.stdscr.addstr(dialog_y + 2, dialog_x + (dialog_width - len(subtitle)) // 2, subtitle, curses.A_DIM)
                
                if not balances:
                    # No tokens - show options
                    self.stdscr.addstr(dialog_y + 5, dialog_x + 4, "No tokens found in wallet.", curses.A_DIM)
                    self.stdscr.addstr(dialog_y + 7, dialog_x + 4, "You need tokens to pay for transactions.", curses.A_DIM)
                    self.stdscr.addstr(dialog_y + 9, dialog_x + 4, "(r) Retry   (f) Fund wallet   (Esc) Cancel", curses.A_DIM)
                else:
                    max_visible = dialog_height - 7
                    visible = balances[scroll_offset:scroll_offset + max_visible]
                    
                    for i, bal in enumerate(visible):
                        y = dialog_y + 4 + i
                        is_selected = (scroll_offset + i) == selected_idx
                        
                        amount = bal.formatted_balance
                        symbol = bal.symbol or bal.token[:10]
                        name = bal.name or ""
                        
                        style = curses.A_REVERSE if is_selected else 0
                        if bal.currency == "USD" or bal.symbol in ("USD", "USDC", "USDT"):
                            style |= curses.color_pair(3)
                        
                        # Show: SYMBOL  BALANCE  NAME
                        line = f"{symbol:>8}  {amount:>16}  {name[:25]}"
                        self.stdscr.addstr(y, dialog_x + 4, line[:dialog_width - 8], style)
                
                # Footer
                if balances:
                    if allow_skip:
                        footer = "↑↓ Navigate • Enter Select • r Refresh • Esc Skip"
                    else:
                        footer = "↑↓ Navigate • Enter Select • r Refresh • Esc Cancel"
                else:
                    footer = ""
                if footer:
                    self.stdscr.addstr(dialog_y + dialog_height - 2, dialog_x + (dialog_width - len(footer)) // 2, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27:  # Escape - cancel/skip
                return False
            elif ch == 10 or ch == 13:  # Enter - select
                if balances and 0 <= selected_idx < len(balances):
                    selected = balances[selected_idx]
                    # Save to wallet config
                    if self.wallet:
                        self.wallet.set_fee_token(
                            address=selected.token,
                            symbol=selected.symbol,
                            decimals=selected.decimals,
                            name=selected.name
                        )
                        save_config(self.wallet.to_dict(), CONFIG_FILE)
                        self.add_output(f"⏺ Fee token set to {selected.symbol or selected.token[:10]}")
                    return True
            elif ch == curses.KEY_UP and selected_idx > 0:
                selected_idx -= 1
                if selected_idx < scroll_offset:
                    scroll_offset = selected_idx
            elif ch == curses.KEY_DOWN and balances and selected_idx < len(balances) - 1:
                selected_idx += 1
                if selected_idx >= scroll_offset + (dialog_height - 7):
                    scroll_offset = selected_idx - (dialog_height - 8)
            elif ch == ord('r') or ch == ord('R'):  # Refresh
                balances = client.get_balances(self.account_address)
                balances = [b for b in balances if b.balance > 0]
                selected_idx = 0
                scroll_offset = 0
            elif ch == ord('f') or ch == ord('F'):  # Fund wallet
                # Open faucet/explorer in browser
                explorer_url = NETWORKS.get(self.current_network, {}).get("explorer", "")
                if explorer_url and self.account_address:
                    webbrowser.open(f"{explorer_url}/address/{self.account_address}")
        
        return False
    
    def show_wallet_transfers_dialog(self, direction: str = "all"):
        """Display TIP-20 transfer history using Index Supply."""
        from .explorer import get_explorer_client, Transfer
        
        height, width = self.get_dims()
        dialog_width = min(85, width - 4)
        dialog_height = min(22, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        if not self.account_address:
            self.add_output("⏺ No wallet configured. Run /newkey first.")
            return
        
        # Show loading
        self.draw()
        try:
            self.stdscr.addstr(dialog_y + 5, dialog_x + 10, "Loading transfers...", curses.A_DIM)
            self.stdscr.refresh()
        except curses.error:
            pass
        
        chain_id = NETWORKS.get(self.current_network, {}).get("chain_id")
        client = get_explorer_client(chain_id)
        transfers = client.get_transfers(self.account_address, direction=direction, limit=100)
        
        scroll_offset = 0
        selected_idx = 0
        current_direction = direction
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                # Title with filter
                filter_text = {"all": "All", "sent": "Sent", "received": "Received"}[current_direction]
                title = f"Transfers ({filter_text})"
                self.stdscr.addstr(dialog_y + 1, dialog_x + (dialog_width - len(title)) // 2, title, curses.color_pair(2) | curses.A_BOLD)
                
                # Header
                self.stdscr.addstr(dialog_y + 3, dialog_x + 4, "Date", curses.A_DIM)
                self.stdscr.addstr(dialog_y + 3, dialog_x + 22, "Dir", curses.A_DIM)
                self.stdscr.addstr(dialog_y + 3, dialog_x + 28, "Amount", curses.A_DIM)
                self.stdscr.addstr(dialog_y + 3, dialog_x + 48, "Address", curses.A_DIM)
                
                if not transfers:
                    self.stdscr.addstr(dialog_y + 6, dialog_x + 4, "No transfers found", curses.A_DIM)
                else:
                    max_visible = dialog_height - 7
                    visible = transfers[scroll_offset:scroll_offset + max_visible]
                    
                    for i, tx in enumerate(visible):
                        y = dialog_y + 4 + i
                        is_selected = (scroll_offset + i) == selected_idx
                        
                        d = tx.direction(self.account_address)
                        is_received = d == "received"
                        arrow = "←" if is_received else "→"
                        other = tx.from_addr if is_received else tx.to_addr
                        other_short = f"{other[:8]}...{other[-6:]}"
                        
                        style = curses.A_REVERSE if is_selected else 0
                        color = curses.color_pair(3) if is_received else curses.color_pair(5)
                        
                        self.stdscr.addstr(y, dialog_x + 4, tx.formatted_time, style)
                        self.stdscr.addstr(y, dialog_x + 22, arrow, style | color | curses.A_BOLD)
                        self.stdscr.addstr(y, dialog_x + 26, f"{tx.formatted_amount:>18}", style | color)
                        self.stdscr.addstr(y, dialog_x + 48, other_short, style)
                
                # Footer
                footer = "↑↓ Nav • f Filter • r Refresh • Esc Close"
                self.stdscr.addstr(dialog_y + dialog_height - 2, dialog_x + (dialog_width - len(footer)) // 2, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):
                break
            elif ch == curses.KEY_UP and selected_idx > 0:
                selected_idx -= 1
                if selected_idx < scroll_offset:
                    scroll_offset = selected_idx
            elif ch == curses.KEY_DOWN and selected_idx < len(transfers) - 1:
                selected_idx += 1
                if selected_idx >= scroll_offset + (dialog_height - 7):
                    scroll_offset = selected_idx - (dialog_height - 8)
            elif ch == ord('f') or ch == ord('F'):  # Toggle filter
                filters = ["all", "sent", "received"]
                idx = filters.index(current_direction)
                current_direction = filters[(idx + 1) % 3]
                transfers = client.get_transfers(self.account_address, direction=current_direction, limit=100)
                scroll_offset = 0
                selected_idx = 0
            elif ch == ord('r') or ch == ord('R'):
                transfers = client.get_transfers(self.account_address, direction=current_direction, limit=100)
        
        self.draw()
    
    def show_wallet_txs_dialog(self):
        """Display transaction history using Index Supply."""
        from .explorer import get_explorer_client, Transaction
        
        height, width = self.get_dims()
        dialog_width = min(85, width - 4)
        dialog_height = min(22, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        if not self.account_address:
            self.add_output("⏺ No wallet configured. Run /newkey first.")
            return
        
        # Show loading
        self.draw()
        try:
            self.stdscr.addstr(dialog_y + 5, dialog_x + 10, "Loading transactions...", curses.A_DIM)
            self.stdscr.refresh()
        except curses.error:
            pass
        
        chain_id = NETWORKS.get(self.current_network, {}).get("chain_id")
        client = get_explorer_client(chain_id)
        txs = client.get_transactions(self.account_address, limit=100)
        
        scroll_offset = 0
        selected_idx = 0
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                title = "Transaction History"
                self.stdscr.addstr(dialog_y + 1, dialog_x + (dialog_width - len(title)) // 2, title, curses.color_pair(2) | curses.A_BOLD)
                
                # Header
                self.stdscr.addstr(dialog_y + 3, dialog_x + 4, "Date", curses.A_DIM)
                self.stdscr.addstr(dialog_y + 3, dialog_x + 22, "Status", curses.A_DIM)
                self.stdscr.addstr(dialog_y + 3, dialog_x + 32, "Hash", curses.A_DIM)
                self.stdscr.addstr(dialog_y + 3, dialog_x + 56, "To", curses.A_DIM)
                
                if not txs:
                    self.stdscr.addstr(dialog_y + 6, dialog_x + 4, "No transactions found", curses.A_DIM)
                else:
                    max_visible = dialog_height - 7
                    visible = txs[scroll_offset:scroll_offset + max_visible]
                    
                    for i, tx in enumerate(visible):
                        y = dialog_y + 4 + i
                        is_selected = (scroll_offset + i) == selected_idx
                        
                        status = "✓" if tx.status else "✗"
                        status_color = curses.color_pair(3) if tx.status else curses.color_pair(5)
                        hash_short = f"{tx.hash[:10]}...{tx.hash[-6:]}"
                        to_short = f"{tx.to_addr[:8]}...{tx.to_addr[-6:]}" if tx.to_addr else "Contract"
                        
                        style = curses.A_REVERSE if is_selected else 0
                        
                        self.stdscr.addstr(y, dialog_x + 4, tx.formatted_time, style)
                        self.stdscr.addstr(y, dialog_x + 22, status, style | status_color | curses.A_BOLD)
                        self.stdscr.addstr(y, dialog_x + 28, hash_short, style)
                        self.stdscr.addstr(y, dialog_x + 52, to_short, style | curses.A_DIM)
                
                footer = "↑↓ Navigate • r Refresh • Esc Close"
                self.stdscr.addstr(dialog_y + dialog_height - 2, dialog_x + (dialog_width - len(footer)) // 2, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):
                break
            elif ch == curses.KEY_UP and selected_idx > 0:
                selected_idx -= 1
                if selected_idx < scroll_offset:
                    scroll_offset = selected_idx
            elif ch == curses.KEY_DOWN and selected_idx < len(txs) - 1:
                selected_idx += 1
                if selected_idx >= scroll_offset + (dialog_height - 7):
                    scroll_offset = selected_idx - (dialog_height - 8)
            elif ch == ord('r') or ch == ord('R'):
                txs = client.get_transactions(self.account_address, limit=100)
        
        self.draw()
    
    def show_wallet_channels_dialog(self):
        """Display streaming payment channels."""
        from .streaming import get_stream_manager
        
        height, width = self.get_dims()
        dialog_width = min(80, width - 4)
        dialog_height = min(18, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        manager = get_stream_manager()
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                title = "Streaming Payment Channels"
                self.stdscr.addstr(dialog_y + 1, dialog_x + (dialog_width - len(title)) // 2, title, curses.color_pair(2) | curses.A_BOLD)
                
                if not manager:
                    self.stdscr.addstr(dialog_y + 4, dialog_x + 4, "No stream manager initialized", curses.A_DIM)
                    self.stdscr.addstr(dialog_y + 5, dialog_x + 4, "Channels are created when using streaming payments", curses.A_DIM)
                elif not manager._channels:
                    self.stdscr.addstr(dialog_y + 4, dialog_x + 4, "No active payment channels", curses.A_DIM)
                    self.stdscr.addstr(dialog_y + 5, dialog_x + 4, "Channels are created automatically during API calls", curses.A_DIM)
                else:
                    # Header
                    self.stdscr.addstr(dialog_y + 3, dialog_x + 4, "Channel ID", curses.A_DIM)
                    self.stdscr.addstr(dialog_y + 3, dialog_x + 30, "Deposit", curses.A_DIM)
                    self.stdscr.addstr(dialog_y + 3, dialog_x + 45, "Used", curses.A_DIM)
                    self.stdscr.addstr(dialog_y + 3, dialog_x + 58, "Remaining", curses.A_DIM)
                    
                    row = 0
                    for key, channel in list(manager._channels.items())[:10]:
                        y = dialog_y + 4 + row
                        
                        ch_id = f"{channel.channel_id[:10]}...{channel.channel_id[-6:]}"
                        deposit = f"${channel.deposit / 1_000_000:.2f}"
                        used = f"${channel.cumulative_amount / 1_000_000:.2f}"
                        remaining = f"${channel.remaining_balance() / 1_000_000:.2f}"
                        
                        is_expired = channel.expiry <= int(__import__('time').time())
                        is_depleted = channel.remaining_balance() <= 0
                        
                        if is_expired:
                            style = curses.color_pair(5)
                        elif is_depleted:
                            style = curses.color_pair(4)
                        else:
                            style = curses.color_pair(3)
                        
                        self.stdscr.addstr(y, dialog_x + 4, ch_id, 0)
                        self.stdscr.addstr(y, dialog_x + 30, deposit, curses.A_DIM)
                        self.stdscr.addstr(y, dialog_x + 45, used, style)
                        self.stdscr.addstr(y, dialog_x + 58, remaining, style | curses.A_BOLD)
                        
                        row += 1
                
                footer = "Esc Close"
                self.stdscr.addstr(dialog_y + dialog_height - 2, dialog_x + (dialog_width - len(footer)) // 2, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):
                break
        
        self.draw()
    
    def show_model_selector(self):
        """Display model selection popup near the model box."""
        height, width = self.get_dims()
        
        # Find current model index
        current_idx = 0
        for i, (model_id, _) in enumerate(AVAILABLE_MODELS):
            if model_id == self.current_model:
                current_idx = i
                break
        
        selected_idx = current_idx
        
        # Calculate popup dimensions
        max_name_len = max(len(name) for _, name in AVAILABLE_MODELS)
        popup_width = max_name_len + 6
        popup_height = len(AVAILABLE_MODELS) + 2
        
        # Position popup in center of screen
        popup_x = max(1, (width - popup_width) // 2)
        popup_y = max(1, (height - popup_height) // 2)
        
        while True:
            self.draw()
            
            try:
                # Draw popup background
                for i in range(popup_height):
                    y = popup_y + i
                    if i == 0:
                        self.stdscr.addstr(y, popup_x, "╭" + "─" * (popup_width - 2) + "╮", curses.color_pair(1))
                    elif i == popup_height - 1:
                        self.stdscr.addstr(y, popup_x, "╰" + "─" * (popup_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, popup_x, "│" + " " * (popup_width - 2) + "│", curses.color_pair(1))
                
                # Draw model options
                for i, (model_id, model_name) in enumerate(AVAILABLE_MODELS):
                    y = popup_y + 1 + i
                    is_selected = i == selected_idx
                    is_current = model_id == self.current_model
                    
                    if is_selected:
                        attr = curses.A_REVERSE
                    elif is_current:
                        attr = curses.color_pair(3)
                    else:
                        attr = 0
                    
                    prefix = "● " if is_current else "  "
                    self.stdscr.addstr(y, popup_x + 2, f"{prefix}{model_name}"[:popup_width - 4], attr)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape or q
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                selected_idx = (selected_idx - 1) % len(AVAILABLE_MODELS)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                selected_idx = (selected_idx + 1) % len(AVAILABLE_MODELS)
            elif ch == 10 or ch == 13:  # Enter
                model_id, model_name = AVAILABLE_MODELS[selected_idx]
                self.current_model = model_id
                self.context_limit = get_model_context_length(model_id)
                self.add_output(f"⏺ Model: {model_name} ({self.context_limit // 1000}k context)")
                break
        
        self.draw()
    
    def show_proxy_url_dialog(self):
        """Display dialog to set the payments proxy URL."""
        from .runtime_settings import get_settings, update_proxy_url
        
        height, width = self.get_dims()
        current_url = get_settings().get_proxy_url()
        
        dialog_width = min(70, width - 4)
        dialog_height = 10
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        url_buffer = current_url
        cursor_pos = len(url_buffer)
        
        while True:
            self.draw()
            
            try:
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                title = "Set Payments Proxy URL"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(2) | curses.A_BOLD)
                
                self.stdscr.addstr(dialog_y + 3, dialog_x + 3, "URL:", curses.A_DIM)
                
                max_display = dialog_width - 12
                if len(url_buffer) > max_display:
                    start = max(0, cursor_pos - max_display + 5)
                    display_url = url_buffer[start:start + max_display]
                    display_cursor = cursor_pos - start
                else:
                    display_url = url_buffer
                    display_cursor = cursor_pos
                
                self.stdscr.addstr(dialog_y + 4, dialog_x + 3, display_url[:max_display])
                
                if display_cursor < max_display:
                    self.stdscr.addstr(dialog_y + 4, dialog_x + 3 + display_cursor, "_", curses.A_BLINK)
                
                hint = "Enter: Save  Esc: Cancel  Ctrl+U: Clear"
                hint_x = dialog_x + (dialog_width - len(hint)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, hint_x, hint, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27:  # Escape
                break
            elif ch == 10 or ch == 13:  # Enter
                if url_buffer.startswith("http://") or url_buffer.startswith("https://"):
                    self.set_proxy_url(url_buffer)
                    break
                else:
                    pass
            elif ch == 21:  # Ctrl+U - clear
                url_buffer = ""
                cursor_pos = 0
            elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                if cursor_pos > 0:
                    url_buffer = url_buffer[:cursor_pos-1] + url_buffer[cursor_pos:]
                    cursor_pos -= 1
            elif ch == curses.KEY_LEFT:
                cursor_pos = max(0, cursor_pos - 1)
            elif ch == curses.KEY_RIGHT:
                cursor_pos = min(len(url_buffer), cursor_pos + 1)
            elif ch == 1:  # Ctrl+A - start of line
                cursor_pos = 0
            elif ch == 5:  # Ctrl+E - end of line
                cursor_pos = len(url_buffer)
            elif ch >= 32 and ch < 127:
                url_buffer = url_buffer[:cursor_pos] + chr(ch) + url_buffer[cursor_pos:]
                cursor_pos += 1
        
        self.draw()
    
    def set_proxy_url(self, url: str):
        """Set the payments proxy URL."""
        from .runtime_settings import get_settings, update_proxy_url
        
        if not url.startswith("http://") and not url.startswith("https://"):
            self.add_output(f"! Invalid URL: must start with http:// or https://")
            return
        
        old_url = get_settings().get_proxy_url()
        update_proxy_url(url)
        
        if url.rstrip('/') != old_url.rstrip('/'):
            self.add_output(f"⏺ Proxy URL updated")
            self.add_output(f"  {url}")
        else:
            self.add_output(f"⏺ Proxy URL unchanged")
    
    def show_rpc_url_dialog(self):
        """Display dialog to set a custom RPC URL override."""
        from .runtime_settings import get_settings, update_rpc_url_override
        
        height, width = self.get_dims()
        settings = get_settings()
        current_url = settings.get_rpc_url()
        is_override = settings.rpc_url_override is not None
        
        dialog_width = min(70, width - 4)
        dialog_height = 12
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        url_buffer = current_url
        cursor_pos = len(url_buffer)
        
        while True:
            self.draw()
            
            try:
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                title = "Set Custom RPC URL"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(2) | curses.A_BOLD)
                
                network_info = f"Network: {settings.get_network()} (chain {settings.get_chain_id()})"
                self.stdscr.addstr(dialog_y + 3, dialog_x + 3, network_info, curses.A_DIM)
                
                status = "Custom" if is_override else "Default"
                self.stdscr.addstr(dialog_y + 4, dialog_x + 3, f"Status: {status}", curses.A_DIM)
                
                self.stdscr.addstr(dialog_y + 6, dialog_x + 3, "URL:", curses.A_DIM)
                
                max_display = dialog_width - 12
                if len(url_buffer) > max_display:
                    start = max(0, cursor_pos - max_display + 5)
                    display_url = url_buffer[start:start + max_display]
                    display_cursor = cursor_pos - start
                else:
                    display_url = url_buffer
                    display_cursor = cursor_pos
                
                self.stdscr.addstr(dialog_y + 7, dialog_x + 3, display_url[:max_display])
                
                if display_cursor < max_display:
                    self.stdscr.addstr(dialog_y + 7, dialog_x + 3 + display_cursor, "_", curses.A_BLINK)
                
                hint = "Enter: Save  Esc: Cancel  Ctrl+R: Reset to default"
                hint_x = dialog_x + (dialog_width - len(hint)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, hint_x, hint, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27:  # Escape
                break
            elif ch == 10 or ch == 13:  # Enter
                if url_buffer.startswith("http://") or url_buffer.startswith("https://"):
                    self.set_rpc_url_override(url_buffer)
                    break
                else:
                    pass
            elif ch == 18:  # Ctrl+R - reset to default
                self.clear_rpc_url_override()
                break
            elif ch == 21:  # Ctrl+U - clear
                url_buffer = ""
                cursor_pos = 0
            elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                if cursor_pos > 0:
                    url_buffer = url_buffer[:cursor_pos-1] + url_buffer[cursor_pos:]
                    cursor_pos -= 1
            elif ch == curses.KEY_LEFT:
                cursor_pos = max(0, cursor_pos - 1)
            elif ch == curses.KEY_RIGHT:
                cursor_pos = min(len(url_buffer), cursor_pos + 1)
            elif ch == 1:  # Ctrl+A - start of line
                cursor_pos = 0
            elif ch == 5:  # Ctrl+E - end of line
                cursor_pos = len(url_buffer)
            elif ch >= 32 and ch < 127:
                url_buffer = url_buffer[:cursor_pos] + chr(ch) + url_buffer[cursor_pos:]
                cursor_pos += 1
        
        self.draw()
    
    def set_rpc_url_override(self, url: str):
        """Set a custom RPC URL override and reinitialize stream manager."""
        from .runtime_settings import get_settings, update_rpc_url_override
        from .streaming import update_stream_manager_rpc
        
        if not url.startswith("http://") and not url.startswith("https://"):
            self.add_output(f"! Invalid URL: must start with http:// or https://")
            return
        
        settings = get_settings()
        old_url = settings.get_rpc_url()
        update_rpc_url_override(url)
        
        new_rpc = settings.get_rpc_url()
        chain_id = settings.get_chain_id()
        update_stream_manager_rpc(new_rpc, chain_id)
        
        self.cached_balance = None
        self.last_balance_check = 0
        
        if url.rstrip('/') != old_url.rstrip('/'):
            self.add_output(f"⏺ RPC URL updated (custom override)")
            self.add_output(f"  {url}")
        else:
            self.add_output(f"⏺ RPC URL unchanged")
    
    def clear_rpc_url_override(self):
        """Clear the custom RPC URL override and return to network default."""
        from .runtime_settings import get_settings, clear_rpc_url_override
        from .streaming import update_stream_manager_rpc
        
        settings = get_settings()
        clear_rpc_url_override()
        
        new_rpc = settings.get_rpc_url()
        chain_id = settings.get_chain_id()
        update_stream_manager_rpc(new_rpc, chain_id)
        
        self.cached_balance = None
        self.last_balance_check = 0
        
        network_name = settings.get_network()
        self.add_output(f"⏺ RPC URL reset to {network_name} default")
        self.add_output(f"  {new_rpc}")
    
    def show_usage_dialog(self):
        """Show session usage details in a dialog."""
        height, width = self.get_dims()
        
        # Calculate dialog dimensions
        dialog_width = min(50, width - 8)
        dialog_height = 15
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Calculate stats
        context_pct = min(100, int((self.session_tokens / self.context_limit) * 100)) if self.context_limit else 0
        if self.session_tokens >= 1000:
            tokens_str = f"{self.session_tokens // 1000}k"
        else:
            tokens_str = str(self.session_tokens)
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        fee_token_name = network_info.get('fee_token_name', 'tokens')
        
        # Block for input (no timeout)
        self.stdscr.timeout(-1)
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                # Title
                title = "Session Usage"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.A_BOLD | curses.color_pair(3))
                
                # Context Window
                self.stdscr.addstr(dialog_y + 3, dialog_x + 3, "Context Window", curses.A_BOLD)
                self.stdscr.addstr(dialog_y + 4, dialog_x + 5, f"Used:    {tokens_str} tokens ({context_pct}%)")
                self.stdscr.addstr(dialog_y + 5, dialog_x + 5, f"Limit:   {self.context_limit // 1000}k tokens")
                
                # Payments
                self.stdscr.addstr(dialog_y + 7, dialog_x + 3, "Payments", curses.A_BOLD)
                self.stdscr.addstr(dialog_y + 8, dialog_x + 5, f"Total:    ${self.session_cost:.4f} {fee_token_name}")
                self.stdscr.addstr(dialog_y + 9, dialog_x + 5, f"Txs:      {self.session_tx_count}")
                self.stdscr.addstr(dialog_y + 10, dialog_x + 5, f"Vouchers: {self.session_voucher_count}")
                
                # Model
                model_short = self.current_model.split("/")[-1]
                self.stdscr.addstr(dialog_y + 12, dialog_x + 5, f"Model:   {model_short}", curses.A_DIM)
                
                # Help text
                help_text = "Press any key to close"
                help_x = dialog_x + (dialog_width - len(help_text)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, help_x, help_text, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            # Any key closes the dialog
            if ch != -1:
                break
        
        # Restore timeout
        self.stdscr.timeout(100)
        self.draw()
    
    def show_wallet_onboarding(self, pending_query: str):
        """Show delightful onboarding when user sends first query without wallet.
        
        Prompts user to press Enter to connect wallet via browser.
        After successful connection, automatically sends the pending query.
        """
        self.add_output("")
        self.add_output("  ╔══════════════════════════════════════════════════════╗")
        self.add_output("  ║                                                      ║")
        self.add_output("  ║   ⚡  CONNECT WALLET TO START                        ║")
        self.add_output("  ║                                                      ║")
        self.add_output("  ║   No API keys. No accounts. Just stablecoins.        ║")
        self.add_output("  ║                                                      ║")
        self.add_output("  ║   Your browser will open to connect your wallet.     ║")
        self.add_output("  ║   Create a new passkey or use an existing one.       ║")
        self.add_output("  ║   Pay per request with stablecoins (~$0.01 each).    ║")
        self.add_output("  ║                                                      ║")
        self.add_output("  ╚══════════════════════════════════════════════════════╝")
        self.add_output("")
        
        # Animated "Press Enter" prompt
        enter_frames = [
            "  ▶▶▶  PRESS ENTER TO CONNECT  ◀◀◀",
            "  ▷▶▶  PRESS ENTER TO CONNECT  ◀◀◁",
            "  ▷▷▶  PRESS ENTER TO CONNECT  ◀◁◁",
            "  ▷▷▷  PRESS ENTER TO CONNECT  ◁◁◁",
            "  ▷▷▶  PRESS ENTER TO CONNECT  ◀◁◁",
            "  ▷▶▶  PRESS ENTER TO CONNECT  ◀◀◁",
        ]
        
        # Add placeholder for animated line
        self.add_output(enter_frames[0])
        enter_line_idx = len(self.output_lines) - 1
        self.draw()
        
        # Wait for Enter key with animation
        frame = 0
        while True:
            # Update animation
            self.output_lines[enter_line_idx] = enter_frames[frame % len(enter_frames)]
            frame += 1
            self.draw()
            
            ch = self.stdscr.getch()
            if ch == 10 or ch == 13:  # Enter
                break
            elif ch == 27 or ch == 3:  # Escape or Ctrl+C
                self.add_output("")
                self.add_output("⏺ No worries! Run /wallet when you're ready.")
                return
            elif ch == curses.KEY_RESIZE:
                self.draw()
        
        # Clear onboarding box and run wallet setup
        self.output_lines = [
            line for line in self.output_lines 
            if not any(x in line for x in [
                "╔═",
                "╚═",
                "║",  # Box frame lines
                "CONNECT WALLET",
                "No API keys",
                "browser will open",
                "new passkey or use",
                "Pay per request",
                "PRESS ENTER TO CONNECT",
                "▶▶▶",
                "▷▷▷",
            ])
        ]
        
        # Store pending query to send after wallet setup
        self._pending_query = pending_query
        
        # Run wallet setup
        self.create_new_access_key()
        
        # After wallet setup, if successful, send the pending query
        if self.private_key and hasattr(self, '_pending_query') and self._pending_query:
            query = self._pending_query
            delattr(self, '_pending_query')
            # Small delay for UI to settle
            time.sleep(0.2)
            self.process_command(query)
        elif hasattr(self, '_pending_query'):
            delattr(self, '_pending_query')
    
    def create_new_access_key(self):
        """Create new access key via browser flow, keeping TUI alive."""
        self.add_output("")
        self.add_output("⏺ Opening browser to create new access key...")
        self.add_output("$ Starting auth server...")
        self.draw()
        
        # Run browser setup in thread so we can keep TUI alive
        import threading
        setup_result = {"config": None, "done": False, "error": None}
        
        def do_setup():
            try:
                # Pass existing account_address if we have one (for /newkey on existing wallet)
                existing_account = self.account_address if hasattr(self, 'account_address') and self.account_address else None
                setup_result["config"] = setup_wallet_browser(network=self.current_network, account_address=existing_account)
            except Exception as e:
                setup_result["error"] = str(e)
            setup_result["done"] = True
        
        thread = threading.Thread(target=do_setup, daemon=True)
        thread.start()
        
        # Wait briefly for server to start, then update message
        time.sleep(0.3)
        for i, line in enumerate(self.output_lines):
            if line.startswith("$ Starting auth"):
                self.output_lines[i] = "$ Waiting for browser... (press Esc to cancel)"
                break
        
        # Keep TUI responsive while waiting
        dots = 0
        self.stdscr.timeout(100)  # Ensure non-blocking input
        while not setup_result["done"]:
            self.draw()
            ch = self.stdscr.getch()
            if ch == 3 or ch == 27:  # Ctrl+C or Escape
                # Clean up waiting messages
                self.output_lines = [
                    line for line in self.output_lines 
                    if not any(x in line for x in [
                        "Opening browser to create",
                        "Starting auth server",
                        "Waiting for browser",
                    ])
                ]
                self.add_output("! Cancelled")
                self.add_output("  Use /newkey to try again")
                return
            time.sleep(0.1)
            dots = (dots + 1) % 4
            # Update status animation
            for i, line in enumerate(self.output_lines):
                if line.startswith("$ Waiting"):
                    self.output_lines[i] = f"$ Waiting for browser{'.' * dots} (press Esc to cancel)"
                    break
        
        if setup_result["error"]:
            self.add_output(f"! Error: {setup_result['error']}")
            return
        
        config = setup_result["config"]
        if config and config.get("access_key_private_key"):
            # Create new AccessKey from the browser response
            new_key = AccessKey(
                private_key=config["access_key_private_key"],
                key_id=config.get("key_id", ""),
                expiry=config.get("expiry", 0),
                public_key=config.get("public_key", ""),
            )
            
            # Update wallet config
            self.wallet.account_address = config.get("account_address", self.wallet.account_address)
            is_new_key = self.wallet.add_key(new_key, make_active=True)
            
            # Save with new format
            save_config(self.wallet.to_dict(), CONFIG_FILE)
            
            # Update legacy fields for compatibility
            self.config = self.wallet.to_dict()
            self.private_key = new_key.private_key
            self.account_address = self.wallet.account_address
            self.key_expiry = new_key.expiry
            self.access_key_address = new_key.address
            
            # Remove old "no wallet" / "waiting" messages and replace with success
            self.output_lines = [
                line for line in self.output_lines 
                if not any(x in line for x in [
                    "No wallet connected", 
                    "Run /newkey to connect", 
                    "Opening browser to create",
                    "Opening browser to connect",
                    "Starting auth server",
                    "Waiting for browser",
                    "Access key expired",
                    "Run /newkey to create",
                    "Ready. Ask anything",
                ])
            ]
            # Also remove any trailing empty lines that create gaps
            while self.output_lines and self.output_lines[-1] == "":
                self.output_lines.pop()
            self.add_output("")
            key_count = len(self.wallet.access_keys)
            if not is_new_key:
                self.add_output(f"$ Access key already exists, switched to it")
            elif key_count > 1:
                self.add_output(f"$ New access key added! ({key_count} keys total)")
            else:
                self.add_output(f"$ Wallet connected!")
            self.add_output(f"  Wallet: {self.account_address}")
            if self.access_key_address:
                self.add_output(f"  Access Key: {self.access_key_address}")
            self.add_output("")
            self.add_output("⏺ Ready. Type /help for commands.")
            
            # Update user context with new wallet
            self.user_context.update_from_wallet(self.wallet, self.current_network)
            
            # Initialize streaming payment channel manager and transaction sender
            if self.private_key and self.account_address:
                network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
                rpc_url = network_info.get("rpc")
                
                # Init TransactionSender first so streaming transactions emit events
                self.init_transaction_sender_with_listener(rpc_url)
                
                manager = init_stream_manager(
                    private_key=self.private_key,
                    wallet_address=self.account_address,
                    chain_id=network_info.get("chain_id"),
                    rpc_url=rpc_url,
                )
                logger.info("Stream channel manager initialized")
                
                # Auto-enable streaming if we have active channels
                if manager:
                    import time as t
                    now = int(t.time())
                    active_channels = [
                        ch for ch in manager._channels.values()
                        if not ch.finalized 
                        and ch.close_requested_at == 0 
                        and ch.expiry > now
                        and ch.remaining_balance() > 0
                    ]
                    if active_channels:
                        self._use_streaming_payments = True
                        self._auto_approve_payments = True
                        self._stream_payment_limit = 5.0
                        logger.info(f"Auto-enabled streaming: {len(active_channels)} active channel(s)")
            
            # Fetch balance in background
            self.refresh_balance_async()
            
            # Refresh access key token limits from chain
            if self.wallet and rpc_url:
                self.wallet.refresh_active_key_limits(rpc_url)
                key = self.wallet.active_key
                if key and key.enforce_limits:
                    usable = key.get_usable_tokens()
                    if usable:
                        self.add_output("")
                        self.add_output("⏺ Access key spending limits:")
                        for tok in usable[:5]:  # Show top 5
                            remaining = tok["remaining"] / (10 ** tok["decimals"])
                            self.add_output(f"  {tok['symbol']}: ${remaining:,.2f} remaining")
                    elif not usable:
                        self.add_output("")
                        self.add_output("⚠ Access key has no spending limits set for any tokens")
        else:
            # Clean up waiting messages
            self.output_lines = [
                line for line in self.output_lines 
                if not any(x in line for x in [
                    "Opening browser to create",
                    "Starting auth server",
                    "Waiting for browser",
                ])
            ]
            self.add_output("! Access key creation cancelled or failed")
            self.add_output("  Use /newkey to try again")
    
    def add_welcome_to_history(self):
        """Add the logo and welcome message to output history."""
        height, width = self.get_dims()
        logo = get_logo(height, width)
        
        # Add logo lines with special prefix for coloring
        for line in logo:
            self.output_lines.append(f"§{line}")
        
        # Add welcome text
        self.output_lines.append("")
        if self.fresh:
            self.output_lines.append("⏺ Fresh start")
        else:
            self.output_lines.append("⏺ Welcome to Presto")
        self.output_lines.append("  AI coding agent · Pay with stablecoins · No API keys")
        self.output_lines.append("")
        
        # Show network and wallet status
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        
        if self.account_address:
            self.output_lines.append(f"  Wallet: {self.account_address}")
            if self.access_key_address and self.access_key_address != self.account_address:
                self.output_lines.append(f"  Access Key: {self.access_key_address}")
            self.output_lines.append(f"  Network: {network_info['name']}")
        self.output_lines.append("")
    
    def run(self):
        logger.info("Presto starting up")
        self.config = load_config(CONFIG_FILE)
        
        # Check if auth server changed - if so, keys are invalid
        from .config import get_auth_url
        saved_auth_server = self.config.get("auth_server", "")
        current_auth_server = get_auth_url()
        if saved_auth_server and saved_auth_server != current_auth_server:
            # Auth server changed - clear wallet config to force new setup
            logger.info(f"Auth server changed from {saved_auth_server} to {current_auth_server}, clearing wallet")
            self.config = {}
        
        # Load wallet using new WalletConfig model (handles migration from old format)
        self.wallet = WalletConfig.from_dict(self.config)
        
        # Set up skill loader callback
        def skill_loader_callback(skill_name, content):
            if skill_name not in self.loaded_skills:
                self.loaded_skills.append(skill_name)
                self.skill_instructions += f"\n\n<loaded_skill name=\"{skill_name}\">\n{content}\n</loaded_skill>\n"
        set_skill_loader(skill_loader_callback)
        
        # Add welcome/logo to history immediately
        self.add_welcome_to_history()
        
        # Set legacy fields from wallet config for backward compatibility
        self.account_address = self.wallet.account_address
        self.current_network = self.wallet.network
        
        # Block mainnet if disabled
        if self.current_network == "mainnet" and MAINNET_BLOCKED:
            self.current_network = DEFAULT_NETWORK
            self.wallet.switch_network(DEFAULT_NETWORK)
            self.add_output("")
            self.add_output("🚨 MAINNET IS DISABLED 🚨")
            self.add_output("")
            self.add_output("Your config had mainnet selected, but mainnet access keys")
            self.add_output("have high storage overhead costs. Switched to moderato.")
            self.add_output("")
        active_key = self.wallet.active_key
        if active_key:
            self.private_key = active_key.private_key
            self.key_expiry = active_key.expiry
            self.access_key_address = active_key.address
        else:
            self.private_key = ""
            self.key_expiry = 0
            self.access_key_address = ""
        self.balance_loading = False
        
        # Initialize user context for AI agent awareness
        self.user_context.update_from_wallet(self.wallet, self.current_network)
        
        # Initialize streaming payment channel manager and transaction sender
        if self.private_key and self.account_address:
            network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
            rpc_url = network_info.get("rpc")
            
            # Init TransactionSender first so streaming transactions emit events
            self.init_transaction_sender_with_listener(rpc_url)
            
            manager = init_stream_manager(
                private_key=self.private_key,
                wallet_address=self.account_address,
                chain_id=network_info.get("chain_id"),
                rpc_url=rpc_url,
            )
            logger.info("Stream channel manager initialized")
            
            # Auto-enable streaming if we have active (non-finalized, non-closing, non-expired) channels
            if manager:
                import time as t
                now = int(t.time())
                active_channels = [
                    ch for ch in manager._channels.values()
                    if not ch.finalized 
                    and ch.close_requested_at == 0 
                    and ch.expiry > now
                    and ch.remaining_balance() > 0
                ]
                if active_channels:
                    self._use_streaming_payments = True
                    self._auto_approve_payments = True
                    self._stream_payment_limit = 5.0  # Default limit
                    logger.info(f"Auto-enabled streaming: {len(active_channels)} active channel(s)")
        
        # Check if active access key is expired
        key_expired = active_key.is_expired if active_key else True
        key_expiring_soon = active_key.expires_soon if active_key else False
        
        # Show wallet status
        if active_key and not key_expired:
            self.output_lines.append("⏺ Ready. Type /help for commands.")
            # Show which server we're connected to
            from .config import PROXY_URL, get_auth_url
            if "localhost" in PROXY_URL or "127.0.0.1" in PROXY_URL:
                self.output_lines.append(f"  Server: {PROXY_URL} (local)")
            elif "payments.tempo.xyz" in PROXY_URL:
                # Extract provider from URL (e.g., "openrouter" from "openrouter.payments.tempo.xyz")
                provider = PROXY_URL.split("//")[1].split(".")[0] if "//" in PROXY_URL else "production"
                self.output_lines.append(f"  Server: {provider}.payments.tempo.xyz")
            else:
                self.output_lines.append(f"  Server: {PROXY_URL}")
            # Show auth server
            auth_url = get_auth_url()
            if "localhost" in auth_url or "127.0.0.1" in auth_url:
                self.output_lines.append(f"  Auth server: {auth_url} (local)")
            elif "presto.tempo.xyz" in auth_url:
                self.output_lines.append(f"  Auth server: presto.tempo.xyz")
            else:
                self.output_lines.append(f"  Auth server: {auth_url}")
            if key_expiring_soon:
                self.output_lines.append(f"! Access key expires in {active_key.time_remaining} - run /newkey to renew")
            
            self.balance_loading = True
            self.output_lines.append("$ Fetching wallet info...")
        elif key_expired and active_key:
            self.output_lines.append("")
            self.output_lines.append("! Access key expired")
            self.output_lines.append("  Run /newkey to create a new access key")
            self.output_lines.append("")
        else:
            # No wallet - just show ready, will prompt on first query
            self.output_lines.append("⏺ Ready. Ask anything.")
        
        # If wallet configured, fetch info in background
        if self.private_key:
            
            def load_wallet_info():
                from concurrent.futures import ThreadPoolExecutor
                
                # Derive access key address from private key
                try:
                    from eth_account import Account
                    account = Account.from_key(self.private_key)
                    self.access_key_address = account.address
                except:
                    self.access_key_address = ""
                
                # If no account_address stored, use access key address as fallback
                if not self.account_address:
                    self.account_address = self.access_key_address
                    if self.account_address:
                        self.config["account_address"] = self.account_address
                        save_config(self.config, CONFIG_FILE)
                
                active_key = self.wallet.active_key if self.wallet else None
                rpc_url = self.get_rpc_url()
                
                # Fetch balance and key expiry in parallel (both are fast single RPC calls)
                # Skip spending limits - they're fetched lazily when needed for payment
                with ThreadPoolExecutor(max_workers=2) as executor:
                    executor.submit(self.refresh_balance_sync)
                    if active_key and rpc_url:
                        executor.submit(active_key.fetch_from_chain, self.account_address, rpc_url)
                
                self.balance_loading = False
                
                # Check if key was revoked
                if active_key and active_key.is_revoked:
                    self._handle_key_revoked()
                    return
                
                # Replace "Fetching wallet info..." with wallet info
                if self.account_address:
                    for i, line in enumerate(self.output_lines):
                        if "Fetching wallet info..." in line:
                            # Build wallet info lines
                            wallet_lines = [f"✓ Wallet: {self.account_address}"]
                            
                            # Show access key
                            if self.access_key_address:
                                wallet_lines.append(f"  Access key: {self.access_key_address}")
                            
                            # Show access key expiry
                            if active_key and active_key.expiry:
                                wallet_lines.append(f"  Key expires: {active_key.time_remaining}")
                            
                            # Replace the loading line and insert additional lines after it
                            self.output_lines[i] = wallet_lines[0]
                            for j, extra_line in enumerate(wallet_lines[1:], 1):
                                self.output_lines.insert(i + j, extra_line)
                            break
            
            import threading
            threading.Thread(target=load_wallet_info, daemon=True).start()
        
        # Start background revocation monitor (polls chain every 5 seconds)
        if self.private_key:
            self._start_revocation_monitor()
        
        spinner_chars = ['◐', '◓', '◑', '◒']
        spinner_idx = 0
        
        while self.running:
            try:
                # Process any pending API events
                self.process_api_queue()
                
                # Animate confirming spinner
                if hasattr(self, '_confirming_line_idx'):
                    idx = self._confirming_line_idx
                    if 0 <= idx < len(self.output_lines):
                        spinner_idx = (spinner_idx + 1) % len(spinner_chars)
                        self.output_lines[idx] = f"  {spinner_chars[spinner_idx]} Confirming..."
                
                # Handle pending wallet connection (needs main thread for curses)
                if hasattr(self, '_pending_wallet_connect') and self._pending_wallet_connect:
                    self._pending_wallet_connect = False
                    self.create_new_access_key()
                    # Update tool context with new wallet info
                    set_tool_context({
                        'account_address': self.account_address,
                        'access_key_address': self.access_key_address,
                        'rpc_url': self.get_rpc_url(),
                    })
                    self._wallet_connected = True
                
                self.draw()
                ch = self.stdscr.getch()
                
                if ch == curses.KEY_RESIZE:
                    self.handle_resize()
                elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                    if self.input_buffer and self.cursor_pos > 0:
                        self.input_buffer = self.input_buffer[:self.cursor_pos-1] + self.input_buffer[self.cursor_pos:]
                        self.cursor_pos -= 1
                elif ch == curses.KEY_LEFT:
                    if self.cursor_pos > 0:
                        self.cursor_pos -= 1
                elif ch == curses.KEY_RIGHT:
                    if self.cursor_pos < len(self.input_buffer):
                        self.cursor_pos += 1
                elif ch == curses.KEY_UP:
                    self.scroll_offset = min(self.scroll_offset + 1, max(0, len(self.output_lines) - 5))
                elif ch == curses.KEY_DOWN:
                    self.scroll_offset = max(0, self.scroll_offset - 1)
                elif ch == curses.KEY_HOME or ch == 1:  # Ctrl+A
                    self.cursor_pos = 0
                elif ch == curses.KEY_END or ch == 5:  # Ctrl+E
                    self.cursor_pos = len(self.input_buffer)
                elif ch == 27:  # Escape - cancel current request
                    if self.api_busy:
                        self.api_cancelled = True
                        self.api_cancel_event.set()  # Signal cancellation to HTTP layer
                        self.activity_status = "Cancelling..."
                        self.add_output("! Cancelling request...")
                        self.draw()
                elif ch == 3:  # Ctrl+C
                    if self.api_busy:
                        self.api_cancelled = True
                        self.api_cancel_event.set()  # Signal cancellation to HTTP layer
                        self.status_message = "Cancelling..."
                    else:
                        self.running = False
                elif ch == 4:  # Ctrl+D
                    self.running = False
                elif ch == 21:  # Ctrl+U - clear input
                    self.input_buffer = ""
                    self.cursor_pos = 0
                elif ch == 15:  # Ctrl+O - insert newline (Shift+Enter doesn't work in most terminals)
                    self.input_buffer = self.input_buffer[:self.cursor_pos] + '\n' + self.input_buffer[self.cursor_pos:]
                    self.cursor_pos += 1
                elif ch == 16:  # Ctrl+P - open command palette
                    self.show_command_palette()
                elif ch == ord('/') and not self.input_buffer:  # "/" as first char opens palette
                    self.show_command_palette()
                elif ch == 10 or ch == 13:  # Enter
                    # Intercept if access key is revoked (block before payment stage)
                    if self._key_revoked_intercept:
                        cmd = self.input_buffer.strip().lower()
                        if cmd in ('/quit', '/exit', '/q'):
                            self.running = False
                        else:
                            self.input_buffer = ""
                            self.cursor_pos = 0
                            self._run_revoked_key_flow()
                    elif self.input_buffer.strip():
                        cmd = self.input_buffer.strip()
                        self.input_buffer = ""
                        self.cursor_pos = 0
                        # process_command handles cancellation if api_busy
                        self.process_command(cmd)
                elif ch != -1 and 32 <= ch <= 126:
                    # Insert the character into the buffer
                    char = chr(ch)
                    self.input_buffer = self.input_buffer[:self.cursor_pos] + char + self.input_buffer[self.cursor_pos:]
                    self.cursor_pos += 1
                    
            except KeyboardInterrupt:
                break
        
        # Cleanup
        self._stop_revocation_monitor()
        
        # Disable alternate scroll mode on exit
        _term_write("\x1b[?1007l")
