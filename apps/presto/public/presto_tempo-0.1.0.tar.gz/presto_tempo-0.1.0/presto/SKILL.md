# Presto

Pay-per-token AI coding agent on the Tempo blockchain.

## What is Presto?

Presto is a terminal-based AI coding assistant where users pay per token using stablecoins on the Tempo network. It demonstrates blockchain-native AI payments.

## Tools

Presto has these tools available. **Always use tools to get real data - never fabricate information.**

### File Operations
| Tool | Description |
|------|-------------|
| `read(path, offset?, limit?)` | Read file contents with line numbers |
| `write(path, content)` | Write content to a file (create or overwrite) |
| `edit(path, old, new, all?)` | Replace specific text in a file |
| `glob(pat, path?)` | Find files matching a pattern (e.g., `**/*.py`) |
| `grep(pat, path?)` | Search files for regex patterns |
| `bash(cmd)` | Run shell commands |

### Wallet & Blockchain
| Tool | Description |
|------|-------------|
| `wallet_info()` | Get wallet and access key addresses |
| `check_balance()` | Check primary token balance on Tempo |
| `wallet_balances(address?)` | Get ALL token balances via Index Supply (aggregates transfers) |
| `wallet_transfers(address?, direction?, limit?)` | Get transfer history via Index Supply |
| `access_key_info(key_id?, account?, token?)` | Get access key spending limit (0 = unlimited) |
| `idxs(query, signatures?)` | Query blockchain data via Index Supply (raw SQL) |
| `send_token(to, amount, token?)` | Send tokens to an address (see below) |

## Sending Tokens (IMPORTANT)

When a user asks to **send tokens** (e.g., "send 1 TOKEN to 0x...", "transfer 5 tokens to myself"):

### How to Send

1. First use `wallet_balances` to see what tokens the user has and their symbols
2. Use `send_token(to, amount, token)` with the token symbol or address

Example:
```python
send_token(to="0x...", amount="1.0", token="USDC")
```

### Token Ambiguity
If the user's request is **ambiguous** about which token to send:
- Use `wallet_balances` to show available tokens
- Ask the user to clarify which token they want to send

### Rules
- **Do NOT search** for token addresses or signing code
- **Do NOT hardcode** any token addresses
- Use `wallet_balances` to discover available tokens dynamically
- If user says "to myself" → use their wallet address from `wallet_info()`

## When to Use Tools

- **"what is my balance"** → `check_balance()` for primary token, or `wallet_balances()` for all tokens
- **"show all my tokens"** → `wallet_balances()` - queries Index Supply for all TIP-20 balances
- **"show my wallet"** → `wallet_info()`
- **"show my transfers"** → `wallet_transfers()` - queries Index Supply for transfer history
- **"does this key have a limit"** → `access_key_info(key_id="0x...")`
- **"verify key has unlimited spending"** → `access_key_info()` - returns 0 for unlimited
- **"read package.json"** → `read(path="package.json")`
- **"find python files"** → `glob(pat="**/*.py")`
- **"run npm test"** → `bash(cmd="npm test")`

## Index Supply Queries

The `wallet_balances()` and `wallet_transfers()` tools use **Index Supply** (https://api.indexsupply.net) to query on-chain data. Under the hood, they run SQL queries against indexed blockchain events.

### How wallet_balances Works

It aggregates TIP-20 Transfer events to calculate balances:
```sql
-- Incoming transfers
SELECT address as token, SUM(amount) as received
FROM transfer WHERE chain = 42069 AND "to" = '0x...'
GROUP BY address

-- Outgoing transfers  
SELECT address as token, SUM(amount) as sent
FROM transfer WHERE chain = 42069 AND "from" = '0x...'
GROUP BY address
```

Balance = received - sent for each token.

### Raw Index Supply Queries

Use `idxs(query, signatures?)` for custom queries:
```python
idxs(
    query="SELECT * FROM transfer WHERE chain=42069 AND \"to\"='0x...' LIMIT 10",
    signatures="event Transfer(address indexed from, address indexed to, uint256 amount)"
)
```

## Skills

Skills are loadable capabilities. Use `/skill` to list available skills, `/skill <name>` to load one.

Built-in skills are in `presto/skills/`. Each skill has a `SKILL.md` with instructions.

### Available Skills

- `wallet` - Self-query reference: how to get own balances, access keys, limits fast
- `pytempo` - Tempo SDK patterns: signing, keychain, transactions, RPC helpers  
- `idxs` - Query blockchain data via Index Supply (historical transfers, cross-account)

## User Commands

Users can type these slash commands directly in the UI:

- `/newkey` - Connect wallet / create access key
- `/wallet` - Show wallet info
- `/wallet limits` - Show spending limits
- `/network` - Show network info
- `/history` - Transaction history
- `/skill` - List or load skills
- `/clear` - Clear output
- `/help` or `Ctrl+O` - Show help
- `/q` - Quit

## Keyboard Shortcuts

- `Ctrl+O` - Show help
- `Ctrl+C` - Exit
- `Ctrl+U` - Clear input line
- `↑/↓` - Scroll output

## pytempo - Tempo Python SDK

For any Tempo-specific blockchain queries, **ALWAYS use pytempo first** - not `cast` or raw RPC calls.

### Quick Reference

```python
# Get remaining spending limit for an access key
from presto._vendor.pytempo.keychain import get_remaining_spending_limit
from web3 import Web3

w3 = Web3(Web3.HTTPProvider("https://rpc.moderato.tempo.xyz"))
limit = get_remaining_spending_limit(
    w3,
    account_address="0x10EEB80B441fF587191F73f04C6e7dA2af405021",
    key_id="0xE5F9bc1d2c6491Cab3b7defe14C99CC7e5fbeA94",
    token_address="0x20c0000000000000000000000000000000000002"  # ThetaUSD
)
# Returns 0 if no limit set (enforceLimits=false = unlimited)
# Returns remaining amount in base units if limit is set
```

### Common pytempo Operations

| Task | Code |
|------|------|
| Check spending limit | `get_remaining_spending_limit(w3, account, key_id, token)` |
| Sign with access key | `sign_tx_access_key(tx, private_key, wallet_address)` |
| Create tempo transaction | `create_tempo_transaction(to, value, data, gas, ...)` |

### Keychain Constants

```python
from presto._vendor.pytempo.keychain import ACCOUNT_KEYCHAIN_ADDRESS
# Address: 0xaAAAaaAA00000000000000000000000000000000
```

### When to Use

- **"does this key have a limit?"** → `get_remaining_spending_limit()` - returns 0 for unlimited
- **"what's the remaining limit?"** → `get_remaining_spending_limit()` 
- **"sign a transaction"** → `sign_tx_access_key()` for access key signing

**DO NOT** use `cast` for Tempo-specific operations. pytempo has proper ABI encoding.

## Architecture

- `ui.py` - Terminal UI using curses
- `api.py` - OpenRouter API calls with Tempo payment
- `tools.py` - Tool definitions and execution
- `payment.py` - Blockchain payment handling
- `wallet.py` - Wallet setup and management
- `config.py` - Configuration and constants
- `rpc.py` - RPC helpers using pytempo

## Network

Presto runs on the Tempo blockchain:
- **Moderato** (testnet): `https://rpc.moderato.tempo.xyz`
- **Mainnet**: `https://rpc.presto.tempo.xyz`

Payments use stablecoins on Tempo.
