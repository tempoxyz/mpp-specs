"""Agent tools for file manipulation and shell commands."""
import glob as globlib
import json
import os
import re
import subprocess


def read(args):
    lines = open(args["path"]).readlines()
    offset = args.get("offset", 0)
    limit = args.get("limit", len(lines))
    selected = lines[offset : offset + limit]
    return "".join(f"{offset + idx + 1:4}| {line}" for idx, line in enumerate(selected))


def write(args):
    path = args["path"]
    content = args["content"]
    is_new = not os.path.exists(path)
    
    with open(path, "w") as f:
        f.write(content)
    
    lines = content.split("\n")
    line_count = len(lines)
    action = "Created" if is_new else "Wrote"
    
    result = [f"WRITE:{path}:+{line_count}"]
    result.append("...")
    for i, line in enumerate(lines[:8], 1):
        result.append(f"{i:4} + {line}")
    if line_count > 8:
        result.append(f"     ... +{line_count - 8} more lines")
    
    return "\n".join(result)


def edit(args):
    text = open(args["path"]).read()
    old, new = args["old"], args["new"]
    if old not in text:
        return "error: old_string not found"
    count = text.count(old)
    if not args.get("all") and count > 1:
        return f"error: old_string appears {count} times, must be unique (use all=true)"
    
    old_lines = old.split("\n")
    new_lines = new.split("\n")
    
    start_line = text[:text.find(old)].count("\n") + 1
    
    replacement = text.replace(old, new) if args.get("all") else text.replace(old, new, 1)
    with open(args["path"], "w") as f:
        f.write(replacement)
    
    return format_diff(args["path"], old_lines, new_lines, start_line)


def format_diff(path, old_lines, new_lines, start_line):
    """Format a nice diff output like Amp does."""
    lines_changed = len(new_lines) - len(old_lines)
    sign = "+" if lines_changed >= 0 else ""
    header = f"DIFF:{path}:{sign}{lines_changed}"
    
    result = [header]
    result.append("...")
    
    import difflib
    sm = difflib.SequenceMatcher(None, old_lines, new_lines)
    
    new_line_num = start_line
    
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            for idx in range(i2 - i1):
                result.append(f"{new_line_num:4}   {old_lines[i1 + idx]}")
                new_line_num += 1
        elif tag == 'replace':
            for idx in range(i1, i2):
                result.append(f"{new_line_num:4} - {old_lines[idx]}")
            for idx in range(j1, j2):
                result.append(f"{new_line_num:4} + {new_lines[idx]}")
                new_line_num += 1
        elif tag == 'delete':
            for idx in range(i1, i2):
                result.append(f"{new_line_num:4} - {old_lines[idx]}")
        elif tag == 'insert':
            for idx in range(j1, j2):
                result.append(f"{new_line_num:4} + {new_lines[idx]}")
                new_line_num += 1
    
    return "\n".join(result)


def glob(args):
    pattern = (args.get("path", ".") + "/" + args["pat"]).replace("//", "/")
    files = globlib.glob(pattern, recursive=True)
    files = sorted(files, key=lambda f: os.path.getmtime(f) if os.path.isfile(f) else 0, reverse=True)
    return "\n".join(files) or "none"


def grep(args):
    pattern = re.compile(args["pat"])
    hits = []
    for filepath in globlib.glob(args.get("path", ".") + "/**", recursive=True):
        try:
            for line_num, line in enumerate(open(filepath), 1):
                if pattern.search(line):
                    hits.append(f"{filepath}:{line_num}:{line.rstrip()}")
        except Exception:
            pass
    return "\n".join(hits[:50]) or "none"


def bash(args):
    proc = subprocess.Popen(args["cmd"], shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    output_lines = []
    try:
        while True:
            line = proc.stdout.readline()
            if not line and proc.poll() is not None:
                break
            if line:
                output_lines.append(line)
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill()
        output_lines.append("\n(timed out after 30s)")
    return "".join(output_lines).strip() or "(empty)"


def web_search(args):
    """Search the web using DuckDuckGo."""
    import urllib.request
    import urllib.parse
    
    query = args.get("query", "")
    if not query:
        return "Error: query is required"
    
    # Use DuckDuckGo HTML search (no API key needed)
    encoded_query = urllib.parse.quote(query)
    url = f"https://html.duckduckgo.com/html/?q={encoded_query}"
    
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
        
        # Parse results from HTML
        results = []
        # Find result links and snippets
        import re
        # Match result blocks
        result_pattern = re.compile(r'<a[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>([^<]*)</a>.*?<a[^>]*class="result__snippet"[^>]*>([^<]*)</a>', re.DOTALL)
        
        for match in result_pattern.finditer(html):
            url_match, title, snippet = match.groups()
            # Clean up the URL (DuckDuckGo wraps URLs)
            if 'uddg=' in url_match:
                actual_url = urllib.parse.unquote(url_match.split('uddg=')[-1].split('&')[0])
            else:
                actual_url = url_match
            title = re.sub(r'<[^>]+>', '', title).strip()
            snippet = re.sub(r'<[^>]+>', '', snippet).strip()
            if title and actual_url:
                results.append(f"**{title}**\n{actual_url}\n{snippet}\n")
        
        if results:
            return "\n".join(results[:5])  # Return top 5 results
        else:
            return f"No results found for: {query}"
    
    except Exception as e:
        return f"Search error: {str(e)}"


def read_url(args):
    """Fetch and read content from a URL."""
    import urllib.request
    
    url = args.get("url", "")
    if not url:
        return "Error: url is required"
    
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
        with urllib.request.urlopen(req, timeout=15) as response:
            content = response.read().decode('utf-8', errors='ignore')
        
        # Strip HTML tags for cleaner output
        import re
        # Remove script and style elements
        content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL)
        content = re.sub(r'<style[^>]*>.*?</style>', '', content, flags=re.DOTALL)
        # Remove HTML tags
        content = re.sub(r'<[^>]+>', ' ', content)
        # Clean up whitespace
        content = re.sub(r'\s+', ' ', content).strip()
        
        # Limit output length
        max_len = 8000
        if len(content) > max_len:
            content = content[:max_len] + f"\n\n... (truncated, {len(content)} chars total)"
        
        return content
    
    except Exception as e:
        return f"Error fetching URL: {str(e)}"


TOOL_DEFINITIONS = [
    {
        "name": "read",
        "description": "Read a file and return its contents with line numbers. Use this to examine source code, config files, or any text file.",
        "parameters": {
            "path": {"type": "string", "description": "Absolute or relative path to the file"},
            "offset": {"type": "integer", "description": "Line number to start from (0-indexed)", "optional": True},
            "limit": {"type": "integer", "description": "Maximum number of lines to return", "optional": True},
        }
    },
    {
        "name": "write",
        "description": "Write content to a file, creating it if it doesn't exist or overwriting if it does.",
        "parameters": {
            "path": {"type": "string", "description": "Path to the file to write"},
            "content": {"type": "string", "description": "Content to write to the file"},
        }
    },
    {
        "name": "edit",
        "description": "Replace a specific string in a file. The old string must exist and be unique (unless all=true).",
        "parameters": {
            "path": {"type": "string", "description": "Path to the file to edit"},
            "old": {"type": "string", "description": "The exact string to find and replace"},
            "new": {"type": "string", "description": "The string to replace it with"},
            "all": {"type": "boolean", "description": "Replace all occurrences (default: false, requires unique match)", "optional": True},
        }
    },
    {
        "name": "glob",
        "description": "Find files matching a glob pattern. Use **/ for recursive search.",
        "parameters": {
            "pat": {"type": "string", "description": "Glob pattern (e.g., '**/*.py', '*.json')"},
            "path": {"type": "string", "description": "Base directory to search from", "optional": True},
        }
    },
    {
        "name": "grep",
        "description": "Search files for lines matching a regex pattern. Returns matching lines with file paths and line numbers.",
        "parameters": {
            "pat": {"type": "string", "description": "Regular expression pattern to search for"},
            "path": {"type": "string", "description": "Directory or file to search in", "optional": True},
        }
    },
    {
        "name": "bash",
        "description": "Run a shell command and return its output. Use for system commands, git, npm, etc.",
        "parameters": {
            "cmd": {"type": "string", "description": "Shell command to execute"},
        }
    },
    {
        "name": "wallet_info",
        "description": "Get the current wallet address and access key address. Use this when the user asks about their wallet, address, or account.",
        "parameters": {}
    },
    {
        "name": "wallet_balances",
        "description": "Get all token balances for a wallet with total USD value. USE THIS for 'what is my balance'. Returns list of all tokens held with amounts.",
        "parameters": {
            "address": {"type": "string", "description": "Wallet address (uses configured wallet if not specified)", "optional": True},
        }
    },
    {
        "name": "wallet_transfers",
        "description": "Get TIP-20 transfer history for a wallet. Shows recent token transfers in/out. Use this when the user asks about their transfer history, recent payments, or transaction history.",
        "parameters": {
            "address": {"type": "string", "description": "Wallet address to check (uses configured wallet if not specified)", "optional": True},
            "direction": {"type": "string", "description": "Filter: 'all', 'sent', or 'received'", "optional": True},
            "limit": {"type": "integer", "description": "Max number of transfers to return (default: 20)", "optional": True},
            "network": {"type": "string", "description": "Network name (mainnet/moderato)", "optional": True},
        }
    },
    {
        "name": "wallet_transactions",
        "description": "Get transaction history for a wallet. Shows all on-chain transactions (not just transfers). Use this when the user asks about all transactions, including contract interactions.",
        "parameters": {
            "address": {"type": "string", "description": "Wallet address to check (uses configured wallet if not specified)", "optional": True},
            "limit": {"type": "integer", "description": "Max number of transactions to return (default: 20)", "optional": True},
            "network": {"type": "string", "description": "Network name (mainnet/moderato)", "optional": True},
        }
    },

    {
        "name": "connect_wallet",
        "description": "Connect a wallet and create an access key. This opens the browser for the user to authenticate with their passkey wallet. Use this when: the user wants to connect a wallet, set up payments, create an access key, or when wallet_info shows no wallet configured.",
        "parameters": {}
    },
    {
        "name": "access_key_info",
        "description": "Get information about an access key including its spending limit for a token. Returns remaining limit (0 = unlimited or no limit set). Use this to verify key limits, check if a key has spending restrictions, or debug access key issues.",
        "parameters": {
            "key_id": {"type": "string", "description": "Access key address (0x...). Uses active key if not specified.", "optional": True},
            "account": {"type": "string", "description": "Wallet account address (0x...). Uses configured wallet if not specified.", "optional": True},
            "token": {"type": "string", "description": "Token address to check limit for. Uses current fee token if not specified.", "optional": True},
        }
    },
    {
        "name": "send_token",
        "description": "Send TIP-20 tokens to an address. Use wallet_balances first to see available tokens. Requires token symbol or address.",
        "parameters": {
            "to": {"type": "string", "description": "Recipient address (0x...)"},
            "amount": {"type": "string", "description": "Amount to send (human readable, e.g., '1.0')"},
            "token": {"type": "string", "description": "Token symbol from wallet or contract address (0x...)", "optional": True},
        }
    },
    {
        "name": "idxs",
        "description": "Query blockchain data via Index Supply API. Supports SQL-like queries for token balances, transfers, and transactions across chains.",
        "parameters": {
            "query": {"type": "string", "description": "SQL-like query (include chain=X, e.g., chain=1 for Ethereum mainnet)"},
            "signatures": {"type": "string", "description": "Event signatures if querying events", "optional": True},
        }
    },
    {
        "name": "load_skill",
        "description": "Load a specialized skill with domain-specific instructions. Built-in: 'pytempo' (Tempo SDK patterns), 'wallet' (self-query reference). Use when writing code that needs SDK patterns or understanding internals.",
        "parameters": {
            "name": {"type": "string", "description": "Skill name: 'pytempo', 'wallet', 'idxs', or others"},
            "list_only": {"type": "boolean", "description": "If true, list available skills without loading", "optional": True},
        }
    },
    {
        "name": "web_search",
        "description": "Search the web using DuckDuckGo. Returns top 5 results with titles, URLs, and snippets. Use this when you need to find information online, look up documentation, or research a topic.",
        "parameters": {
            "query": {"type": "string", "description": "Search query"},
        }
    },
    {
        "name": "read_url",
        "description": "Fetch and read content from a URL. Strips HTML and returns plain text. Use this to read web pages, documentation, API docs, etc.",
        "parameters": {
            "url": {"type": "string", "description": "URL to fetch"},
        }
    },
]

# Context set by UI before running tools
_tool_context = {}

# Skills directories
PRESTO_SKILLS_DIR = os.path.dirname(os.path.abspath(__file__)) + "/skills"
USER_SKILLS_DIR = os.path.expanduser("~/.config/agents/skills")

# Callback for loading skills (set by UI)
_skill_loader = None

def set_skill_loader(loader):
    global _skill_loader
    _skill_loader = loader

def set_tool_context(ctx):
    global _tool_context
    _tool_context = ctx

def wallet_info(args):
    """Return wallet and access key addresses."""
    return f"""Wallet Address: {_tool_context.get('account_address', 'not set')}
Access Key Address: {_tool_context.get('access_key_address', 'not set')}

The wallet is the main account (created with passkey).
The access key is used by presto to sign transactions."""

def check_balance(args):
    """Check token balance using shared RPC utilities."""
    from .rpc import get_token_balance, format_balance
    
    address = _tool_context.get('account_address', '')
    if not address:
        return "No wallet address configured"
    
    fee_token = _tool_context.get('fee_token', '')
    if not fee_token:
        return "No fee token selected. Run /wallet fee-token to choose one."
    
    fee_token_name = _tool_context.get('fee_token_name', 'tokens')
    rpc_url = _tool_context.get('rpc_url', '')
    
    balance = get_token_balance(address, fee_token, rpc_url, decimals=6)
    return f"Balance: {format_balance(balance, fee_token_name)}\nWallet: {address}"


def wallet_balances(args):
    """Get all TIP-20 token balances via Index Supply."""
    from .explorer import wallet_balance
    
    address = args.get('address') or _tool_context.get('account_address', '')
    network = args.get('network') or _tool_context.get('network', '')
    
    return wallet_balance(address, network)


def wallet_transfers(args):
    """Get TIP-20 transfer history via Index Supply."""
    from .explorer import wallet_transfers as get_transfers
    
    address = args.get('address') or _tool_context.get('account_address', '')
    direction = args.get('direction', 'all')
    limit = args.get('limit', 20)
    network = args.get('network') or _tool_context.get('network', '')
    
    return get_transfers(address, direction, limit, network)


def wallet_transactions(args):
    """Get transaction history via Index Supply."""
    from .explorer import wallet_txs
    
    address = args.get('address') or _tool_context.get('account_address', '')
    limit = args.get('limit', 20)
    network = args.get('network') or _tool_context.get('network', '')
    
    return wallet_txs(address, limit, network)


def idxs(args):
    """Query blockchain data via Index Supply."""
    from .skills.idxs import run_idxs_tool
    return run_idxs_tool(args)


def connect_wallet(args):
    """Connect wallet - signals UI to trigger browser flow."""
    # This is a special tool that the UI intercepts
    return "__CONNECT_WALLET__"


def access_key_info(args):
    """Get access key information including spending limit."""
    from .rpc import get_remaining_spending_limit, format_spending_limit
    
    account = args.get('account') or _tool_context.get('account_address', '')
    # key_id is the access key address - used as identifier in keychain precompile
    key_id = args.get('key_id') or _tool_context.get('access_key_address', '')
    token = args.get('token') or _tool_context.get('fee_token', '')
    rpc_url = _tool_context.get('rpc_url', '')
    fee_token_name = _tool_context.get('fee_token_name', 'tokens')
    
    if not account:
        return "No wallet address configured. Run /wallet to connect."
    if not key_id:
        return "No access key specified or active."
    if not token:
        return "No token specified and no fee token configured. Run /wallet fee-token."
    if not rpc_url:
        return "No RPC URL configured."
    
    limit = get_remaining_spending_limit(account, key_id, token, rpc_url)
    limit_str = format_spending_limit(limit)
    
    if limit_str == "∞":
        limit_explanation = "No spending limit set (enforceLimits=false) - key has unlimited spending for this token."
    else:
        limit_explanation = f"Remaining spending limit: {limit_str} (depletes as tokens are spent)"
    
    return f"""Access Key Info:
  Account: {account}
  Key ID: {key_id}
  Token: {token} ({fee_token_name})
  
Spending Limit:
  Raw value: {limit} (base units)
  Formatted: {limit_str}
  
{limit_explanation}"""


def send_token(args):
    """Send TIP-20 tokens to an address using pytempo."""
    from .payment import sign_tempo_transaction
    from .rpc import broadcast_tx, wait_for_receipt, get_token_symbol, get_token_decimals
    from .config import NETWORKS, DEFAULT_NETWORK
    from datetime import datetime
    
    # Get required params
    to_address = args.get("to", "")
    amount_str = args.get("amount", "")
    token = args.get("token", "")
    
    if not to_address:
        return "Error: 'to' address is required"
    if not amount_str:
        return "Error: 'amount' is required"
    if not token:
        return "Error: 'token' is required. Use wallet_balances to see available tokens, or provide a token address."
    
    # Get wallet info from context
    wallet_address = _tool_context.get('account_address', '')
    rpc_url = _tool_context.get('rpc_url', '')
    network = _tool_context.get('network', DEFAULT_NETWORK)
    
    # Resolve token - check wallet's known tokens first
    token_address = None
    token_symbol = None
    decimals = 6
    
    # If it's already an address, use it directly
    if token.startswith("0x") and len(token) == 42:
        token_address = token.lower()
        # Fetch metadata from chain
        token_symbol = get_token_symbol(token_address, rpc_url) or token[:10] + "..."
        try:
            decimals = get_token_decimals(token_address, rpc_url)
        except:
            decimals = 6
    else:
        # Try to find token by symbol in wallet's known tokens
        known_tokens = _tool_context.get('known_tokens', {})
        token_upper = token.upper()
        
        if token_upper in known_tokens:
            token_info = known_tokens[token_upper]
            token_address = token_info.get('address')
            token_symbol = token_info.get('symbol', token_upper)
            decimals = token_info.get('decimals', 6)
        else:
            # List available tokens for user
            if known_tokens:
                available = ", ".join(known_tokens.keys())
                return f"Error: Unknown token '{token}'. Available tokens in wallet: {available}"
            else:
                return f"Error: Unknown token '{token}'. Provide a token address (0x...) or ensure wallet has tokens."
    
    # Get access key from context
    access_key = _tool_context.get('access_key', '')
    
    if not wallet_address:
        return "Error: No wallet connected. Use connect_wallet first."
    if not access_key:
        return "Error: No access key configured."
    
    # Get chain_id
    chain_id = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])["chain_id"]
    
    # Convert amount to base units
    try:
        amount_float = float(amount_str)
        amount_base = int(amount_float * (10 ** decimals))
    except ValueError:
        return f"Error: Invalid amount '{amount_str}'"
    
    # Sign and send transaction
    try:
        signed_tx = sign_tempo_transaction(
            access_key_private_key=access_key,
            wallet_address=wallet_address,
            amount=str(amount_base),
            asset=token_address,
            destination=to_address,
            rpc_url=rpc_url,
            chain_id=chain_id,
        )
        
        tx_hash = broadcast_tx(signed_tx, rpc_url)
        receipt = wait_for_receipt(tx_hash, rpc_url)
        
        if receipt and receipt.get("status") == 1:
            block_num = receipt.get("blockNumber", "?")
            now = datetime.now().strftime("%m/%d/%Y, %I:%M %p")
            
            return f"""TEMPO RECEIPT
Tx Hash: {tx_hash}
Date: {now}
Block: {block_num}
Sender: {wallet_address}
--------------------------------------------------
SEND {token_symbol} TO {to_address}  {amount_str}
--------------------------------------------------
Success! Token transfer complete."""
        else:
            return f"Transaction failed. Hash: {tx_hash}"
            
    except Exception as e:
        return f"Error sending tokens: {str(e)}"


def load_skill(args):
    """Load a skill or list available skills."""
    list_only = args.get("list_only", False)
    skill_name = args.get("name", "")
    
    # Collect available skills
    available = {}
    for skills_dir in [PRESTO_SKILLS_DIR, USER_SKILLS_DIR]:
        if os.path.isdir(skills_dir):
            for name in os.listdir(skills_dir):
                skill_path = os.path.join(skills_dir, name, "SKILL.md")
                if os.path.isfile(skill_path):
                    available[name] = skill_path
    
    if list_only or not skill_name:
        if not available:
            return "No skills available"
        skills_list = sorted(available.keys())
        return f"Available skills ({len(skills_list)}):\n" + "\n".join(f"  - {s}" for s in skills_list[:20])
    
    if skill_name not in available:
        return f"Skill '{skill_name}' not found. Available: {', '.join(sorted(available.keys())[:10])}"
    
    # Load the skill content
    try:
        with open(available[skill_name], 'r') as f:
            content = f.read()
        
        # Use callback to inject into system prompt if available
        if _skill_loader:
            _skill_loader(skill_name, content)
            return f"Loaded skill: {skill_name}\n\nThe skill instructions are now available. Follow them to help the user."
        else:
            # Return content directly for agent to use
            return f"Skill '{skill_name}' loaded:\n\n{content}"
    except Exception as e:
        return f"Error loading skill: {e}"


def run_tool(name, args):
    """Execute a tool by name with the given arguments."""
    tools = {
        "read": read, "write": write, "edit": edit, 
        "glob": glob, "grep": grep, "bash": bash,
        "wallet_info": wallet_info, "wallet_balances": wallet_balances,
        "wallet_transfers": wallet_transfers,
        "wallet_transactions": wallet_transactions, "send_token": send_token,
        "access_key_info": access_key_info,
        "idxs": idxs, "connect_wallet": connect_wallet, "load_skill": load_skill,
        "web_search": web_search, "read_url": read_url,
    }
    
    if name not in tools:
        return f"Error: Unknown tool '{name}'. Available tools: {', '.join(tools.keys())}"
    
    try:
        return tools[name](args)
    except Exception as e:
        return f"Error running {name}: {str(e)}"


def make_schema():
    """Convert TOOL_DEFINITIONS to OpenAI-compatible tool schemas."""
    result = []
    for tool_def in TOOL_DEFINITIONS:
        properties = {}
        required = []
        
        for param_name, param_info in tool_def.get("parameters", {}).items():
            prop = {"type": param_info["type"]}
            if "description" in param_info:
                prop["description"] = param_info["description"]
            properties[param_name] = prop
            
            if not param_info.get("optional", False):
                required.append(param_name)
        
        result.append({
            "name": tool_def["name"],
            "description": tool_def["description"],
            "input_schema": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        })
    return result


def get_tools_summary():
    """Get a concise summary of available tools for the system prompt."""
    lines = []
    for tool_def in TOOL_DEFINITIONS:
        params = ", ".join(tool_def.get("parameters", {}).keys())
        if params:
            lines.append(f"- {tool_def['name']}({params}): {tool_def['description']}")
        else:
            lines.append(f"- {tool_def['name']}(): {tool_def['description']}")
    return "\n".join(lines)
