"""
Unified structured logging for Presto.

- Standard library logging only
- JSON Lines output (one JSON object per line) for log aggregation
- Semantic event types via `event` record attribute
- Env control via PRESTO_LOG_LEVEL

Usage:
    from presto.logger import get_logger
    logger = get_logger(__name__)
    
    # Standard logging
    logger.info("Starting server")
    logger.debug("Details", extra={"key": "value"})
    logger.error("Failed", extra={"reason": "timeout"})
    
    # Structured events (preserved API)
    logger.payment(amount_usd=1.0, status="confirmed", tx_hash="0x...")
    logger.proxy_response_402(amount_usd=0.32, challenge_id="abc123")
    logger.tool_use(name="web_search", args={"q": "test"})
    
    # Custom events
    logger.event("CHANNEL_OPENED", channel_id="0x...", deposit=5.0)

Environment variables:
    PRESTO_LOG_LEVEL: DEBUG, INFO, WARNING, ERROR (default: INFO)
    PRESTO_LOG_MAX_BYTES: Max log file size before rotation (default: 5MB)
    PRESTO_LOG_BACKUP_COUNT: Number of backup files to keep (default: 3)
"""

from __future__ import annotations

import json
import logging
import os
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Dict, Optional

# ----------------------------
# Configuration / defaults
# ----------------------------

_PRESTO_LOGGER_NAME = "presto"
_DEFAULT_LEVEL = os.getenv("PRESTO_LOG_LEVEL", "INFO")
_MAX_BYTES = int(os.getenv("PRESTO_LOG_MAX_BYTES", str(5 * 1024 * 1024)))  # 5MB
_BACKUP_COUNT = int(os.getenv("PRESTO_LOG_BACKUP_COUNT", "3"))

_CONFIGURED = False


def _find_log_file() -> Path:
    """Single canonical log file location.
    
    Priority:
    1. PRESTO_LOG_FILE env var (for testing isolation)
    2. ~/.cache/presto/presto.log (default)
    3. ./presto.log (dev mode fallback)
    """
    import os
    
    # Allow override via environment variable (for testing isolation)
    env_log = os.environ.get("PRESTO_LOG_FILE")
    if env_log:
        log_path = Path(env_log)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        return log_path
    
    cache_dir = Path.home() / ".cache" / "presto"
    cwd_log = Path.cwd() / "presto.log"

    if cache_dir.exists() or not cwd_log.exists():
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir / "presto.log"

    return cwd_log


LOG_FILE: Path = _find_log_file()


# ----------------------------
# JSON formatting
# ----------------------------

_STANDARD_LOGRECORD_ATTRS = {
    "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
    "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
    "created", "msecs", "relativeCreated", "thread", "threadName", "processName",
    "process", "message", "asctime", "taskName",
}

_SENSITIVE_KEYS = {
    "api_key", "authorization", "auth_header", "auth_header_preview",
    "signed_tx", "private_key", "seed", "mnemonic", "password", "access_key",
}


def _json_safe(value: Any) -> Any:
    """Best-effort conversion to JSON-safe values."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    return repr(value)


def _redact_dict(d: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for k, v in d.items():
        if k.lower() in _SENSITIVE_KEYS:
            out[k] = "[REDACTED]"
        else:
            out[k] = v
    return out


class JsonLineFormatter(logging.Formatter):
    """JSON Lines formatter - one JSON object per log record."""
    
    def format(self, record: logging.LogRecord) -> str:
        message = record.getMessage()

        payload: Dict[str, Any] = {
            "ts": time.time(),
            "time": time.strftime("%H:%M:%S"),
            "level": record.levelname,
            "event": getattr(record, "event", record.levelname),
            "msg": message,
        }

        if record.levelname in ("WARNING", "ERROR", "CRITICAL"):
            payload["module"] = record.module
            payload["func"] = record.funcName
            payload["line"] = record.lineno

        extras: Dict[str, Any] = {}
        for k, v in record.__dict__.items():
            if k in _STANDARD_LOGRECORD_ATTRS or k == "event":
                continue
            extras[k] = _json_safe(v)

        extras = _redact_dict(extras)
        payload.update(extras)

        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)

        return json.dumps(payload, ensure_ascii=False)


# ----------------------------
# Event logger (ergonomic API)
# ----------------------------

def _normalize_extra_fields(fields: Dict[str, Any]) -> Dict[str, Any]:
    """Prevent collisions with reserved LogRecord attributes."""
    normalized: Dict[str, Any] = {}
    for k, v in fields.items():
        key = str(k)
        if key in _STANDARD_LOGRECORD_ATTRS:
            key = f"data_{key}"
        normalized[key] = v
    return normalized


class EventLogger(logging.Logger):
    """Standard Logger + convenience methods for semantic/structured events."""

    def event(self, event: str, *, level: int = logging.INFO, msg: Optional[str] = None, **fields: Any) -> None:
        """Log a structured event with semantic type."""
        extra = {"event": event, **_normalize_extra_fields(fields)}
        self.log(level, msg or event, extra=extra)

    # --- Domain helpers (preserve existing API) ---

    def proxy_request(self, *, model: str, messages_count: int, has_tools: bool = False,
                      url: Optional[str] = None) -> None:
        self.event("PROXY_REQUEST", model=model, messages=messages_count, tools=has_tools, url=url)

    def proxy_response_402(self, *, amount_usd: float, challenge_id: str) -> None:
        self.event("PROXY_402", level=logging.INFO, amount_usd=amount_usd, 
                   challenge_id=challenge_id, msg="Payment required")

    def proxy_response_ok(self, *, status_code: int, tokens: int = 0,
                          cost: Optional[float] = None, tx_hash: Optional[str] = None) -> None:
        self.event("PROXY_OK", status=status_code, tokens=tokens, cost=cost, tx_hash=tx_hash or "")

    def tool_use(self, name: str, args: dict) -> None:
        self.event("TOOL_USE", level=logging.DEBUG, tool=name, args=args)

    def tool_result(self, name: str, result_len: int) -> None:
        self.event("TOOL_RESULT", level=logging.DEBUG, tool=name, result_len=result_len)

    def payment(self, *, amount_usd: float, status: str, tx_hash: Optional[str] = None, **extra: Any) -> None:
        self.event("PAYMENT", amount_usd=amount_usd, status=status, tx_hash=tx_hash, **extra)

    def payment_request(self, *, challenge_id: str, amount: str, asset: str, 
                        destination: str, rpc_url: Optional[str] = None) -> None:
        self.event("PAYMENT_REQUEST", challenge_id=challenge_id, amount=amount,
                   asset=asset, destination=destination, rpc_url=rpc_url)

    def payment_signed(self, *, signed_tx: str, from_address: str, nonce: str) -> None:
        self.event("PAYMENT_SIGNED", signed_tx=signed_tx, from_address=from_address, nonce=nonce)

    def payment_submitted(self, *, auth_header_preview: str, proxy_url: Optional[str] = None) -> None:
        self.event("PAYMENT_SUBMITTED", auth_header_preview=auth_header_preview, proxy_url=proxy_url)

    def payment_confirmed(self, *, tx_hash: str, amount_usd: float, explorer_url: str) -> None:
        self.event("PAYMENT_CONFIRMED", tx_hash=tx_hash, amount_usd=amount_usd, explorer_url=explorer_url)

    def http_error(self, *, code: int, url: str, body: str = "", message: str = "") -> None:
        self.event("HTTP_ERROR", level=logging.ERROR, code=code, url=url,
                   body=(body[:500] if body else ""), msg=(message or f"HTTP {code}"))


def configure_logging(*, level: Optional[str] = None, log_file: Optional[Path] = None) -> EventLogger:
    """
    Configure presto logging (idempotent).
    Call once near application entrypoint.
    """
    global _CONFIGURED

    logging.setLoggerClass(EventLogger)

    log_path = Path(log_file) if log_file else LOG_FILE
    lvl_name = (level or os.getenv("PRESTO_LOG_LEVEL", _DEFAULT_LEVEL)).upper()
    lvl = getattr(logging, lvl_name, logging.INFO)

    presto_logger = logging.getLogger(_PRESTO_LOGGER_NAME)
    presto_logger.setLevel(lvl)
    presto_logger.propagate = False

    if not _CONFIGURED:
        handler = RotatingFileHandler(
            log_path,
            maxBytes=_MAX_BYTES,
            backupCount=_BACKUP_COUNT,
            encoding="utf-8",
        )
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(JsonLineFormatter())
        presto_logger.addHandler(handler)
        _CONFIGURED = True

    return presto_logger  # type: ignore[return-value]


def get_logger(name: Optional[str] = None) -> EventLogger:
    """
    Get a child logger under the presto namespace.
    
    Usage:
        logger = get_logger(__name__)  # e.g., presto.api
        logger = get_logger()          # root presto logger
    """
    if not _CONFIGURED:
        configure_logging()

    if not name or name == _PRESTO_LOGGER_NAME:
        return logging.getLogger(_PRESTO_LOGGER_NAME)  # type: ignore[return-value]

    # Extract module name from full path (e.g., "presto.api" -> "api")
    if name.startswith("presto."):
        full = name
    elif "." in name:
        full = f"{_PRESTO_LOGGER_NAME}.{name.split('.')[-1]}"
    else:
        full = f"{_PRESTO_LOGGER_NAME}.{name}"
    
    return logging.getLogger(full)  # type: ignore[return-value]


def set_level(level: str) -> None:
    """Runtime verbosity control."""
    lvl = getattr(logging, level.upper(), logging.INFO)
    logging.getLogger(_PRESTO_LOGGER_NAME).setLevel(lvl)


# Module-level default logger for backwards compatibility
logger: EventLogger = get_logger()

# Backwards-compatible function aliases
def info(message: str) -> None:
    logger.info(message)

def debug(message: str, **details: Any) -> None:
    logger.debug(message, extra=details)

def error(message: str, **details: Any) -> None:
    logger.error(message, extra=details)

def warning(message: str, **details: Any) -> None:
    logger.warning(message, extra=details)

def log(event: str, **data: Any) -> None:
    """Legacy log function - use logger.event() instead."""
    logger.event(event, **data)

def api_call(model: str, messages_count: int, has_tools: bool = False, url: str = None, body: dict = None) -> None:
    logger.proxy_request(model=model, messages_count=messages_count, has_tools=has_tools, url=url)

def proxy_response_402(amount_usd: float, challenge_id: str) -> None:
    logger.proxy_response_402(amount_usd=amount_usd, challenge_id=challenge_id)

def proxy_response_ok(status_code: int, tokens: int = 0, cost: float = None, tx_hash: str = None) -> None:
    logger.proxy_response_ok(status_code=status_code, tokens=tokens, cost=cost, tx_hash=tx_hash)

def tool_use(name: str, args: dict) -> None:
    logger.tool_use(name, args)

def tool_result(name: str, result_len: int) -> None:
    logger.tool_result(name, result_len)

def payment(amount_usd: float, status: str, tx_hash: str = None, **extra) -> None:
    logger.payment(amount_usd=amount_usd, status=status, tx_hash=tx_hash, **extra)

def payment_request(challenge_id: str, amount: str, asset: str, destination: str, rpc_url: str = None) -> None:
    logger.payment_request(challenge_id=challenge_id, amount=amount, asset=asset, 
                           destination=destination, rpc_url=rpc_url)

def payment_signed(signed_tx: str, from_address: str, nonce: str) -> None:
    logger.payment_signed(signed_tx=signed_tx, from_address=from_address, nonce=nonce)

def payment_submitted(auth_header_preview: str, proxy_url: str = None) -> None:
    logger.payment_submitted(auth_header_preview=auth_header_preview, proxy_url=proxy_url)

def payment_confirmed(tx_hash: str, amount_usd: float, explorer_url: str) -> None:
    logger.payment_confirmed(tx_hash=tx_hash, amount_usd=amount_usd, explorer_url=explorer_url)

def http_error(code: int, url: str, body: str = "", message: str = "") -> None:
    logger.http_error(code=code, url=url, body=body, message=message)
