"""OSC 8 hyperlink support for terminal output and explorer URL helpers."""
import re
from .config import NETWORKS, DEFAULT_NETWORK


def get_explorer_url(value: str, network: str = DEFAULT_NETWORK, value_type: str = "auto") -> str:
    """Get block explorer URL for an address or transaction hash.
    
    Args:
        value: Address or transaction hash
        network: Network name (e.g., 'moderato', 'mainnet')
        value_type: 'address', 'tx', or 'auto' (auto-detects based on length)
    
    Returns:
        Full explorer URL
    """
    if not value:
        return ""
    explorer = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK]).get("explorer", "")
    if not explorer:
        return ""
    
    if value_type == "auto":
        # Tx hashes are 66 chars (0x + 64 hex), addresses are 42 chars (0x + 40 hex)
        value_type = "tx" if len(value) > 50 else "address"
    
    return f"{explorer}/{value_type}/{value}"


def osc8_link(url: str, text: str) -> str:
    """Create an OSC 8 hyperlink that's clickable in modern terminals.
    
    Supported terminals: iTerm2, Terminal.app, Ghostty, VS Code, Kitty, WezTerm, 
    GNOME Terminal, Konsole, Windows Terminal, and more.
    
    Format: ESC]8;;URL ESC\\ TEXT ESC]8;; ESC\\
    """
    return f"\x1b]8;;{url}\x1b\\{text}\x1b]8;;\x1b\\"


def tx_link(tx_hash: str, network: str = DEFAULT_NETWORK) -> str:
    """Create a clickable transaction hash link to block explorer."""
    if not tx_hash:
        return ""
    explorer = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK]).get("explorer", "")
    if not explorer:
        return tx_hash
    url = f"{explorer}/tx/{tx_hash}"
    return osc8_link(url, tx_hash)


def address_link(address: str, network: str = DEFAULT_NETWORK) -> str:
    """Create a clickable address link to block explorer."""
    if not address:
        return ""
    explorer = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK]).get("explorer", "")
    if not explorer:
        return address
    url = f"{explorer}/address/{address}"
    return osc8_link(url, address)


def visible_length(text: str) -> int:
    """Calculate visible length of text, excluding ANSI/OSC escape sequences.
    
    This is critical for proper line wrapping in curses when text contains
    OSC 8 hyperlinks or ANSI color codes.
    """
    # Remove OSC 8 hyperlinks: ESC]8;...ESC\\ (keeps the visible text between)
    # Pattern: \x1b]8;[^;]*;[^\x1b]*\x1b\\  (opening) and \x1b]8;;\x1b\\ (closing)
    text = re.sub(r'\x1b\]8;[^;]*;[^\x1b]*\x1b\\', '', text)
    text = re.sub(r'\x1b\]8;;\x1b\\', '', text)
    
    # Remove ANSI color/style codes: ESC[...m
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    
    return len(text)


def strip_escapes(text: str) -> str:
    """Remove all ANSI/OSC escape sequences from text."""
    text = re.sub(r'\x1b\]8;[^;]*;[^\x1b]*\x1b\\', '', text)
    text = re.sub(r'\x1b\]8;;\x1b\\', '', text)
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    return text
