"""API client for OpenRouter (direct or via payments-proxy)."""
import json
import urllib.request
import urllib.error
import os
import socket
import threading

from . import config
from . import logger
from .payment import parse_www_authenticate, handle_402_payment
from .tools import make_schema
from .streaming import get_stream_manager, StreamChannel

# Cache for model info (context lengths, etc.)
_model_info_cache = {}

# Connection timeout - long enough for real connections, but not forever
_CONNECT_TIMEOUT = 30

# Read timeout - long enough to avoid "timed out object" errors
# Cancellation is handled by closing the response from watcher thread
_READ_TIMEOUT = 300  # 5 minutes


def urlopen_interruptible(request, cancel_event, timeout_s=_CONNECT_TIMEOUT):
    """Open URL, checking cancel_event before connecting.
    
    Cancellation is handled by closing the response from a watcher thread,
    not by short read timeouts (which poison the socket in CPython).
    
    NOTE: We don't retry on timeout because retrying HTTP requests can cause
    duplicate submissions (especially problematic for payment flows).
    """
    if cancel_event and cancel_event.is_set():
        raise StreamCancelled("Cancelled before connect")
    
    # Use connection timeout, then set a long read timeout
    response = urllib.request.urlopen(request, timeout=timeout_s)
    
    # Set a reasonable read timeout (not too short - causes "timed out object" errors)
    try:
        if hasattr(response, 'fp') and hasattr(response.fp, 'raw'):
            response.fp.raw._sock.settimeout(_READ_TIMEOUT)
        elif hasattr(response, 'fp') and hasattr(response.fp, '_sock'):
            response.fp._sock.settimeout(_READ_TIMEOUT)
    except (AttributeError, OSError):
        pass
    
    # Start watcher thread to close response on cancellation
    if cancel_event:
        def _cancel_closer():
            cancel_event.wait()
            try:
                response.close()
            except Exception:
                pass
        t = threading.Thread(target=_cancel_closer, daemon=True)
        t.start()
    
    return response


def iter_lines_interruptible(response, cancel_event):
    """Yield lines from response, checking cancel_event between reads.
    
    Cancellation works by the watcher thread closing the response.
    """
    while True:
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Cancelled during stream")
        try:
            line = response.readline()
        except Exception as e:
            # If cancelled, convert to StreamCancelled
            if cancel_event and cancel_event.is_set():
                raise StreamCancelled("Cancelled during stream") from e
            raise
        if not line:
            break
        yield line


def read_all_interruptible(response, cancel_event, chunk_size=8192):
    """Read entire response body in chunks, checking cancel_event between reads.
    
    Returns the complete body as bytes.
    """
    parts = []
    while True:
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Cancelled while reading body")
        try:
            chunk = response.read(chunk_size)
        except Exception as e:
            # If cancelled, convert to StreamCancelled
            if cancel_event and cancel_event.is_set():
                raise StreamCancelled("Cancelled while reading body") from e
            raise
        if not chunk:
            break
        parts.append(chunk)
    return b"".join(parts)


def get_model_context_length(model_id: str) -> int:
    """Get the context length for a model from OpenRouter API."""
    global _model_info_cache
    
    # Return cached value if available
    if model_id in _model_info_cache:
        return _model_info_cache[model_id].get("context_length", 128000)
    
    # Default context lengths for common models (from OpenRouter docs)
    defaults = {
        "anthropic/claude-sonnet-4": 1000000,
        "anthropic/claude-opus-4": 200000,
        "anthropic/claude-opus-4.5": 200000,
        "anthropic/claude-3.5-sonnet": 200000,
        "anthropic/claude-3-opus": 200000,
        "openai/gpt-4.1": 1047576,
        "openai/gpt-4.1-mini": 1047576,
        "openai/gpt-4o": 128000,
        "openai/gpt-4o-mini": 128000,
        "openai/gpt-4-turbo": 128000,
        "google/gemini-2.5-pro": 1048576,
        "google/gemini-2.5-flash": 1048576,
        "google/gemini-2.0-flash-001": 1000000,
        "google/gemini-pro-1.5": 1000000,
        "deepseek/deepseek-r1": 64000,
        "meta-llama/llama-3.1-405b-instruct": 131072,
    }
    
    if model_id in defaults:
        _model_info_cache[model_id] = {"context_length": defaults[model_id]}
        return defaults[model_id]
    
    # Try to fetch from OpenRouter API
    try:
        url = "https://openrouter.ai/api/v1/models"
        request = urllib.request.Request(url)
        request.add_header("User-Agent", "presto/1.0")
        response = urllib.request.urlopen(request, timeout=5)
        data = json.loads(response.read())
        
        for model in data.get("data", []):
            mid = model.get("id", "")
            ctx = model.get("context_length", 128000)
            _model_info_cache[mid] = {"context_length": ctx}
        
        if model_id in _model_info_cache:
            return _model_info_cache[model_id]["context_length"]
    except Exception:
        pass
    
    # Default fallback
    return 128000


def parse_sse_line(line: str) -> dict:
    """Parse a Server-Sent Events line."""
    if line.startswith("data: "):
        data = line[6:]
        if data.strip() == "[DONE]":
            return {"done": True}
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return {}
    return {}


class StreamCancelled(Exception):
    """Raised when streaming is cancelled by the user."""
    pass


class PaymentError(Exception):
    """Raised when request fails after payment was made.
    
    Carries payment info so it can still be tracked in session totals.
    """
    def __init__(self, message: str, payment_info: dict | None = None):
        super().__init__(message)
        self.payment_info = payment_info or {}


def _is_stream_challenge(www_auth: str) -> bool:
    """Check if WWW-Authenticate indicates a streaming payment channel option."""
    return 'intent="stream"' in www_auth or 'intent=stream' in www_auth


def _try_stream_payment(
    www_auth: str,
    private_key: str,
    from_address: str,
    amount: int,
    on_payment_step=None,
    use_direct_signing: bool = False,
    stream_deposit_usd: float = None,
    on_stream_depleted=None,
) -> tuple[str, bool]:
    """Try to use streaming payment channel if available.
    
    Args:
        www_auth: WWW-Authenticate header value
        private_key: Private key for signing
        from_address: Wallet address
        amount: Payment amount in base units
        on_payment_step: callback(step, status) for progress
        use_direct_signing: If True, sign directly (EOA mode)
        stream_deposit_usd: User's requested deposit amount in USD (overrides server suggestion)
        on_stream_depleted: callback(channel_info: dict) -> new_limit_usd or None, called when channel depleted
    
    Returns:
        (auth_header, used_stream) - Authorization header and whether stream was used
    """
    manager = get_stream_manager()
    if not manager:
        return None, False
    
    # Parse stream challenge
    stream_params = manager.parse_stream_challenge(www_auth)
    if not stream_params:
        return None, False
    
    # Get challenge ID (required for credential envelope per spec §6)
    challenge_id = stream_params.get("id", "")
    if not challenge_id:
        logger.warning("Stream challenge missing 'id', falling back to per-request")
        return None, False
    
    # Extract stream-specific parameters from 'request' object (per spec §5)
    request = stream_params.get("request", {})
    if isinstance(request, str):
        try:
            from .payment import base64url_decode
            request = json.loads(base64url_decode(request))
        except:
            request = {}
    
    # Fallback to top-level params for backwards compatibility
    escrow_contract = request.get("escrowContract") or stream_params.get("escrowContract", "")
    payee = request.get("destination") or stream_params.get("destination", "")
    token = request.get("asset") or stream_params.get("asset", "")
    deposit = int(request.get("deposit") or stream_params.get("deposit", "0"))
    expires = request.get("expires") or stream_params.get("expires", "")
    salt = request.get("salt") or stream_params.get("salt", "")
    voucher_endpoint = request.get("voucherEndpoint") or stream_params.get("voucherEndpoint", "")
    min_delta = int(request.get("minVoucherDelta") or stream_params.get("minVoucherDelta", "0"))
    
    if not escrow_contract or not payee:
        logger.info("Stream challenge missing required params, falling back to per-request")
        return None, False
    
    # Check for existing channel by ON-CHAIN IDENTITY (escrow + payee)
    # The channel is an agreement with a specific payee address, not a URL
    channel = manager.get_active_channel(escrow_contract, payee, voucher_endpoint=voucher_endpoint)
    
    if channel and channel.can_afford(amount):
        # Use existing channel - just sign a voucher (instant, no gas!)
        logger.info(f"Using existing channel {channel.channel_id[:18]}...")
        
        # Check if channel needs re-registration with new endpoint
        needs_reregistration = (
            voucher_endpoint and 
            channel.voucher_endpoint and 
            channel.voucher_endpoint != voucher_endpoint
        )
        
        if needs_reregistration:
            logger.info(f"Re-registering channel with new endpoint: {voucher_endpoint[:50]}...")
            if on_payment_step:
                on_payment_step('registering', 'pending', None)
            
            try:
                import urllib.request
                import urllib.error
                
                # Sign zero-amount voucher for re-registration
                zero_voucher = manager.sign_voucher(channel, 0)
                channel.cumulative_amount -= 0  # Don't increment for registration
                
                open_credential = manager.build_stream_credential(
                    channel, zero_voucher, challenge_id,
                    action="open",
                    open_tx_hash=channel.open_tx_hash
                )
                
                # Fix localhost URLs
                fixed_endpoint = voucher_endpoint
                if voucher_endpoint.startswith("https://localhost") or voucher_endpoint.startswith("https://127.0.0.1"):
                    fixed_endpoint = voucher_endpoint.replace("https://", "http://")
                
                from .payment import base64url_decode
                cred_data = json.loads(base64url_decode(open_credential.replace("Payment ", "")))
                reg_data = json.dumps(cred_data["payload"]).encode()
                
                reg_req = urllib.request.Request(fixed_endpoint, data=reg_data, headers={
                    "Content-Type": "application/json",
                })
                
                reg_response = urllib.request.urlopen(reg_req, timeout=30)
                reg_result = json.loads(reg_response.read().decode())
                logger.info(f"Channel re-registered with server: {reg_result}")
                
                # Update stored endpoint
                channel.voucher_endpoint = voucher_endpoint
                manager._save_channels()
                
                if on_payment_step:
                    on_payment_step('registering', 'done', None)
                    
            except urllib.error.HTTPError as e:
                error_body = e.read().decode('utf-8', errors='ignore')
                logger.error(f"Failed to re-register channel: {e.code} - {error_body}")
                # Continue anyway - server might already know about the channel
            except Exception as e:
                logger.error(f"Failed to re-register channel: {e}")
                # Continue anyway
        
        if on_payment_step:
            on_payment_step('voucher', 'pending', None)
        
        try:
            voucher = manager.sign_voucher(channel, amount)
            # Use action="voucher" for existing channels (per spec §6)
            auth_header = manager.build_stream_credential(
                channel, voucher, challenge_id, action="voucher"
            )
            
            if on_payment_step:
                # Pass channel info for display
                channel_info = {
                    "channel_id": channel.channel_id,
                    "server": channel.voucher_endpoint or payee,
                    "used": channel.cumulative_amount / 1_000_000,
                    "deposit": channel.deposit / 1_000_000,
                }
                on_payment_step('voucher', 'done', channel_info)
            
            logger.info(f"Voucher signed (instant): cumulative={channel.cumulative_amount}")
            return auth_header, True
        except Exception as e:
            logger.error(f"Failed to sign voucher: {e}")
            return None, False
    
    # Channel exists but depleted - ask user if they want a new channel with higher deposit
    # Note: Due to channelId including deposit, we cannot top up existing channels.
    # We must open a new channel with the desired deposit amount.
    if channel and not channel.can_afford(amount):
        current_limit_usd = channel.deposit / 1_000_000
        used_usd = channel.cumulative_amount / 1_000_000
        logger.info(f"Channel depleted: used ${used_usd:.2f} of ${current_limit_usd:.2f} deposit")
        
        if on_stream_depleted:
            # Pass detailed channel info to UI
            channel_info = {
                'deposit_usd': current_limit_usd,
                'spent_usd': used_usd,
                'remaining_usd': (channel.deposit - channel.cumulative_amount) / 1_000_000,
                'token': channel.token,
                'payee': channel.payee,
                'voucher_endpoint': channel.voucher_endpoint or '',
                'voucher_count': channel.voucher_count,
            }
            new_limit = on_stream_depleted(channel_info)
            if new_limit is not None and new_limit > current_limit_usd:
                stream_deposit_usd = new_limit
                logger.info(f"User requested new channel with ${new_limit:.2f} deposit")
            else:
                logger.info("User declined, falling back to per-request payment")
                return None, False
    
    # Open a new channel (either first time, or after depletion with new deposit)
    logger.info("Opening new streaming channel...")
    
    # Use user's deposit preference if specified (convert USD to base units: 6 decimals)
    if stream_deposit_usd is not None and stream_deposit_usd > 0:
        user_deposit = int(stream_deposit_usd * 1_000_000)
        logger.info(f"Using user-specified deposit: ${stream_deposit_usd} ({user_deposit} base units)")
        deposit = user_deposit
    
    # Parse expiry
    import time
    try:
        from datetime import datetime
        expiry_ts = int(datetime.fromisoformat(expires.replace('Z', '+00:00')).timestamp())
    except:
        expiry_ts = int(time.time()) + 3600  # Default 1 hour
    
    try:
        channel = manager.open_channel(
            escrow_contract=escrow_contract,
            payee=payee,
            token=token,
            deposit=deposit,
            expiry=expiry_ts,
            salt=salt,
            voucher_endpoint=voucher_endpoint,
            min_voucher_delta=min_delta,
            on_step=on_payment_step,
            use_direct_signing=use_direct_signing,
        )
        
        # Register channel with server via voucher endpoint (action="open")
        if on_payment_step:
            on_payment_step('registering', 'pending', None)
        
        # Sign zero-amount voucher for registration (server requires cumulativeAmount=0)
        zero_voucher = manager.sign_voucher(channel, 0)
        # Reset cumulative amount since this is just for registration
        channel.cumulative_amount = 0
        
        open_credential = manager.build_stream_credential(
            channel, zero_voucher, challenge_id,
            action="open",
            open_tx_hash=channel.open_tx_hash
        )
        
        # Register with voucher endpoint
        if voucher_endpoint:
            try:
                import urllib.request
                import urllib.error
                
                # Fix localhost HTTPS -> HTTP (localhost doesn't have valid SSL certs)
                fixed_endpoint = voucher_endpoint
                if voucher_endpoint.startswith("https://localhost") or voucher_endpoint.startswith("https://127.0.0.1"):
                    fixed_endpoint = voucher_endpoint.replace("https://", "http://")
                
                # Extract just the payload for the voucher endpoint
                from .payment import base64url_decode
                cred_data = json.loads(base64url_decode(open_credential.replace("Payment ", "")))
                payload = cred_data.get("payload", {})
                
                reg_data = json.dumps(payload).encode()
                reg_req = urllib.request.Request(fixed_endpoint, data=reg_data, headers={
                    "Content-Type": "application/json",
                })
                
                reg_response = urllib.request.urlopen(reg_req, timeout=30)
                reg_result = json.loads(reg_response.read().decode())
                logger.info(f"Channel registered with server: {reg_result}")
                
            except urllib.error.HTTPError as e:
                error_body = e.read().decode('utf-8', errors='ignore')
                logger.error(f"Failed to register channel: {e.code} - {error_body}")
                # Remove the unregistered channel to prevent reuse
                manager._channels.pop(channel.channel_id, None)
                manager._save_channels()
                if on_payment_step:
                    on_payment_step('registering', 'error', f"Channel registration failed: {error_body}")
                return None, False
            except Exception as e:
                import traceback
                logger.error(f"Failed to register channel: {e}\n{traceback.format_exc()}")
                # Remove the unregistered channel to prevent reuse
                manager._channels.pop(channel.channel_id, None)
                manager._save_channels()
                if on_payment_step:
                    on_payment_step('registering', 'error', str(e))
                return None, False
        
        if on_payment_step:
            on_payment_step('registering', 'done', None)
            on_payment_step('voucher', 'pending', None)
        
        # Now sign a voucher with the actual payment amount
        voucher = manager.sign_voucher(channel, amount)
        auth_header = manager.build_stream_credential(
            channel, voucher, challenge_id, action="voucher"
        )
        
        if on_payment_step:
            # Pass channel info for display
            channel_info = {
                "channel_id": channel.channel_id,
                "server": channel.voucher_endpoint or payee,
                "used": channel.cumulative_amount / 1_000_000,
                "deposit": channel.deposit / 1_000_000,
            }
            on_payment_step('voucher', 'done', channel_info)
        
        return auth_header, True
        
    except Exception as e:
        import traceback
        logger.error(f"Failed to open channel: {e}\n{traceback.format_exc()}")
        return None, False


def read_stream_response(response, on_text_chunk=None, cancel_event=None):
    """Read a streaming SSE response and accumulate the result.
    
    Args:
        response: HTTP response object
        on_text_chunk: callback(chunk) -> bool, return False to cancel
        cancel_event: threading.Event, if set, stream is cancelled
    
    If on_text_chunk returns False, the stream is cancelled.
    """
    full_text = ""
    tool_calls = {}  # id -> {id, name, arguments}
    usage = {"tokens": 0, "prompt_tokens": 0, "completion_tokens": 0, "cost": None}
    
    for line in response:
        # Check cancellation event before processing each line
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Stream cancelled by cancel_event")
        
        line = line.decode('utf-8', errors='ignore').strip()
        if not line:
            continue
        
        chunk = parse_sse_line(line)
        if chunk.get("done"):
            break
        
        if "usage" in chunk:
            usage["tokens"] = chunk["usage"].get("total_tokens", 0)
            usage["prompt_tokens"] = chunk["usage"].get("prompt_tokens", 0)
            usage["completion_tokens"] = chunk["usage"].get("completion_tokens", 0)
            usage["cost"] = chunk["usage"].get("cost")
        
        choices = chunk.get("choices", [])
        if not choices:
            continue
        
        delta = choices[0].get("delta", {})
        
        # Handle text content
        if "content" in delta and delta["content"]:
            text_chunk = delta["content"]
            full_text += text_chunk
            if on_text_chunk:
                # If callback returns False, cancel the stream
                result = on_text_chunk(text_chunk)
                if result is False:
                    raise StreamCancelled("Stream cancelled by user")
        
        # Handle tool calls
        if "tool_calls" in delta:
            for tc in delta["tool_calls"]:
                idx = tc.get("index", 0)
                if idx not in tool_calls:
                    tool_calls[idx] = {"id": "", "name": "", "arguments": ""}
                if "id" in tc:
                    tool_calls[idx]["id"] = tc["id"]
                if "function" in tc:
                    if "name" in tc["function"]:
                        tool_calls[idx]["name"] = tc["function"]["name"]
                    if "arguments" in tc["function"]:
                        tool_calls[idx]["arguments"] += tc["function"]["arguments"]
    
    # Build final result
    content = []
    if full_text:
        content.append({"type": "text", "text": full_text})
    
    for idx in sorted(tool_calls.keys()):
        tc = tool_calls[idx]
        try:
            args = json.loads(tc["arguments"]) if tc["arguments"] else {}
        except json.JSONDecodeError:
            args = {}
        content.append({
            "type": "tool_use",
            "id": tc["id"],
            "name": tc["name"],
            "input": args
        })
    
    return {"content": content, "usage": usage}


def looks_like_sse(line: bytes) -> bool:
    """Check if a line looks like SSE format."""
    s = line.decode('utf-8', errors='ignore').strip()
    return s.startswith('data:') or s.startswith(':') or s == ''


def try_stream_response(response, on_text_chunk=None, cancel_event=None):
    """Try to read response as SSE stream, fall back to JSON if not SSE.
    
    Args:
        response: HTTP response object
        on_text_chunk: callback(chunk) -> bool, return False to cancel
        cancel_event: threading.Event, if set, stream is cancelled
    
    Returns (result, tokens, cost) tuple.
    """
    # Check cancellation before starting
    if cancel_event and cancel_event.is_set():
        raise StreamCancelled("Cancelled before reading response")
    
    # Read first line to detect format (with timeout handling)
    first_line = None
    while first_line is None:
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Cancelled while reading first line")
        try:
            first_line = response.readline()
        except (socket.timeout, TimeoutError):
            continue
    
    if looks_like_sse(first_line):
        # It's SSE - create iterator that includes first line, using interruptible reads
        def line_iter():
            yield first_line
            for line in iter_lines_interruptible(response, cancel_event):
                yield line
        
        result = read_stream_response(line_iter(), on_text_chunk, cancel_event)
        tokens = result["usage"].get("tokens", 0)
        cost = result["usage"].get("cost")
        return result, tokens, cost
    else:
        # Not SSE - read rest with interruptible chunked reads
        rest = read_all_interruptible(response, cancel_event)
        full_body = first_line + rest
        resp_data = json.loads(full_body)
        result = parse_openai_response(resp_data)
        usage_data = resp_data.get('usage', {})
        tokens = usage_data.get('total_tokens', 0)
        cost = usage_data.get('cost')
        result["usage"] = {"tokens": tokens, "cost": cost}
        return result, tokens, cost


def parse_openai_response(resp: dict) -> dict:
    """Parse OpenAI/OpenRouter response into our internal format."""
    content = []
    choice = resp.get("choices", [{}])[0]
    message = choice.get("message", {})
    
    # Log the finish reason for debugging
    finish_reason = choice.get("finish_reason", "unknown")
    logger.info(f"Response finish_reason: {finish_reason}")
    
    if message.get("content"):
        content.append({"type": "text", "text": message["content"]})
    
    tool_calls = message.get("tool_calls", [])
    if tool_calls:
        logger.info(f"Model requested {len(tool_calls)} tool call(s)")
    
    for tc in tool_calls:
        try:
            content.append({
                "type": "tool_use",
                "id": tc["id"],
                "name": tc["function"]["name"],
                "input": json.loads(tc["function"]["arguments"])
            })
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse tool arguments: {e}")
            content.append({
                "type": "tool_use",
                "id": tc["id"],
                "name": tc["function"]["name"],
                "input": {}
            })
    
    return {"content": content}


def call_api(messages: list, system_prompt: str, private_key: str, from_address: str, 
             rpc_url: str = None, chain_id: int = 1088, on_payment=None, on_status=None, 
             on_confirm=None, model: str = None, explorer_url: str = None,
             on_text_chunk=None, on_payment_step=None, use_direct_signing: bool = False,
             cancel_event: threading.Event = None, stream_deposit_usd=None,
             on_stream_depleted=None) -> dict:
    """
    Call OpenRouter API (directly if OPENROUTER_API_KEY set, otherwise via payments-proxy).
    
    Args:
        messages: Conversation history
        system_prompt: System prompt for the model
        private_key: Private key for signing payments
        from_address: Wallet address for payments
        rpc_url: RPC endpoint for blockchain
        chain_id: Chain ID for transactions
        on_payment: callback(amount_usd) called when payment is required
        on_status: callback(message) called for status updates
        on_confirm: callback(amount_usd, asset_address) -> bool, called to confirm payment
        model: Model to use
        explorer_url: Block explorer URL
        on_text_chunk: callback(chunk) for streaming text
        on_payment_step: callback(step, status) called during payment processing
        use_direct_signing: If True, sign directly with private key (for simple EOA wallets)
        cancel_event: threading.Event, if set, cancels the request
        stream_deposit_usd: If set, use streaming payment channels with this deposit amount (USD)
        on_stream_depleted: callback(channel_info: dict) -> new_limit_usd, called when channel is depleted
    
    Raises:
        StreamCancelled: If cancel_event is set during the request
    """
    def check_cancelled():
        """Check if request has been cancelled, raise if so."""
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Request cancelled")
    # Always use payments-proxy for crypto payments (default behavior)
    # Only use direct OpenRouter if explicitly requested via PRESTO_USE_DIRECT_API=1
    import os
    from .runtime_settings import get_settings
    use_direct = os.environ.get("PRESTO_USE_DIRECT_API") == "1"
    proxy_url = get_settings().get_proxy_url()
    url = config.OPENROUTER_URL if use_direct else f"{proxy_url}/v1/chat/completions"
    
    chat_messages = [{"role": "system", "content": system_prompt}]
    for msg in messages:
        if msg["role"] == "user":
            if isinstance(msg["content"], str):
                chat_messages.append({"role": "user", "content": msg["content"]})
            elif isinstance(msg["content"], list):
                for item in msg["content"]:
                    if item.get("type") == "tool_result":
                        chat_messages.append({
                            "role": "tool",
                            "tool_call_id": item["tool_use_id"],
                            "content": item["content"]
                        })
        elif msg["role"] == "assistant":
            if isinstance(msg["content"], str):
                chat_messages.append({"role": "assistant", "content": msg["content"]})
            elif isinstance(msg["content"], list):
                text_parts = []
                tool_calls = []
                for block in msg["content"]:
                    if block["type"] == "text":
                        text_parts.append(block["text"])
                    elif block["type"] == "tool_use":
                        tool_calls.append({
                            "id": block["id"],
                            "type": "function",
                            "function": {
                                "name": block["name"],
                                "arguments": json.dumps(block["input"])
                            }
                        })
                assistant_msg = {"role": "assistant"}
                if text_parts:
                    assistant_msg["content"] = "\n".join(text_parts)
                if tool_calls:
                    assistant_msg["tool_calls"] = tool_calls
                chat_messages.append(assistant_msg)
    
    openai_tools = [{
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t["description"],
            "parameters": t["input_schema"]
        }
    } for t in make_schema()]
    
    selected_model = model or config.MODEL
    stream_enabled = on_text_chunk is not None
    body_dict = {
        "model": selected_model,
        "max_tokens": 8192,
        "messages": chat_messages,
        "tools": openai_tools,
        "tool_choice": "auto",
        "stream": stream_enabled,
    }
    
    # Request usage stats in streaming responses
    if stream_enabled:
        body_dict["stream_options"] = {"include_usage": True}
    body = json.dumps(body_dict).encode()
    
    logger.api_call(selected_model, len(chat_messages), has_tools=bool(openai_tools), url=url, body=body_dict)
    
    headers = {"Content-Type": "application/json"}
    
    # SSE-friendly headers to ensure proxies don't buffer the stream
    if stream_enabled:
        headers["Accept"] = "text/event-stream"
        headers["Cache-Control"] = "no-cache"
        headers["Accept-Encoding"] = "identity"  # Disable compression for streaming
    if use_direct:
        headers["Authorization"] = f"Bearer {config.OPENROUTER_API_KEY}"
    
    # For localhost, set Host header with partner subdomain (e.g., "openrouter.localhost")
    if "localhost" in url:
        headers["Host"] = f"{config.get_provider()}.localhost"
    
    request = urllib.request.Request(url, data=body, headers=headers)
    
    logger.log("REQUEST", url=request.full_url, method=request.get_method(), headers=dict(request.headers), body_len=len(body))
    
    if use_direct:
        try:
            response = urllib.request.urlopen(request)
            resp_data = json.loads(response.read())
            result = parse_openai_response(resp_data)
            tool_calls = sum(1 for b in result.get('content', []) if b.get('type') == 'tool_use')
            tokens = resp_data.get('usage', {}).get('total_tokens', 0)
            logger.api_response("ok", tokens=tokens, tool_calls=tool_calls, raw_response=resp_data)
            return result
        except urllib.error.HTTPError as e:
            error_body = ""
            try:
                error_body = e.read().decode('utf-8', errors='ignore')[:500]
            except:
                pass
            logger.http_error(code=e.code, url=url, body=error_body, message=f"Direct API error")
            if e.code == 402:
                raise RuntimeError("OpenRouter requires credits. Add funds at https://openrouter.ai/credits")
            raise
        except urllib.error.URLError as e:
            logger.error(f"Connection error: {e.reason}", url=url)
            raise RuntimeError(f"Cannot connect to OpenRouter API ({url}). Check your internet connection.")
    
    # Check cancellation before making request
    check_cancelled()
    
    try:
        response = urlopen_interruptible(request, cancel_event)
        
        # Check cancellation after connection established
        check_cancelled()
        
        if stream_enabled:
            # Try streaming - peek at first line to detect SSE format
            result, tokens, cost = try_stream_response(response, on_text_chunk, cancel_event)
        else:
            body_bytes = read_all_interruptible(response, cancel_event)
            resp_data = json.loads(body_bytes)
            result = parse_openai_response(resp_data)
            usage_data = resp_data.get('usage', {})
            tokens = usage_data.get('total_tokens', 0)
            prompt_tokens = usage_data.get('prompt_tokens', 0)
            completion_tokens = usage_data.get('completion_tokens', 0)
            cost = usage_data.get('cost')
            result["usage"] = {"tokens": tokens, "prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens, "cost": cost}
        logger.proxy_response_ok(200, tokens=tokens, cost=cost)
        return result
    except urllib.error.HTTPError as e:
        if e.code == 402:
            # Check cancellation before starting payment flow
            check_cancelled()
            
            www_auth = e.headers.get("WWW-Authenticate", "")
            if not www_auth:
                logger.error("402 without WWW-Authenticate header")
                raise RuntimeError("402 without WWW-Authenticate header")
            
            challenge = parse_www_authenticate(www_auth)
            challenge_id = challenge.get("id", "unknown")
            amount_usd = float(challenge["request"]["amount"]) / 1_000_000
            amount_base = int(challenge["request"]["amount"])
            logger.proxy_response_402(amount_usd=amount_usd, challenge_id=challenge_id)
            
            if on_payment:
                on_payment(amount_usd)
            
            if not private_key:
                raise RuntimeError("402 Payment Required - no wallet configured")
            
            # Check cancellation before payment
            check_cancelled()
            
            # Check if we can skip confirmation because an active streaming channel exists
            skip_confirm = False
            is_callable = callable(stream_deposit_usd)
            effective_stream_deposit = stream_deposit_usd() if is_callable else stream_deposit_usd
            
            if effective_stream_deposit is not None and _is_stream_challenge(www_auth):
                # Check for an active channel that can handle this payment
                manager = get_stream_manager()
                if manager:
                    stream_params = manager.parse_stream_challenge(www_auth)
                    if stream_params:
                        request = stream_params.get("request", {})
                        if isinstance(request, str):
                            try:
                                from .payment import base64url_decode
                                request = json.loads(base64url_decode(request))
                            except:
                                request = {}
                        escrow = request.get("escrowContract") or stream_params.get("escrowContract", "")
                        payee = request.get("destination") or stream_params.get("destination", "")
                        voucher_ep = request.get("voucherEndpoint") or stream_params.get("voucherEndpoint", "")
                        if escrow and payee:
                            active_channel = manager.get_active_channel(escrow, payee, voucher_endpoint=voucher_ep)
                            if active_channel and active_channel.remaining_balance() >= amount_base:
                                skip_confirm = True
                                logger.info(f"Skipping confirmation - active channel has ${active_channel.remaining_balance()/1_000_000:.2f} remaining")
            
            # Ask for confirmation first (user may select "Always" which enables streaming)
            # Skip if we have an active streaming channel with sufficient balance
            if on_confirm and not skip_confirm:
                asset_address = challenge["request"].get("asset", "")
                confirmed = on_confirm(amount_usd, asset_address)
                if not confirmed:
                    raise RuntimeError("Payment declined by user")
            
            # Check cancellation after confirmation
            check_cancelled()
            
            # Re-check stream_deposit_usd - it may have been enabled during confirmation
            effective_stream_deposit = stream_deposit_usd() if is_callable else stream_deposit_usd
            
            # Try streaming payment first (much faster, no on-chain tx per request)
            used_stream = False
            is_stream = _is_stream_challenge(www_auth)
            if is_stream and effective_stream_deposit is not None:
                auth_header, used_stream = _try_stream_payment(
                    www_auth, private_key, from_address, amount_base,
                    on_payment_step=on_payment_step, use_direct_signing=use_direct_signing,
                    stream_deposit_usd=effective_stream_deposit,
                    on_stream_depleted=on_stream_depleted
                )
                if used_stream:
                    logger.info("Using streaming payment channel (instant voucher)")
            
            # Fall back to per-request payment if streaming not available/failed
            if not used_stream:
                auth_header = handle_402_payment(challenge, private_key, from_address, rpc_url, chain_id, on_step=on_payment_step, use_direct_signing=use_direct_signing)
            
            # Check cancellation after signing (subprocess calls can take time)
            check_cancelled()
            
            # Mark sending as done, waiting for confirmation (only for per-request, not streaming)
            if on_payment_step and not used_stream:
                on_payment_step('sending', 'done', None)
                on_payment_step('confirming', 'pending', None)
            
            headers["Authorization"] = auth_header
            request = urllib.request.Request(url, data=body, headers=headers)
            
            # Retry loop for transient errors (rate limits, expired challenges)
            max_retries = 3
            last_error = None
            for retry_num in range(max_retries):
                try:
                    response = urlopen_interruptible(request, cancel_event)
                    break  # Success
                except urllib.error.HTTPError as retry_err:
                    error_body = ""
                    try:
                        error_body = retry_err.read().decode('utf-8', errors='ignore')[:500]
                    except:
                        pass
                    last_error = (retry_err.code, error_body)
                    
                    # Context length exceeded (HTTP 400) - don't retry, give clear error
                    if retry_err.code == 400 and "context length" in error_body.lower():
                        logger.error(f"Context length exceeded: {error_body[:200]}")
                        payment_info = {
                            "amount_usd": amount_usd,
                            "stream": used_stream,
                            "tx_hash": "",
                            "explorer_url": "",
                        }
                        raise PaymentError(
                            "Context length exceeded. Your conversation is too long. "
                            "Start a new chat or use a shorter query.",
                            payment_info=payment_info
                        )
                    
                    # Rate limit - wait and retry
                    if "rate limit" in error_body.lower() and retry_num < max_retries - 1:
                        import re
                        import time as time_mod
                        match = re.search(r'try again in (\d+)ms', error_body)
                        wait_ms = int(match.group(1)) if match else 100
                        logger.info(f"Rate limited, waiting {wait_ms}ms (retry {retry_num + 1})")
                        time_mod.sleep(wait_ms / 1000.0 + 0.1)
                        continue
                    
                    # Expired/unknown challenge - get fresh challenge, reuse signed tx
                    if retry_err.code in (401, 402) and retry_num < max_retries - 1:
                        if "expired" in error_body.lower() or "unknown" in error_body.lower():
                            logger.info(f"Challenge expired, refreshing (retry {retry_num + 1})")
                            try:
                                # Get fresh challenge
                                fresh_req = urllib.request.Request(url, data=body, headers={
                                    k: v for k, v in headers.items() if k != "Authorization"
                                })
                                urllib.request.urlopen(fresh_req, timeout=30)
                            except urllib.error.HTTPError as fresh_err:
                                if fresh_err.code == 402:
                                    new_www_auth = fresh_err.headers.get("WWW-Authenticate", "")
                                    if new_www_auth:
                                        new_challenge = parse_www_authenticate(new_www_auth)
                                        # Rebuild auth with new challenge ID, same signed tx
                                        import base64
                                        old_cred_b64 = auth_header.replace("Payment ", "")
                                        # Add padding for base64 decode
                                        old_cred_b64 += "=" * (4 - len(old_cred_b64) % 4)
                                        old_cred = json.loads(base64.urlsafe_b64decode(old_cred_b64))
                                        new_cred = {
                                            "id": new_challenge["id"],
                                            "source": old_cred["source"],
                                            "payload": old_cred["payload"]
                                        }
                                        from .payment import format_authorization
                                        auth_header = format_authorization(new_cred)
                                        headers["Authorization"] = auth_header
                                        request = urllib.request.Request(url, data=body, headers=headers)
                                        continue
                            except Exception as e:
                                logger.error(f"Failed to refresh challenge: {e}")
                    
                    # Check for nonce_stale error
                    if retry_err.code == 402:
                        try:
                            err_json = json.loads(error_body)
                            if err_json.get("error") == "nonce_stale":
                                logger.info(f"Nonce stale: {err_json.get('message')}.")
                                from .payment import clear_nonce_cache
                                clear_nonce_cache(from_address)
                                raise RuntimeError("Transaction nonce was stale. Please try again.")
                        except json.JSONDecodeError:
                            pass
                    
                    # No retry possible, raise error with payment info
                    logger.http_error(code=retry_err.code, url=url, body=error_body, message="Post-payment retry failed")
                    
                    # Check for common proxy misconfiguration errors
                    error_msg = error_body[:200] if error_body else 'Unknown error'
                    if "cookie auth" in error_body.lower() or "no auth" in error_body.lower():
                        error_msg = "Proxy API key not configured. Check payments-proxy environment variables."
                    
                    # Build payment info so UI can track the spent amount
                    payment_info = {
                        "amount_usd": amount_usd,
                        "stream": used_stream,
                        "tx_hash": "",
                        "explorer_url": "",
                    }
                    raise PaymentError(
                        f"HTTP {retry_err.code} after payment: {error_msg}",
                        payment_info=payment_info
                    )
            else:
                # All retries exhausted
                if last_error:
                    payment_info = {
                        "amount_usd": amount_usd,
                        "stream": used_stream,
                        "tx_hash": "",
                        "explorer_url": "",
                    }
                    raise PaymentError(
                        f"HTTP {last_error[0]} after payment (retries exhausted): {last_error[1][:200]}",
                        payment_info=payment_info
                    )
            
            # Check cancellation after retry request completes
            check_cancelled()
            
            # Extract payment receipt info from response headers
            tx_hash = response.headers.get("X-Payment-TxHash", "")
            tx_explorer_url = f"{explorer_url}/tx/{tx_hash}" if tx_hash and explorer_url else ""
            
            # Mark confirmed with tx hash (only for per-request payments)
            if on_payment_step and not used_stream:
                on_payment_step('confirmed', tx_hash, None)
            
            if stream_enabled:
                # Try streaming - peek at first line to detect SSE format
                result, tokens, cost = try_stream_response(response, on_text_chunk, cancel_event)
            else:
                body_bytes = read_all_interruptible(response, cancel_event)
                resp_data = json.loads(body_bytes)
                result = parse_openai_response(resp_data)
                tokens = resp_data.get('usage', {}).get('total_tokens', 0)
                cost = resp_data.get('usage', {}).get('cost')
                result["usage"] = {"tokens": tokens, "cost": cost}
            
            logger.proxy_response_ok(200, tokens=tokens, cost=cost, tx_hash=tx_hash)
            
            # Track payment info for session totals
            if used_stream:
                # Streaming payment - no tx hash, but track the voucher amount
                result["payment"] = {
                    "tx_hash": "",  # No on-chain tx for vouchers
                    "amount_usd": amount_usd,
                    "explorer_url": "",
                    "stream": True,
                }
            elif tx_hash:
                # Per-request payment with on-chain tx
                result["payment"] = {
                    "tx_hash": tx_hash,
                    "amount_usd": amount_usd,
                    "explorer_url": tx_explorer_url
                }
            
            return result
        else:
            error_body = ""
            try:
                error_body = e.read().decode('utf-8', errors='ignore')[:500]
            except:
                pass
            logger.http_error(code=e.code, url=url, body=error_body, message=f"Proxy API error")
            
            # Parse JSON error if available
            error_msg = ""
            try:
                err_json = json.loads(error_body)
                error_msg = err_json.get("error") or err_json.get("message") or ""
            except:
                pass
            if not error_msg:
                error_msg = error_body[:200] if error_body else "Unknown error"
            
            # Handle specific error codes
            if e.code == 400 and "context length" in error_body.lower():
                raise RuntimeError(
                    "Context length exceeded. Your conversation is too long. "
                    "Start a new chat or use a shorter query."
                )
            elif e.code == 402 and "no funds" in error_body.lower():
                raise RuntimeError(f"Your wallet has insufficient funds. Use /portal to add funds.")
            elif e.code == 500:
                raise RuntimeError(f"Server error (500). The proxy may be down or misconfigured. Check {url}")
            elif e.code == 502 or e.code == 503 or e.code == 504:
                raise RuntimeError(f"Service unavailable ({e.code}). The API may be temporarily down. Try again later.")
            raise RuntimeError(f"HTTP {e.code}: {error_msg}")
    except urllib.error.URLError as e:
        logger.error(f"Connection error: {e.reason}", url=url)
        raise RuntimeError(f"Cannot connect to payments proxy ({url}). Check your internet connection or try again later.")
