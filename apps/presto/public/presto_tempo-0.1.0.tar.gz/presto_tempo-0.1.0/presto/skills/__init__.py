"""Presto skills - loadable capabilities for the AI agent."""
import os

# Local skills in presto package
SKILLS_DIR = os.path.dirname(os.path.abspath(__file__))

# Skills from ai-skills submodule (tempoxyz/ai)
AI_SKILLS_DIR = os.path.join(os.path.dirname(SKILLS_DIR), "..", "ai-skills", "skills")
AI_SKILLS_DIR = os.path.normpath(AI_SKILLS_DIR)


def _get_skill_dirs() -> list[str]:
    """Get all skill directories to search."""
    dirs = [SKILLS_DIR]
    if os.path.isdir(AI_SKILLS_DIR):
        dirs.append(AI_SKILLS_DIR)
    return dirs


def list_skills() -> list[str]:
    """List available skills from all sources."""
    skills = set()
    for skills_dir in _get_skill_dirs():
        if not os.path.isdir(skills_dir):
            continue
        for name in os.listdir(skills_dir):
            skill_path = os.path.join(skills_dir, name)
            if os.path.isdir(skill_path) and os.path.exists(os.path.join(skill_path, "SKILL.md")):
                skills.add(name)
    return sorted(skills)


def get_skill_path(name: str) -> str | None:
    """Get the path to a skill's SKILL.md file."""
    # Check local skills first, then ai-skills submodule
    for skills_dir in _get_skill_dirs():
        skill_md = os.path.join(skills_dir, name, "SKILL.md")
        if os.path.exists(skill_md):
            return skill_md
    return None


def load_skill(name: str) -> str | None:
    """Load a skill's instructions from its SKILL.md file."""
    skill_path = get_skill_path(name)
    if skill_path:
        with open(skill_path) as f:
            return f.read()
    return None
