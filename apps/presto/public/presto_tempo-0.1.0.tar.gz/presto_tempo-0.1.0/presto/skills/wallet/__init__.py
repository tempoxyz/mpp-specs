"""Wallet skill - self-query reference for presto's own wallet, keys, and balances."""
