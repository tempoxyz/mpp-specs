# Wallet Skill - Self-Query Reference

How presto queries information about its own wallet, access keys, and balances.

## Available Tools (Use These First)

| Tool | Use For |
|------|---------|
| `wallet_info()` | Get wallet address + access key address |
| `check_balance()` | Primary token balance (fast, RPC) |
| `wallet_balances()` | All token balances (slower, Index Supply) |
| `access_key_info()` | Spending limits for access key |
| `wallet_transfers()` | Transfer history |
| `wallet_transactions()` | Full tx history |

## Quick Queries

### "What's my address?"
```
wallet_info()
```

### "What's my balance?"
```
check_balance()       # Fast - just primary token
wallet_balances()     # Slower - all tokens
```

### "List my access keys"
```python
from presto._vendor.pytempo import list_access_keys
from presto.rpc import get_web3

w3 = get_web3(rpc_url)
keys = list_access_keys(w3, account_address)
```

### "What are my spending limits?"
```
access_key_info()  # Uses current access key + fee token
access_key_info(key_id="0x...", token="0x...")  # Specific key/token
```

### "Show my recent transfers"
```
wallet_transfers(limit=10)
wallet_transfers(direction="sent")
wallet_transfers(direction="received")
```

## RPC vs Index Supply

| Fast (RPC) | Slow (Index Supply) |
|------------|---------------------|
| `check_balance()` | `wallet_balances()` |
| `access_key_info()` | `wallet_transfers()` |
| Direct `get_token_balance()` | `wallet_transactions()` |
| `list_access_keys()` | `idxs()` queries |

**For self-queries, prefer RPC tools.** They're faster and don't need external indexing.

## Direct RPC (When Tools Aren't Enough)

```python
from presto.rpc import (
    get_token_balance,      # Single token balance
    get_token_balance_raw,  # Raw balance (no decimal division)
    get_token_metadata,     # name, symbol, decimals
    get_tx_count,           # Nonce
    get_2d_nonce,           # Parallel nonce
)
from presto._vendor.pytempo import (
    list_access_keys,              # All keys for account
    get_access_key_info,           # Single key info
    get_remaining_spending_limit,  # Spending limit
)
```

## Context Available

Tools automatically get context via `_tool_context`:
- `account_address` - Wallet address
- `access_key_address` - Current access key
- `fee_token` - Current fee token address
- `fee_token_name` - Fee token symbol
- `rpc_url` - RPC endpoint
- `network` - Network name (mainnet/moderato)
- `known_tokens` - Dict of {SYMBOL: {address, decimals, symbol}}

## Source Files

- Tools: `presto/tools.py`
- RPC helpers: `presto/rpc.py`
- Wallet model: `presto/wallet.py`
- Explorer (Index Supply): `presto/explorer.py`
