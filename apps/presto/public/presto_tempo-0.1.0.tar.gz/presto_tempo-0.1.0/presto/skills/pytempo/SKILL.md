# pytempo - Tempo Python SDK

Quick reference for Tempo blockchain operations in Python.

## Imports

```python
from presto._vendor.pytempo import (
    create_tempo_transaction,
    sign_tx_access_key,
    list_access_keys,
    get_access_key_info,
    get_remaining_spending_limit,
    ACCOUNT_KEYCHAIN_ADDRESS,
)
from presto.rpc import get_web3, get_token_balance, get_tx_count, get_2d_nonce, broadcast_tx, wait_for_receipt
```

## RPC vs Index Supply

| Use RPC (fast) | Use Index Supply (slow) |
|----------------|-------------------------|
| Own balances, nonces | Historical transfers |
| Access keys, spending limits | Cross-account queries |
| Sending transactions | Time-series analytics |

## Common Operations

### Token Balance
```python
from presto.rpc import get_token_balance, get_token_balance_raw
balance = get_token_balance(wallet, token, rpc)  # Returns float
raw = get_token_balance_raw(wallet, token, rpc)  # Returns int (base units)
```

### List Access Keys
```python
from presto._vendor.pytempo import list_access_keys
w3 = get_web3(rpc)
keys = list_access_keys(w3, account_address)
# Returns: [{"key_id", "expiry", "enforce_limits", "is_revoked", "signature_type"}]
```

### Spending Limit
```python
from presto._vendor.pytempo import get_remaining_spending_limit, get_access_key_info

info = get_access_key_info(w3, account, key_id)
if info.get("enforce_limits"):
    limit = get_remaining_spending_limit(w3, account, key_id, token)
else:
    # Unlimited
```

### Create & Sign Transaction
```python
from presto._vendor.pytempo import create_tempo_transaction

tx = create_tempo_transaction(
    to="0x...", value=0, data="0x", gas=100000,
    max_fee_per_gas=2000000000, max_priority_fee_per_gas=1000000000,
    nonce=get_tx_count(wallet, rpc), chain_id=42431,
    fee_token="0x20c0000000000000000000000000000000000001",
)
tx.sign(private_key)
tx_hash = broadcast_tx(tx.encode().hex(), rpc)
```

### Sign with Access Key
```python
from presto._vendor.pytempo import sign_tx_access_key
sign_tx_access_key(tx, access_key_private, root_account)
```

### Batch Calls
```python
tx = create_tempo_transaction(
    to="", calls=[
        {"to": "0x...", "value": 0, "data": "0x..."},
        {"to": "0x...", "value": 0, "data": "0x..."},
    ], ...
)
```

### 2D Nonce (Parallel Txs)
```python
from presto.rpc import get_2d_nonce
nonce = get_2d_nonce(wallet, nonce_key=1, rpc_url=rpc)
tx = create_tempo_transaction(..., nonce=nonce, nonce_key=1)
```

## Constants

```python
ACCOUNT_KEYCHAIN_ADDRESS = "0xaAAAaaAA00000000000000000000000000000000"
NONCE_PRECOMPILE = "0x4E4F4E4345000000000000000000000000000000"
MODERATO_CHAIN_ID = 42431
```

## Source Code

- Transaction: `presto/_vendor/pytempo/transaction.py`
- Keychain: `presto/_vendor/pytempo/keychain.py`
- RPC helpers: `presto/rpc.py`
