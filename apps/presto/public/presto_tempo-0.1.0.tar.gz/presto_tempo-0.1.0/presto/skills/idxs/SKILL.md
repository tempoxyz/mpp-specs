# Index Supply (idxs)

Query blockchain data via Index Supply - live blockchain queries with SQL.

## When to Use

- Query transactions by address
- Find ERC20/ERC721 transfers (requires event signature)
- Query custom events (requires event signature)
- Get historical blockchain data

## Tool

```
idxs query:str signatures?:str
```

### Parameters

- `query` (required): SQL query. MUST include `chain = X` in WHERE clause.
- `signatures` (optional): Semicolon-separated event signatures for event tables (use `;` not `,` because signatures contain commas)

## Important Notes

1. **Always include `chain = X`** in WHERE clause (e.g., `WHERE chain = 1`)
2. **Event tables require signatures** - you must provide the event signature to query events
3. **Use `block_num` predicates** for faster queries on large datasets
4. **Addresses use hex format** without quotes: `0xd8da6bf26964af9d7eed9e03e53415d37aa96045`

## Example Queries

### Get transactions by address
```sql
SELECT block_timestamp::date, hash, "to", substring(input, 1, 4) as "4b"
FROM txs
WHERE chain = 1 AND "from" = 0xd8da6bf26964af9d7eed9e03e53415d37aa96045
LIMIT 10
```

### Get ERC20 token balances (SUM/CASE pattern)
Signatures: `event Transfer(address indexed from, address indexed to, uint256 value)`
```sql
SELECT
    max(block_num) block,
    address token,
    sum(
        case
            when "from" = 0xYOUR_ADDRESS then -value
            when "to" = 0xYOUR_ADDRESS then value
            else 0
        end
    ) balance
FROM transfer
WHERE chain = 1 AND ("to" = 0xYOUR_ADDRESS OR "from" = 0xYOUR_ADDRESS)
GROUP BY token
```

### Get ERC721 current token holders
Signatures: `event Transfer(address indexed from, address indexed to, uint indexed tokenId)`
```sql
SELECT t1."to", t1.tokenId, t1.block_num
FROM transfer t1
LEFT JOIN transfer t2
ON t1.tokenId = t2.tokenId AND t1.block_num < t2.block_num AND t1.address = t2.address
WHERE t1.chain = 1 AND t1.address = 0xCONTRACT_ADDRESS AND t2.tokenId IS NULL
```

## Supported Chains

- 1: Ethereum Mainnet
- 8453: Base
- 10: Optimism  
- 42161: Arbitrum
- 137: Polygon
- Plus: Zora, Scroll, Linea, BNB, Celo, Forma, Tempo Mainnet/Moderato, and more

## Base Tables

- `txs` - Transactions: hash, from, to, value, gas, input, block_num, block_timestamp
- `logs` - Raw event logs

## Event Tables

Created dynamically from signatures. The table name is the lowercase event name.
Example: `event Transfer(...)` creates table `transfer`.

## API

https://indexsupply.net
