"""Index Supply (idxs) - Query blockchain data via Index Supply API."""
import json
import os
import urllib.request
import urllib.error
from typing import Optional


IDXS_API_URL = "https://api.indexsupply.net/v2/query"
IDXS_API_KEY = os.environ.get("IDXS_API_KEY", "")


def query(
    sql: str,
    chain: int = 1,
    signatures: Optional[list[str]] = None,
    cursor: Optional[str] = None,
) -> dict:
    """
    Execute a SQL query against Index Supply.
    
    Args:
        sql: SQL query to execute
        chain: Chain ID (default 1 for Ethereum mainnet)
        signatures: Optional list of event/function signatures for custom tables
        cursor: Optional cursor for pagination
    
    Returns:
        Dict with 'columns', 'rows', and 'cursor' keys
    """
    request_body = {"query": sql}
    
    if signatures:
        request_body["signatures"] = signatures
    
    if cursor:
        request_body["cursor"] = cursor
    
    headers = {"Content-Type": "application/json"}
    if IDXS_API_KEY:
        headers["Api-Key"] = IDXS_API_KEY
    
    data = json.dumps([request_body]).encode('utf-8')
    req = urllib.request.Request(IDXS_API_URL, data=data, headers=headers, method='POST')
    
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            results = json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            error_body = e.read().decode('utf-8')
            error_msg = json.loads(error_body).get("message", error_body)
        except:
            error_msg = str(e)
        raise Exception(f"Index Supply API error ({e.code}): {error_msg}")
    except urllib.error.URLError as e:
        raise Exception(f"Index Supply API error: {e.reason}")
    
    if not results or len(results) == 0:
        return {"columns": [], "rows": [], "cursor": None}
    
    result = results[0]
    return {
        "columns": result.get("columns", []),
        "rows": result.get("rows", result.get("result", [])),
        "cursor": result.get("cursor"),
        "block_height": result.get("block_height"),
    }


# Tool function for Presto
def run_idxs_tool(args: dict) -> str:
    """Run idxs tool with given arguments."""
    sql = args.get("query", "")
    signatures_str = args.get("signatures", "")
    
    if not sql:
        return "Error: query parameter is required"
    
    signatures = None
    if signatures_str:
        # Use semicolon as separator since signatures contain commas
        signatures = [s.strip() for s in signatures_str.split(";") if s.strip()]
    
    try:
        result = query(sql, signatures=signatures)
        
        # Format output
        columns = result.get("columns", [])
        rows = result.get("rows", [])
        
        if not rows:
            return "No results found"
        
        # Extract column names
        col_names = [c.get("name", str(c)) if isinstance(c, dict) else str(c) for c in columns]
        
        # Build table output
        lines = []
        lines.append(f"Columns: {', '.join(col_names)}")
        lines.append(f"Rows: {len(rows)}")
        lines.append("")
        
        # Show first 20 rows
        for i, row in enumerate(rows[:20]):
            row_str = " | ".join(str(v)[:50] for v in row)
            lines.append(f"{i+1}. {row_str}")
        
        if len(rows) > 20:
            lines.append(f"... and {len(rows) - 20} more rows")
        
        if result.get("cursor"):
            lines.append(f"\nCursor: {result['cursor']}")
        
        return "\n".join(lines)
    
    except Exception as e:
        return f"Error: {e}"
