"""Wallet setup via browser or manual key import.

Wallet Model:
- One master wallet (passkey-based, identified by account_address)
- Multiple access keys (one is always active/default)
- Access keys have expiry and optional spending limits
"""
import http.server
import json
import os
import secrets
import subprocess
import time
import webbrowser
from urllib.parse import urlparse, parse_qs
from typing import Optional

from eth_account import Account

from .auth_server import get_auth_server
from .config import DEFAULT_NETWORK, get_auth_url


class AccessKey:
    """Represents a single access key.
    
    Minimal local storage: only private_key, label, and spending_limit are persisted.
    - key_id/public_key: derived from private_key
    - expiry/enforce_limits: fetched from chain via get_access_key_info() when needed
    - token_limits: per-token spending limits fetched from chain
    """
    
    def __init__(self, private_key: str, label: str = "", spending_limit: int = 0,
                 # Legacy params - still accepted but not persisted
                 key_id: str = "", expiry: int = 0, public_key: str = ""):
        self.private_key = private_key
        self.label = label or "Unnamed"
        self.spending_limit = spending_limit
        self._address = None
        self._cached_expiry = expiry  # Cache for chain-fetched expiry
        self._expiry_fetched = expiry > 0  # Track if we have valid expiry
        self._enforce_limits = False  # Whether spending limits are enforced
        self._is_revoked = False  # Whether key has been revoked on-chain
        self._token_limits: dict[str, dict] = {}  # {token_addr: {"remaining": int, "symbol": str, "decimals": int}}
    
    @property
    def address(self) -> str:
        """Derive address from private key (cached)."""
        if self._address is None:
            try:
                account = Account.from_key(self.private_key)
                self._address = account.address
            except Exception:
                self._address = ""
        return self._address
    
    @property
    def key_id(self) -> str:
        """Key ID is the address derived from private key."""
        return self.address
    
    @property
    def expiry(self) -> int:
        """Get cached expiry. Call fetch_from_chain() to update from chain."""
        return self._cached_expiry
    
    @expiry.setter
    def expiry(self, value: int):
        """Set expiry (used when fetching from chain)."""
        self._cached_expiry = value
        self._expiry_fetched = True
    
    @property
    def enforce_limits(self) -> bool:
        """Whether this key has spending limits enforced."""
        return self._enforce_limits
    
    @property
    def token_limits(self) -> dict[str, dict]:
        """Per-token spending limits: {token_addr: {"remaining": int, "symbol": str, "decimals": int}}."""
        return self._token_limits
    
    @property
    def is_revoked(self) -> bool:
        """Whether this key has been revoked on-chain."""
        return self._is_revoked
    
    def get_usable_tokens(self) -> list[dict]:
        """Get tokens this key can spend, sorted by remaining limit descending.
        
        Returns list of dicts with: address, symbol, decimals, remaining
        """
        if not self._enforce_limits:
            # No limits enforced - return all tokens (caller should use wallet balances)
            return []
        
        tokens = []
        for addr, info in self._token_limits.items():
            if info.get("remaining", 0) > 0:
                tokens.append({
                    "address": addr,
                    "symbol": info.get("symbol", ""),
                    "decimals": info.get("decimals", 6),
                    "remaining": info.get("remaining", 0),
                })
        tokens.sort(key=lambda x: -x["remaining"])
        return tokens
    
    def get_token_for_payment(self, amount: int, token_address: str = None) -> Optional[str]:
        """Get a token address that can cover the payment amount.
        
        Args:
            amount: Amount needed in base units
            token_address: If specified, check if this specific token can be used
            
        Returns:
            Token address that can cover the payment, or None if no token works
        """
        if not self._enforce_limits:
            # No limits enforced - any token works (if user has balance)
            return token_address
        
        if token_address:
            # Check specific token
            info = self._token_limits.get(token_address.lower(), {})
            if info.get("remaining", 0) >= amount:
                return token_address
            return None
        
        # Find first token with sufficient remaining limit
        for addr, info in self._token_limits.items():
            if info.get("remaining", 0) >= amount:
                return addr
        return None
    
    def fetch_from_chain(self, account_address: str, rpc_url: str) -> bool:
        """Fetch key info (expiry, revoked status, enforce_limits) from chain.
        
        Returns True if successful.
        """
        from .rpc import get_access_key_info
        info = get_access_key_info(account_address, self.address, rpc_url)
        if info:
            self._cached_expiry = info.get('expiry', 0)
            self._enforce_limits = info.get('enforce_limits', False)
            self._is_revoked = info.get('is_revoked', False)
            self._expiry_fetched = True
            return True
        return False
    
    def fetch_token_limits(self, account_address: str, rpc_url: str, token_balances: list) -> dict[str, dict]:
        """Fetch spending limits for tokens the wallet has balance in.
        
        Args:
            account_address: The root wallet address
            rpc_url: RPC endpoint URL
            token_balances: List of TokenBalance objects (from explorer.get_balances)
            
        Returns:
            Dict of {token_addr: {"remaining": int, "symbol": str, "decimals": int}}
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from .rpc import get_web3
        from presto._vendor.pytempo.keychain import get_remaining_spending_limit
        
        if not self._enforce_limits:
            # No limits enforced - key can spend unlimited
            self._token_limits = {}
            return self._token_limits
        
        w3 = get_web3(rpc_url)
        limits = {}
        
        # Limit to top 5 tokens by balance to avoid slow startup
        top_tokens = sorted(token_balances, key=lambda x: -x.balance)[:5]
        
        def fetch_limit(balance):
            token_addr = balance.token.lower()
            try:
                remaining = get_remaining_spending_limit(
                    w3, account_address, self.address, token_addr
                )
                if remaining > 0:
                    return token_addr, {
                        "remaining": remaining,
                        "symbol": balance.symbol,
                        "decimals": balance.decimals,
                    }
            except Exception:
                pass
            return None, None
        
        # Fetch limits in parallel
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = {executor.submit(fetch_limit, b): b for b in top_tokens}
            for future in as_completed(futures):
                token_addr, info = future.result()
                if token_addr and info:
                    limits[token_addr] = info
        
        self._token_limits = limits
        return limits
    
    @property
    def is_expired(self) -> bool:
        """Check if key is expired."""
        if self._cached_expiry <= 0:
            return False
        return int(time.time()) >= self._cached_expiry
    
    @property
    def expires_soon(self) -> bool:
        """Check if key expires within 1 hour."""
        if self._cached_expiry <= 0 or self.is_expired:
            return False
        return (self._cached_expiry - int(time.time())) < 3600
    
    @property
    def time_remaining(self) -> str:
        """Human-readable time remaining."""
        if self._cached_expiry <= 0:
            return "No expiry"
        remaining = self._cached_expiry - int(time.time())
        if remaining <= 0:
            return "EXPIRED"
        if remaining < 3600:
            return f"{remaining // 60}m"
        if remaining < 86400:
            hours = remaining // 3600
            mins = (remaining % 3600) // 60
            return f"{hours}h {mins}m"
        days = remaining // 86400
        hours = (remaining % 86400) // 3600
        return f"{days}d {hours}h"
    
    def to_dict(self) -> dict:
        """Minimal persistence: only private_key, label, spending_limit."""
        return {
            "private_key": self.private_key,
            "label": self.label,
            "spending_limit": self.spending_limit,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "AccessKey":
        return cls(
            private_key=data.get("private_key", ""),
            label=data.get("label", ""),
            spending_limit=data.get("spending_limit", 0),
            # Legacy fields - accepted for backwards compat but not used
            key_id=data.get("key_id", ""),
            expiry=data.get("expiry", 0),
            public_key=data.get("public_key", ""),
        )


class FeeToken:
    """Represents the user's selected fee token for a network."""
    
    def __init__(self, address: str = "", symbol: str = "", decimals: int = 6, name: str = ""):
        self.address = address.lower() if address else ""
        self.symbol = symbol
        self.decimals = decimals
        self.name = name
    
    def to_dict(self) -> dict:
        return {
            "address": self.address,
            "symbol": self.symbol,
            "decimals": self.decimals,
            "name": self.name,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "FeeToken":
        return cls(
            address=data.get("address", ""),
            symbol=data.get("symbol", ""),
            decimals=data.get("decimals", 6),
            name=data.get("name", ""),
        )
    
    @property
    def is_set(self) -> bool:
        """Check if a fee token has been selected."""
        return bool(self.address)
    
    def __repr__(self) -> str:
        if not self.is_set:
            return "FeeToken(not set)"
        return f"FeeToken({self.symbol or self.address[:10]})"


class NetworkWallet:
    """Wallet configuration for a single network."""
    
    def __init__(self, account_address: str = "", access_keys: list = None, 
                 active_key_index: int = 0, direct_signing: bool = False,
                 fee_token: FeeToken = None, fee_token_match_transfer: bool = False):
        self.account_address = account_address
        self.access_keys: list[AccessKey] = access_keys or []
        self.active_key_index = active_key_index
        self.direct_signing = direct_signing  # If True, sign directly with private key (no access key mode)
        self.fee_token = fee_token or FeeToken()
        self.fee_token_match_transfer = fee_token_match_transfer  # If True, use same token as TIP20 transfer
    
    @property
    def active_key(self) -> Optional[AccessKey]:
        """Get the currently active access key."""
        if not self.access_keys:
            return None
        idx = min(self.active_key_index, len(self.access_keys) - 1)
        return self.access_keys[idx] if idx >= 0 else None
    
    @property
    def has_valid_key(self) -> bool:
        """Check if there's a non-expired active key."""
        key = self.active_key
        return key is not None and not key.is_expired
    
    def add_key(self, key: AccessKey, make_active: bool = True) -> bool:
        """Add a new access key. Returns True if new, False if already exists."""
        for i, existing in enumerate(self.access_keys):
            if existing.address.lower() == key.address.lower():
                self.access_keys[i] = key
                if make_active:
                    self.active_key_index = i
                return False
        self.access_keys.append(key)
        if make_active:
            self.active_key_index = len(self.access_keys) - 1
        return True
    
    def to_dict(self) -> dict:
        result = {
            "account_address": self.account_address,
            "access_keys": [k.to_dict() for k in self.access_keys],
            "active_key_index": self.active_key_index,
        }
        if self.direct_signing:
            result["direct_signing"] = True
        if self.fee_token.is_set:
            result["fee_token"] = self.fee_token.to_dict()
        if self.fee_token_match_transfer:
            result["fee_token_match_transfer"] = True
        return result
    
    @classmethod
    def from_dict(cls, data: dict) -> "NetworkWallet":
        all_keys = [AccessKey.from_dict(k) for k in data.get("access_keys", [])]
        seen_addresses = set()
        access_keys = []
        for key in all_keys:
            addr = key.address.lower()
            if addr not in seen_addresses:
                seen_addresses.add(addr)
                access_keys.append(key)
        active_index = data.get("active_key_index", 0)
        if active_index >= len(access_keys):
            active_index = max(0, len(access_keys) - 1)
        
        # Load fee token if present
        fee_token = None
        if "fee_token" in data:
            fee_token = FeeToken.from_dict(data["fee_token"])
        
        return cls(
            account_address=data.get("account_address", ""),
            access_keys=access_keys,
            active_key_index=active_index,
            direct_signing=data.get("direct_signing", False),
            fee_token=fee_token,
            fee_token_match_transfer=data.get("fee_token_match_transfer", False),
        )


class WalletConfig:
    """Manages wallet configuration across multiple networks."""
    
    def __init__(self, network: str = None, networks: dict = None):
        self.network = network if network is not None else DEFAULT_NETWORK
        self._networks: dict[str, NetworkWallet] = networks or {}
    
    def _current_wallet(self) -> NetworkWallet:
        """Get or create wallet for current network."""
        if self.network not in self._networks:
            self._networks[self.network] = NetworkWallet()
        return self._networks[self.network]
    
    def get_wallet(self, network: str) -> NetworkWallet:
        """Get or create wallet for a specific network."""
        if network not in self._networks:
            self._networks[network] = NetworkWallet()
        return self._networks[network]
    
    @property
    def account_address(self) -> str:
        """Get account address for current network."""
        return self._current_wallet().account_address
    
    @account_address.setter
    def account_address(self, value: str):
        """Set account address for current network."""
        self._current_wallet().account_address = value
    
    @property
    def access_keys(self) -> list:
        """Get access keys for current network."""
        return self._current_wallet().access_keys
    
    @property
    def active_key_index(self) -> int:
        """Get active key index for current network."""
        return self._current_wallet().active_key_index
    
    @active_key_index.setter
    def active_key_index(self, value: int):
        """Set active key index for current network."""
        self._current_wallet().active_key_index = value
    
    @property
    def active_key(self) -> Optional[AccessKey]:
        """Get the currently active access key for current network."""
        return self._current_wallet().active_key
    
    @property
    def has_valid_key(self) -> bool:
        """Check if there's a non-expired active key for current network."""
        return self._current_wallet().has_valid_key
    
    @property
    def direct_signing(self) -> bool:
        """Check if direct signing mode is enabled for current network."""
        return self._current_wallet().direct_signing
    
    @property
    def fee_token(self) -> FeeToken:
        """Get fee token for current network."""
        return self._current_wallet().fee_token
    
    @fee_token.setter
    def fee_token(self, value: FeeToken):
        """Set fee token for current network."""
        self._current_wallet().fee_token = value
    
    @property
    def fee_token_match_transfer(self) -> bool:
        """Check if fee token should match transfer token for TIP20 transfers."""
        return getattr(self._current_wallet(), 'fee_token_match_transfer', False)
    
    @fee_token_match_transfer.setter
    def fee_token_match_transfer(self, value: bool):
        """Set fee token match transfer preference."""
        self._current_wallet().fee_token_match_transfer = value
    
    def set_fee_token(self, address: str, symbol: str = "", decimals: int = 6, name: str = ""):
        """Set fee token for current network from individual values."""
        self._current_wallet().fee_token = FeeToken(address, symbol, decimals, name)
    
    def add_key(self, key: AccessKey, make_active: bool = True):
        """Add a new access key to current network."""
        self._current_wallet().add_key(key, make_active)
    
    def switch_to_key(self, index: int) -> bool:
        """Switch to a different access key by index."""
        wallet = self._current_wallet()
        if 0 <= index < len(wallet.access_keys):
            wallet.active_key_index = index
            return True
        return False
    
    def remove_expired_keys(self) -> int:
        """Remove all expired keys from current network, returns count removed."""
        wallet = self._current_wallet()
        before = len(wallet.access_keys)
        wallet.access_keys = [k for k in wallet.access_keys if not k.is_expired]
        after = len(wallet.access_keys)
        if wallet.active_key_index >= len(wallet.access_keys):
            wallet.active_key_index = max(0, len(wallet.access_keys) - 1)
        return before - after
    
    def refresh_active_key_limits(self, rpc_url: str) -> bool:
        """Fetch chain info and token limits for the active access key.
        
        This queries:
        1. Key info (expiry, enforce_limits) from AccountKeychain precompile
        2. Token spending limits for all tokens in wallet balance
        
        Returns True if successful.
        """
        key = self.active_key
        if not key or not self.account_address:
            return False
        
        # First fetch key info (expiry, enforce_limits)
        if not key.fetch_from_chain(self.account_address, rpc_url):
            return False
        
        # If limits are enforced, fetch per-token spending limits
        if key.enforce_limits:
            from .explorer import get_explorer_client
            from .config import NETWORKS
            
            # Get chain ID for current network
            chain_id = NETWORKS.get(self.network, {}).get("chain_id")
            if not chain_id:
                return True  # Key info fetched, but can't get token limits without chain_id
            
            # Get all token balances for the wallet
            client = get_explorer_client(chain_id, rpc_url=rpc_url)
            balances = client.get_balances(self.account_address)
            
            # Fetch spending limits for each token
            key.fetch_token_limits(self.account_address, rpc_url, balances)
        
        return True
    
    def get_payment_token(self, amount: int, required_token: str = None) -> Optional[str]:
        """Get a token address the active key can use for payment.
        
        Args:
            amount: Amount needed in base units
            required_token: If specified, check if this specific token can be used
            
        Returns:
            Token address that can cover the payment, or None if no token works
        """
        key = self.active_key
        if not key:
            return None
        return key.get_token_for_payment(amount, required_token)
    
    def switch_network(self, network: str):
        """Switch to a different network."""
        self.network = network
    
    def to_dict(self) -> dict:
        """Convert to dict for saving (new multi-network format)."""
        from .config import get_auth_url
        result = {
            "network": self.network,
            "networks": {name: wallet.to_dict() for name, wallet in self._networks.items()},
            "auth_server": get_auth_url(),  # Track which auth server created the keys
        }
        # For backward compatibility, also store current network's active key at top level
        if self.active_key:
            result["account_address"] = self.account_address
            result["access_key_private_key"] = self.active_key.private_key
            result["key_id"] = self.active_key.key_id
        return result
    
    @classmethod
    def from_dict(cls, data: dict) -> "WalletConfig":
        """Load from dict (handles old single-network and new multi-network format)."""
        network = data.get("network", DEFAULT_NETWORK)
        
        # New multi-network format
        if "networks" in data:
            networks = {}
            for net_name, net_data in data["networks"].items():
                networks[net_name] = NetworkWallet.from_dict(net_data)
            return cls(network=network, networks=networks)
        
        # Old format: single network config at top level
        account_address = data.get("account_address", "")
        
        if "access_keys" in data:
            access_keys = [AccessKey.from_dict(k) for k in data["access_keys"]]
            active_idx = data.get("active_key_index", 0)
        elif "access_key_private_key" in data:
            key = AccessKey(
                private_key=data["access_key_private_key"],
                # Legacy fields for backwards compat
                key_id=data.get("key_id", ""),
                expiry=data.get("expiry", 0),
            )
            access_keys = [key]
            active_idx = 0
        else:
            access_keys = []
            active_idx = 0
        
        # Migrate old format to new multi-network format
        wallet = NetworkWallet(
            account_address=account_address,
            access_keys=access_keys,
            active_key_index=active_idx,
        )
        return cls(network=network, networks={network: wallet})


def load_wallet_config() -> Optional[WalletConfig]:
    """Load wallet config from the config file."""
    from .config import load_config
    data = load_config()
    if data:
        return WalletConfig.from_dict(data)
    return None


def setup_wallet_browser(auth_url: str = None, network: str = None, account_address: str = None):
    """Open browser for passkey wallet creation, returns config dict.
    
    If account_address is provided, skips wallet creation and goes directly to access key creation.
    """
    # Use default network if not specified
    if network is None:
        network = DEFAULT_NETWORK
    
    # Determine auth URL: use production URL or start local server for dev
    auth_url = get_auth_url()
    if auth_url.startswith("http://localhost") or auth_url.startswith("http://127.0.0.1"):
        # Local dev mode - start local auth server
        auth_server = get_auth_server()
        try:
            auth_url = auth_server.ensure_running()
        except RuntimeError:
            pass  # Keep the original auth_url
    
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        port = s.getsockname()[1]
    
    received_config = {"done": False, "config": None, "aborted": False}
    state = secrets.token_urlsafe(16)
    
    class AuthHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass
        
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path == "/abort":
                # Only abort if we haven't received a successful config yet
                if not received_config["config"]:
                    received_config["aborted"] = True
                    received_config["done"] = True
                self.send_response(200)
                self.end_headers()
                return
            if parsed.path == "/callback":
                # GET callback for backwards compatibility with older auth pages
                # Note: POST is preferred as it doesn't expose secrets in URL/history
                params = parse_qs(parsed.query)
                
                # Validate state to prevent CSRF
                received_state = params.get("state", [""])[0]
                if received_state != state:
                    from . import logger
                    logger.error(f"State mismatch: expected {state[:8]}..., got {received_state[:8] if received_state else 'none'}...")
                    self.send_response(400)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    html = """<!DOCTYPE html>
<html><head><title>Presto - Error</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#000;color:#fff;font-family:"Space Mono",ui-monospace,monospace}
body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.18;background-image:radial-gradient(circle at 1px 1px,rgba(255,255,255,.22) 1px,transparent 0);background-size:14px 14px}
.container{position:relative;width:min(420px,calc(100vw - 48px));border:2px solid rgba(255,255,255,.85);padding:32px;text-align:center}
h1{font-family:"Instrument Serif",ui-serif,serif;font-weight:400;margin:0 0 8px 0;font-size:24px}
p{margin:0;color:rgba(255,255,255,.78);line-height:1.6;font-size:13px}
.mark{font-size:48px;line-height:1;margin-bottom:16px;color:#ff2e2e}
</style></head>
<body><div class="container"><div class="mark">&#10007;</div><h1>Security Error</h1><p>Invalid state parameter. Please restart wallet setup.</p></div></body></html>"""
                    self.wfile.write(html.encode('utf-8'))
                    return
                
                if "access_key" in params:
                    expiry = params.get("expiry", ["0"])[0]
                    received_config["config"] = {
                        "access_key_private_key": params["access_key"][0],
                        "account_address": params.get("account_address", [""])[0],
                        "key_id": params.get("key_id", [""])[0],
                        "expiry": int(expiry) if expiry else 0,
                    }
                    received_config["done"] = True
                    
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    html = """<!DOCTYPE html>
<html><head><title>Presto - Connected</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#000;color:#fff;font-family:"Space Mono",ui-monospace,monospace}
body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.18;background-image:radial-gradient(circle at 1px 1px,rgba(255,255,255,.22) 1px,transparent 0);background-size:14px 14px}
.container{position:relative;width:min(420px,calc(100vw - 48px));border:2px solid rgba(255,255,255,.85);padding:32px;text-align:center}
h1{font-family:"Instrument Serif",ui-serif,serif;font-weight:400;margin:0 0 8px 0;font-size:24px}
p{margin:0;color:rgba(255,255,255,.78);line-height:1.6;font-size:13px}
.mark{font-size:48px;line-height:1;margin-bottom:16px;color:#00ff6a}
</style></head>
<body><div class="container"><div class="mark">&#10003;</div><h1>Wallet Connected!</h1><p>Return to your terminal.</p></div>
<script>try{window.close()}catch(e){}</script></body></html>"""
                    self.wfile.write(html.encode('utf-8'))
                else:
                    self.send_error(400, "Missing access_key")
                return
            self.send_error(404)
        
        def do_POST(self):
            if self.path == "/abort":
                # Only abort if we haven't received a successful config yet
                if not received_config["config"]:
                    received_config["aborted"] = True
                    received_config["done"] = True
                self.send_response(200)
                self.end_headers()
                return
            if self.path == "/faucet":
                # Proxy faucet request through CLI with auth credentials
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                try:
                    data = json.loads(body)
                    address = data.get("address", "")
                    
                    # Get RPC URL with credentials from config
                    from .config import NETWORKS
                    net_config = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
                    rpc_url = net_config["rpc"]
                    
                    # Make RPC call with credentials using subprocess (handles auth in URL)
                    req_body = json.dumps({
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "tempo_fundAddress",
                        "params": [address],
                    })
                    
                    curl_result = subprocess.run(
                        ["curl", "-s", "-X", "POST", rpc_url,
                         "-H", "Content-Type: application/json",
                         "-d", req_body],
                        capture_output=True, text=True, timeout=30
                    )
                    result = json.loads(curl_result.stdout)
                    
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps(result).encode('utf-8'))
                except Exception as e:
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": {"message": str(e)}}).encode('utf-8'))
                return
            if self.path == "/balance":
                # Proxy balance check through CLI with auth credentials
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                try:
                    data = json.loads(body)
                    address = data.get("address", "")
                    token = data.get("token", "")
                    
                    # Get RPC URL with credentials from config
                    from .config import NETWORKS
                    from .rpc import get_token_balance_raw
                    net_config = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
                    rpc_url = net_config["rpc"]
                    
                    balance = get_token_balance_raw(address, token, rpc_url)
                    
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps({"balance": balance}).encode('utf-8'))
                except Exception as e:
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": {"message": str(e)}}).encode('utf-8'))
                return
            if self.path == "/callback":
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                content_type = self.headers.get('Content-Type', '')
                
                try:
                    # Handle both form-urlencoded (from form POST navigation) and JSON
                    if 'application/x-www-form-urlencoded' in content_type:
                        from urllib.parse import parse_qs
                        parsed = parse_qs(body)
                        data = {k: v[0] for k, v in parsed.items()}
                    else:
                        data = json.loads(body) if body else {}
                    
                    # Validate state to prevent CSRF
                    received_state = data.get("state", "")
                    if received_state != state:
                        from . import logger
                        logger.error(f"State mismatch: expected {state[:8]}..., got {received_state[:8] if received_state else 'none'}...")
                        self.send_response(400)
                        self.send_header("Content-Type", "text/html; charset=utf-8")
                        self.end_headers()
                        html = """<!DOCTYPE html>
<html><head><title>Presto - Error</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#000;color:#fff;font-family:"Space Mono",ui-monospace,monospace}
body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.18;background-image:radial-gradient(circle at 1px 1px,rgba(255,255,255,.22) 1px,transparent 0);background-size:14px 14px}
.container{position:relative;width:min(420px,calc(100vw - 48px));border:2px solid rgba(255,255,255,.85);padding:32px;text-align:center}
h1{font-family:"Instrument Serif",ui-serif,serif;font-weight:400;margin:0 0 8px 0;font-size:24px}
p{margin:0;color:rgba(255,255,255,.78);line-height:1.6;font-size:13px}
.mark{font-size:48px;line-height:1;margin-bottom:16px;color:#ff2e2e}
</style></head>
<body><div class="container"><div class="mark">&#10007;</div><h1>Security Error</h1><p>Invalid state parameter. Please restart wallet setup.</p></div></body></html>"""
                        self.wfile.write(html.encode('utf-8'))
                        return
                    
                    from . import logger
                    logger.info(f"Callback received: account_address={data.get('account_address')}, key_id={data.get('key_id')}, has_access_key={bool(data.get('access_key'))}")
                    
                    expiry_val = data.get("expiry", 0)
                    received_config["config"] = {
                        "access_key_private_key": data.get("access_key"),
                        "account_address": data.get("account_address", ""),
                        "key_id": data.get("key_id", ""),
                        "expiry": int(expiry_val) if expiry_val else 0,
                    }
                    received_config["done"] = True
                    
                    # Return HTML success page (this is a form navigation, not XHR)
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    html = """<!DOCTYPE html>
<html><head><title>Presto - Connected</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#000;color:#fff;font-family:"Space Mono",ui-monospace,monospace}
body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.18;background-image:radial-gradient(circle at 1px 1px,rgba(255,255,255,.22) 1px,transparent 0);background-size:14px 14px}
.container{position:relative;width:min(420px,calc(100vw - 48px));border:2px solid rgba(255,255,255,.85);padding:32px;text-align:center}
h1{font-family:"Instrument Serif",ui-serif,serif;font-weight:400;margin:0 0 8px 0;font-size:24px}
p{margin:0;color:rgba(255,255,255,.78);line-height:1.6;font-size:13px}
.mark{font-size:48px;line-height:1;margin-bottom:16px;color:#00ff6a}
</style></head>
<body><div class="container"><div class="mark">&#10003;</div><h1>Wallet Connected!</h1><p>Return to your terminal.</p></div>
<script>try{window.close()}catch(e){}</script></body></html>"""
                    self.wfile.write(html.encode('utf-8'))
                except Exception as e:
                    from . import logger
                    logger.error(f"Callback error: {e}")
                    self.send_error(400)
            else:
                self.send_error(404)
        
        def do_OPTIONS(self):
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
    
    server = http.server.HTTPServer(("127.0.0.1", port), AuthHandler)
    server.timeout = 5  # Short timeout so we can check for abort
    
    callback_url = f"http://127.0.0.1:{port}/callback"
    # Determine flow type: 'setup' for first-time, 'newkey' for adding key to existing wallet
    flow = "newkey" if account_address else "setup"
    full_auth_url = f"{auth_url}?callback={callback_url}&state={state}&network={network}&flow={flow}"
    
    # If account_address is provided, pass it to skip wallet creation step
    if account_address:
        full_auth_url += f"&account={account_address}"
    
    # Open browser silently using subprocess to avoid terminal disruption
    import platform
    import time
    if platform.system() == "Darwin":
        subprocess.Popen(
            ["open", full_auth_url],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL
        )
    else:
        import sys
        import io
        old_stdout, old_stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = io.StringIO(), io.StringIO()
        try:
            webbrowser.open(full_auth_url)
        finally:
            sys.stdout, sys.stderr = old_stdout, old_stderr
    
    # Wait for callback with 5 minute total timeout
    start_time = time.time()
    max_wait = 300  # 5 minutes
    
    while not received_config["done"]:
        if time.time() - start_time > max_wait:
            server.server_close()
            return None
        try:
            server.handle_request()
        except Exception:
            pass
    
    server.server_close()
    
    # Return None if user closed browser window (aborted)
    if received_config["aborted"]:
        return None
    
    return received_config["config"]


def setup_wallet_manual():
    """Prompt user to enter private key manually."""
    print(f"\n\033[1mImport Private Key\033[0m\n")
    
    private_key = input(f"\033[34mEnter your private key (0x...): \033[0m").strip()
    if not private_key.startswith("0x"):
        private_key = "0x" + private_key
    
    try:
        account = Account.from_key(private_key)
        address = account.address
    except Exception:
        print(f"\033[31mError: Invalid private key format\033[0m")
        return None
    
    return {
        "access_key_private_key": private_key,
        "account_address": address,
    }
