#!/usr/bin/env python3
"""Presto entry point - minimal AI coding agent with Tempo payment authentication."""
import os
import sys
from curses import wrapper

from .config import CONFIG_FILE, RESET, BOLD, DIM, GREEN, CYAN, MODEL, AVAILABLE_MODELS
from .ui import PrestoUI

VERSION = "0.1.0"


def is_frozen() -> bool:
    """Check if running as a frozen binary (PyInstaller, etc.)."""
    return getattr(sys, "frozen", False)


def is_dev_checkout() -> bool:
    """Check if running from a dev checkout with submodules."""
    repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # Check for ai-payments submodule
    proxy_path = os.path.join(repo_root, "ai-payments", "apps", "payments-proxy")
    return os.path.isdir(proxy_path)

HELP_TEXT = f"""{BOLD}presto{RESET} - Pay-per-token AI coding agent

{BOLD}DESCRIPTION{RESET}
  Presto is a minimal AI coding agent that pays for LLM API calls with crypto
  via Tempo's payments-proxy. No API keys required - just connect a wallet
  and start coding.

{BOLD}USAGE{RESET}
  presto [options]

{BOLD}OPTIONS{RESET}
  {GREEN}-h, --help{RESET}      Show this help message
  {GREEN}-v, --version{RESET}   Show version number
  {GREEN}-f, --fresh{RESET}     Start fresh conversation (keeps wallet)
  {GREEN}-r, --reset{RESET}     Delete wallet config and start fresh
  {GREEN}-H, --headless{RESET}  Run in headless mode (no TUI)
  
  {GREEN}--auth-server URL{RESET}    Override auth server URL
  {GREEN}--proxy-server URL{RESET}   Override payments proxy URL
  {GREEN}--provider NAME{RESET}      Provider for localhost (default: openrouter)

{BOLD}COMMANDS{RESET} (dev only - run from source checkout)
  {GREEN}presto dev{RESET}      Run with local proxy + auth server
  {GREEN}presto test{RESET}     Run e2e tests

{BOLD}IN-APP COMMANDS{RESET}
  {CYAN}/help{RESET}           Show help and keyboard shortcuts
  {CYAN}/model{RESET}          Select AI model
  {CYAN}/newkey{RESET}         Connect wallet / create access key
  {CYAN}/wallet{RESET}         Show wallet info dialog
  {CYAN}/wallet limits{RESET}    Show spending limits
  {CYAN}/portal{RESET}         Open web portal
  {CYAN}/skills{RESET}         List available skills
  {CYAN}/skill <name>{RESET}   Load a skill
  {CYAN}/network{RESET}        Show network info
  {CYAN}/clear{RESET}          Clear conversation
  {CYAN}/quit{RESET}           Exit presto

{BOLD}KEYBOARD SHORTCUTS{RESET}
  {DIM}↑/↓{RESET}             Scroll output
  {DIM}Ctrl+P{RESET}          Open command palette
  {DIM}Ctrl+U{RESET}          Clear input line
  {DIM}Ctrl+A/E{RESET}        Jump to start/end of line
  {DIM}Ctrl+C/D{RESET}        Exit

{BOLD}MODELS{RESET}
  Default: {MODEL}
  Available: {', '.join(name for _, name in AVAILABLE_MODELS)}

{BOLD}TOOLS{RESET}
  Presto has access to: read, write, edit, glob, grep, bash, check_balance,
  wallet_info, connect_wallet, idxs (blockchain queries)

{BOLD}ENVIRONMENT{RESET}
  PRESTO_PROXY_URL   Payments proxy URL (default: https://openrouter.payments.tempo.xyz)
  PRESTO_PROVIDER    Provider for localhost Host header (default: openrouter)
  OPENROUTER_API_KEY Use OpenRouter directly (bypasses payments-proxy)
  MODEL              Default model (default: anthropic/claude-sonnet-4)
  PRESTO_LOG_LEVEL   Log level (default: DEBUG)

{BOLD}FILES{RESET}
  ~/.config/presto/config.json   Wallet & settings (production)
  ~/.presto.json                 Wallet configuration (legacy)
  ~/.cache/presto/presto.log     Debug logs

{BOLD}EXAMPLES{RESET}
  {DIM}# Start presto{RESET}
  $ presto

  {DIM}# Start with fresh conversation{RESET}
  $ presto --fresh

  {DIM}# Reset wallet config{RESET}
  $ presto --reset

{BOLD}MORE INFO{RESET}
  https://github.com/tempoxyz/presto
"""


def main(stdscr, fresh=False):
    ui = PrestoUI(stdscr, fresh=fresh)
    ui.run()


def start_local_payments_proxy():
    """Start local payments-proxy if not already running."""
    import subprocess
    import socket
    import time
    
    # Check if already running on port 8787
    def is_running():
        try:
            with socket.create_connection(("localhost", 8787), timeout=1):
                return True
        except (socket.error, socket.timeout):
            return False
    
    if is_running():
        print(f"{DIM}Local payments-proxy already running on :8787{RESET}")
        return True
    
    # Try to start it
    proxy_dir = os.path.join(os.path.dirname(__file__), "..", "ai-payments", "apps", "payments-proxy")
    if not os.path.exists(proxy_dir):
        print(f"{DIM}payments-proxy not found at {proxy_dir}{RESET}")
        print(f"{DIM}Clone ai-payments submodule or run from presto repo{RESET}")
        return False
    
    print(f"{DIM}Starting local payments-proxy...{RESET}")
    try:
        # Start in background
        subprocess.Popen(
            ["pnpm", "dev"],
            cwd=proxy_dir,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
        
        # Wait for it to start
        for _ in range(30):  # Wait up to 15 seconds
            time.sleep(0.5)
            if is_running():
                print(f"{GREEN}✓ Local payments-proxy started on :8787{RESET}")
                return True
        
        print(f"{DIM}Timeout waiting for payments-proxy to start{RESET}")
        return False
    except Exception as e:
        print(f"{DIM}Failed to start payments-proxy: {e}{RESET}")
        return False


def run_tests(args):
    """Run presto e2e tests with optional local services."""
    import subprocess
    
    # Block in frozen binary
    if is_frozen():
        print(f"{BOLD}presto test{RESET} is a developer command.")
        print(f"Clone the repo to run tests: https://github.com/tempoxyz/presto")
        sys.exit(1)
    
    use_local_proxy = False
    use_dev_auth = False
    pytest_args = []
    test_type = "e2e"  # default
    
    while args:
        arg = args[0]
        if arg in ("--local-proxy", "-l"):
            use_local_proxy = True
            args = args[1:]
        elif arg in ("--dev-auth", "-d"):
            use_dev_auth = True
            args = args[1:]
        elif arg in ("--live",):
            test_type = "live"
            args = args[1:]
        elif arg in ("--all", "-a"):
            test_type = "all"
            args = args[1:]
        elif arg in ("--help", "-h"):
            print(f"""{BOLD}presto test{RESET} - Run presto e2e tests

{BOLD}USAGE{RESET}
  presto test [options]

{BOLD}OPTIONS{RESET}
  {GREEN}--local-proxy, -l{RESET}   Start local payments-proxy
  {GREEN}--dev-auth, -d{RESET}      Use local auth server
  {GREEN}--live{RESET}              Run live blockchain tests
  {GREEN}--all, -a{RESET}           Run all tests (e2e + live)
  
{BOLD}EXAMPLES{RESET}
  presto test                    # Run e2e tests
  presto test --local-proxy      # Run with local proxy
  presto test --live -l          # Run live tests with local proxy
""")
            sys.exit(0)
        else:
            pytest_args.append(arg)
            args = args[1:]
    
    env = os.environ.copy()
    env["PRESTO_LIVE_TESTS"] = "1"
    env["SKIP_FAUCET"] = "1"
    
    # Start local proxy if requested (fail if can't start)
    if use_local_proxy:
        if not is_dev_checkout():
            print(f"{BOLD}Error:{RESET} --local-proxy requires ai-payments submodule")
            print(f"Run: git submodule update --init")
            sys.exit(1)
        if not start_local_payments_proxy():
            print(f"{BOLD}Error:{RESET} Could not start local payments-proxy")
            sys.exit(1)
        env["PRESTO_PROXY_URL"] = "http://localhost:8787/openrouter"
    
    if use_dev_auth:
        env["PRESTO_AUTH_URL"] = "http://localhost:8000"
    
    # Build pytest command
    markers = {"e2e": "e2e", "live": "live", "all": "e2e or live"}[test_type]
    cmd = [
        sys.executable, "-m", "pytest",
        "-m", markers,
        "tests/e2e/",
        "-v", "--tb=short",
        *pytest_args
    ]
    
    print(f"{BOLD}Running {test_type} tests...{RESET}")
    if use_local_proxy:
        print(f"{DIM}  Proxy: http://localhost:8787/openrouter{RESET}")
    
    result = subprocess.run(cmd, env=env)
    sys.exit(result.returncode)


def run_dev(args):
    """Run presto in dev mode with local services."""
    # Block in frozen binary
    if is_frozen():
        print(f"{BOLD}presto dev{RESET} is a developer command.")
        print(f"Clone the repo to run in dev mode: https://github.com/tempoxyz/presto")
        sys.exit(1)
    
    if not is_dev_checkout():
        print(f"{BOLD}Error:{RESET} presto dev requires ai-payments submodule")
        print(f"Run: git submodule update --init")
        sys.exit(1)
    
    headless_mode = False
    headless_args = []
    fresh = False
    
    # Parse args
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in ("--headless", "-H"):
            headless_mode = True
            i += 1
        elif arg in ("--fresh", "-f"):
            fresh = True
            i += 1
        elif arg in ("--help", "-h"):
            print(f"""{BOLD}presto dev{RESET} - Run presto with local services

{BOLD}USAGE{RESET}
  presto dev [options]

{BOLD}OPTIONS{RESET}
  {GREEN}--headless, -H{RESET}   Run in headless mode
  {GREEN}--fresh, -f{RESET}      Start fresh conversation
  
{BOLD}DESCRIPTION{RESET}
  Starts local payments-proxy and auth server, then runs presto.
  Equivalent to: --local-proxy --dev-auth
  
{BOLD}EXAMPLES{RESET}
  presto dev                         # Dev mode TUI
  presto dev --headless "query"      # Dev mode headless
""")
            sys.exit(0)
        else:
            headless_args.append(arg)
            i += 1
    
    # Start local services
    print(f"{BOLD}Starting dev environment...{RESET}")
    
    if not start_local_payments_proxy():
        print(f"{BOLD}Error:{RESET} Could not start local payments-proxy")
        sys.exit(1)
    
    os.environ["PRESTO_PROXY_URL"] = "http://localhost:8787/openrouter"
    os.environ["PRESTO_AUTH_URL"] = "http://localhost:8000"
    
    print(f"{GREEN}✓ Dev mode ready{RESET}")
    print(f"{DIM}  Proxy: http://localhost:8787/openrouter{RESET}")
    print(f"{DIM}  Auth:  http://localhost:8000{RESET}")
    print()
    
    if headless_mode:
        from .headless import main as headless_main
        sys.argv = ["presto", *headless_args]
        headless_main()
    else:
        wrapper(lambda stdscr: main(stdscr, fresh=fresh))


def cli():
    fresh = False
    args = sys.argv[1:]
    use_local_proxy = False
    
    # Check for subcommands first
    if args and args[0] == "test":
        run_tests(args[1:])
        return
    if args and args[0] == "dev":
        run_dev(args[1:])
        return
    
    # Process all flags
    while args:
        arg = args[0]
        if arg in ("--reset", "--delete", "-r"):
            if os.path.exists(CONFIG_FILE):
                os.remove(CONFIG_FILE)
                print(f"{GREEN}✓ Deleted {CONFIG_FILE}{RESET}")
            else:
                print(f"{DIM}No config file found{RESET}")
            sys.exit(0)
        elif arg in ("--version", "-v"):
            print(f"presto {VERSION}")
            sys.exit(0)
        elif arg in ("--fresh", "-f"):
            fresh = True
            args = args[1:]
        elif arg == "--auth-server" and len(args) > 1:
            os.environ["PRESTO_AUTH_URL"] = args[1]
            args = args[2:]
        elif arg == "--proxy-server" and len(args) > 1:
            os.environ["PRESTO_PROXY_URL"] = args[1]
            args = args[2:]
        elif arg == "--provider" and len(args) > 1:
            os.environ["PRESTO_PROVIDER"] = args[1]
            args = args[2:]
        elif arg in ("--dev-auth",):
            # Use local auth server (serves auth/index.html locally)
            os.environ["PRESTO_AUTH_URL"] = "http://localhost:8000"
            args = args[1:]
        elif arg in ("--dev", "-d"):
            # Legacy: same as --dev-auth
            os.environ["PRESTO_AUTH_URL"] = "http://localhost:8000"
            args = args[1:]
        elif arg in ("--local-proxy",):
            use_local_proxy = True
            args = args[1:]
        elif arg in ("--help", "-h"):
            print(HELP_TEXT)
            sys.exit(0)
        elif arg in ("--headless", "-H"):
            from .headless import main as headless_main
            sys.argv = args[1:]  # Remove --headless from args
            headless_main()
            sys.exit(0)
        else:
            break
    
    # Start local payments-proxy if requested
    if use_local_proxy:
        if start_local_payments_proxy():
            os.environ["PRESTO_PROXY_URL"] = "http://localhost:8787/openrouter"
        else:
            print(f"{DIM}Continuing with production proxy...{RESET}")
    
    try:
        wrapper(lambda stdscr: main(stdscr, fresh=fresh))
    except KeyboardInterrupt:
        pass
    print(f"\n{GREEN}Thanks for using Presto. Goodbye!{RESET}\n")


if __name__ == "__main__":
    cli()
