"""Auto-starting auth server for browser wallet flows."""
import os
import subprocess
import sys
import time


class AuthServerManager:
    """Manages the local auth server for browser wallet flows."""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._process = None
        self._port = 8000
        self._auth_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "auth")
    
    def _is_server_responding(self, port: int) -> bool:
        """Check if server is responding on port."""
        import urllib.request
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{port}/", method='HEAD')
            with urllib.request.urlopen(req, timeout=1) as resp:
                return resp.status == 200
        except Exception:
            return False
    
    def ensure_running(self) -> str:
        """Ensure auth server is running, start if needed. Returns the URL."""
        auth_url = os.environ.get("PRESTO_AUTH_URL", f"http://localhost:{self._port}")
        
        # If pointing to external URL (not localhost), don't manage it
        if "localhost" not in auth_url and "127.0.0.1" not in auth_url:
            return auth_url
        
        # Extract port from URL
        try:
            from urllib.parse import urlparse
            parsed = urlparse(auth_url)
            self._port = parsed.port or 8000
        except Exception:
            self._port = 8000
        
        # Check if already responding
        if self._is_server_responding(self._port):
            return auth_url
        
        # Kill any existing process we started
        self.stop()
        
        # Start new server process
        self._process = subprocess.Popen(
            [sys.executable, "-m", "http.server", str(self._port), "-b", "127.0.0.1"],
            cwd=self._auth_dir,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        
        # Wait for it to be ready
        for _ in range(30):  # 3 second timeout
            if self._is_server_responding(self._port):
                return auth_url
            time.sleep(0.1)
        
        # Failed to start
        self.stop()
        raise RuntimeError(f"Failed to start auth server on port {self._port}")
    
    def stop(self):
        """Stop the auth server if running."""
        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=2)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass
            self._process = None


# Singleton accessor
def get_auth_server() -> AuthServerManager:
    """Get the auth server manager singleton."""
    return AuthServerManager()
