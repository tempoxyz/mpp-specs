# Demo 402 Payment API

A simple API that implements the IETF Payment HTTP Authentication Scheme for testing presto.

## Quick Start

```bash
# Start the server
python server.py

# In another terminal, test it
curl http://localhost:8402/api/hello
# Returns 402 with WWW-Authenticate header

curl http://localhost:8402/info
# Returns API info (free)
```

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8402` | Server port |
| `TEMPO_RPC_URL` | Presto RPC | Tempo RPC endpoint |
| `ASSET` | `0x20c0...0000` | TIP-20 asset address (AlphaUSD) |
| `DESTINATION` | `0x...0001` | Payment recipient address |
| `PRICE_CENTS` | `1` | Price in cents per request |

## Endpoints

### Free
- `GET /` - Health check
- `GET /info` - API configuration

### Paid (require 402 payment)
- `GET /api/hello` - Hello message
- `GET /api/fortune` - Random fortune
- `GET /api/time` - Current time
- `GET /api/*` - Any other path

## 402 Flow

1. Client requests protected endpoint
2. Server returns `402 Payment Required` with `WWW-Authenticate: Payment ...`
3. Client parses challenge, signs Tempo transaction
4. Client retries with `Authorization: Payment <credential>`
5. Server verifies and broadcasts transaction
6. Server returns response with `Payment-Receipt` header

## Testing with Presto

```bash
# Set the demo API as proxy
export PRESTO_PROXY_URL=http://localhost:8402

# Run presto (it will pay for API calls)
presto
```
