"""Shared RPC utilities for Presto.

This module contains common RPC operations used by both the TUI and headless modes.
"""
import json
import subprocess
from typing import Optional

from . import logger


def get_token_balance(address: str, token_address: str, rpc_url: str, decimals: int = 6) -> float:
    """Fetch ERC20 token balance for an address.
    
    Args:
        address: The wallet address to check
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
        decimals: Token decimals (default 6 for USDC-style tokens)
    
    Returns:
        Balance as a float (already divided by 10^decimals)
    """
    if not address or not token_address or not rpc_url:
        return 0.0
    
    try:
        # Build balanceOf call data: 0x70a08231 + padded address
        addr_no_prefix = address[2:].lower() if address.startswith("0x") else address.lower()
        call_data = f"0x70a08231000000000000000000000000{addr_no_prefix}"
        
        req_body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "eth_call",
            "params": [{"to": token_address, "data": call_data}, "latest"],
        })
        
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", rpc_url,
             "-H", "Content-Type: application/json",
             "-d", req_body],
            capture_output=True, text=True, timeout=10
        )
        
        if result.returncode == 0:
            response = json.loads(result.stdout)
            if "result" in response and response["result"]:
                balance_wei = int(response["result"], 16)
                return balance_wei / (10 ** decimals)
    except Exception as e:
        logger.error(f"RPC balance check error: {e}")
    
    return 0.0


def get_token_balance_raw(address: str, token_address: str, rpc_url: str) -> int:
    """Fetch raw ERC20 token balance (in wei/smallest unit).
    
    Args:
        address: The wallet address to check
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
    
    Returns:
        Raw balance as integer
    """
    if not address or not token_address or not rpc_url:
        return 0
    
    try:
        addr_no_prefix = address[2:].lower() if address.startswith("0x") else address.lower()
        call_data = f"0x70a08231000000000000000000000000{addr_no_prefix}"
        
        req_body = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "eth_call",
            "params": [{"to": token_address, "data": call_data}, "latest"],
        })
        
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", rpc_url,
             "-H", "Content-Type: application/json",
             "-d", req_body],
            capture_output=True, text=True, timeout=10
        )
        
        if result.returncode == 0:
            response = json.loads(result.stdout)
            if "result" in response and response["result"]:
                return int(response["result"], 16)
    except Exception as e:
        logger.error(f"RPC balance check error: {e}")
    
    return 0


def format_balance(balance: float, token_name: str = "tokens") -> str:
    """Format a balance for display.
    
    Args:
        balance: The numeric balance
        token_name: Token name/symbol to append
    
    Returns:
        Formatted string like "$10.50 mUSDC"
    """
    return f"${balance:.2f} {token_name}"


def get_formatted_balance(address: str, token_address: str, rpc_url: str, 
                          token_name: str = "tokens", decimals: int = 6) -> str:
    """Fetch and format token balance in one call.
    
    Args:
        address: The wallet address to check
        token_address: The token contract address
        rpc_url: The RPC endpoint URL
        token_name: Token name for display
        decimals: Token decimals
    
    Returns:
        Formatted string like "$10.50 mUSDC"
    """
    balance = get_token_balance(address, token_address, rpc_url, decimals)
    return format_balance(balance, token_name)
