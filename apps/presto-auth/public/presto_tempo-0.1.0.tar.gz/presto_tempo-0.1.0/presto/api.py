"""API client for OpenRouter (direct or via payments-proxy)."""
import json
import urllib.request
import urllib.error
import os
import socket
import threading

from . import config
from . import logger
from .payment import parse_www_authenticate, handle_402_payment
from .tools import make_schema

# Cache for model info (context lengths, etc.)
_model_info_cache = {}

# Read timeout for cooperative cancellation (seconds)
# Short enough to check cancellation frequently, long enough to not spam
_READ_CHUNK_TIMEOUT = 0.3

# Connection timeout - long enough for real connections, but not forever
_CONNECT_TIMEOUT = 30


def urlopen_interruptible(request, cancel_event, timeout_s=_CONNECT_TIMEOUT):
    """Open URL, checking cancel_event before connecting.
    
    Uses a reasonable timeout for the connection. Only sets short read timeouts
    when cancel_event is provided (for responsive cancellation during streaming).
    
    NOTE: We don't retry on timeout because retrying HTTP requests can cause
    duplicate submissions (especially problematic for payment flows).
    """
    if cancel_event and cancel_event.is_set():
        raise StreamCancelled("Cancelled before connect")
    
    # Use the timeout for connection - if it times out, that's a real error
    response = urllib.request.urlopen(request, timeout=timeout_s)
    
    # Only set short read timeout when we need responsive cancellation
    # Setting ultra-short timeouts without cancel_event causes "timed out object" errors
    if cancel_event is not None:
        try:
            if hasattr(response, 'fp') and hasattr(response.fp, 'raw'):
                response.fp.raw._sock.settimeout(_READ_CHUNK_TIMEOUT)
            elif hasattr(response, 'fp') and hasattr(response.fp, '_sock'):
                response.fp._sock.settimeout(_READ_CHUNK_TIMEOUT)
        except (AttributeError, OSError):
            pass  # Best effort - if we can't set it, reads may block longer
    
    return response


def iter_lines_interruptible(response, cancel_event, timeout_s=_READ_CHUNK_TIMEOUT):
    """Yield lines from response, checking cancel_event between reads.
    
    Uses short read timeouts to allow frequent cancellation checks.
    """
    while True:
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Cancelled during stream")
        try:
            line = response.readline()
        except socket.timeout:
            continue
        except TimeoutError:
            continue
        if not line:
            break
        yield line


def read_all_interruptible(response, cancel_event, timeout_s=_READ_CHUNK_TIMEOUT, chunk_size=8192):
    """Read entire response body in chunks, checking cancel_event between reads.
    
    Returns the complete body as bytes.
    """
    parts = []
    while True:
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Cancelled while reading body")
        try:
            chunk = response.read(chunk_size)
        except socket.timeout:
            continue
        except TimeoutError:
            continue
        if not chunk:
            break
        parts.append(chunk)
    return b"".join(parts)


def get_model_context_length(model_id: str) -> int:
    """Get the context length for a model from OpenRouter API."""
    global _model_info_cache
    
    # Return cached value if available
    if model_id in _model_info_cache:
        return _model_info_cache[model_id].get("context_length", 128000)
    
    # Default context lengths for common models
    defaults = {
        "anthropic/claude-sonnet-4": 200000,
        "anthropic/claude-opus-4": 200000,
        "anthropic/claude-3.5-sonnet": 200000,
        "anthropic/claude-3-opus": 200000,
        "openai/gpt-4o": 128000,
        "openai/gpt-4o-mini": 128000,
        "openai/gpt-4-turbo": 128000,
        "google/gemini-2.0-flash-001": 1000000,
        "google/gemini-pro-1.5": 1000000,
        "meta-llama/llama-3.1-405b-instruct": 131072,
    }
    
    if model_id in defaults:
        _model_info_cache[model_id] = {"context_length": defaults[model_id]}
        return defaults[model_id]
    
    # Try to fetch from OpenRouter API
    try:
        url = "https://openrouter.ai/api/v1/models"
        request = urllib.request.Request(url)
        request.add_header("User-Agent", "presto/1.0")
        response = urllib.request.urlopen(request, timeout=5)
        data = json.loads(response.read())
        
        for model in data.get("data", []):
            mid = model.get("id", "")
            ctx = model.get("context_length", 128000)
            _model_info_cache[mid] = {"context_length": ctx}
        
        if model_id in _model_info_cache:
            return _model_info_cache[model_id]["context_length"]
    except Exception:
        pass
    
    # Default fallback
    return 128000


def parse_sse_line(line: str) -> dict:
    """Parse a Server-Sent Events line."""
    if line.startswith("data: "):
        data = line[6:]
        if data.strip() == "[DONE]":
            return {"done": True}
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return {}
    return {}


class StreamCancelled(Exception):
    """Raised when streaming is cancelled by the user."""
    pass


def read_stream_response(response, on_text_chunk=None, cancel_event=None):
    """Read a streaming SSE response and accumulate the result.
    
    Args:
        response: HTTP response object
        on_text_chunk: callback(chunk) -> bool, return False to cancel
        cancel_event: threading.Event, if set, stream is cancelled
    
    If on_text_chunk returns False, the stream is cancelled.
    """
    full_text = ""
    tool_calls = {}  # id -> {id, name, arguments}
    usage = {"tokens": 0, "prompt_tokens": 0, "completion_tokens": 0, "cost": None}
    
    for line in response:
        # Check cancellation event before processing each line
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Stream cancelled by cancel_event")
        
        line = line.decode('utf-8', errors='ignore').strip()
        if not line:
            continue
        
        chunk = parse_sse_line(line)
        if chunk.get("done"):
            break
        
        if "usage" in chunk:
            usage["tokens"] = chunk["usage"].get("total_tokens", 0)
            usage["prompt_tokens"] = chunk["usage"].get("prompt_tokens", 0)
            usage["completion_tokens"] = chunk["usage"].get("completion_tokens", 0)
            usage["cost"] = chunk["usage"].get("cost")
        
        choices = chunk.get("choices", [])
        if not choices:
            continue
        
        delta = choices[0].get("delta", {})
        
        # Handle text content
        if "content" in delta and delta["content"]:
            text_chunk = delta["content"]
            full_text += text_chunk
            if on_text_chunk:
                # If callback returns False, cancel the stream
                result = on_text_chunk(text_chunk)
                if result is False:
                    raise StreamCancelled("Stream cancelled by user")
        
        # Handle tool calls
        if "tool_calls" in delta:
            for tc in delta["tool_calls"]:
                idx = tc.get("index", 0)
                if idx not in tool_calls:
                    tool_calls[idx] = {"id": "", "name": "", "arguments": ""}
                if "id" in tc:
                    tool_calls[idx]["id"] = tc["id"]
                if "function" in tc:
                    if "name" in tc["function"]:
                        tool_calls[idx]["name"] = tc["function"]["name"]
                    if "arguments" in tc["function"]:
                        tool_calls[idx]["arguments"] += tc["function"]["arguments"]
    
    # Build final result
    content = []
    if full_text:
        content.append({"type": "text", "text": full_text})
    
    for idx in sorted(tool_calls.keys()):
        tc = tool_calls[idx]
        try:
            args = json.loads(tc["arguments"]) if tc["arguments"] else {}
        except json.JSONDecodeError:
            args = {}
        content.append({
            "type": "tool_use",
            "id": tc["id"],
            "name": tc["name"],
            "input": args
        })
    
    return {"content": content, "usage": usage}


def looks_like_sse(line: bytes) -> bool:
    """Check if a line looks like SSE format."""
    s = line.decode('utf-8', errors='ignore').strip()
    return s.startswith('data:') or s.startswith(':') or s == ''


def try_stream_response(response, on_text_chunk=None, cancel_event=None):
    """Try to read response as SSE stream, fall back to JSON if not SSE.
    
    Args:
        response: HTTP response object
        on_text_chunk: callback(chunk) -> bool, return False to cancel
        cancel_event: threading.Event, if set, stream is cancelled
    
    Returns (result, tokens, cost) tuple.
    """
    # Check cancellation before starting
    if cancel_event and cancel_event.is_set():
        raise StreamCancelled("Cancelled before reading response")
    
    # Read first line to detect format (with timeout handling)
    first_line = None
    while first_line is None:
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Cancelled while reading first line")
        try:
            first_line = response.readline()
        except (socket.timeout, TimeoutError):
            continue
    
    if looks_like_sse(first_line):
        # It's SSE - create iterator that includes first line, using interruptible reads
        def line_iter():
            yield first_line
            for line in iter_lines_interruptible(response, cancel_event):
                yield line
        
        result = read_stream_response(line_iter(), on_text_chunk, cancel_event)
        tokens = result["usage"].get("tokens", 0)
        cost = result["usage"].get("cost")
        return result, tokens, cost
    else:
        # Not SSE - read rest with interruptible chunked reads
        rest = read_all_interruptible(response, cancel_event)
        full_body = first_line + rest
        resp_data = json.loads(full_body)
        result = parse_openai_response(resp_data)
        usage_data = resp_data.get('usage', {})
        tokens = usage_data.get('total_tokens', 0)
        cost = usage_data.get('cost')
        result["usage"] = {"tokens": tokens, "cost": cost}
        return result, tokens, cost


def parse_openai_response(resp: dict) -> dict:
    """Parse OpenAI/OpenRouter response into our internal format."""
    content = []
    choice = resp.get("choices", [{}])[0]
    message = choice.get("message", {})
    
    # Log the finish reason for debugging
    finish_reason = choice.get("finish_reason", "unknown")
    logger.info(f"Response finish_reason: {finish_reason}")
    
    if message.get("content"):
        content.append({"type": "text", "text": message["content"]})
    
    tool_calls = message.get("tool_calls", [])
    if tool_calls:
        logger.info(f"Model requested {len(tool_calls)} tool call(s)")
    
    for tc in tool_calls:
        try:
            content.append({
                "type": "tool_use",
                "id": tc["id"],
                "name": tc["function"]["name"],
                "input": json.loads(tc["function"]["arguments"])
            })
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse tool arguments: {e}")
            content.append({
                "type": "tool_use",
                "id": tc["id"],
                "name": tc["function"]["name"],
                "input": {}
            })
    
    return {"content": content}


def call_api(messages: list, system_prompt: str, private_key: str, from_address: str, 
             rpc_url: str = None, chain_id: int = 1088, on_payment=None, on_status=None, 
             on_confirm=None, model: str = None, explorer_url: str = None,
             on_text_chunk=None, on_payment_step=None, use_direct_signing: bool = False,
             cancel_event: threading.Event = None) -> dict:
    """
    Call OpenRouter API (directly if OPENROUTER_API_KEY set, otherwise via payments-proxy).
    
    Args:
        messages: Conversation history
        system_prompt: System prompt for the model
        private_key: Private key for signing payments
        from_address: Wallet address for payments
        rpc_url: RPC endpoint for blockchain
        chain_id: Chain ID for transactions
        on_payment: callback(amount_usd) called when payment is required
        on_status: callback(message) called for status updates
        on_confirm: callback(amount_usd) -> bool, called to confirm payment
        model: Model to use
        explorer_url: Block explorer URL
        on_text_chunk: callback(chunk) for streaming text
        on_payment_step: callback(step, status) called during payment processing
        use_direct_signing: If True, sign directly with private key (for simple EOA wallets)
        cancel_event: threading.Event, if set, cancels the request
    
    Raises:
        StreamCancelled: If cancel_event is set during the request
    """
    def check_cancelled():
        """Check if request has been cancelled, raise if so."""
        if cancel_event and cancel_event.is_set():
            raise StreamCancelled("Request cancelled")
    # Always use payments-proxy for crypto payments (default behavior)
    # Only use direct OpenRouter if explicitly requested via PRESTO_USE_DIRECT_API=1
    import os
    use_direct = os.environ.get("PRESTO_USE_DIRECT_API") == "1"
    url = config.OPENROUTER_URL if use_direct else f"{config.get_proxy_url()}/v1/chat/completions"
    
    chat_messages = [{"role": "system", "content": system_prompt}]
    for msg in messages:
        if msg["role"] == "user":
            if isinstance(msg["content"], str):
                chat_messages.append({"role": "user", "content": msg["content"]})
            elif isinstance(msg["content"], list):
                for item in msg["content"]:
                    if item.get("type") == "tool_result":
                        chat_messages.append({
                            "role": "tool",
                            "tool_call_id": item["tool_use_id"],
                            "content": item["content"]
                        })
        elif msg["role"] == "assistant":
            if isinstance(msg["content"], str):
                chat_messages.append({"role": "assistant", "content": msg["content"]})
            elif isinstance(msg["content"], list):
                text_parts = []
                tool_calls = []
                for block in msg["content"]:
                    if block["type"] == "text":
                        text_parts.append(block["text"])
                    elif block["type"] == "tool_use":
                        tool_calls.append({
                            "id": block["id"],
                            "type": "function",
                            "function": {
                                "name": block["name"],
                                "arguments": json.dumps(block["input"])
                            }
                        })
                assistant_msg = {"role": "assistant"}
                if text_parts:
                    assistant_msg["content"] = "\n".join(text_parts)
                if tool_calls:
                    assistant_msg["tool_calls"] = tool_calls
                chat_messages.append(assistant_msg)
    
    openai_tools = [{
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t["description"],
            "parameters": t["input_schema"]
        }
    } for t in make_schema()]
    
    selected_model = model or config.MODEL
    stream_enabled = on_text_chunk is not None
    body_dict = {
        "model": selected_model,
        "max_tokens": 8192,
        "messages": chat_messages,
        "tools": openai_tools,
        "tool_choice": "auto",
        "stream": stream_enabled,
    }
    
    # Request usage stats in streaming responses
    if stream_enabled:
        body_dict["stream_options"] = {"include_usage": True}
    body = json.dumps(body_dict).encode()
    
    logger.api_call(selected_model, len(chat_messages), has_tools=bool(openai_tools), url=url, body=body_dict)
    
    headers = {"Content-Type": "application/json"}
    
    # Add anthropic-version header when using Anthropic proxy
    if "anthropic" in url.lower():
        headers["anthropic-version"] = "2023-06-01"
    
    # SSE-friendly headers to ensure proxies don't buffer the stream
    if stream_enabled:
        headers["Accept"] = "text/event-stream"
        headers["Cache-Control"] = "no-cache"
        headers["Accept-Encoding"] = "identity"  # Disable compression for streaming
    if use_direct:
        headers["Authorization"] = f"Bearer {config.OPENROUTER_API_KEY}"
    request = urllib.request.Request(url, data=body, headers=headers)
    
    if use_direct:
        try:
            response = urllib.request.urlopen(request)
            resp_data = json.loads(response.read())
            result = parse_openai_response(resp_data)
            tool_calls = sum(1 for b in result.get('content', []) if b.get('type') == 'tool_use')
            tokens = resp_data.get('usage', {}).get('total_tokens', 0)
            logger.api_response("ok", tokens=tokens, tool_calls=tool_calls, raw_response=resp_data)
            return result
        except urllib.error.HTTPError as e:
            error_body = ""
            try:
                error_body = e.read().decode('utf-8', errors='ignore')[:500]
            except:
                pass
            logger.http_error(code=e.code, url=url, body=error_body, message=f"Direct API error")
            if e.code == 402:
                raise RuntimeError("OpenRouter requires credits. Add funds at https://openrouter.ai/credits")
            raise
        except urllib.error.URLError as e:
            logger.error(f"Connection error: {e.reason}", url=url)
            raise RuntimeError(f"Cannot connect to OpenRouter API ({url}). Check your internet connection.")
    
    # Check cancellation before making request
    check_cancelled()
    
    try:
        response = urlopen_interruptible(request, cancel_event)
        
        # Check cancellation after connection established
        check_cancelled()
        
        if stream_enabled:
            # Try streaming - peek at first line to detect SSE format
            result, tokens, cost = try_stream_response(response, on_text_chunk, cancel_event)
        else:
            body_bytes = read_all_interruptible(response, cancel_event)
            resp_data = json.loads(body_bytes)
            result = parse_openai_response(resp_data)
            usage_data = resp_data.get('usage', {})
            tokens = usage_data.get('total_tokens', 0)
            prompt_tokens = usage_data.get('prompt_tokens', 0)
            completion_tokens = usage_data.get('completion_tokens', 0)
            cost = usage_data.get('cost')
            result["usage"] = {"tokens": tokens, "prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens, "cost": cost}
        logger.proxy_response_ok(200, tokens=tokens, cost=cost)
        return result
    except urllib.error.HTTPError as e:
        if e.code == 402:
            # Check cancellation before starting payment flow
            check_cancelled()
            
            www_auth = e.headers.get("WWW-Authenticate", "")
            if not www_auth:
                logger.error("402 without WWW-Authenticate header")
                raise RuntimeError("402 without WWW-Authenticate header")
            
            challenge = parse_www_authenticate(www_auth)
            challenge_id = challenge.get("id", "unknown")
            amount_usd = float(challenge["request"]["amount"]) / 1_000_000
            logger.proxy_response_402(amount_usd=amount_usd, challenge_id=challenge_id)
            
            if on_payment:
                on_payment(amount_usd)
            
            if not private_key:
                raise RuntimeError("402 Payment Required - no wallet configured")
            
            # Ask for confirmation if callback provided
            if on_confirm:
                confirmed = on_confirm(amount_usd)
                if not confirmed:
                    raise RuntimeError("Payment declined by user")
            
            # Check cancellation after confirmation (user may have typed new message)
            check_cancelled()
            
            auth_header = handle_402_payment(challenge, private_key, from_address, rpc_url, chain_id, on_step=on_payment_step, use_direct_signing=use_direct_signing)
            
            # Check cancellation after signing (subprocess calls can take time)
            check_cancelled()
            
            # Mark sending as done, waiting for confirmation
            if on_payment_step:
                on_payment_step('sending', 'done')
                on_payment_step('confirming', 'pending')
            
            headers["Authorization"] = auth_header
            request = urllib.request.Request(url, data=body, headers=headers)
            
            # Retry loop for expired challenge IDs
            max_challenge_retries = 2
            for challenge_retry in range(max_challenge_retries + 1):
                try:
                    response = urlopen_interruptible(request, cancel_event)
                    break  # Success
                except urllib.error.HTTPError as retry_err:
                    error_body = ""
                    try:
                        error_body = retry_err.read().decode('utf-8', errors='ignore')[:500]
                    except:
                        pass
                    
                    # Check for rate limit - wait and retry
                    if retry_err.code == 500 and "rate limit" in error_body.lower() and challenge_retry < max_challenge_retries:
                        import re
                        import time as time_mod
                        # Extract wait time from message like "try again in 24ms"
                        match = re.search(r'try again in (\d+)ms', error_body)
                        wait_ms = int(match.group(1)) if match else 100
                        logger.info(f"Rate limited, waiting {wait_ms}ms (retry {challenge_retry + 1})")
                        time_mod.sleep(wait_ms / 1000.0 + 0.05)  # Add 50ms buffer
                        continue
                    
                    # Check for expired challenge ID - get new challenge, reuse signed tx
                    if retry_err.code in (401, 402) and challenge_retry < max_challenge_retries:
                        try:
                            err_json = json.loads(error_body)
                            err_msg = err_json.get("message", "")
                            if "expired" in err_msg.lower() or "unknown" in err_msg.lower():
                                logger.info(f"Challenge expired, getting fresh challenge (retry {challenge_retry + 1})")
                                
                                # Get new challenge by making request without auth
                                fresh_request = urllib.request.Request(url, data=body, headers={
                                    k: v for k, v in headers.items() if k != "Authorization"
                                })
                                try:
                                    urllib.request.urlopen(fresh_request, timeout=30)
                                except urllib.error.HTTPError as fresh_err:
                                    if fresh_err.code == 402:
                                        www_auth = fresh_err.headers.get("WWW-Authenticate", "")
                                        if www_auth:
                                            new_challenge = parse_www_authenticate(www_auth)
                                            # Extract signed tx from old auth header
                                            old_cred = json.loads(auth_header.replace("Payment ", "").replace("-", "+").replace("_", "/") + "==")
                                            # Rebuild credential with new challenge ID, same signed tx
                                            from .payment import format_authorization
                                            new_cred = {
                                                "id": new_challenge["id"],
                                                "source": old_cred["source"],
                                                "payload": old_cred["payload"]
                                            }
                                            auth_header = format_authorization(new_cred)
                                            headers["Authorization"] = auth_header
                                            request = urllib.request.Request(url, data=body, headers=headers)
                                            continue  # Retry with new challenge
                        except (json.JSONDecodeError, KeyError, Exception) as e:
                            logger.error(f"Failed to refresh challenge: {e}")
                    
                    # Check for nonce_stale error (402) - means our tx nonce was outdated
                    if retry_err.code == 402:
                        try:
                            err_json = json.loads(error_body)
                            if err_json.get("error") == "nonce_stale":
                                logger.info(f"Nonce stale: {err_json.get('message')}. Client should retry.")
                                from .payment import clear_nonce_cache
                                clear_nonce_cache(from_address)
                                raise RuntimeError("Transaction nonce was stale (cancelled request still pending). Please try again.")
                        except json.JSONDecodeError:
                            pass
                    
                    logger.http_error(code=retry_err.code, url=url, body=error_body, message="Post-payment retry failed")
                    raise RuntimeError(f"HTTP {retry_err.code} after payment: {error_body[:200] if error_body else 'Unknown error'}")
            
            # Check cancellation after retry request completes
            check_cancelled()
            
            # Extract payment receipt info from response headers
            tx_hash = response.headers.get("X-Payment-TxHash", "")
            tx_explorer_url = f"{explorer_url}/tx/{tx_hash}" if tx_hash and explorer_url else ""
            
            # Mark confirmed with tx hash
            if on_payment_step:
                on_payment_step('confirmed', tx_hash)
            
            if stream_enabled:
                # Try streaming - peek at first line to detect SSE format
                result, tokens, cost = try_stream_response(response, on_text_chunk, cancel_event)
            else:
                body_bytes = read_all_interruptible(response, cancel_event)
                resp_data = json.loads(body_bytes)
                result = parse_openai_response(resp_data)
                tokens = resp_data.get('usage', {}).get('total_tokens', 0)
                cost = resp_data.get('usage', {}).get('cost')
                result["usage"] = {"tokens": tokens, "cost": cost}
            
            logger.proxy_response_ok(200, tokens=tokens, cost=cost, tx_hash=tx_hash)
            
            if tx_hash:
                result["payment"] = {
                    "tx_hash": tx_hash,
                    "amount_usd": amount_usd,
                    "explorer_url": tx_explorer_url
                }
            
            return result
        else:
            error_body = ""
            try:
                error_body = e.read().decode('utf-8', errors='ignore')[:500]
            except:
                pass
            logger.http_error(code=e.code, url=url, body=error_body, message=f"Proxy API error")
            
            # Parse JSON error if available
            error_msg = ""
            try:
                err_json = json.loads(error_body)
                error_msg = err_json.get("error") or err_json.get("message") or ""
            except:
                pass
            if not error_msg:
                error_msg = error_body[:200] if error_body else "Unknown error"
            
            # Handle specific error codes
            if e.code == 402 and "no funds" in error_body.lower():
                raise RuntimeError(f"Your wallet has insufficient funds. Use /portal to add funds.")
            elif e.code == 500:
                raise RuntimeError(f"Server error (500). The proxy may be down or misconfigured. Check {url}")
            elif e.code == 502 or e.code == 503 or e.code == 504:
                raise RuntimeError(f"Service unavailable ({e.code}). The API may be temporarily down. Try again later.")
            raise RuntimeError(f"HTTP {e.code}: {error_msg}")
    except urllib.error.URLError as e:
        logger.error(f"Connection error: {e.reason}", url=url)
        raise RuntimeError(f"Cannot connect to payments proxy ({url}). Check your internet connection or try again later.")
