#!/usr/bin/env python3
"""Headless mode for presto - run queries without TUI.

This module provides programmatic access to Presto's core functionality
for testing, automation, and integration purposes.
"""
import json
import sys
import os
import time

from .api import call_api
from .config import CONFIG_FILE, NETWORKS, MODEL, DEFAULT_NETWORK
from .rpc import get_token_balance, format_balance
from .tools import run_tool, make_schema, set_tool_context
from .wallet import WalletConfig
from .links import address_link
from . import logger


class PrestoSession:
    """Stateful session for headless Presto operations.
    
    Mirrors the key functionality of PrestoUI for testing:
    - Wallet/account info (like navbar)
    - Balance checking
    - Chat with message history
    - Session stats (cost, tokens, tx count)
    """
    
    def __init__(self, network: str = "moderato", auto_confirm: bool = True, verbose: bool = False):
        self.network = network
        self.auto_confirm = auto_confirm
        self.verbose = verbose
        self.wallet: WalletConfig = None
        self.messages = []
        
        # Session stats (like PrestoUI)
        self.session_cost = 0.0
        self.session_tokens = 0
        self.session_tx_count = 0
        
        # Cached data
        self._cached_balance = None
        self._last_balance_check = 0
        
        # Load wallet
        self._load_wallet()
    
    def _load_wallet(self):
        """Load wallet config from file."""
        if not os.path.exists(CONFIG_FILE):
            return
        with open(CONFIG_FILE) as f:
            data = json.load(f)
        self.wallet = WalletConfig.from_dict(data)
    
    @property
    def network_info(self) -> dict:
        """Get current network configuration."""
        return NETWORKS.get(self.network, NETWORKS[DEFAULT_NETWORK])
    
    @property
    def account_address(self) -> str:
        """Get the main wallet address (like navbar display)."""
        if not self.wallet:
            return ""
        return self.wallet.account_address or ""
    
    @property
    def access_key_address(self) -> str:
        """Get the access key address."""
        if not self.wallet or not self.wallet.active_key:
            return ""
        return self.wallet.active_key.address or ""
    
    @property
    def access_key_expires(self) -> int:
        """Get access key expiry timestamp."""
        if not self.wallet or not self.wallet.active_key:
            return 0
        return self.wallet.active_key.expiry
    
    @property
    def access_key_is_expired(self) -> bool:
        """Check if access key is expired."""
        if not self.wallet or not self.wallet.active_key:
            return True
        return self.wallet.active_key.is_expired
    
    @property
    def access_key_time_remaining(self) -> str:
        """Get human-readable time remaining (like navbar)."""
        if not self.wallet or not self.wallet.active_key:
            return "no key"
        if self.wallet.active_key.is_expired:
            return "EXPIRED"
        return self.wallet.active_key.time_remaining
    
    @property
    def is_configured(self) -> bool:
        """Check if wallet is fully configured and ready."""
        return (
            self.wallet is not None
            and self.wallet.account_address
            and self.wallet.active_key is not None
            and not self.wallet.active_key.is_expired
        )
    
    def get_balance(self, force_refresh: bool = False) -> str:
        """Get wallet balance (like navbar display).
        
        Returns formatted string like "$10.50 mUSDC" or "$0.00 mUSDC".
        """
        now = time.time()
        fee_token_name = self.network_info.get("fee_token_name", "tokens")
        
        # Return cached if fresh (within 30 seconds)
        if not force_refresh and self._cached_balance and (now - self._last_balance_check) < 30:
            return self._cached_balance
        
        if not self.account_address:
            return format_balance(0.0, fee_token_name)
        
        balance = get_token_balance(
            self.account_address,
            self.network_info.get("fee_token", ""),
            self.network_info.get("rpc", ""),
            decimals=6
        )
        self._cached_balance = format_balance(balance, fee_token_name)
        self._last_balance_check = now
        
        return self._cached_balance
    
    def get_balance_numeric(self, force_refresh: bool = False) -> float:
        """Get wallet balance as a numeric value."""
        balance_str = self.get_balance(force_refresh)
        try:
            # Parse "$10.50 mUSDC" -> 10.50
            return float(balance_str.split()[0].replace("$", ""))
        except:
            return 0.0
    
    def get_account_info(self) -> dict:
        """Get full account info (like navbar would show).
        
        Returns dict with all wallet/account details.
        """
        return {
            "account_address": self.account_address,
            "access_key_address": self.access_key_address,
            "access_key_expires": self.access_key_expires,
            "access_key_is_expired": self.access_key_is_expired,
            "access_key_time_remaining": self.access_key_time_remaining,
            "balance": self.get_balance(),
            "balance_numeric": self.get_balance_numeric(),
            "network": self.network,
            "network_name": self.network_info.get("name", self.network),
            "rpc_url": self.network_info.get("rpc", ""),
            "chain_id": self.network_info.get("chain_id", 0),
            "explorer_url": self.network_info.get("explorer", ""),
            "is_configured": self.is_configured,
            "direct_signing": self.wallet.direct_signing if self.wallet else False,
        }
    
    def get_session_stats(self) -> dict:
        """Get session statistics (like /usage would show)."""
        return {
            "cost": self.session_cost,
            "tokens": self.session_tokens,
            "tx_count": self.session_tx_count,
            "messages": len(self.messages),
        }
    
    def chat(self, query: str, max_turns: int = 10) -> dict:
        """Send a message and get a response (like typing in the TUI).
        
        Args:
            query: The user message
            max_turns: Maximum tool use iterations
            
        Returns:
            dict with 'response', 'tool_calls', 'payment', 'usage'
        """
        if not self.is_configured:
            raise RuntimeError("Wallet not configured. Run presto interactively first.")
        
        private_key = self.wallet.active_key.private_key
        account_address = self.wallet.account_address
        direct_signing = self.wallet.direct_signing
        rpc_url = self.network_info["rpc"]
        chain_id = self.network_info["chain_id"]
        explorer_url = self.network_info["explorer"]
        
        # Set tool context
        set_tool_context({
            'account_address': account_address,
            'access_key_address': self.wallet.active_key.address,
            'rpc_url': rpc_url,
            'fee_token': self.network_info.get('fee_token', ''),
            'fee_token_name': self.network_info.get('fee_token_name', 'tokens'),
        })
        
        self.messages.append({"role": "user", "content": query})
        system_prompt = get_system_prompt(cwd=os.getcwd(), rpc_url=rpc_url)
        
        result = {
            'response': '',
            'tool_calls': [],
            'payment': None,
            'usage': {'tokens': 0, 'cost': 0.0},
            'turns': 0
        }
        
        def on_payment(amount_usd):
            if self.verbose:
                print(f"[payment] ${amount_usd:.6f}", file=sys.stderr)
        
        def on_status(msg):
            if self.verbose:
                print(f"[status] {msg}", file=sys.stderr)
        
        def on_confirm(amount_usd):
            if self.auto_confirm:
                if self.verbose:
                    print(f"[confirm] Auto-confirming ${amount_usd:.6f}", file=sys.stderr)
                return True
            return False
        
        for turn in range(max_turns):
            result['turns'] = turn + 1
            
            if self.verbose:
                print(f"[turn {turn + 1}] Calling API...", file=sys.stderr)
            
            response = call_api(
                self.messages, system_prompt,
                private_key, account_address,
                rpc_url, chain_id,
                on_payment, on_status, on_confirm,
                explorer_url=explorer_url,
                use_direct_signing=direct_signing
            )
            
            # Track usage
            if "usage" in response:
                usage = response["usage"]
                tokens = usage.get("tokens", 0)
                self.session_tokens += tokens
                result['usage']['tokens'] += tokens
                if usage.get("cost"):
                    result['usage']['cost'] += float(usage["cost"])
            
            if response.get("payment"):
                result['payment'] = response["payment"]
                self.session_cost += response["payment"].get("amount_usd", 0)
                self.session_tx_count += 1
                # Invalidate balance cache after payment
                self._cached_balance = None
                self._last_balance_check = 0
            
            content_blocks = response.get("content", [])
            
            # Collect text and tool uses
            text_parts = []
            tool_uses = []
            
            for block in content_blocks:
                if block["type"] == "text":
                    text_parts.append(block["text"])
                elif block["type"] == "tool_use":
                    tool_uses.append(block)
            
            # If no tool uses, we're done
            if not tool_uses:
                result['response'] = "\n".join(text_parts)
                self.messages.append({"role": "assistant", "content": content_blocks})
                break
            
            # Add assistant message with tool uses
            self.messages.append({"role": "assistant", "content": content_blocks})
            
            # Execute tools
            tool_results = []
            for tool in tool_uses:
                tool_name = tool["name"]
                tool_args = tool["input"]
                
                if self.verbose:
                    print(f"[tool] {tool_name}({list(tool_args.keys())})", file=sys.stderr)
                
                result['tool_calls'].append({
                    'name': tool_name,
                    'args': tool_args
                })
                
                tool_result = run_tool(tool_name, tool_args)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tool["id"],
                    "content": tool_result
                })
                
                if self.verbose:
                    preview = tool_result[:100] + "..." if len(tool_result) > 100 else tool_result
                    print(f"[result] {preview}", file=sys.stderr)
            
            # Add tool results
            self.messages.append({"role": "user", "content": tool_results})
        
        return result
    
    def clear_history(self):
        """Clear message history (like /clear in TUI)."""
        self.messages = []
    
    def reset_session_stats(self):
        """Reset session statistics."""
        self.session_cost = 0.0
        self.session_tokens = 0
        self.session_tx_count = 0


def load_wallet():
    """Load wallet config from file."""
    if not os.path.exists(CONFIG_FILE):
        return None
    with open(CONFIG_FILE) as f:
        data = json.load(f)
    return WalletConfig.from_dict(data)


def get_system_prompt(cwd: str = None, rpc_url: str = None):
    """System prompt for headless mode."""
    cwd = cwd or os.getcwd()
    if rpc_url is None:
        rpc_url = NETWORKS[DEFAULT_NETWORK]["rpc"]
    
    return f"""You are Presto, an AI coding agent. You help with software engineering tasks.

# How to Work
- Use tools to understand and modify code
- Be concise and direct
- Complete tasks without asking for confirmation
- Verify your work when possible

# Environment
- Working directory: {cwd}
- RPC: {rpc_url}

# Tools
- glob: Find files by pattern
- grep: Search for text in files  
- read: Read file contents
- edit: Make changes to files (old_str → new_str)
- write: Create or overwrite files
- bash: Run shell commands

IMPORTANT: Use tools to get real data. Never guess."""


def run_query(query: str, network: str = "moderato", max_turns: int = 10, 
              verbose: bool = False, auto_confirm: bool = True) -> dict:
    """
    Run a single query through presto headless.
    
    This is a convenience function that creates a PrestoSession and runs a single query.
    For multiple queries or session state tracking, use PrestoSession directly.
    
    Args:
        query: The user query to process
        network: Network to use (mainnet, moderato)
        max_turns: Maximum tool use iterations
        verbose: Print progress to stderr
        auto_confirm: Auto-confirm payments (for testing)
    
    Returns:
        dict with 'response' (final text), 'tool_calls' (list), 'payment' (if any), 'turns', 'usage'
    """
    session = PrestoSession(network=network, auto_confirm=auto_confirm, verbose=verbose)
    return session.chat(query, max_turns=max_turns)


# =============================================================================
# Convenience functions for quick checks (useful for testing/scripts)
# =============================================================================

def get_account_info(network: str = "moderato") -> dict:
    """Quick function to get account info without creating a session.
    
    Example:
        info = get_account_info()
        print(f"Wallet: {info['account_address']}")
        print(f"Balance: {info['balance']}")
    """
    session = PrestoSession(network=network)
    return session.get_account_info()


def get_balance(network: str = "moderato", force_refresh: bool = True) -> str:
    """Quick function to get wallet balance.
    
    Example:
        balance = get_balance()
        print(balance)  # "$10.50 mUSDC"
    """
    session = PrestoSession(network=network)
    return session.get_balance(force_refresh=force_refresh)


def check_wallet_ready(network: str = "moderato") -> tuple[bool, str]:
    """Check if wallet is configured and ready for use.
    
    Returns:
        (is_ready, message) - message explains what's wrong if not ready
    """
    session = PrestoSession(network=network)
    
    if not session.wallet:
        return False, "No wallet configured. Run presto interactively first."
    
    if not session.account_address:
        return False, "No account address configured."
    
    if not session.wallet.active_key:
        return False, "No access key configured. Run /newkey in presto."
    
    if session.access_key_is_expired:
        return False, f"Access key expired. Run /newkey in presto to create a new one."
    
    return True, f"Ready. Key expires in {session.access_key_time_remaining}"


def main():
    """CLI entry point for headless mode."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Presto headless mode - run queries or check status without TUI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  presto-headless "What files are in this directory?"
  presto-headless --account              # Show account info
  presto-headless --balance              # Show balance
  presto-headless --check                # Check if wallet is ready
  echo "List files" | presto-headless    # Read from stdin
  presto-headless --json "Hello"         # JSON output
"""
    )
    parser.add_argument("query", nargs="?", help="Query to run (or use stdin)")
    parser.add_argument("-n", "--network", default="moderato", help="Network (mainnet, moderato)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    parser.add_argument("--max-turns", type=int, default=10, help="Max tool iterations")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    # New convenience commands
    parser.add_argument("--account", action="store_true", help="Show account info (like navbar)")
    parser.add_argument("--balance", action="store_true", help="Show wallet balance")
    parser.add_argument("--check", action="store_true", help="Check if wallet is configured and ready")
    
    args = parser.parse_args()
    
    # Handle convenience commands
    if args.account:
        try:
            info = get_account_info(network=args.network)
            if args.json:
                print(json.dumps(info, indent=2))
            else:
                acct = info['account_address']
                key = info['access_key_address']
                network = info.get('network', DEFAULT_NETWORK)
                print(f"Account:     {address_link(acct, network) if acct else '(not configured)'}")
                print(f"Access Key:  {address_link(key, network) if key else '(none)'}")
                print(f"Key Status:  {info['access_key_time_remaining']}")
                print(f"Balance:     {info['balance']}")
                print(f"Network:     {info['network_name']}")
                print(f"Ready:       {'Yes' if info['is_configured'] else 'No'}")
        except Exception as e:
            if args.json:
                print(json.dumps({"error": str(e)}))
            else:
                print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        return
    
    if args.balance:
        try:
            balance = get_balance(network=args.network)
            if args.json:
                session = PrestoSession(network=args.network)
                print(json.dumps({
                    "balance": balance,
                    "balance_numeric": session.get_balance_numeric(),
                    "network": args.network,
                }))
            else:
                print(balance)
        except Exception as e:
            if args.json:
                print(json.dumps({"error": str(e)}))
            else:
                print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        return
    
    if args.check:
        is_ready, message = check_wallet_ready(network=args.network)
        if args.json:
            print(json.dumps({"ready": is_ready, "message": message}))
        else:
            if is_ready:
                print(f"✓ {message}")
            else:
                print(f"✗ {message}")
        sys.exit(0 if is_ready else 1)
    
    # Get query from args or stdin
    if args.query:
        query = args.query
    elif not sys.stdin.isatty():
        query = sys.stdin.read().strip()
        if not query:
            parser.error("Query required (stdin was empty)")
    else:
        parser.error("Query required (positional arg or stdin). Use --help for options.")
    
    try:
        result = run_query(
            query,
            network=args.network,
            max_turns=args.max_turns,
            verbose=args.verbose
        )
        
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(result['response'])
            
    except Exception as e:
        if args.json:
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
