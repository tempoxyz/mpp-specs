"""User context for AI agent awareness of wallet, payments, and session state.

The UserContext provides a sanitized snapshot of the user's state that gets
injected into the system prompt. This makes the agent "smart" about:
- Wallet address and access keys
- Balance and network
- Session spending and transaction history

SECURITY: Never include private keys in context. Always sanitize RPC URLs.
"""
import json
import time
from dataclasses import dataclass, field
from typing import Optional

from .config import NETWORKS, DEFAULT_NETWORK


@dataclass
class PaymentRecord:
    """Record of a single payment."""
    timestamp: int
    amount_usd: float
    tx_hash: str
    
    def to_dict(self) -> dict:
        return {
            "ts": self.timestamp,
            "amount_usd": round(self.amount_usd, 4),
            "tx_hash": self.tx_hash,
        }


@dataclass 
class UserContext:
    """Sanitized user context for injection into system prompt.
    
    This is the single source of truth for what the agent should "know"
    about the user without calling tools.
    """
    # Wallet
    account_address: str = ""
    access_key_address: str = ""
    access_key_expiry: int = 0
    access_key_label: str = ""
    access_key_count: int = 0
    
    # Network
    network_name: str = DEFAULT_NETWORK
    chain_id: int = 0
    explorer_url: str = ""
    fee_token_name: str = ""
    
    # Balance
    balance_display: str = ""
    balance_checked_at: int = 0
    balance_stale_after_s: int = 30
    
    # Session usage
    session_started_at: int = field(default_factory=lambda: int(time.time()))
    session_cost_usd: float = 0.0
    session_tokens: int = 0
    session_tx_count: int = 0
    recent_payments: list = field(default_factory=list)
    
    # Metadata
    generated_at: int = field(default_factory=lambda: int(time.time()))
    
    def update_from_wallet(self, wallet, network: str):
        """Update context from WalletConfig."""
        self.account_address = wallet.account_address or ""
        self.network_name = network
        
        # Network info
        net_info = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
        self.chain_id = net_info.get("chain_id", 0)
        self.explorer_url = net_info.get("explorer", "")
        self.fee_token_name = net_info.get("fee_token_name", "tokens")
        
        # Access key info (sanitized - no private key)
        active_key = wallet.active_key
        if active_key:
            self.access_key_address = active_key.address
            self.access_key_expiry = active_key.expiry
            self.access_key_label = active_key.label
        else:
            self.access_key_address = ""
            self.access_key_expiry = 0
            self.access_key_label = ""
        
        self.access_key_count = len(wallet.access_keys)
        self.generated_at = int(time.time())
    
    def update_balance(self, balance_display: str):
        """Update cached balance."""
        self.balance_display = balance_display
        self.balance_checked_at = int(time.time())
        self.generated_at = int(time.time())
    
    def record_payment(self, amount_usd: float, tx_hash: str):
        """Record a payment and update session totals."""
        self.session_cost_usd += amount_usd
        self.session_tx_count += 1
        
        payment = PaymentRecord(
            timestamp=int(time.time()),
            amount_usd=amount_usd,
            tx_hash=tx_hash,
        )
        self.recent_payments.append(payment)
        
        # Keep only last 5 payments
        if len(self.recent_payments) > 5:
            self.recent_payments = self.recent_payments[-5:]
        
        self.generated_at = int(time.time())
    
    def record_usage(self, tokens: int):
        """Record token usage."""
        self.session_tokens += tokens
        self.generated_at = int(time.time())
    
    @property
    def is_balance_stale(self) -> bool:
        """Check if balance needs refresh."""
        if not self.balance_checked_at:
            return True
        return (int(time.time()) - self.balance_checked_at) > self.balance_stale_after_s
    
    @property
    def access_key_is_expired(self) -> bool:
        """Check if access key is expired."""
        if not self.access_key_expiry:
            return False
        return int(time.time()) >= self.access_key_expiry
    
    @property
    def access_key_expires_soon(self) -> bool:
        """Check if access key expires within 1 hour."""
        if not self.access_key_expiry or self.access_key_is_expired:
            return False
        return (self.access_key_expiry - int(time.time())) < 3600
    
    @property
    def access_key_time_remaining(self) -> str:
        """Human-readable time remaining on access key."""
        if not self.access_key_expiry:
            return "no expiry"
        remaining = self.access_key_expiry - int(time.time())
        if remaining <= 0:
            return "EXPIRED"
        if remaining < 3600:
            return f"{remaining // 60}m"
        if remaining < 86400:
            return f"{remaining // 3600}h"
        return f"{remaining // 86400}d"
    
    def to_prompt_block(self) -> str:
        """Generate the context block for system prompt injection.
        
        Returns a markdown/JSON block that the agent can reference.
        """
        now = int(time.time())
        
        # Build context dict (sanitized, no secrets)
        ctx = {
            "wallet": {
                "account_address": self.account_address or "(not connected)",
                "access_key": {
                    "address": self.access_key_address or "(none)",
                    "expires_in": self.access_key_time_remaining,
                    "is_expired": self.access_key_is_expired,
                    "expires_soon": self.access_key_expires_soon,
                } if self.access_key_address else None,
                "total_keys": self.access_key_count,
            },
            "network": {
                "name": self.network_name,
                "chain_id": self.chain_id,
                "explorer": self.explorer_url,
                "fee_token": self.fee_token_name,
            },
            "balance": {
                "display": self.balance_display or "(unknown)",
                "age_seconds": now - self.balance_checked_at if self.balance_checked_at else None,
                "is_stale": self.is_balance_stale,
            },
            "session": {
                "cost_usd": round(self.session_cost_usd, 4),
                "tokens": self.session_tokens,
                "tx_count": self.session_tx_count,
                "recent_payments": [p.to_dict() for p in self.recent_payments[-3:]],
            },
        }
        
        # Format as prompt block
        json_str = json.dumps(ctx, indent=2)
        
        return f"""
### RUNTIME_CONTEXT
The following is your current runtime state. Use this to answer questions about
the user's wallet, balance, spending, and access keys WITHOUT calling tools.

```json
{json_str}
```

**Context Policy:**
- If user asks "what's my balance/address/spending?", answer from RUNTIME_CONTEXT if balance is not stale.
- If balance.is_stale is true, call check_balance() to get fresh data.
- If wallet.account_address is "(not connected)", suggest using connect_wallet tool.
- If access_key.expires_soon is true, warn the user and suggest /newkey.
- Never request or output private keys.
### /RUNTIME_CONTEXT
"""
