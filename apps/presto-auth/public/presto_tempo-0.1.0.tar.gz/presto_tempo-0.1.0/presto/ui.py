"""Curses-based terminal UI for presto."""
import curses
import os
import random
import re
import subprocess
import sys
import time
import threading
import queue


def _term_write(seq: str) -> None:
    """Write escape sequence directly to terminal."""
    try:
        sys.stdout.write(seq)
        sys.stdout.flush()
    except Exception:
        pass

from .config import CONFIG_FILE, NETWORKS, DEFAULT_NETWORK, get_logo, AVAILABLE_MODELS, MODEL, MAINNET_BLOCKED
from .payment import load_config, save_config
from .api import call_api, get_model_context_length, StreamCancelled
from .rpc import get_token_balance, format_balance
from .tools import run_tool, set_tool_context, get_tools_summary, set_skill_loader
from .wallet import setup_wallet_browser, setup_wallet_manual, WalletConfig, AccessKey
from .context import UserContext

from . import skills as presto_skills
from . import logger
import webbrowser


# Look for skills in both the package and user config
PRESTO_SKILLS_DIR = os.path.dirname(os.path.abspath(__file__)) + "/skills"
USER_SKILLS_DIR = os.path.expanduser("~/.config/agents/skills")

# Settlement show messages - rotate during blockchain confirmation
SETTLEMENT_MESSAGES = [
    # Technical vibes
    "Confirming blocks...",
    "Verifying chain state...",
    "Hashing the hashes...",
    "Consensus achieved...",
    "Validators validating...",
    "Merkle roots intensify...",
    "Finality approaching...",
    "Propagating to nodes...",
    "Crunching cryptography...",
    "Byzantine fault? Never heard of her.",
    # Dank memes  
    "Blocks go brrr...",
    "In crypto we trust...",
    "Much confirm. Very chain. Wow.",
    "This is the way.",
    "WAGMI 🤝",
    "ser, your tx is cooking...",
    "wen confirm? soon™",
    "gm blockchain ☀️",
    "Not your keys? Not your AI.",
    "Decentralized vibes only.",
    "The chain remembers.",
    "Probably nothing...",
    "LFG 🚀",
    "Based and chainpilled.",
    "Few understand this.",
    "API keys are mass surveillance.",
    "No middlemen. Just math.",
    "Trust the process...",
    "Imagine using API keys lmao",
    "Your money, your model.",
    "ngmi if you use subscriptions",
    "Have fun staying centralized.",
    "Nodes are gossiping about you...",
    "Sir, this is a blockchain.",
    "We're all gonna make it.",
    "Number go up (blocks).",
    "The future is permissionless.",
    "Satoshi would be proud.",
    "Touch grass? Touch chain.",
    "Immutability loading...",
    "Your tx is valid and we love it.",
    "Consensus says yes.",
    "Making history (literally).",
    "The mempool chose you.",
    "Built different. Paid different.",
    "No cap, all chain.",
    "Vibes: ✓ immaculate",
    "POV: you don't need API keys",
    "Main character energy.",
    "Blockchain whisperer at work...",
]

# Fun success messages when payment confirms
SUCCESS_MESSAGES = [
    "Clean. 🧹",
    "Sheesh.",
    "Built different.",
    "No cap.",
    "Immaculate.",
    "That's gas.",
    "W.",
    "Certified.",
    "Bussin.",
    "Locked in.",
    "Goated.",
    "Fire.",
    "Valid.",
    "Based.",
    "Smooth.",
]

# Animated spinner frames for different payment phases
SPINNER_FAST = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]  # 12fps feel
SPINNER_PULSE = ["█", "▓", "▒", "░", "▒", "▓"]  # Slower pulse for confirming


class PrestoUI:
    def __init__(self, stdscr, fresh=False):
        self.stdscr = stdscr
        self.fresh = fresh
        self.messages = []
        self.output_lines = []
        self.input_buffer = ""
        self.cursor_pos = 0
        self.scroll_offset = 0
        self.config = {}
        self.wallet: WalletConfig = WalletConfig()  # New wallet model
        self.private_key = ""
        self.account_address = ""  # Main passkey wallet address
        self.access_key_address = ""  # Access key address (derived from private key)
        self.running = True
        self.status_message = ""
        self.is_first_run = False
        self.current_network = DEFAULT_NETWORK
        self.loaded_skills = []  # List of loaded skill names
        self.skill_instructions = ""  # Combined skill instructions
        self.animation_frame = 0  # For logo animation
        self.cached_balance = None  # Cached balance string
        self.last_balance_check = 0  # Timestamp of last balance check
        self.balance_refresh_in_progress = False  # Guard for balance refresh
        self.api_thread = None  # Background thread for API calls
        self.api_busy = False  # True when API call is in progress
        self.api_cancelled = False  # True when user cancels current request
        self.api_cancel_event = threading.Event()  # Event to signal cancellation to call_api
        self.api_queue = queue.Queue()  # Queue for API responses/events
        self.api_request_id = 0  # Monotonic request ID for ignoring stale results
        self.activity_status = ""  # Current activity for status bar (e.g., "Streaming response...", "Running read...")
        self.current_model = MODEL  # Currently selected model
        self.model_box_x = 0  # For click detection
        self.model_box_width = 0
        self.session_cost = 0.0  # Total paid this session
        self.session_tokens = 0  # Total tokens used this session
        self.session_tx_count = 0  # Number of transactions this session
        self.context_limit = 200000  # Model context limit (200k for Claude)
        
        # User context for AI agent awareness
        self.user_context = UserContext()
        
        # Payment UX state for dopamine loop
        self._payment_state = None  # Current payment state: 'signing', 'sending', 'confirming', 'confirmed'
        self._payment_started_at = 0  # When confirm phase started
        self._payment_msg_idx = 0  # Index into rotating messages
        
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_BLUE, -1)
        curses.init_pair(2, curses.COLOR_CYAN, -1)
        curses.init_pair(3, curses.COLOR_GREEN, -1)
        curses.init_pair(4, curses.COLOR_YELLOW, -1)
        curses.init_pair(5, curses.COLOR_RED, -1)
        curses.init_pair(6, curses.COLOR_MAGENTA, -1)
        curses.curs_set(1)
        # Enable keypad mode for arrow keys
        self.stdscr.keypad(True)
        self.wallet_box_x = 0
        self.wallet_box_width = 0
        self.model_box_y = 0  # Initialize for click detection
        self.cached_git_branch = ""  # Cache git branch to avoid repeated subprocess calls
        self.last_git_check = 0  # Timestamp of last git check
        
        self.stdscr.timeout(100)
        
        # Reduce escape delay so ESC key is responsive (default is 1000ms!)
        # This makes pressing ESC feel instant instead of laggy
        try:
            curses.set_escdelay(25)  # 25ms delay
        except AttributeError:
            # Older curses versions don't have set_escdelay
            os.environ.setdefault('ESCDELAY', '25')
        
        # Don't capture mouse clicks - let terminal handle text selection natively
        curses.mousemask(0)
        
        # Enable xterm alternate scroll mode: wheel generates Up/Down keys
        # This preserves native text selection while enabling scroll wheel
        _term_write("\x1b[?1007h")
        
    def get_dims(self):
        return self.stdscr.getmaxyx()
    
    def get_logo(self):
        """Get appropriately sized logo for current terminal."""
        height, width = self.get_dims()
        return get_logo(height, width)
    
    def center_text(self, text, width):
        padding = max(0, (width - len(text)) // 2)
        return " " * padding + text
    
    def get_network_name(self):
        return self.current_network
    
    def get_rpc_url(self):
        return NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])["rpc"]
    
    def get_chain_id(self):
        return NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])["chain_id"]
    
    
    def get_cached_balance(self):
        """Get cached balance, refresh every 30 seconds."""
        now = time.time()
        
        # Refresh balance every 30 seconds (with guard to prevent multiple concurrent refreshes)
        if not self.balance_refresh_in_progress:
            if self.cached_balance is None or (now - self.last_balance_check) > 30:
                self.refresh_balance_async()
        
        return self.cached_balance
    
    def refresh_balance_sync(self):
        """Synchronously fetch token balance via RPC."""
        if not self.account_address:
            return
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        fee_token_name = network_info.get("fee_token_name", "tokens")
        
        balance = get_token_balance(
            self.account_address,
            network_info.get("fee_token", ""),
            network_info.get("rpc", ""),
            decimals=6
        )
        self.cached_balance = format_balance(balance, fee_token_name)
        self.last_balance_check = time.time()
    
    def refresh_balance_async(self):
        """Refresh token balance in background via RPC."""
        if not self.account_address:
            return
        
        self.balance_refresh_in_progress = True
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        fee_token = network_info.get("fee_token", "")
        fee_token_name = network_info.get("fee_token_name", "tokens")
        rpc_url = network_info.get("rpc", "")
        account = self.account_address
        
        def fetch():
            try:
                balance = get_token_balance(account, fee_token, rpc_url, decimals=6)
                self.cached_balance = format_balance(balance, fee_token_name)
                self.last_balance_check = time.time()
                # Update user context with new balance
                self.user_context.update_balance(self.cached_balance)
            except Exception as e:
                logger.error(f"Balance refresh error: {e}")
            finally:
                self.balance_refresh_in_progress = False
        
        thread = threading.Thread(target=fetch, daemon=True)
        thread.start()
    
    def get_header_height(self):
        return 2
    
    def draw_header(self):
        height, width = self.get_dims()
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        
        # Compact single-line header
        try:
            self.stdscr.addstr(0, 0, "PRESTO", curses.A_BOLD | curses.color_pair(3))
            
            # Build right-side info box
            if self.account_address:
                active_key = self.wallet.active_key if self.wallet else None
                
                # Full address (no OSC 8 in curses - escape sequences don't work with addstr)
                addr_display = self.account_address
                
                # Balance with token name
                if self.cached_balance:
                    balance_str = self.cached_balance
                else:
                    fee_token_name = network_info.get('fee_token_name', 'tokens')
                    balance_str = f"$0.00 {fee_token_name}"
                
                # Key expiry
                key_status = ""
                if active_key:
                    if active_key.is_expired:
                        key_status = "EXPIRED"
                    else:
                        key_status = active_key.time_remaining
                
                box_text = f"┃ {addr_display} │ {balance_str} │ {key_status} ┃"
            else:
                # Premium CTA for wallet connection
                box_text = "┃ Connect wallet (/wallet) ┃"
            
            box_x = width - len(box_text) - 1
            self.wallet_box_x = box_x
            self.wallet_box_width = len(box_text)
            
            if self.account_address:
                active_key = self.wallet.active_key if self.wallet else None
                if active_key and active_key.is_expired:
                    self.stdscr.addstr(0, box_x, box_text, curses.color_pair(5))
                elif active_key and active_key.expires_soon:
                    self.stdscr.addstr(0, box_x, box_text, curses.color_pair(4))
                else:
                    self.stdscr.addstr(0, box_x, box_text, curses.color_pair(3))
            else:
                # Cyan for CTA (inviting, not error)
                self.stdscr.addstr(0, box_x, box_text, curses.color_pair(2))
        except curses.error:
            pass
        
        # Separator line
        try:
            self.stdscr.addstr(1, 0, "─" * width, curses.color_pair(1) | curses.A_DIM)
        except curses.error:
            pass
    
    def draw_separator(self, y):
        height, width = self.get_dims()
        try:
            self.stdscr.addstr(y, 0, "─" * width, curses.color_pair(1) | curses.A_DIM)
        except curses.error:
            pass
    
    def draw_output(self):
        height, width = self.get_dims()
        output_start = self.get_header_height()
        box_height = 3
        status_bar_height = 1 if (self.api_busy and self.activity_status) else 0
        output_end = height - box_height - status_bar_height - 1
        max_lines = output_end - output_start
        
        if max_lines <= 0:
            return
        
        total = len(self.output_lines)
        max_offset = max(0, total - max_lines)
        self.scroll_offset = min(max(self.scroll_offset, 0), max_offset)
        
        visible_lines = self.output_lines[-(max_lines + self.scroll_offset):]
        if self.scroll_offset > 0:
            visible_lines = visible_lines[:max_lines]
        else:
            visible_lines = visible_lines[-max_lines:]
        
        # Bottom-align: calculate offset so content sticks to bottom
        content_lines = len(visible_lines)
        start_row = max_lines - content_lines  # Empty rows at top
        
        for i in range(max_lines):
            y = output_start + i
            try:
                self.stdscr.move(y, 0)
                self.stdscr.clrtoeol()
                # Only render if we're past the empty top rows
                line_idx = i - start_row
                if line_idx >= 0 and line_idx < len(visible_lines):
                    line = visible_lines[line_idx]
                    self.render_line(y, line, width)
            except curses.error:
                pass
        
        # Draw scrollbar on right edge when content exceeds viewport
        if total > max_lines:
            scrollbar_x = width - 1
            track_height = max_lines
            
            # Calculate thumb size and position
            # Thumb size proportional to visible portion
            thumb_height = max(1, int(track_height * (max_lines / total)))
            
            # Thumb position: 0 = bottom (newest), max_offset = top (oldest)
            # We want thumb at bottom when scroll_offset=0, top when scroll_offset=max_offset
            if max_offset > 0:
                # Position from top: when scroll_offset is high (old content), thumb near top
                thumb_pos = int((self.scroll_offset / max_offset) * (track_height - thumb_height))
                # Invert: scroll_offset=0 means bottom, scroll_offset=max means top
                thumb_pos = track_height - thumb_height - thumb_pos
            else:
                thumb_pos = track_height - thumb_height
            
            # Draw scrollbar track and thumb
            for i in range(track_height):
                y = output_start + i
                try:
                    if thumb_pos <= i < thumb_pos + thumb_height:
                        # Thumb - bright block
                        self.stdscr.addstr(y, scrollbar_x, "█", curses.A_DIM)
                    else:
                        # Track - dim line
                        self.stdscr.addstr(y, scrollbar_x, "│", curses.A_DIM)
                except curses.error:
                    pass
    
    def render_markdown_line(self, y, x, text, max_width, base_attr=0):
        """Render a line with basic markdown: **bold** and *italic*."""
        import re
        pos = x
        remaining = max_width
        
        # Pattern for **bold** and *italic* (non-greedy)
        pattern = re.compile(r'(\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`)')
        last_end = 0
        
        for match in pattern.finditer(text):
            # Render text before this match
            before = text[last_end:match.start()]
            if before and remaining > 0:
                chunk = before[:remaining]
                try:
                    self.stdscr.addstr(y, pos, chunk, base_attr)
                except curses.error:
                    pass
                pos += len(chunk)
                remaining -= len(chunk)
            
            # Render the matched styled text
            if remaining > 0:
                if match.group(2):  # **bold**
                    styled_text = match.group(2)[:remaining]
                    try:
                        self.stdscr.addstr(y, pos, styled_text, base_attr | curses.A_BOLD)
                    except curses.error:
                        pass
                elif match.group(3):  # *italic*
                    styled_text = match.group(3)[:remaining]
                    try:
                        self.stdscr.addstr(y, pos, styled_text, base_attr | curses.A_ITALIC if hasattr(curses, 'A_ITALIC') else base_attr | curses.A_DIM)
                    except curses.error:
                        pass
                elif match.group(4):  # `code`
                    styled_text = match.group(4)[:remaining]
                    try:
                        self.stdscr.addstr(y, pos, styled_text, base_attr | curses.A_REVERSE)
                    except curses.error:
                        pass
                else:
                    styled_text = ""
                pos += len(styled_text)
                remaining -= len(styled_text)
            
            last_end = match.end()
        
        # Render remaining text after last match
        after = text[last_end:]
        if after and remaining > 0:
            chunk = after[:remaining]
            try:
                self.stdscr.addstr(y, pos, chunk, base_attr)
            except curses.error:
                pass
    
    def render_line(self, y, line, width):
        margin = 3
        content_width = width - margin - 5
        if line.startswith("⏺ "):
            # Assistant response - render with markdown
            try:
                self.render_markdown_line(y, margin, line[2:], content_width)
            except curses.error:
                pass
        elif line.startswith("→ "):
            # User input - vertical bar with italic-style (dim) text
            try:
                self.stdscr.addstr(y, margin, "│ ", curses.color_pair(4))
                self.stdscr.addstr(line[2:][:content_width], curses.A_ITALIC if hasattr(curses, 'A_ITALIC') else curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("$ "):
            # Status message
            try:
                self.stdscr.addstr(y, margin, "✓ ", curses.color_pair(3))
                self.stdscr.addstr(line[2:][:content_width], curses.A_BOLD)
            except curses.error:
                pass
        elif line.startswith("@ "):
            # Thinking indicator with animated spinner
            try:
                # Braille spinner frames: dots rotating around
                spinner_frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
                frame = spinner_frames[self.animation_frame % len(spinner_frames)]
                self.stdscr.addstr(y, margin, f"{frame} ", curses.color_pair(4))
                self.stdscr.addstr(line[2:][:content_width], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("! "):
            # Error
            try:
                self.stdscr.addstr(y, margin, "✗ ", curses.color_pair(5))
                self.stdscr.addstr(line[2:][:content_width])
            except curses.error:
                pass
        elif line.startswith("⎿ "):
            # Tool result - dim
            try:
                self.stdscr.addstr(y, margin + 2, line[2:][:content_width-2], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("~ "):
            # Subtle info (e.g., payment summary after completion) - very dim
            try:
                self.stdscr.addstr(y, margin, line[2:][:content_width], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("◊ "):
            # Tool call line like "◊ ✓ Read file.py @1-50"
            try:
                rest = line[2:]
                if rest.startswith("○ "):
                    # Pending - show spinner
                    spinner_frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
                    frame = spinner_frames[self.animation_frame % len(spinner_frames)]
                    self.stdscr.addstr(y, margin, f"{frame} ", curses.color_pair(4))
                    self.stdscr.addstr(rest[2:][:content_width-2], curses.color_pair(2))
                elif rest.startswith("✓ "):
                    # Completed - green checkmark
                    self.stdscr.addstr(y, margin, "✓ ", curses.color_pair(3))
                    self.stdscr.addstr(rest[2:][:content_width-2], curses.A_DIM)
                else:
                    self.stdscr.addstr(y, margin, rest[:content_width], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("✓EDIT "):
            # Edit header - green checkmark with file info
            try:
                self.stdscr.addstr(y, margin, "✓ Edit ", curses.color_pair(3))
                self.stdscr.addstr(line[6:][:content_width-8], curses.color_pair(2))
            except curses.error:
                pass
        elif line.startswith("+DIFF"):
            # Added line - green
            diff_line = line[5:]
            try:
                parts = diff_line.split(" + ", 1)
                line_num = parts[0].strip() if parts else ""
                content = parts[1] if len(parts) > 1 else ""
                self.stdscr.addstr(y, margin, f"{line_num} ", curses.A_DIM)
                self.stdscr.addstr("+ ", curses.color_pair(3) | curses.A_BOLD)
                self.stdscr.addstr(content[:content_width-10], curses.color_pair(3))
            except curses.error:
                pass
        elif line.startswith("-DIFF"):
            # Removed line - red
            diff_line = line[5:]
            try:
                parts = diff_line.split(" - ", 1)
                line_num = parts[0].strip() if parts else ""
                content = parts[1] if len(parts) > 1 else ""
                self.stdscr.addstr(y, margin, f"{line_num} ", curses.A_DIM)
                self.stdscr.addstr("- ", curses.color_pair(5) | curses.A_BOLD)
                self.stdscr.addstr(content[:content_width-10], curses.color_pair(5) | curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith(" DIFF"):
            # Context line - dim
            diff_line = line[5:]
            try:
                self.stdscr.addstr(y, margin + 2, diff_line[:content_width-4], curses.A_DIM)
            except curses.error:
                pass
        elif line.startswith("§"):
            # Logo line - render with animated wave effect
            import math
            logo_text = line[1:]
            logo_margin = margin
            for j, char in enumerate(logo_text[:content_width]):
                try:
                    x = logo_margin + j
                    # Wave effect based on position and animation frame
                    wave = math.sin((j * 0.3) + (y * 0.2) + (self.animation_frame * 0.15))
                    bright = wave > 0.3
                    dim = wave < -0.3
                    
                    if char == '+':
                        attr = curses.A_BOLD if bright else 0
                        self.stdscr.addstr(y, x, char, curses.color_pair(3) | attr)
                    elif char == '=':
                        if bright:
                            self.stdscr.addstr(y, x, char, curses.color_pair(3) | curses.A_BOLD)
                        elif dim:
                            self.stdscr.addstr(y, x, char, curses.color_pair(1) | curses.A_DIM)
                        else:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2))
                    elif char == '-':
                        if bright:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2) | curses.A_BOLD)
                        else:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2) | (curses.A_DIM if dim else 0))
                    elif char == '·':
                        if bright:
                            self.stdscr.addstr(y, x, char, curses.color_pair(2) | curses.A_BOLD)
                        else:
                            self.stdscr.addstr(y, x, char, curses.color_pair(1) | curses.A_DIM)
                    elif char != ' ':
                        self.stdscr.addstr(y, x, char, curses.color_pair(3))
                except curses.error:
                    pass
        else:
            try:
                self.stdscr.addstr(y, margin, line[:content_width])
            except curses.error:
                pass
    
    def draw_input(self, show_cursor=True):
        height, width = self.get_dims()
        margin = 2
        box_height = 3
        box_top = height - box_height
        box_left = margin
        # Leave 3 chars margin on right to avoid curses edge issues
        box_width = max(20, width - margin * 2 - 3)
        
        # Build top border with stats embedded
        inner_width = box_width - 2  # Excluding corners
        if self.session_tokens > 0 or self.session_cost > 0:
            context_pct = min(100, int((self.session_tokens / self.context_limit) * 100)) if self.context_limit > 0 else 0
            stats = f"{context_pct}% of {self.context_limit // 1000}k · ${self.session_cost:.2f}"
            left_dashes = 2
            right_dashes = inner_width - len(stats) - left_dashes
            if right_dashes < 1:
                top_border = "╭" + "─" * inner_width + "╮"
            else:
                top_border = "╭" + "─" * left_dashes + stats + "─" * right_dashes + "╮"
        else:
            top_border = "╭" + "─" * inner_width + "╮"
        
        bottom_border = "╰" + "─" * inner_width + "╯"
        middle_line = "│" + " " * inner_width + "│"
        
        try:
            self.stdscr.addstr(box_top, box_left, top_border, curses.color_pair(1) | curses.A_DIM)
            self.stdscr.addstr(box_top + 1, box_left, middle_line, curses.color_pair(1))
            self.stdscr.addstr(box_top + 2, box_left, bottom_border, curses.color_pair(1))
        except curses.error:
            pass
        
        input_y = box_top + 1
        input_padding = 2
        input_x = box_left + input_padding
        
        # Get short model name for display (simple, no box)
        model_short = self.current_model.split("/")[-1]
        if len(model_short) > 20:
            model_short = model_short[:18] + "…"
        model_label = model_short
        model_label_width = len(model_label)
        
        try:
            # Draw user input
            max_input = max(10, inner_width - model_label_width - 4)
            visible_input = self.input_buffer[-max_input:] if len(self.input_buffer) > max_input else self.input_buffer
            self.stdscr.addstr(input_y, input_x, visible_input[:max_input])
            
            # Draw model name on the right side (dimmed)
            model_x = box_left + inner_width - model_label_width
            if model_x > input_x + len(visible_input):
                self.stdscr.addstr(input_y, model_x, model_label, curses.color_pair(1) | curses.A_DIM)
            
            # Position cursor
            if show_cursor:
                cursor_x = input_x + min(self.cursor_pos, len(visible_input))
                self.stdscr.move(input_y, cursor_x)
        except curses.error:
            pass
        
        # Draw activity status on the bottom border when busy
        if self.api_busy and self.activity_status:
            spinner_frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
            spinner = spinner_frames[self.animation_frame % len(spinner_frames)]
            status_text = f"{spinner} {self.activity_status}"
            hint_text = "Esc to cancel"
            
            try:
                # Draw status in bottom border
                status_x = box_left + 2
                max_status = inner_width - len(hint_text) - 6
                self.stdscr.addstr(box_top + 2, status_x, status_text[:max_status], curses.color_pair(2))
                # Draw hint on the right
                hint_x = box_left + inner_width - len(hint_text)
                self.stdscr.addstr(box_top + 2, hint_x, hint_text, curses.color_pair(1) | curses.A_DIM)
            except curses.error:
                pass
    
    def draw(self):
        self.animation_frame += 1
        
        # Animate payment progress during active payment phases
        if self._payment_state in ('signing', 'sending', 'confirming'):
            self._update_payment_animation()
        
        self.stdscr.erase()
        self.draw_header()
        self.draw_output()
        self.draw_input()
        self.stdscr.refresh()
    
    def _update_payment_animation(self):
        """Update payment line spinner and rotating messages during confirmation."""
        amount = getattr(self, '_payment_amount', 0)
        token = getattr(self, '_payment_token', 'USD')
        idx = getattr(self, '_payment_line_idx', None)
        if idx is None or idx >= len(self.output_lines):
            return
        
        if self._payment_state == 'signing':
            spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
            self.output_lines[idx] = f"$ {amount:.4f} {token}  {spinner} sign  ○ send  ○ confirm"
        elif self._payment_state == 'sending':
            spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
            self.output_lines[idx] = f"$ {amount:.4f} {token}  ✓ sign  {spinner} send  ○ confirm"
        elif self._payment_state == 'confirming':
            # Slower pulse spinner during confirmation
            spinner = SPINNER_PULSE[self.animation_frame % len(SPINNER_PULSE)]
            self.output_lines[idx] = f"$ {amount:.4f} {token}  ✓ sign  ✓ send  {spinner} confirm"
            
            # Rotate shuffled messages every ~8 frames (~0.8 second)
            messages = getattr(self, '_shuffled_messages', SETTLEMENT_MESSAGES)
            msg_num = (self.animation_frame // 8) % len(messages)
            msg = messages[msg_num]
            
            # Update the message line below payment progress
            msg_line_idx = getattr(self, '_payment_msg_line_idx', None)
            if msg_line_idx is not None and 0 <= msg_line_idx < len(self.output_lines):
                self.output_lines[msg_line_idx] = f"~ {msg}"
    
    def _format_tool_call(self, tool_name, tool_args, pending=False, result=None):
        """Format tool call inline like Amp: ✓ Read file.py @1-50"""
        icon = "○" if pending else "✓"
        
        # Format based on tool type
        if tool_name == "read":
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            range_str = ""
            if "read_range" in tool_args:
                r = tool_args["read_range"]
                range_str = f" @{r[0]}-{r[1]}" if isinstance(r, list) and len(r) == 2 else ""
            return f"◊ {icon} Read {short_path}{range_str}"
        
        elif tool_name == "edit":
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            # Count lines changed from result
            count = ""
            if result and (result.startswith("DIFF:") or result.startswith("WRITE:")):
                parts = result.split(":", 3)
                if len(parts) > 2:
                    count = f" {parts[2]}"
            return f"◊ {icon} Edit {short_path}{count}"
        
        elif tool_name == "write":
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            return f"◊ {icon} Write {short_path}"
        
        elif tool_name == "grep":
            pattern = tool_args.get("pattern", "")[:30]
            path = tool_args.get("path", "")
            short_path = path.split("/")[-1] if "/" in path else path
            return f"◊ {icon} Grep {pattern} in {short_path}"
        
        elif tool_name == "glob":
            pattern = tool_args.get("pattern", tool_args.get("filePattern", ""))[:40]
            return f"◊ {icon} Glob {pattern}"
        
        elif tool_name == "bash":
            cmd = tool_args.get("cmd", tool_args.get("command", ""))[:50]
            return f"◊ {icon} Bash {cmd}"
        
        elif tool_name == "skill":
            skill = tool_args.get("name", "")
            return f"◊ {icon} Skill {skill}"
        
        elif tool_name == "web_search":
            query = tool_args.get("query", "")[:40]
            return f"◊ {icon} Search {query}"
        
        elif tool_name == "read_url":
            url = tool_args.get("url", "")
            # Show just the domain
            if "://" in url:
                domain = url.split("://")[1].split("/")[0]
            else:
                domain = url[:30]
            return f"◊ {icon} Fetch {domain}"
        
        else:
            # Generic format
            arg_preview = ""
            if tool_args:
                first_val = str(list(tool_args.values())[0])[:30]
                arg_preview = f" {first_val}"
            return f"◊ {icon} {tool_name}{arg_preview}"
    
    def add_output(self, line):
        height, width = self.get_dims()
        margin = 2
        content_width = width - margin - 6
        
        if content_width < 20:
            content_width = 60
        
        if len(line) > content_width + 2:
            prefix = ""
            text = line
            if line.startswith("⏺ "):
                prefix = "⏺ "
                text = line[2:]
            elif line.startswith("→ "):
                prefix = "→ "
                text = line[2:]
            elif line.startswith("$ "):
                prefix = "$ "
                text = line[2:]
            elif line.startswith("! "):
                prefix = "! "
                text = line[2:]
            elif line.startswith("⎿ "):
                prefix = "⎿ "
                text = line[2:]
            
            if prefix:
                cont_prefix = "⏺ " if prefix == "⏺ " else "  "
                while text:
                    chunk = text[:content_width]
                    text = text[content_width:]
                    self.output_lines.append(prefix + chunk)
                    prefix = cont_prefix
            else:
                self.output_lines.append(line)
        else:
            self.output_lines.append(line)
        
        self.scroll_offset = 0
        self.draw()
    
    def handle_resize(self):
        curses.endwin()
        self.stdscr.refresh()
        self.draw()
    
    def remove_thinking_line(self):
        """Remove the thinking indicator line from output."""
        for i in range(len(self.output_lines) - 1, -1, -1):
            if self.output_lines[i].startswith("@ Thinking"):
                self.output_lines.pop(i)
                break
    
    def reinit_curses(self):
        """Refresh curses after something disrupted terminal."""
        self.stdscr.erase()
        self.stdscr.refresh()
    
    def process_command(self, cmd):
        if cmd in ("/q", "exit", "/quit"):
            self.running = False
            return
        if cmd == "/c" or cmd == "/clear":
            self.messages = []
            self.output_lines = []
            self.add_output("⏺ Cleared conversation")
            return
        if cmd == "/wallet":
            self.show_wallet_dialog()
            return

        if cmd == "/help":
            self.show_help()
            return
        if cmd == "/p" or cmd == "/menu" or cmd == "/commands":
            self.show_command_palette()
            return
        if cmd == "/skill" or cmd == "/skills":
            self.list_skills()
            return
        if cmd.startswith("/skill "):
            skill_name = cmd.split(" ", 1)[1].strip()
            self.load_skill(skill_name)
            return
        if cmd == "/network":
            net_info = NETWORKS[self.current_network]
            self.add_output(f"⏺ Network: {net_info['name']}")
            self.add_output(f"  RPC: {net_info['rpc']}")
            self.add_output(f"  Available: {', '.join(NETWORKS.keys())}")
            return
        if cmd.startswith("/network "):
            net_name = cmd.split(" ", 1)[1].strip().lower()
            if net_name == "mainnet" and MAINNET_BLOCKED:
                self.add_output("")
                self.add_output("🚨 MAINNET IS DISABLED 🚨")
                self.add_output("")
                self.add_output("Mainnet access keys have high storage overhead costs.")
                self.add_output("Use 'moderato' testnet until costs are optimized.")
                self.add_output("")
                self.add_output("  /network moderato")
                self.add_output("")
                return
            if net_name in NETWORKS:
                self.current_network = net_name
                self.wallet.switch_network(net_name)
                # Update legacy fields from new network's wallet
                self.account_address = self.wallet.account_address
                active_key = self.wallet.active_key
                if active_key:
                    self.private_key = active_key.private_key
                    self.key_expiry = active_key.expiry
                    self.access_key_address = active_key.address
                else:
                    self.private_key = None
                    self.key_expiry = 0
                    self.access_key_address = None
                # Clear cached balance for new network
                self.cached_balance = None
                self.last_balance_check = 0
                # Save config
                self.config = self.wallet.to_dict()
                save_config(self.config, CONFIG_FILE)
                # Update user context for new network
                self.user_context.update_from_wallet(self.wallet, self.current_network)
                net_info = NETWORKS[net_name]
                self.add_output(f"⏺ Switched to {net_info['name']}")
                if self.account_address:
                    self.add_output(f"  Wallet: {self.account_address}")
                else:
                    self.add_output(f"  No wallet configured for this network")
            else:
                self.add_output(f"! Unknown network: {net_name}")
                self.add_output(f"  Available: {', '.join(NETWORKS.keys())}")
            return
        if cmd == "/history":
            self.show_history()
            return
        if cmd == "/newkey":
            self.create_new_access_key()
            return
        if cmd == "/portal":
            self.open_portal()
            return
        if cmd == "/model" or cmd == "/models":
            self.show_model_selector()
            return
        if cmd == "/usage":
            self.show_usage_dialog()
            return
        if cmd == "/faucet":
            self.request_faucet()
            return
        
        # Check if wallet is configured - if not, show delightful onboarding
        if not self.private_key:
            self.add_output("")
            self.add_output(f"→ {cmd}")
            self.add_output("")
            self.show_wallet_onboarding(cmd)
            return
        
        # If API is busy, cancel old request and start new one immediately
        if self.api_busy:
            self.api_cancelled = True
            self.api_cancel_event.set()  # Signal cancellation to call_api
            self.api_busy = False
            self.activity_status = ""
            self.remove_thinking_line()
            # Clear any streaming state from old request
            if hasattr(self, '_streaming_text'):
                delattr(self, '_streaming_text')
            if hasattr(self, '_streaming_started'):
                delattr(self, '_streaming_started')
            if hasattr(self, '_streaming_line_idx'):
                delattr(self, '_streaming_line_idx')
            # Reset payment state
            self._payment_state = None
            for attr in ('_payment_line_idx', '_payment_amount', '_payment_token', '_payment_msg_line_idx'):
                if hasattr(self, attr):
                    delattr(self, attr)
            self.add_output("⏺ Interrupted")
        
        # Increment request ID - old threads will be ignored
        self.api_request_id += 1
        
        logger.info(f"User query: {cmd[:50]}...")
        self.messages.append({"role": "user", "content": cmd})
        self.add_output("")  # blank line before user message
        self.add_output(f"→ {cmd}")
        self.add_output("")  # blank line after user message
        
        # Start API call in background thread
        self.add_output("@ Thinking")
        self.api_cancelled = False
        self.api_cancel_event.clear()  # Reset cancel event for new request
        self.api_busy = True
        self.activity_status = "Calling API..."
        self.start_api_thread()
    

    
    def start_api_thread(self):
        """Start background thread for API call."""
        system_prompt = self.get_system_prompt()
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info["rpc"]
        chain_id = network_info["chain_id"]
        explorer_url = network_info["explorer"]
        
        # Capture current request ID - results with old IDs will be ignored
        my_request_id = self.api_request_id
        
        # Set tool context for wallet tools
        set_tool_context({
            'account_address': self.account_address,
            'access_key_address': self.access_key_address,
            'rpc_url': rpc_url,
            'fee_token': network_info.get('fee_token', ''),
            'fee_token_name': network_info.get('fee_token_name', 'tokens'),
        })
        
        # Shared state for payment confirmation
        self._payment_confirm_result = None
        self._payment_confirm_pending = False
        
        def api_worker():
            try:
                def on_payment(amount_usd):
                    self.api_queue.put((my_request_id, 'payment', amount_usd))
                
                def on_status(msg):
                    self.api_queue.put((my_request_id, 'status', msg))
                
                def on_confirm(amount_usd):
                    """Block until user confirms or declines payment."""
                    self._payment_confirm_pending = True
                    self._payment_confirm_result = None
                    self.api_queue.put((my_request_id, 'confirm_payment', amount_usd))
                    
                    # Wait for user response (or cancellation)
                    while self._payment_confirm_result is None and my_request_id == self.api_request_id:
                        time.sleep(0.05)
                    
                    self._payment_confirm_pending = False
                    return self._payment_confirm_result if my_request_id == self.api_request_id else False
                
                def on_text_chunk(chunk):
                    """Stream text chunks to UI as they arrive.
                    
                    Returns False to cancel the stream (triggers StreamCancelled exception).
                    """
                    if self.api_cancelled or my_request_id != self.api_request_id:
                        return False  # Cancel stream if user pressed Esc or request is stale
                    self.api_queue.put((my_request_id, 'text_chunk', chunk))
                    return True
                
                def on_payment_step(step, status):
                    """Callback for payment progress updates."""
                    self.api_queue.put((my_request_id, 'payment_step', (step, status)))
                
                while True:
                    # Check if this request is stale
                    if my_request_id != self.api_request_id:
                        return  # Silently exit, new request has started
                    # Check if cancelled before making API call
                    if self.api_cancelled:
                        self.api_queue.put((my_request_id, 'cancelled', None))
                        return
                    response = call_api(
                        self.messages, system_prompt,
                        self.private_key, self.account_address,
                        rpc_url, chain_id, on_payment, on_status, on_confirm,
                        model=self.current_model, explorer_url=explorer_url,
                        on_text_chunk=on_text_chunk, on_payment_step=on_payment_step,
                        use_direct_signing=self.wallet.direct_signing if self.wallet else False,
                        cancel_event=self.api_cancel_event
                    )
                    
                    # Check if stale after API call returns
                    if my_request_id != self.api_request_id:
                        return  # Silently exit, new request has started
                    
                    content_blocks = response.get("content", [])
                    
                    # Track token usage
                    if "usage" in response:
                        self.api_queue.put((my_request_id, 'usage', response["usage"]))
                    
                    # Check for payment info and display it prominently
                    if "payment" in response:
                        self.api_queue.put((my_request_id, 'payment_success', response["payment"]))
                    tool_results = []
                    
                    for block in content_blocks:
                        if block["type"] == "text":
                            # Skip if we already streamed this text
                            if not hasattr(self, '_streaming_text') or not self._streaming_text:
                                self.api_queue.put((my_request_id, 'text', block["text"]))
                        if block["type"] == "tool_use":
                            tool_name = block["name"]
                            tool_args = block["input"]
                            logger.tool_use(tool_name, tool_args)
                            self.api_queue.put((my_request_id, 'tool_start', (tool_name, tool_args)))
                            
                            # Check if stale before running tool
                            if my_request_id != self.api_request_id:
                                return
                            
                            result = run_tool(tool_name, tool_args)
                            
                            # Check if stale after running tool
                            if my_request_id != self.api_request_id:
                                return
                            
                            # Special handling for connect_wallet tool
                            if result == "__CONNECT_WALLET__":
                                self.api_queue.put((my_request_id, 'connect_wallet', None))
                                # Wait for wallet connection to complete
                                while not hasattr(self, '_wallet_connected') and my_request_id == self.api_request_id:
                                    time.sleep(0.1)
                                if my_request_id != self.api_request_id:
                                    return
                                delattr(self, '_wallet_connected')
                                result = f"Wallet connected successfully!\nWallet: {self.account_address}\nAccess Key: {self.access_key_address}"
                            
                            logger.tool_result(tool_name, len(result))
                            self.api_queue.put((my_request_id, 'tool_result', (tool_name, result)))
                            
                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": block["id"],
                                "content": result,
                            })
                    
                    # Check if stale or cancelled after processing
                    if my_request_id != self.api_request_id or self.api_cancelled:
                        return
                    
                    self.messages.append({"role": "assistant", "content": content_blocks})
                    if not tool_results:
                        break
                    self.messages.append({"role": "user", "content": tool_results})
                
                self.api_queue.put((my_request_id, 'done', None))
            except StreamCancelled:
                # User cancelled the stream - this is expected, not an error
                self.api_queue.put((my_request_id, 'cancelled', None))
            except Exception as e:
                self.api_queue.put((my_request_id, 'error', str(e)))
        
        self.api_thread = threading.Thread(target=api_worker, daemon=True)
        self.api_thread.start()
    
    def process_api_queue(self):
        """Process events from the API background thread."""
        try:
            while True:
                item = self.api_queue.get_nowait()
                
                # New format: (request_id, event_type, data)
                if len(item) == 3:
                    req_id, event_type, data = item
                    # Ignore events from stale requests
                    if req_id != self.api_request_id:
                        continue
                else:
                    # Legacy format (shouldn't happen)
                    event_type, data = item
                
                if event_type == 'payment':
                    # Remove thinking indicator - payment is happening
                    self.remove_thinking_line()
                    # Initialize payment progress - get token name from network config
                    self._payment_amount = data
                    network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
                    token_name = network_info.get('fee_token_name', 'USD')
                    self._payment_token = token_name
                    self._payment_state = 'init'
                    self.activity_status = "Processing payment..."
                    
                    # Check if we already have an active payment line that should be reused
                    # A line is "active" if _payment_line_idx points to a line starting with "$ "
                    existing_idx = getattr(self, '_payment_line_idx', None)
                    should_reuse = False
                    if existing_idx is not None and 0 <= existing_idx < len(self.output_lines):
                        existing_line = self.output_lines[existing_idx]
                        # Only reuse if it's still a payment progress line (starts with $ or has payment pattern)
                        if existing_line.startswith("$ ") or "○ sign" in existing_line or "✓ sign" in existing_line:
                            should_reuse = True
                    
                    if should_reuse:
                        # Update existing payment line
                        self.output_lines[existing_idx] = f"$ {data:.4f} {token_name}  ○ sign  ○ send  ○ confirm"
                    else:
                        # Create new payment line
                        self.add_output(f"$ {data:.4f} {token_name}  ○ sign  ○ send  ○ confirm")
                        self._payment_line_idx = len(self.output_lines) - 1
                    self.draw()
                elif event_type == 'payment_step':
                    step, status = data
                    amount = getattr(self, '_payment_amount', 0)
                    token = getattr(self, '_payment_token', 'USD')
                    idx = getattr(self, '_payment_line_idx', None)
                    
                    # Track payment state for animation
                    if step == 'signing' and status == 'pending':
                        self._payment_state = 'signing'
                        spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
                        progress = f"$ {amount:.4f} {token}  {spinner} sign  ○ send  ○ confirm"
                    elif step == 'signing' and status == 'done':
                        self._payment_state = 'signed'
                        progress = f"$ {amount:.4f} {token}  ✓ sign  ○ send  ○ confirm"
                    elif step == 'sending' and status == 'pending':
                        self._payment_state = 'sending'
                        spinner = SPINNER_FAST[self.animation_frame % len(SPINNER_FAST)]
                        progress = f"$ {amount:.4f} {token}  ✓ sign  {spinner} send  ○ confirm"
                    elif step == 'sending' and status == 'done':
                        self._payment_state = 'sent'
                        progress = f"$ {amount:.4f} {token}  ✓ sign  ✓ send  ○ confirm"
                    elif step == 'confirming' and status == 'pending':
                        self._payment_state = 'confirming'
                        self._payment_started_at = time.time()
                        # Shuffle messages for variety each time
                        self._shuffled_messages = random.sample(SETTLEMENT_MESSAGES, len(SETTLEMENT_MESSAGES))
                        spinner = SPINNER_PULSE[self.animation_frame % len(SPINNER_PULSE)]
                        progress = f"$ {amount:.4f} {token}  ✓ sign  ✓ send  {spinner} confirm"
                        # Add placeholder line for rotating messages below payment progress
                        self.output_lines.append(f"~ {self._shuffled_messages[0]}")
                        self._payment_msg_line_idx = len(self.output_lines) - 1
                    elif step == 'confirmed':
                        self._payment_state = 'confirmed'
                        tx_hash = status if status else ""
                        # Calculate confirmation time
                        elapsed = time.time() - getattr(self, '_payment_started_at', time.time())
                        # Remove the rotating meme message line entirely
                        msg_idx = getattr(self, '_payment_msg_line_idx', None)
                        if msg_idx is not None and 0 <= msg_idx < len(self.output_lines):
                            self.output_lines.pop(msg_idx)
                            # Adjust payment line idx if it was after the removed line
                            if idx is not None and msg_idx < idx:
                                idx -= 1
                        # Use ~ prefix for grey/dim rendering, full tx hash
                        summary = f"~ ✓ ${amount:.2f} · {elapsed:.1f}s · {tx_hash}"
                        if idx is not None and 0 <= idx < len(self.output_lines):
                            self.output_lines[idx] = summary
                        # Clear all payment state so next payment creates a fresh line
                        self._payment_state = None
                        self._payment_line_idx = None
                        self._payment_msg_line_idx = None
                        self.draw()
                        return
                    else:
                        return
                    
                    # Update the progress line in place
                    if idx is not None and 0 <= idx < len(self.output_lines):
                        self.output_lines[idx] = progress
                    self.draw()
                elif event_type == 'confirm_payment':
                    # Show payment confirmation dialog
                    confirmed = self.show_payment_confirm_dialog(data)
                    self._payment_confirm_result = confirmed
                elif event_type == 'payment_success':
                    # Track session totals
                    tx_hash = data.get("tx_hash", "")
                    amount = data.get("amount_usd", 0)
                    self.session_cost += amount
                    self.session_tx_count += 1
                    
                    # Update user context with payment
                    self.user_context.record_payment(amount, tx_hash)
                    
                    # Store tx for potential click handling
                    network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
                    explorer_url = data.get("explorer_url", f"{network_info['explorer']}/tx/{tx_hash}")
                    self._last_tx = {"hash": tx_hash, "url": explorer_url}
                    # Refresh balance immediately after payment
                    self.last_balance_check = 0
                    self.refresh_balance_async()
                elif event_type == 'status':
                    self.status_message = data
                elif event_type == 'usage':
                    tokens = data.get("tokens", 0)
                    prompt_tokens = data.get("prompt_tokens", 0)
                    self.session_tokens += tokens
                    if prompt_tokens > 0:
                        self.context_tokens = prompt_tokens  # Track current context size
                    # Update user context with token usage
                    if tokens > 0:
                        self.user_context.record_usage(tokens)
                elif event_type == 'text_chunk':
                    # Handle streaming text chunk
                    self.activity_status = "Streaming response..."
                    self.remove_thinking_line()
                    if not hasattr(self, '_streaming_text'):
                        self._streaming_text = ""
                        self._streaming_started = False
                    
                    self._streaming_text += data
                    
                    # Update the display with current streamed text
                    if not self._streaming_started:
                        self._streaming_started = True
                        self.add_output("")
                    
                    # Re-render the streaming lines
                    lines = self._streaming_text.split("\n")
                    # Remove old streaming lines and add updated ones
                    while self.output_lines and self.output_lines[-1].startswith("⏺ "):
                        self.output_lines.pop()
                    for line in lines:
                        self.output_lines.append(f"⏺ {line}")
                    self.scroll_offset = 0
                    self.draw()
                elif event_type == 'text':
                    # Full text (non-streaming fallback)
                    self.add_output("")
                    for text_line in data.split("\n"):
                        self.add_output(f"⏺ {text_line}")
                elif event_type == 'tool_start':
                    # Reset streaming state when tool starts
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    tool_name, tool_args = data
                    self.activity_status = f"Running {tool_name}..."
                    # Store for tool_result to update inline
                    self._current_tool = tool_name
                    self._current_tool_args = tool_args
                    # Format inline like Amp: "○ Read file.py @1-50"
                    tool_display = self._format_tool_call(tool_name, tool_args, pending=True)
                    self.add_output(tool_display)
                    self._tool_line_idx = len(self.output_lines) - 1
                elif event_type == 'tool_result':
                    tool_name, result = data
                    tool_args = getattr(self, '_current_tool_args', {})
                    tool_line_idx = getattr(self, '_tool_line_idx', None)
                    
                    # Update the tool line to show checkmark (completed)
                    tool_display = self._format_tool_call(tool_name, tool_args, pending=False, result=result)
                    if tool_line_idx is not None and 0 <= tool_line_idx < len(self.output_lines):
                        self.output_lines[tool_line_idx] = tool_display
                    
                    # Show diff for edit operations
                    result_lines = result.split("\n")
                    if result.startswith("DIFF:") or result.startswith("WRITE:"):
                        for line in result_lines[1:]:
                            if " + " in line[:8]:
                                self.add_output(f"+DIFF{line}")
                            elif " - " in line[:8]:
                                self.add_output(f"-DIFF{line}")
                    
                    self.draw()
                elif event_type == 'connect_wallet':
                    self.add_output("$ Opening browser to connect wallet...")
                    # This needs special handling - mark for main loop
                    self._pending_wallet_connect = True
                elif event_type == 'done':
                    self.remove_thinking_line()
                    self.api_busy = False
                    self.api_cancelled = False
                    self.status_message = ""
                    self.activity_status = ""
                    # Reset streaming state
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    # Reset payment state
                    for attr in ('_payment_line_idx', '_payment_amount', '_payment_token'):
                        if hasattr(self, attr):
                            delattr(self, attr)
                elif event_type == 'cancelled':
                    self.remove_thinking_line()
                    self.api_busy = False
                    self.api_cancelled = False
                    self.status_message = ""
                    self.activity_status = ""
                    # Reset streaming state
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    # Reset payment state
                    for attr in ('_payment_line_idx', '_payment_amount', '_payment_token'):
                        if hasattr(self, attr):
                            delattr(self, attr)
                    self.add_output("! Cancelled")
                elif event_type == 'error':
                    self.remove_thinking_line()
                    # Reset streaming state
                    if hasattr(self, '_streaming_text'):
                        delattr(self, '_streaming_text')
                    if hasattr(self, '_streaming_started'):
                        delattr(self, '_streaming_started')
                    # Reset payment state
                    for attr in ('_payment_line_idx', '_payment_amount', '_payment_token'):
                        if hasattr(self, attr):
                            delattr(self, attr)
                    error_msg = data
                    logger.error(error_msg)
                    if "402" in error_msg and not self.private_key:
                        self.add_output("")
                        self.add_output("! Payment required - wallet not configured")
                        self.add_output("  Use /wallet to connect and start paying with stablecoins")
                    else:
                        self.add_output(f"! Error: {error_msg}")
                    self.api_busy = False
                    self.status_message = ""
                    self.activity_status = ""
        except queue.Empty:
            pass
    
    def list_skills(self):
        """List available and loaded skills."""
        if self.loaded_skills:
            self.add_output(f"⏺ Loaded skills: {', '.join(self.loaded_skills)}")
        else:
            self.add_output("⏺ No skills loaded")
        
        # Collect skills from both presto package and user config
        available = set()
        
        # Presto built-in skills
        if os.path.isdir(PRESTO_SKILLS_DIR):
            for name in os.listdir(PRESTO_SKILLS_DIR):
                skill_path = os.path.join(PRESTO_SKILLS_DIR, name, "SKILL.md")
                if os.path.isfile(skill_path):
                    available.add(name)
        
        # User skills
        if os.path.isdir(USER_SKILLS_DIR):
            for name in os.listdir(USER_SKILLS_DIR):
                skill_path = os.path.join(USER_SKILLS_DIR, name, "SKILL.md")
                if os.path.isfile(skill_path):
                    available.add(name)
        
        available = sorted(available)
        if available:
            self.add_output(f"  Available: {', '.join(available[:10])}")
            if len(available) > 10:
                self.add_output(f"  ... and {len(available) - 10} more")
        else:
            self.add_output("  No skills found")
    
    def load_skill(self, skill_name):
        """Load a skill by name from presto package or user config."""
        # Check presto built-in skills first
        skill_path = os.path.join(PRESTO_SKILLS_DIR, skill_name, "SKILL.md")
        
        # Fall back to user skills
        if not os.path.isfile(skill_path):
            skill_path = os.path.join(USER_SKILLS_DIR, skill_name, "SKILL.md")
        
        if not os.path.isfile(skill_path):
            self.add_output(f"! Skill not found: {skill_name}")
            self.add_output(f"  Checked: {PRESTO_SKILLS_DIR}/{skill_name}/")
            self.add_output(f"  Checked: {USER_SKILLS_DIR}/{skill_name}/")
            return
        
        try:
            with open(skill_path, 'r') as f:
                content = f.read()
            
            if skill_name in self.loaded_skills:
                self.add_output(f"⏺ Skill already loaded: {skill_name}")
                return
            
            self.loaded_skills.append(skill_name)
            self.skill_instructions += f"\n\n<loaded_skill name=\"{skill_name}\">\n{content}\n</loaded_skill>\n"
            self.add_output(f"⏺ Loaded skill: {skill_name}")
        except Exception as e:
            self.add_output(f"! Error loading skill: {e}")
    
    def get_system_prompt(self):
        """Build system prompt optimized for reliable tool use."""
        tools_summary = get_tools_summary()
        rpc_url = self.get_rpc_url()
        cwd = os.getcwd()
        
        wallet_status = f"Connected: {self.account_address}" if self.account_address else "NOT CONNECTED - use connect_wallet tool to set up"
        
        prompt = f"""You are Presto, a powerful AI coding agent that runs in the terminal. You help users with software engineering tasks.

# Agency
You take initiative. When the user asks you to do something:
1. Use your tools to understand the codebase and context
2. Make changes and complete the task
3. Verify your work (run tests, check for errors)
4. Continue iterating until the task is done

Do not ask for permission or confirmation - just do the work. If something fails, try to fix it.

# Environment
- Working directory: {cwd}
- Network: {self.current_network}
- Wallet: {wallet_status}
- RPC: {rpc_url}

# Tools
{tools_summary}

# How to Work

## Reading and Understanding Code
- Use `glob` to find files by pattern (e.g., "**/*.py", "src/**/*.ts")
- Use `grep` to search for text/patterns in files
- Use `read` to view file contents
- Always explore the codebase before making changes

## Making Changes
- Use `edit` for surgical changes to existing files (provide old_str and new_str)
- Use `write` to create new files or completely rewrite existing ones
- Use `bash` to run commands (build, test, install dependencies)

## Verification
After making changes:
- Run relevant tests if they exist
- Check for syntax/type errors
- Verify the change works as expected

# Style Guide
- Be concise and direct. Skip unnecessary preamble.
- When you use a tool, briefly explain what you're doing and why.
- After completing a task, give a short summary of what you did.
- NEVER use markdown formatting (no **bold**, *italic*, `code`). This is a plain text terminal.
- Link to files by their path when referencing them.

# Blockchain (cast CLI)
For blockchain queries, use bash with Foundry's `cast`:
- `cast call <contract> "function(args)(returnType)" --rpc-url {rpc_url}`
- `cast balance <address> --rpc-url {rpc_url}`
- `cast block-number --rpc-url {rpc_url}`

# Wallet
- "connect wallet" → use connect_wallet tool
- "check balance" → use check_balance tool
- "wallet info" → use wallet_info tool

IMPORTANT: Use tools to get real data. Never guess or fabricate information."""

        if self.skill_instructions:
            prompt += "\n\n# Loaded Skills\n" + self.skill_instructions
        
        # Inject user context for wallet/balance/spending awareness
        prompt += self.user_context.to_prompt_block()
        
        return prompt
    
    def show_history(self):
        if not self.account_address:
            self.add_output("! No wallet connected")
            return
        
        self.add_output("⏺ Fetching transaction history...")
        try:
            chain_id = self.get_chain_id()
            # Query transfers TO this address (received)
            received_query = f'SELECT block_num, "from", value FROM transfer WHERE chain = {chain_id} AND "to" = \'{self.account_address.lower()}\' ORDER BY block_num DESC LIMIT 5'
            # Query transfers FROM this address (sent)
            sent_query = f'SELECT block_num, "to", value FROM transfer WHERE chain = {chain_id} AND "from" = \'{self.account_address.lower()}\' ORDER BY block_num DESC LIMIT 5'
            
            import subprocess
            import json
            
            # Get received transfers
            received_result = subprocess.run(
                ["idxs", "query", received_query, "--signature", "event Transfer(address indexed from, address indexed to, uint256 value)", "--format", "json"],
                capture_output=True, text=True, timeout=30
            )
            # Get sent transfers
            sent_result = subprocess.run(
                ["idxs", "query", sent_query, "--signature", "event Transfer(address indexed from, address indexed to, uint256 value)", "--format", "json"],
                capture_output=True, text=True, timeout=30
            )
            
            received = json.loads(received_result.stdout) if received_result.returncode == 0 and received_result.stdout.strip() else []
            sent = json.loads(sent_result.stdout) if sent_result.returncode == 0 and sent_result.stdout.strip() else []
            
            if not received and not sent:
                self.add_output("  No transactions found")
                return
            
            self.add_output("")
            if received:
                self.add_output("  Received:")
                for tx in received[:5]:
                    value = int(tx.get("value", 0)) / 1e18
                    from_addr = tx.get("from", "?")
                    self.add_output(f"    {value:.4f} from {from_addr}")
            
            if sent:
                self.add_output("  Sent:")
                for tx in sent[:5]:
                    value = int(tx.get("value", 0)) / 1e18
                    to_addr = tx.get("to", "?")
                    self.add_output(f"    {value:.4f} to {to_addr}")
            
            network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
            explorer_url = f"{network_info['explorer']}/address/{self.account_address}"
            self.add_output(f"\n  Full history: {explorer_url}")
            
        except FileNotFoundError:
            self.add_output("! 'idxs' CLI not found")
        except subprocess.TimeoutExpired:
            self.add_output("! Query timed out")
        except Exception as e:
            self.add_output(f"! Error: {e}")
    
    def request_faucet(self, show_command=True):
        """Request testnet funds via tempo_fundAddress RPC."""
        # Show command as user input (conversation style)
        if show_command:
            self.add_output("")
            self.add_output("→ /faucet")
            self.add_output("")
        
        if not self.account_address:
            self.add_output("! No wallet configured. Run /wallet first.")
            return
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        rpc_url = network_info["rpc"]
        fee_token_name = network_info.get("fee_token_name", "tokens")
        
        # Show progress
        self.add_output(f"@ Requesting {fee_token_name} from faucet...")
        self.draw()
        
        try:
            import subprocess
            import json
            
            # Fund BOTH master wallet and access key (access key pays for gas)
            addresses_to_fund = [("Wallet", self.account_address)]
            if self.access_key_address and self.access_key_address != self.account_address:
                addresses_to_fund.append(("Access Key", self.access_key_address))
            
            total_tokens = 0
            all_tx_hashes = []
            
            for label, addr in addresses_to_fund:
                req_body = json.dumps({
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tempo_fundAddress",
                    "params": [addr],
                })
                
                result = subprocess.run(
                    ["curl", "-s", "-X", "POST", rpc_url,
                     "-H", "Content-Type: application/json",
                     "-d", req_body],
                    capture_output=True, text=True, timeout=30
                )
                
                response = json.loads(result.stdout)
                
                if "error" in response:
                    error_msg = response["error"].get("message", "Unknown error")
                    self.add_output(f"  ✗ {label}: {error_msg}")
                    continue
                
                tx_hashes = response.get("result", [])
                if tx_hashes:
                    total_tokens += len(tx_hashes)
                    for tx_hash in tx_hashes:
                        all_tx_hashes.append((label, tx_hash))
            
            if total_tokens > 0:
                # Replace progress with success
                self.output_lines[-1] = f"✓ Received {total_tokens} token(s)!"
                for label, tx_hash in all_tx_hashes:
                    self.add_output(f"  {label}: {tx_hash}")
                # Force balance refresh after short delay for indexing
                self.cached_balance = None
                self.last_balance_check = 0
                time.sleep(1)  # Wait for tx to be indexed
                self.refresh_balance_async()
            else:
                self.output_lines[-1] = "✓ Faucet request sent"
                
        except subprocess.TimeoutExpired:
            self.output_lines[-1] = "✗ Faucet request timed out"
        except json.JSONDecodeError:
            self.output_lines[-1] = "✗ Invalid response from faucet"
        except Exception as e:
            self.output_lines[-1] = f"✗ Faucet error: {e}"
    
    def open_portal(self):
        """Open a local web portal showing wallet info."""
        import http.server
        import webbrowser
        import threading
        import socket
        
        # Find a free port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            port = s.getsockname()[1]
        
        # Get balance from cache
        balance = self.cached_balance or "..."
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        explorer_url = network_info.get("explorer", "https://explore.tempo.xyz")
        rpc_url = network_info["rpc"]
        chain_id = network_info["chain_id"]
        
        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Presto · Wallet</title>
<style>
:root {{
  --bg-primary: #111111;
  --bg-surface: #1a1a1a;
  --bg-card: #222222;
  --bg-card-header: #191919;
  --border-primary: #262626;
  --border-secondary: #2a2a2a;
  --content-primary: #f5f5f5;
  --content-secondary: #a0a0a0;
  --content-tertiary: #6e6e6e;
  --content-positive: #22c55e;
  --accent: #60a5fa;
  --accent-dim: rgba(96, 165, 250, 0.1);
  --font-display: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
  --font-mono: ui-monospace, 'SF Mono', Menlo, Monaco, monospace;
}}
*, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
html {{ background: var(--bg-primary); color: var(--content-primary); }}
body {{ font-family: var(--font-display); min-height: 100vh; line-height: 1.5; }}

.header {{
  border-bottom: 1px solid var(--border-primary);
  padding: 16px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: var(--bg-surface);
}}
.header-left {{ display: flex; align-items: center; gap: 12px; }}
.tempo-wordmark {{ height: 24px; width: auto; fill: var(--content-primary); }}
.presto-badge {{
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 8px;
  background: var(--accent-dim);
  border: 1px solid rgba(96, 165, 250, 0.2);
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--accent);
}}
.badge {{
  background: var(--bg-card);
  border: 1px solid var(--border-secondary);
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  color: var(--content-secondary);
  text-decoration: none;
}}
.badge:hover {{ background: var(--bg-card-header); }}
.badge.live {{ color: var(--content-positive); }}
.badge.live::before {{ content: '●'; margin-right: 6px; }}

.main {{ max-width: 720px; margin: 0 auto; padding: 32px 24px; }}

.balance-card {{
  background: linear-gradient(135deg, #1a1a2e 0%, #1a1a1a 100%);
  border: 1px solid #2a2a3a;
  border-radius: 16px;
  padding: 32px;
  margin-bottom: 24px;
}}
.balance-label {{ font-size: 13px; color: var(--content-tertiary); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }}
.balance-value {{ font-size: 42px; font-weight: 600; color: var(--accent); font-variant-numeric: tabular-nums; }}
.balance-value .symbol {{ font-size: 24px; color: var(--content-secondary); margin-left: 8px; }}

.section {{ margin-bottom: 24px; }}
.section-title {{ font-size: 11px; color: var(--content-tertiary); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; font-weight: 500; }}

.card {{
  background: var(--bg-card);
  border: 1px solid var(--border-secondary);
  border-radius: 12px;
  overflow: hidden;
}}
.card-row {{
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-primary);
}}
.card-row:last-child {{ border-bottom: none; }}
.card-row:hover {{ background: var(--bg-card-header); }}
.card-label {{ color: var(--content-secondary); font-size: 14px; }}
.card-value {{ font-family: var(--font-mono); font-size: 13px; color: var(--content-primary); }}
.card-value a {{ color: var(--accent); text-decoration: none; }}
.card-value a:hover {{ text-decoration: underline; }}
.card-value.full {{ word-break: break-all; }}

.address-card {{
  background: var(--bg-card);
  border: 1px solid var(--border-secondary);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 12px;
}}
.address-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
.address-type {{ font-size: 12px; color: var(--content-tertiary); text-transform: uppercase; letter-spacing: 0.5px; }}
.address-value {{
  font-family: var(--font-mono);
  font-size: 14px;
  color: var(--content-primary);
  word-break: break-all;
  background: var(--bg-card-header);
  padding: 12px 16px;
  border-radius: 8px;
  border: 1px solid var(--border-primary);
}}
.address-value a {{ color: inherit; text-decoration: none; }}
.address-value a:hover {{ color: var(--accent); }}
.address-note {{ font-size: 12px; color: var(--content-tertiary); margin-top: 8px; }}

.copy-btn {{
  background: var(--bg-card-header);
  border: 1px solid var(--border-secondary);
  color: var(--content-secondary);
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s;
}}
.copy-btn:hover {{ background: var(--border-secondary); color: var(--content-primary); }}

.tx-list {{ max-height: 300px; overflow-y: auto; }}
.tx-row {{
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 20px;
  border-bottom: 1px solid var(--border-primary);
  font-size: 13px;
}}
.tx-row:last-child {{ border-bottom: none; }}
.tx-hash {{ font-family: var(--font-mono); color: var(--accent); text-decoration: none; }}
.tx-hash:hover {{ text-decoration: underline; }}
.tx-amount {{ font-family: var(--font-mono); }}
.tx-amount.positive {{ color: var(--content-positive); }}
.tx-amount.negative {{ color: #ef4444; }}

.loading {{ color: var(--content-tertiary); padding: 20px; text-align: center; }}
.empty {{ color: var(--content-tertiary); padding: 20px; text-align: center; font-size: 14px; }}

@keyframes pulse {{ 0%, 100% {{ opacity: 1; }} 50% {{ opacity: 0.5; }} }}
.loading {{ animation: pulse 1.5s ease-in-out infinite; }}
</style>
</head>
<body>

<header class="header">
  <div class="header-left">
    <svg class="tempo-wordmark" viewBox="0 0 102 25" aria-label="Tempo" role="img">
      <path d="M95.1 16.1c1.74 0 3.35-1.25 3.35-3.73 0-2.49-1.6-3.74-3.34-3.74-1.74 0-3.34 1.25-3.34 3.74 0 2.48 1.6 3.74 3.34 3.74Zm0-10.7c3.93 0 6.9 2.9 6.9 6.97a6.73 6.73 0 0 1-6.9 6.97 6.75 6.75 0 0 1-6.88-6.97A6.75 6.75 0 0 1 95.1 5.4ZM77.34 24.01h-3.56V5.8h3.45v1.6c.59-1.01 2.06-1.9 4.03-1.9 3.85 0 6.07 2.94 6.07 6.84s-2.49 6.92-6.2 6.92c-1.82 0-3.15-.72-3.8-1.6V24Zm6.49-11.64c0-2.33-1.45-3.69-3.26-3.69-1.82 0-3.29 1.36-3.29 3.69 0 2.32 1.47 3.71 3.29 3.71 1.81 0 3.26-1.36 3.26-3.71ZM56 18.94h-3.56V5.8h3.39v1.6c.72-1.28 2.4-1.98 3.85-1.98 1.79 0 3.23.78 3.9 2.2a4.57 4.57 0 0 1 4.16-2.2c2.43 0 4.76 1.47 4.76 5v8.52h-3.45v-7.8c0-1.42-.7-2.48-2.32-2.48-1.52 0-2.43 1.17-2.43 2.59v7.69h-3.53v-7.8c0-1.42-.72-2.48-2.32-2.48-1.6 0-2.46 1.14-2.46 2.59v7.69Zm-14.13-8.07h5.87c-.05-1.3-.9-2.59-2.93-2.59a2.84 2.84 0 0 0-2.94 2.6Zm6.22 3.42 2.97.88c-.67 2.27-2.75 4.17-5.99 4.17-3.6 0-6.78-2.6-6.78-7.03 0-4.2 3.1-6.92 6.46-6.92 4.06 0 6.5 2.6 6.5 6.82 0 .5-.06 1.04-.06 1.1h-9.4c.08 1.73 1.55 2.98 3.31 2.98 1.66 0 2.56-.83 3-2Z" />
      <path d="M41.08 3.5H35.1v15.44h-3.71V3.5H25.4V0h15.68v3.5Z" />
      <path fill-rule="evenodd" clip-rule="evenodd" d="M18.96 18.95H0V.01h18.96v18.94ZM6.46 5.26a.27.27 0 0 0-.25.19l-.82 2.44c-.03.1.04.19.13.19H7.9c.1 0 .16.09.13.18l-1.75 5.25c-.03.1.04.19.14.19h2.53c.12 0 .22-.08.26-.19l1.75-5.25a.27.27 0 0 1 .25-.18h2.37c.12 0 .22-.08.26-.19l.81-2.44a.14.14 0 0 0-.13-.19H6.46Z" />
    </svg>
    <span class="presto-badge">Presto</span>
    <span class="badge live">{network_info["name"]}</span>
  </div>
  <div class="header-left">
    <a href="{explorer_url}" target="_blank" class="badge">Explorer ↗</a>
    {'<a href="' + network_info.get("faucet", "") + '" target="_blank" class="badge">Faucet ↗</a>' if network_info.get("faucet") else ''}
  </div>
</header>

<main class="main">
  <div class="balance-card">
    <div class="balance-label">{network_info.get("fee_token_name", "Token")} Balance</div>
    <div class="balance-value" id="balance">{balance}<span class="symbol">{network_info.get("fee_token_name", "")}</span></div>
    <button id="faucet-btn" onclick="requestFaucet()" style="margin-top: 16px; padding: 12px 24px; background: var(--accent); color: #000; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer;">💧 Get Testnet Funds</button>
    <div id="faucet-status" style="margin-top: 8px; font-size: 13px; color: var(--content-secondary);"></div>
  </div>

  <div class="section">
    <div class="section-title">Addresses</div>
    <div class="address-card">
      <div class="address-header">
        <span class="address-type">Wallet</span>
        <button class="copy-btn" onclick="copy('{self.account_address}')">Copy</button>
      </div>
      <div class="address-value">
        <a href="{explorer_url}/address/{self.account_address}" target="_blank">{self.account_address}</a>
      </div>
    </div>
    <div class="address-card">
      <div class="address-header">
        <span class="address-type">Access Key</span>
        <button class="copy-btn" onclick="copy('{self.access_key_address}')">Copy</button>
      </div>
      <div class="address-value">
        <a href="{explorer_url}/address/{self.access_key_address}" target="_blank">{self.access_key_address}</a>
      </div>
      <div class="address-note">Signs transactions on behalf of your wallet</div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Recent Transactions</div>
    <div class="card">
      <div class="tx-list" id="txList">
        <div class="loading">Loading transactions...</div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Configuration</div>
    <div class="card">
      <div class="card-row">
        <span class="card-label">Network</span>
        <span class="card-value">{network_info["name"]}</span>
      </div>
      <div class="card-row">
        <span class="card-label">Chain ID</span>
        <span class="card-value">{chain_id}</span>
      </div>
      <div class="card-row">
        <span class="card-label">RPC</span>
        <span class="card-value truncate">{rpc_url}</span>
      </div>
      <div class="card-row">
        <span class="card-label">Config</span>
        <span class="card-value truncate">{CONFIG_FILE}</span>
      </div>
    </div>
  </div>
</main>

<script>
const RPC = '{rpc_url}';
const WALLET = '{self.account_address}';
const ASSET = '{network_info.get("fee_token", "0x20c0000000000000000000000000000001")}';
const EXPLORER = '{explorer_url}';
const NETWORK = '{self.current_network}';
const FEE_TOKEN_NAME = '{network_info.get("fee_token_name", "tokens")}';

function copy(text) {{
  navigator.clipboard.writeText(text);
  event.target.textContent = 'Copied!';
  setTimeout(() => event.target.textContent = 'Copy', 1500);
}}

async function rpcCall(method, params) {{
  const res = await fetch(RPC, {{
    method: 'POST',
    headers: {{ 'Content-Type': 'application/json' }},
    body: JSON.stringify({{ jsonrpc: '2.0', id: 1, method, params }})
  }});
  return (await res.json()).result;
}}

async function loadBalance() {{
  const data = '0x70a08231000000000000000000000000' + WALLET.slice(2);
  const result = await rpcCall('eth_call', [{{ to: ASSET, data }}, 'latest']);
  if (result) {{
    const balance = parseInt(result, 16) / 1e6;
    document.getElementById('balance').innerHTML = '$' + balance.toFixed(2) + '<span class="symbol">' + FEE_TOKEN_NAME + '</span>';
  }}
}}

async function loadTransactions() {{
  const txList = document.getElementById('txList');
  try {{
    // Get recent blocks and scan for Transfer events
    const latest = await rpcCall('eth_blockNumber', []);
    const from = Math.max(0, parseInt(latest, 16) - 1000);
    
    const logs = await rpcCall('eth_getLogs', [{{
      fromBlock: '0x' + from.toString(16),
      toBlock: 'latest',
      address: ASSET,
      topics: [
        '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',
        null,
        '0x000000000000000000000000' + WALLET.slice(2).toLowerCase()
      ]
    }}]);
    
    const outLogs = await rpcCall('eth_getLogs', [{{
      fromBlock: '0x' + from.toString(16),
      toBlock: 'latest',
      address: ASSET,
      topics: [
        '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',
        '0x000000000000000000000000' + WALLET.slice(2).toLowerCase()
      ]
    }}]);
    
    const allLogs = [...(logs || []).map(l => ({{...l, dir: 'in'}})), ...(outLogs || []).map(l => ({{...l, dir: 'out'}}))];
    allLogs.sort((a, b) => parseInt(b.blockNumber, 16) - parseInt(a.blockNumber, 16));
    
    if (allLogs.length === 0) {{
      txList.innerHTML = '<div class="empty">No transactions yet</div>';
      return;
    }}
    
    txList.innerHTML = allLogs.slice(0, 10).map(log => {{
      const amount = parseInt(log.data, 16) / 1e6;
      const isIn = log.dir === 'in';
      return `<div class="tx-row">
        <a href="${{EXPLORER}}/tx/${{log.transactionHash}}" target="_blank" class="tx-hash">
          ${{log.transactionHash}}
        </a>
        <span class="tx-amount ${{isIn ? 'positive' : 'negative'}}">
          ${{isIn ? '+' : '-'}}$${{amount.toFixed(2)}}
        </span>
      </div>`;
    }}).join('');
  }} catch (e) {{
    txList.innerHTML = '<div class="empty">Could not load transactions</div>';
  }}
}}

async function requestFaucet() {{
  const btn = document.getElementById('faucet-btn');
  const status = document.getElementById('faucet-status');
  btn.disabled = true;
  btn.textContent = 'Requesting funds...';
  status.textContent = '';
  
  try {{
    // Fund wallet address
    const walletResult = await rpcCall('tempo_fundAddress', [WALLET]);
    // Fund access key address
    const accessKeyAddr = '{self.access_key_address}';
    if (accessKeyAddr && accessKeyAddr !== WALLET) {{
      await rpcCall('tempo_fundAddress', [accessKeyAddr]);
    }}
    
    btn.textContent = '✓ Funds received!';
    btn.style.background = 'var(--content-positive)';
    status.innerHTML = 'Tokens sent! <a href="' + EXPLORER + '/address/' + WALLET + '" target="_blank">View on explorer</a>';
    
    // Refresh balance after a delay
    setTimeout(loadBalance, 2000);
  }} catch (e) {{
    btn.textContent = '💧 Get Testnet Funds';
    btn.disabled = false;
    status.textContent = 'Error: ' + (e.message || 'Failed to get funds');
    status.style.color = '#ef4444';
  }}
}}

loadBalance();
loadTransactions();
setInterval(loadBalance, 30000);
</script>
</body>
</html>'''
        
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(html.encode())
        
        server = http.server.HTTPServer(("127.0.0.1", port), Handler)
        
        def serve():
            server.handle_request()
            server.server_close()
        
        thread = threading.Thread(target=serve, daemon=True)
        thread.start()
        
        url = f"http://127.0.0.1:{port}"
        webbrowser.open(url)
        self.add_output(f"⏺ Opened portal: {url}")
    
    def show_command_palette(self):
        """Display command palette as overlay dialog."""
        # Different commands based on wallet state
        if not self.private_key:
            commands = [
                ("wallet", "connect", "Connect wallet → pay with stablecoins", "/wallet"),
                ("faucet", "funds", "Get free testnet funds", "/faucet"),
                ("model", "select", "Change AI model", "/model"),
                ("presto", "help", "Show keyboard shortcuts", ""),
                ("presto", "quit", "Exit presto", "Ctrl+C"),
            ]
        else:
            commands = [
                ("presto", "help", "Show keyboard shortcuts", ""),
                ("presto", "usage", "Show session usage & costs", "/usage"),
                ("model", "select", "Change AI model", "/model"),
        
                ("wallet", "faucet", "Get testnet funds", "/faucet"),
                ("wallet", "info", "Show wallet details", "/wallet"),
                ("wallet", "portal", "Open web portal", "/portal"),
                ("wallet", "renew", "Create new access key", "/newkey"),
                ("network", "switch", "Show/switch network", "/network"),
                ("history", "transactions", "Show tx history", "/history"),
                ("presto", "clear", "Clear conversation", "/clear"),
                ("presto", "quit", "Exit presto", "Ctrl+C"),
            ]
        
        height, width = self.get_dims()
        
        dialog_width = min(60, width - 4)
        dialog_height = min(len(commands) + 6, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        search_buffer = ""
        selected_idx = 0
        
        while True:
            filtered = [c for c in commands if search_buffer.lower() in f"{c[0]} {c[1]} {c[2]}".lower()]
            if selected_idx >= len(filtered):
                selected_idx = max(0, len(filtered) - 1)
            
            self.draw()
            
            try:
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                title = "Command Palette"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(2) | curses.A_BOLD)
                
                self.stdscr.addstr(dialog_y + 2, dialog_x + 2, "> ", curses.color_pair(3) | curses.A_BOLD)
                self.stdscr.addstr(dialog_y + 2, dialog_x + 4, search_buffer[:dialog_width - 8])
                
                self.stdscr.addstr(dialog_y + 3, dialog_x + 1, "─" * (dialog_width - 2), curses.color_pair(1) | curses.A_DIM)
                
                max_items = dialog_height - 6
                for i, cmd in enumerate(filtered[:max_items]):
                    y = dialog_y + 4 + i
                    cat, name, desc, action = cmd
                    
                    if i == selected_idx:
                        self.stdscr.addstr(y, dialog_x + 2, " " * (dialog_width - 4), curses.color_pair(4) | curses.A_REVERSE)
                        self.stdscr.addstr(y, dialog_x + 3, f"{cat:>8}", curses.color_pair(4) | curses.A_REVERSE)
                        self.stdscr.addstr(y, dialog_x + 13, name[:25], curses.color_pair(4) | curses.A_REVERSE | curses.A_BOLD)
                        if action:
                            self.stdscr.addstr(y, dialog_x + dialog_width - len(action) - 4, action, curses.color_pair(4) | curses.A_REVERSE)
                    else:
                        self.stdscr.addstr(y, dialog_x + 3, f"{cat:>8}", curses.A_DIM)
                        self.stdscr.addstr(y, dialog_x + 13, name[:25])
                        if action:
                            self.stdscr.addstr(y, dialog_x + dialog_width - len(action) - 4, action, curses.A_DIM)
                
                help_text = "↑↓ Nav  ⏎ Select  Esc Close"
                help_x = dialog_x + (dialog_width - len(help_text)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, help_x, help_text, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == 15 or ch == 16:  # Escape, Ctrl+O, Ctrl+P (toggle)
                break
            elif ch == curses.KEY_UP:
                selected_idx = max(0, selected_idx - 1)
            elif ch == curses.KEY_DOWN:
                selected_idx = min(len(filtered) - 1, selected_idx + 1)
            elif ch == 10 or ch == 13:  # Enter
                # Check if search_buffer is a direct command (starts with /)
                if search_buffer.startswith('/'):
                    self.process_command(search_buffer.strip())
                    break
                # Otherwise execute selected palette item
                if filtered and selected_idx < len(filtered):
                    cmd = filtered[selected_idx]
                    self.execute_palette_command(cmd)
                break
            elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                search_buffer = search_buffer[:-1]
            elif ch != -1 and 32 <= ch <= 126:
                search_buffer += chr(ch)
        
        self.draw()
    
    def show_payment_confirm_dialog(self, amount_usd: float) -> bool:
        """Show payment confirmation dialog. Returns True if confirmed, False if declined."""
        # If auto-approve is enabled, skip dialog
        if getattr(self, '_auto_approve_payments', False):
            self.add_output(f"$ Auto-approved: ${amount_usd:.4f}")
            return True
        
        height, width = self.get_dims()
        
        dialog_width = min(50, width - 4)
        dialog_height = 12
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Get token name for display
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        token_name = network_info.get('fee_token_name', 'USD')
        
        # Format amount nicely
        if amount_usd < 0.01:
            amount_display = f"${amount_usd:.4f} {token_name}"
        else:
            amount_display = f"${amount_usd:.2f} {token_name}"
        
        # Get short model name
        model_short = self.current_model.split("/")[-1]
        
        # 0 = Pay, 1 = Always pay, 2 = Cancel
        options = [
            ("Pay", curses.color_pair(3)),
            ("Always", curses.color_pair(2)),
            ("Cancel", curses.color_pair(5)),
        ]
        selected = 0
        
        while True:
            self.draw()
            
            try:
                # Draw compact dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(4))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(4))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(4))
                
                # Title
                title = "Authorize Payment"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.color_pair(4) | curses.A_BOLD)
                
                # Amount - larger, centered
                amount_x = dialog_x + (dialog_width - len(amount_display)) // 2
                self.stdscr.addstr(dialog_y + 3, amount_x, amount_display, curses.A_BOLD | curses.color_pair(3))
                
                # Model info (dimmed)
                model_line = f"→ {model_short}"
                model_x = dialog_x + (dialog_width - len(model_line)) // 2
                self.stdscr.addstr(dialog_y + 4, model_x, model_line, curses.A_DIM)
                
                # Value prop (dimmed)
                prop_line = "Pay per request · No subscription"
                prop_x = dialog_x + (dialog_width - len(prop_line)) // 2
                self.stdscr.addstr(dialog_y + 5, prop_x, prop_line, curses.A_DIM | curses.color_pair(2))
                
                # Horizontal options on single line
                opt_y = dialog_y + 7
                total_width = sum(len(label) + 4 for label, _ in options) + 4
                start_x = dialog_x + (dialog_width - total_width) // 2
                
                x = start_x
                for i, (label, color) in enumerate(options):
                    if i == selected:
                        self.stdscr.addstr(opt_y, x, f"[{label}]", color | curses.A_BOLD | curses.A_REVERSE)
                    else:
                        self.stdscr.addstr(opt_y, x, f" {label} ", curses.A_DIM)
                    x += len(label) + 4
                
                # Keyboard hints
                hint = "←→ select · enter confirm · esc cancel"
                hint_x = dialog_x + (dialog_width - len(hint)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, hint_x, hint, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            
            ch = self.stdscr.getch()
            
            if ch == curses.KEY_LEFT or ch == ord('h'):
                selected = (selected - 1) % len(options)
            elif ch == curses.KEY_RIGHT or ch == ord('l'):
                selected = (selected + 1) % len(options)
            elif ch == curses.KEY_UP or ch == ord('k'):
                selected = (selected - 1) % len(options)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                selected = (selected + 1) % len(options)
            elif ch == 10 or ch == 13:  # Enter
                if selected == 0:  # Pay
                    return True
                elif selected == 1:  # Always
                    self._auto_approve_payments = True
                    return True
                else:  # Cancel
                    return False
            elif ch == ord('p') or ch == ord('P') or ch == ord('y') or ch == ord('Y'):
                return True
            elif ch == ord('a') or ch == ord('A'):
                self._auto_approve_payments = True
                return True
            elif ch == ord('c') or ch == ord('C') or ch == ord('n') or ch == ord('N') or ch == 27:
                return False
        
        return False
    
    def execute_palette_command(self, cmd):
        """Execute a command from the palette."""
        cat, name, desc, action = cmd
        
        # Show the command as user input (like regular messages)
        if action:
            self.add_output("")
            self.add_output(f"→ {action}")
            self.add_output("")
        
        if name == "help":
            self.show_help()
        elif name == "usage":
            self.show_usage_dialog()
        elif name == "connect":
            self.create_new_access_key()
        elif name == "info" and cat == "wallet":
            self.process_command("/wallet")
        elif name == "faucet":
            self.request_faucet(show_command=False)
        elif name == "portal":
            self.open_portal()
        elif name == "renew" or name == "new key":
            self.create_new_access_key()
        elif name == "funds":
            self.request_faucet(show_command=False)
        elif name == "select" and cat == "model":
            self.show_model_selector()
        elif name == "info" and cat == "network":
            self.process_command("/network")
        elif name == "switch":
            self.add_output("⏺ Use /network <name> to switch (mainnet, moderato)")
        elif name == "transactions":
            self.show_history()
        elif name == "clear":
            self.output_lines = []
            self.add_welcome_to_history()
        elif name == "quit":
            self.running = False
    
    def show_help(self):
        """Display help panel overlay."""
        help_content = [
            ("", "Presto - Help & Keyboard Shortcuts", "title"),
            ("", "", ""),
            ("", "Navigation", "section"),
            ("↑, ↓", "Scroll output up/down", ""),
            ("Ctrl+P", "Open command palette", ""),
            ("", "", ""),
            ("", "Editing", "section"),
            ("Ctrl+U", "Clear input line", ""),
            ("Ctrl+A", "Jump to start of line", ""),
            ("Ctrl+E", "Jump to end of line", ""),
            ("←, →", "Move cursor left/right", ""),
            ("Backspace", "Delete character backward", ""),
            ("Enter", "Submit input", ""),
            ("", "", ""),
            ("", "Commands", "section"),
            ("/help", "Show this help panel", ""),
            ("/usage", "Show session usage & costs", ""),
            ("/model", "Change AI model", ""),
            ("/wallet", "Connect wallet → pay with stablecoins", ""),
            ("/newkey", "Create new access key", ""),
            ("/faucet", "Get free testnet funds", ""),
            ("/portal", "Open web portal", ""),
            ("/network", "Show/switch network", ""),
            ("/skills", "List available skills", ""),
            ("/clear", "Clear conversation", ""),
            ("", "", ""),
            ("", "Exit", "section"),
            ("/quit", "Exit presto", ""),
            ("Ctrl+C, Ctrl+D", "Exit presto", ""),
        ]
        
        height, width = self.get_dims()
        dialog_width = min(70, width - 4)
        dialog_height = min(len(help_content) + 4, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        scroll_offset = 0
        max_visible = dialog_height - 4
        
        while True:
            self.draw()
            
            try:
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                visible_content = help_content[scroll_offset:scroll_offset + max_visible]
                for i, (key, desc, style) in enumerate(visible_content):
                    y = dialog_y + 2 + i
                    if style == "title":
                        title_x = dialog_x + (dialog_width - len(desc)) // 2
                        self.stdscr.addstr(y, title_x, desc, curses.color_pair(2) | curses.A_BOLD)
                    elif style == "section":
                        self.stdscr.addstr(y, dialog_x + 4, desc, curses.color_pair(3) | curses.A_BOLD)
                    elif key:
                        self.stdscr.addstr(y, dialog_x + 8, f"{key:20}", curses.color_pair(4))
                        self.stdscr.addstr(y, dialog_x + 30, desc[:dialog_width - 34])
                
                footer = "Press Escape to close • Use ↑↓ or j/k to scroll"
                footer_x = dialog_x + (dialog_width - len(footer)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, footer_x, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape or q
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                scroll_offset = max(0, scroll_offset - 1)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                scroll_offset = min(max(0, len(help_content) - max_visible), scroll_offset + 1)
        
        self.draw()
    
    def show_wallet_dialog(self):
        """Display wallet info panel overlay with access key management."""
        import time as time_module
        
        network = self.get_network_name()
        network_info = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
        
        # Track selected key for switching
        selected_key_idx = self.wallet.active_key_index if self.wallet else 0
        
        height, width = self.get_dims()
        dialog_width = min(80, width - 4)
        dialog_height = min(30, height - 4)
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        scroll_offset = 0
        
        while True:
            # Rebuild content each loop (in case of key switch)
            wallet_content = [
                ("", "Wallet Connection", "title"),
                ("", "", ""),
            ]
            
            if self.account_address:
                wallet_content.extend([
                    ("", "Master Wallet", "section"),
                    ("Address", self.account_address, ""),
                    ("Balance", self.cached_balance or "Loading...", ""),
                    ("", "", ""),
                    ("", "Network", "section"),
                    ("Name", network_info["name"], ""),
                    ("Chain ID", str(network_info["chain_id"]), ""),
                    ("", "", ""),
                ])
                
                # Show all access keys
                if self.wallet and self.wallet.access_keys:
                    wallet_content.append(("", f"Access Keys ({len(self.wallet.access_keys)})", "section"))
                    
                    for idx, key in enumerate(self.wallet.access_keys):
                        is_active = idx == self.wallet.active_key_index
                        is_selected = idx == selected_key_idx
                        
                        # Build key display - full address (no truncation)
                        key_addr = key.address
                        status = key.time_remaining
                        
                        if key.is_expired:
                            style = "key_expired"
                        elif key.expires_soon:
                            style = "key_warning"
                        elif is_selected:
                            style = "key_selected"
                        elif is_active:
                            style = "key_active"
                        else:
                            style = "key"
                        
                        prefix = "● " if is_active else "  "
                        selector = "▶ " if is_selected else "  "
                        wallet_content.append((f"{selector}{prefix}Key {idx + 1}", f"{key_addr}  [{status}]", style))
                    
                    wallet_content.append(("", "", ""))
                    wallet_content.append(("", "↑↓ Select • Enter Switch • N New key", "hint"))
                else:
                    wallet_content.append(("", "Access Keys", "section"))
                    wallet_content.append(("", "No access keys configured", "warning"))
                    wallet_content.append(("", "Press N to create a new access key", "hint"))
            else:
                wallet_content.extend([
                    ("", "No wallet connected", "error"),
                    ("", "", ""),
                    ("", "Run /newkey to connect a wallet", ""),
                ])
            
            max_visible = dialog_height - 4
            
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                visible_content = wallet_content[scroll_offset:scroll_offset + max_visible]
                for i, (key, value, style) in enumerate(visible_content):
                    y = dialog_y + 2 + i
                    if style == "title":
                        title_x = dialog_x + (dialog_width - len(value)) // 2
                        self.stdscr.addstr(y, title_x, value, curses.color_pair(2) | curses.A_BOLD)
                    elif style == "section":
                        self.stdscr.addstr(y, dialog_x + 4, value, curses.color_pair(3) | curses.A_BOLD)
                    elif style == "error":
                        self.stdscr.addstr(y, dialog_x + 4, value, curses.color_pair(5))
                    elif style == "warning":
                        self.stdscr.addstr(y, dialog_x + 8, f"{key:16}", curses.color_pair(4))
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(4))
                    elif style == "hint":
                        hint_x = dialog_x + (dialog_width - len(value)) // 2
                        self.stdscr.addstr(y, hint_x, value, curses.A_DIM)
                    elif style == "key_selected":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.A_REVERSE | curses.A_BOLD)
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.A_REVERSE)
                    elif style == "key_active":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.color_pair(3) | curses.A_BOLD)
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(3))
                    elif style == "key_expired":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.color_pair(5))
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(5))
                    elif style == "key_warning":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.color_pair(4))
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30], curses.color_pair(4))
                    elif style == "key":
                        self.stdscr.addstr(y, dialog_x + 6, f"{key:18}", curses.A_DIM)
                        self.stdscr.addstr(y, dialog_x + 26, value[:dialog_width - 30])
                    elif key:
                        self.stdscr.addstr(y, dialog_x + 8, f"{key:14}", curses.A_DIM)
                        self.stdscr.addstr(y, dialog_x + 24, value[:dialog_width - 28])
                    elif value:
                        self.stdscr.addstr(y, dialog_x + 4, value[:dialog_width - 8], curses.A_DIM)
                
                footer = "Esc Close"
                footer_x = dialog_x + (dialog_width - len(footer)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, footer_x, footer, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape or q
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                if self.wallet and self.wallet.access_keys:
                    selected_key_idx = max(0, selected_key_idx - 1)
                else:
                    scroll_offset = max(0, scroll_offset - 1)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                if self.wallet and self.wallet.access_keys:
                    selected_key_idx = min(len(self.wallet.access_keys) - 1, selected_key_idx + 1)
                else:
                    scroll_offset = min(max(0, len(wallet_content) - max_visible), scroll_offset + 1)
            elif ch == 10 or ch == 13:  # Enter - switch to selected key
                if self.wallet and self.wallet.access_keys and selected_key_idx != self.wallet.active_key_index:
                    self.wallet.switch_to_key(selected_key_idx)
                    # Update legacy fields
                    active_key = self.wallet.active_key
                    if active_key:
                        self.private_key = active_key.private_key
                        self.access_key_address = active_key.address
                        self.key_expiry = active_key.expiry
                    # Save config
                    save_config(self.wallet.to_dict(), CONFIG_FILE)
                    self.add_output(f"$ Switched to access key {selected_key_idx + 1}")
                    break
            elif ch == ord('n') or ch == ord('N'):  # New key
                break  # Close dialog, will trigger /newkey after
        
        self.draw()
        
        # If user pressed N, create new key
        if ch == ord('n') or ch == ord('N'):
            self.create_new_access_key()
    
    def show_model_selector(self):
        """Display model selection popup near the model box."""
        height, width = self.get_dims()
        
        # Find current model index
        current_idx = 0
        for i, (model_id, _) in enumerate(AVAILABLE_MODELS):
            if model_id == self.current_model:
                current_idx = i
                break
        
        selected_idx = current_idx
        
        # Calculate popup dimensions
        max_name_len = max(len(name) for _, name in AVAILABLE_MODELS)
        popup_width = max_name_len + 6
        popup_height = len(AVAILABLE_MODELS) + 2
        
        # Position popup in center of screen
        popup_x = max(1, (width - popup_width) // 2)
        popup_y = max(1, (height - popup_height) // 2)
        
        while True:
            self.draw()
            
            try:
                # Draw popup background
                for i in range(popup_height):
                    y = popup_y + i
                    if i == 0:
                        self.stdscr.addstr(y, popup_x, "╭" + "─" * (popup_width - 2) + "╮", curses.color_pair(1))
                    elif i == popup_height - 1:
                        self.stdscr.addstr(y, popup_x, "╰" + "─" * (popup_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, popup_x, "│" + " " * (popup_width - 2) + "│", curses.color_pair(1))
                
                # Draw model options
                for i, (model_id, model_name) in enumerate(AVAILABLE_MODELS):
                    y = popup_y + 1 + i
                    is_selected = i == selected_idx
                    is_current = model_id == self.current_model
                    
                    if is_selected:
                        attr = curses.A_REVERSE
                    elif is_current:
                        attr = curses.color_pair(3)
                    else:
                        attr = 0
                    
                    prefix = "● " if is_current else "  "
                    self.stdscr.addstr(y, popup_x + 2, f"{prefix}{model_name}"[:popup_width - 4], attr)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            if ch == 27 or ch == ord('q'):  # Escape or q
                break
            elif ch == curses.KEY_UP or ch == ord('k'):
                selected_idx = (selected_idx - 1) % len(AVAILABLE_MODELS)
            elif ch == curses.KEY_DOWN or ch == ord('j'):
                selected_idx = (selected_idx + 1) % len(AVAILABLE_MODELS)
            elif ch == 10 or ch == 13:  # Enter
                model_id, model_name = AVAILABLE_MODELS[selected_idx]
                self.current_model = model_id
                self.context_limit = get_model_context_length(model_id)
                self.add_output(f"⏺ Model: {model_name} ({self.context_limit // 1000}k context)")
                break
        
        self.draw()
    
    def show_usage_dialog(self):
        """Show session usage details in a dialog."""
        height, width = self.get_dims()
        
        # Calculate dialog dimensions
        dialog_width = min(50, width - 8)
        dialog_height = 14
        dialog_x = (width - dialog_width) // 2
        dialog_y = (height - dialog_height) // 2
        
        # Calculate stats
        context_pct = min(100, int((self.session_tokens / self.context_limit) * 100)) if self.context_limit else 0
        if self.session_tokens >= 1000:
            tokens_str = f"{self.session_tokens // 1000}k"
        else:
            tokens_str = str(self.session_tokens)
        
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        fee_token_name = network_info.get('fee_token_name', 'tokens')
        
        # Block for input (no timeout)
        self.stdscr.timeout(-1)
        
        while True:
            self.draw()
            
            try:
                # Draw dialog box
                for i in range(dialog_height):
                    y = dialog_y + i
                    if i == 0:
                        self.stdscr.addstr(y, dialog_x, "╭" + "─" * (dialog_width - 2) + "╮", curses.color_pair(1))
                    elif i == dialog_height - 1:
                        self.stdscr.addstr(y, dialog_x, "╰" + "─" * (dialog_width - 2) + "╯", curses.color_pair(1))
                    else:
                        self.stdscr.addstr(y, dialog_x, "│" + " " * (dialog_width - 2) + "│", curses.color_pair(1))
                
                # Title
                title = "Session Usage"
                title_x = dialog_x + (dialog_width - len(title)) // 2
                self.stdscr.addstr(dialog_y + 1, title_x, title, curses.A_BOLD | curses.color_pair(3))
                
                # Context Window
                self.stdscr.addstr(dialog_y + 3, dialog_x + 3, "Context Window", curses.A_BOLD)
                self.stdscr.addstr(dialog_y + 4, dialog_x + 5, f"Used:    {tokens_str} tokens ({context_pct}%)")
                self.stdscr.addstr(dialog_y + 5, dialog_x + 5, f"Limit:   {self.context_limit // 1000}k tokens")
                
                # Payments
                self.stdscr.addstr(dialog_y + 7, dialog_x + 3, "Payments", curses.A_BOLD)
                self.stdscr.addstr(dialog_y + 8, dialog_x + 5, f"Total:   ${self.session_cost:.4f} {fee_token_name}")
                self.stdscr.addstr(dialog_y + 9, dialog_x + 5, f"Txs:     {self.session_tx_count}")
                
                # Model
                model_short = self.current_model.split("/")[-1]
                self.stdscr.addstr(dialog_y + 11, dialog_x + 5, f"Model:   {model_short}", curses.A_DIM)
                
                # Help text
                help_text = "Press any key to close"
                help_x = dialog_x + (dialog_width - len(help_text)) // 2
                self.stdscr.addstr(dialog_y + dialog_height - 2, help_x, help_text, curses.A_DIM)
                
            except curses.error:
                pass
            
            self.stdscr.refresh()
            ch = self.stdscr.getch()
            
            # Any key closes the dialog
            if ch != -1:
                break
        
        # Restore timeout
        self.stdscr.timeout(100)
        self.draw()
    
    def show_wallet_onboarding(self, pending_query: str):
        """Show delightful onboarding when user sends first query without wallet.
        
        Prompts user to press Enter to connect wallet via browser.
        After successful connection, automatically sends the pending query.
        """
        self.add_output("")
        self.add_output("  ╔══════════════════════════════════════════════════════╗")
        self.add_output("  ║                                                      ║")
        self.add_output("  ║   ⚡  CONNECT WALLET TO START                        ║")
        self.add_output("  ║                                                      ║")
        self.add_output("  ║   No API keys. No accounts. Just stablecoins.        ║")
        self.add_output("  ║                                                      ║")
        self.add_output("  ║   Your browser will open to create a wallet.         ║")
        self.add_output("  ║   Pay per request with AlphaUSD (~$0.01 each).       ║")
        self.add_output("  ║                                                      ║")
        self.add_output("  ╚══════════════════════════════════════════════════════╝")
        self.add_output("")
        
        # Animated "Press Enter" prompt
        enter_frames = [
            "  ▶▶▶  PRESS ENTER TO CONNECT  ◀◀◀",
            "  ▷▶▶  PRESS ENTER TO CONNECT  ◀◀◁",
            "  ▷▷▶  PRESS ENTER TO CONNECT  ◀◁◁",
            "  ▷▷▷  PRESS ENTER TO CONNECT  ◁◁◁",
            "  ▷▷▶  PRESS ENTER TO CONNECT  ◀◁◁",
            "  ▷▶▶  PRESS ENTER TO CONNECT  ◀◀◁",
        ]
        
        # Add placeholder for animated line
        self.add_output(enter_frames[0])
        enter_line_idx = len(self.output_lines) - 1
        self.draw()
        
        # Wait for Enter key with animation
        frame = 0
        while True:
            # Update animation
            self.output_lines[enter_line_idx] = enter_frames[frame % len(enter_frames)]
            frame += 1
            self.draw()
            
            ch = self.stdscr.getch()
            if ch == 10 or ch == 13:  # Enter
                break
            elif ch == 27 or ch == 3:  # Escape or Ctrl+C
                self.add_output("")
                self.add_output("⏺ No worries! Run /wallet when you're ready.")
                return
            elif ch == curses.KEY_RESIZE:
                self.draw()
        
        # Clear onboarding box and run wallet setup
        self.output_lines = [
            line for line in self.output_lines 
            if not any(x in line for x in [
                "╔═",
                "╚═",
                "║",  # Box frame lines
                "CONNECT WALLET",
                "No API keys",
                "browser will open",
                "Pay per request",
                "PRESS ENTER TO CONNECT",
                "▶▶▶",
                "▷▷▷",
            ])
        ]
        
        # Store pending query to send after wallet setup
        self._pending_query = pending_query
        
        # Run wallet setup
        self.create_new_access_key()
        
        # After wallet setup, if successful, send the pending query
        if self.private_key and hasattr(self, '_pending_query') and self._pending_query:
            query = self._pending_query
            delattr(self, '_pending_query')
            # Small delay for UI to settle
            time.sleep(0.2)
            self.process_command(query)
        elif hasattr(self, '_pending_query'):
            delattr(self, '_pending_query')
    
    def create_new_access_key(self):
        """Create new access key via browser flow, keeping TUI alive."""
        self.add_output("")
        self.add_output("⏺ Opening browser to create new access key...")
        self.add_output("$ Starting auth server...")
        self.draw()
        
        # Run browser setup in thread so we can keep TUI alive
        import threading
        setup_result = {"config": None, "done": False, "error": None}
        
        def do_setup():
            try:
                # Pass existing account_address if we have one (for /newkey on existing wallet)
                existing_account = self.account_address if hasattr(self, 'account_address') and self.account_address else None
                setup_result["config"] = setup_wallet_browser(network=self.current_network, account_address=existing_account)
            except Exception as e:
                setup_result["error"] = str(e)
            setup_result["done"] = True
        
        thread = threading.Thread(target=do_setup, daemon=True)
        thread.start()
        
        # Wait briefly for server to start, then update message
        time.sleep(0.3)
        for i, line in enumerate(self.output_lines):
            if line.startswith("$ Starting auth"):
                self.output_lines[i] = "$ Waiting for browser..."
                break
        
        # Keep TUI responsive while waiting
        dots = 0
        while not setup_result["done"]:
            self.draw()
            ch = self.stdscr.getch()
            if ch == 3:  # Ctrl+C
                self.add_output("! Cancelled")
                return
            time.sleep(0.1)
            dots = (dots + 1) % 4
            # Update status animation
            for i, line in enumerate(self.output_lines):
                if line.startswith("$ Waiting"):
                    self.output_lines[i] = f"$ Waiting for browser{'.' * dots}"
                    break
        
        if setup_result["error"]:
            self.add_output(f"! Error: {setup_result['error']}")
            return
        
        config = setup_result["config"]
        if config and config.get("access_key_private_key"):
            # Create new AccessKey from the browser response
            new_key = AccessKey(
                private_key=config["access_key_private_key"],
                key_id=config.get("key_id", ""),
                expiry=config.get("expiry", 0),
                public_key=config.get("public_key", ""),
            )
            
            # Update wallet config
            self.wallet.account_address = config.get("account_address", self.wallet.account_address)
            self.wallet.add_key(new_key, make_active=True)
            
            # Save with new format
            save_config(self.wallet.to_dict(), CONFIG_FILE)
            
            # Update legacy fields for compatibility
            self.config = self.wallet.to_dict()
            self.private_key = new_key.private_key
            self.account_address = self.wallet.account_address
            self.key_expiry = new_key.expiry
            self.access_key_address = new_key.address
            
            # Remove old "no wallet" / "waiting" messages and replace with success
            self.output_lines = [
                line for line in self.output_lines 
                if not any(x in line for x in [
                    "No wallet connected", 
                    "Run /newkey to connect", 
                    "Opening browser to create",
                    "Opening browser to connect",
                    "Starting auth server",
                    "Waiting for browser",
                    "Access key expired",
                    "Run /newkey to create",
                    "Ready. Ask anything",
                ])
            ]
            # Also remove any trailing empty lines that create gaps
            while self.output_lines and self.output_lines[-1] == "":
                self.output_lines.pop()
            self.add_output("")
            key_count = len(self.wallet.access_keys)
            if key_count > 1:
                self.add_output(f"$ New access key added! ({key_count} keys total)")
            else:
                self.add_output(f"$ Wallet connected!")
            self.add_output(f"  Wallet: {self.account_address}")
            if self.access_key_address:
                self.add_output(f"  Access Key: {self.access_key_address}")
            self.add_output("")
            self.add_output("⏺ Ready. Type /help for commands.")
            
            # Update user context with new wallet
            self.user_context.update_from_wallet(self.wallet, self.current_network)
            
            # Fetch balance in background
            self.refresh_balance_async()
        else:
            # Clean up waiting messages
            self.output_lines = [
                line for line in self.output_lines 
                if not any(x in line for x in [
                    "Opening browser to create",
                    "Starting auth server",
                    "Waiting for browser",
                ])
            ]
            self.add_output("! Access key creation cancelled or failed")
            self.add_output("  Use /newkey to try again")
    
    def add_welcome_to_history(self):
        """Add the logo and welcome message to output history."""
        height, width = self.get_dims()
        logo = get_logo(height, width)
        
        # Add logo lines with special prefix for coloring
        for line in logo:
            self.output_lines.append(f"§{line}")
        
        # Add welcome text
        self.output_lines.append("")
        if self.fresh:
            self.output_lines.append("⏺ Fresh start")
        else:
            self.output_lines.append("⏺ Welcome to Presto")
        self.output_lines.append("  AI coding agent · Pay with stablecoins · No API keys")
        self.output_lines.append("")
        
        # Show network and wallet status
        network_info = NETWORKS.get(self.current_network, NETWORKS[DEFAULT_NETWORK])
        
        if self.account_address:
            self.output_lines.append(f"  Wallet: {self.account_address}")
            if self.access_key_address and self.access_key_address != self.account_address:
                self.output_lines.append(f"  Access Key: {self.access_key_address}")
            self.output_lines.append(f"  Network: {network_info['name']}")
        self.output_lines.append("")
    
    def run(self):
        logger.info("Presto starting up")
        self.config = load_config(CONFIG_FILE)
        
        # Check if auth server changed - if so, keys are invalid
        from .config import get_auth_url
        saved_auth_server = self.config.get("auth_server", "")
        current_auth_server = get_auth_url()
        if saved_auth_server and saved_auth_server != current_auth_server:
            # Auth server changed - clear wallet config to force new setup
            logger.info(f"Auth server changed from {saved_auth_server} to {current_auth_server}, clearing wallet")
            self.config = {}
        
        # Load wallet using new WalletConfig model (handles migration from old format)
        self.wallet = WalletConfig.from_dict(self.config)
        
        # Set up skill loader callback
        def skill_loader_callback(skill_name, content):
            if skill_name not in self.loaded_skills:
                self.loaded_skills.append(skill_name)
                self.skill_instructions += f"\n\n<loaded_skill name=\"{skill_name}\">\n{content}\n</loaded_skill>\n"
        set_skill_loader(skill_loader_callback)
        
        # Add welcome/logo to history immediately
        self.add_welcome_to_history()
        
        # Set legacy fields from wallet config for backward compatibility
        self.account_address = self.wallet.account_address
        self.current_network = self.wallet.network
        
        # Block mainnet if disabled
        if self.current_network == "mainnet" and MAINNET_BLOCKED:
            self.current_network = DEFAULT_NETWORK
            self.wallet.switch_network(DEFAULT_NETWORK)
            self.add_output("")
            self.add_output("🚨 MAINNET IS DISABLED 🚨")
            self.add_output("")
            self.add_output("Your config had mainnet selected, but mainnet access keys")
            self.add_output("have high storage overhead costs. Switched to moderato.")
            self.add_output("")
        active_key = self.wallet.active_key
        if active_key:
            self.private_key = active_key.private_key
            self.key_expiry = active_key.expiry
            self.access_key_address = active_key.address
        else:
            self.private_key = ""
            self.key_expiry = 0
            self.access_key_address = ""
        self.balance_loading = False
        
        # Initialize user context for AI agent awareness
        self.user_context.update_from_wallet(self.wallet, self.current_network)
        
        # Check if active access key is expired
        key_expired = active_key.is_expired if active_key else True
        key_expiring_soon = active_key.expires_soon if active_key else False
        
        # Show wallet status
        if active_key and not key_expired:
            self.output_lines.append("⏺ Ready. Type /help for commands.")
            if key_expiring_soon:
                self.output_lines.append(f"! Access key expires in {active_key.time_remaining} - run /newkey to renew")
            self.balance_loading = True
            self.output_lines.append("$ Fetching wallet info...")
        elif key_expired and active_key:
            self.output_lines.append("")
            self.output_lines.append("! Access key expired")
            self.output_lines.append("  Run /newkey to create a new access key")
            self.output_lines.append("")
        else:
            # No wallet - just show ready, will prompt on first query
            self.output_lines.append("⏺ Ready. Ask anything.")
        
        # If wallet configured, fetch info in background
        if self.private_key:
            
            def load_wallet_info():
                # Derive access key address from private key
                try:
                    self.access_key_address = subprocess.run(
                        ["cast", "wallet", "address", self.private_key],
                        capture_output=True, text=True, check=True, timeout=5
                    ).stdout.strip()
                except:
                    self.access_key_address = ""
                
                # If no account_address stored, use access key address as fallback
                if not self.account_address:
                    self.account_address = self.access_key_address
                    if self.account_address:
                        self.config["account_address"] = self.account_address
                        save_config(self.config, CONFIG_FILE)
                
                # Fetch balance synchronously (this is the main wallet balance)
                self.refresh_balance_sync()
                
                self.balance_loading = False
                # Replace "Fetching wallet info..." with wallet info
                if self.account_address:
                    for i, line in enumerate(self.output_lines):
                        if "Fetching wallet info..." in line:
                            self.output_lines[i] = f"✓ Wallet: {self.account_address}"
                            break
            
            import threading
            threading.Thread(target=load_wallet_info, daemon=True).start()
        
        spinner_chars = ['◐', '◓', '◑', '◒']
        spinner_idx = 0
        
        while self.running:
            try:
                # Process any pending API events
                self.process_api_queue()
                
                # Animate confirming spinner
                if hasattr(self, '_confirming_line_idx'):
                    idx = self._confirming_line_idx
                    if 0 <= idx < len(self.output_lines):
                        spinner_idx = (spinner_idx + 1) % len(spinner_chars)
                        self.output_lines[idx] = f"  {spinner_chars[spinner_idx]} Confirming..."
                
                # Handle pending wallet connection (needs main thread for curses)
                if hasattr(self, '_pending_wallet_connect') and self._pending_wallet_connect:
                    self._pending_wallet_connect = False
                    self.create_new_access_key()
                    # Update tool context with new wallet info
                    set_tool_context({
                        'account_address': self.account_address,
                        'access_key_address': self.access_key_address,
                        'rpc_url': self.get_rpc_url(),
                    })
                    self._wallet_connected = True
                
                self.draw()
                ch = self.stdscr.getch()
                
                if ch == curses.KEY_RESIZE:
                    self.handle_resize()
                elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
                    if self.input_buffer and self.cursor_pos > 0:
                        self.input_buffer = self.input_buffer[:self.cursor_pos-1] + self.input_buffer[self.cursor_pos:]
                        self.cursor_pos -= 1
                elif ch == curses.KEY_LEFT:
                    if self.cursor_pos > 0:
                        self.cursor_pos -= 1
                elif ch == curses.KEY_RIGHT:
                    if self.cursor_pos < len(self.input_buffer):
                        self.cursor_pos += 1
                elif ch == curses.KEY_UP:
                    self.scroll_offset = min(self.scroll_offset + 1, max(0, len(self.output_lines) - 5))
                elif ch == curses.KEY_DOWN:
                    self.scroll_offset = max(0, self.scroll_offset - 1)
                elif ch == curses.KEY_HOME or ch == 1:  # Ctrl+A
                    self.cursor_pos = 0
                elif ch == curses.KEY_END or ch == 5:  # Ctrl+E
                    self.cursor_pos = len(self.input_buffer)
                elif ch == 27:  # Escape - cancel current request
                    if self.api_busy:
                        self.api_cancelled = True
                        self.api_cancel_event.set()  # Signal cancellation to HTTP layer
                        self.activity_status = "Cancelling..."
                        self.add_output("! Cancelling request...")
                        self.draw()
                elif ch == 3:  # Ctrl+C
                    if self.api_busy:
                        self.api_cancelled = True
                        self.api_cancel_event.set()  # Signal cancellation to HTTP layer
                        self.status_message = "Cancelling..."
                    else:
                        self.running = False
                elif ch == 4:  # Ctrl+D
                    self.running = False
                elif ch == 21:  # Ctrl+U
                    self.input_buffer = ""
                    self.cursor_pos = 0
                elif ch == 16:  # Ctrl+P - open command palette
                    self.show_command_palette()
                elif ch == ord('/') and not self.input_buffer:  # "/" as first char opens palette
                    self.show_command_palette()
                elif ch == 10 or ch == 13:  # Enter
                    if self.input_buffer.strip():
                        cmd = self.input_buffer.strip()
                        self.input_buffer = ""
                        self.cursor_pos = 0
                        # process_command handles cancellation if api_busy
                        self.process_command(cmd)
                elif ch != -1 and 32 <= ch <= 126:
                    # Insert the character into the buffer
                    char = chr(ch)
                    self.input_buffer = self.input_buffer[:self.cursor_pos] + char + self.input_buffer[self.cursor_pos:]
                    self.cursor_pos += 1
                    
            except KeyboardInterrupt:
                break
        
        # Disable alternate scroll mode on exit
        _term_write("\x1b[?1007l")
