"""JSON logger for presto with event types."""
import json
import os
import time
from pathlib import Path

LOG_FILE = Path(__file__).parent.parent / "presto.log"

def log(event: str, **data):
    """Log a JSON event to presto.log"""
    entry = {
        "ts": time.time(),
        "time": time.strftime("%H:%M:%S"),
        "event": event,
        **data
    }
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")

def api_call(model: str, messages_count: int, has_tools: bool = False, url: str = None, body: dict = None):
    log("PROXY_REQUEST", url=url, model=model, messages=messages_count, tools=has_tools)

def proxy_response_402(amount_usd: float, challenge_id: str):
    log("PROXY_402", amount_usd=amount_usd, challenge_id=challenge_id, message="Payment required")

def proxy_response_ok(status_code: int, tokens: int = 0, cost: float = None, tx_hash: str = None):
    log("PROXY_OK", status=status_code, tokens=tokens, cost=cost, tx_hash=tx_hash)

def tool_use(name: str, args: dict):
    log("TOOL_USE", tool=name, args=args)

def tool_result(name: str, result_len: int):
    log("TOOL_RESULT", tool=name, result_len=result_len)

def payment(amount_usd: float, status: str, tx_hash: str = None, **extra):
    log("PAYMENT", amount=amount_usd, status=status, tx_hash=tx_hash, **extra)

def payment_request(challenge_id: str, amount: str, asset: str, destination: str, rpc_url: str = None):
    log("PAYMENT_REQUEST", challenge_id=challenge_id, amount=amount, asset=asset, destination=destination, rpc_url=rpc_url)

def payment_signed(signed_tx: str, from_address: str, nonce: str):
    log("PAYMENT_SIGNED", signed_tx=signed_tx, from_address=from_address, nonce=nonce)

def payment_submitted(auth_header_preview: str, proxy_url: str = None):
    log("PAYMENT_SUBMITTED", auth_header_preview=auth_header_preview, proxy_url=proxy_url)

def payment_confirmed(tx_hash: str, amount_usd: float, explorer_url: str):
    log("PAYMENT_CONFIRMED", tx_hash=tx_hash, amount_usd=amount_usd, explorer_url=explorer_url)

def error(message: str, **details):
    log("ERROR", message=message, **details)

def http_error(code: int, url: str, body: str = "", message: str = ""):
    """Log HTTP error with full details."""
    log("HTTP_ERROR", code=code, url=url, body=body[:500] if body else "", message=message or f"HTTP {code}")

def info(message: str):
    log("INFO", message=message)
