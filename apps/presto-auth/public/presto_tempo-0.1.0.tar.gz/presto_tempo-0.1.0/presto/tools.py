"""Agent tools for file manipulation and shell commands."""
import glob as globlib
import json
import os
import re
import subprocess


def read(args):
    lines = open(args["path"]).readlines()
    offset = args.get("offset", 0)
    limit = args.get("limit", len(lines))
    selected = lines[offset : offset + limit]
    return "".join(f"{offset + idx + 1:4}| {line}" for idx, line in enumerate(selected))


def write(args):
    path = args["path"]
    content = args["content"]
    is_new = not os.path.exists(path)
    
    with open(path, "w") as f:
        f.write(content)
    
    lines = content.split("\n")
    line_count = len(lines)
    action = "Created" if is_new else "Wrote"
    
    result = [f"WRITE:{path}:+{line_count}"]
    result.append("...")
    for i, line in enumerate(lines[:8], 1):
        result.append(f"{i:4} + {line}")
    if line_count > 8:
        result.append(f"     ... +{line_count - 8} more lines")
    
    return "\n".join(result)


def edit(args):
    text = open(args["path"]).read()
    old, new = args["old"], args["new"]
    if old not in text:
        return "error: old_string not found"
    count = text.count(old)
    if not args.get("all") and count > 1:
        return f"error: old_string appears {count} times, must be unique (use all=true)"
    
    old_lines = old.split("\n")
    new_lines = new.split("\n")
    
    start_line = text[:text.find(old)].count("\n") + 1
    
    replacement = text.replace(old, new) if args.get("all") else text.replace(old, new, 1)
    with open(args["path"], "w") as f:
        f.write(replacement)
    
    return format_diff(args["path"], old_lines, new_lines, start_line)


def format_diff(path, old_lines, new_lines, start_line):
    """Format a nice diff output like Amp does."""
    lines_changed = len(new_lines) - len(old_lines)
    sign = "+" if lines_changed >= 0 else ""
    header = f"DIFF:{path}:{sign}{lines_changed}"
    
    result = [header]
    result.append("...")
    
    import difflib
    sm = difflib.SequenceMatcher(None, old_lines, new_lines)
    
    new_line_num = start_line
    
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            for idx in range(i2 - i1):
                result.append(f"{new_line_num:4}   {old_lines[i1 + idx]}")
                new_line_num += 1
        elif tag == 'replace':
            for idx in range(i1, i2):
                result.append(f"{new_line_num:4} - {old_lines[idx]}")
            for idx in range(j1, j2):
                result.append(f"{new_line_num:4} + {new_lines[idx]}")
                new_line_num += 1
        elif tag == 'delete':
            for idx in range(i1, i2):
                result.append(f"{new_line_num:4} - {old_lines[idx]}")
        elif tag == 'insert':
            for idx in range(j1, j2):
                result.append(f"{new_line_num:4} + {new_lines[idx]}")
                new_line_num += 1
    
    return "\n".join(result)


def glob(args):
    pattern = (args.get("path", ".") + "/" + args["pat"]).replace("//", "/")
    files = globlib.glob(pattern, recursive=True)
    files = sorted(files, key=lambda f: os.path.getmtime(f) if os.path.isfile(f) else 0, reverse=True)
    return "\n".join(files) or "none"


def grep(args):
    pattern = re.compile(args["pat"])
    hits = []
    for filepath in globlib.glob(args.get("path", ".") + "/**", recursive=True):
        try:
            for line_num, line in enumerate(open(filepath), 1):
                if pattern.search(line):
                    hits.append(f"{filepath}:{line_num}:{line.rstrip()}")
        except Exception:
            pass
    return "\n".join(hits[:50]) or "none"


def bash(args):
    proc = subprocess.Popen(args["cmd"], shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    output_lines = []
    try:
        while True:
            line = proc.stdout.readline()
            if not line and proc.poll() is not None:
                break
            if line:
                output_lines.append(line)
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill()
        output_lines.append("\n(timed out after 30s)")
    return "".join(output_lines).strip() or "(empty)"


def web_search(args):
    """Search the web using DuckDuckGo."""
    import urllib.request
    import urllib.parse
    
    query = args.get("query", "")
    if not query:
        return "Error: query is required"
    
    # Use DuckDuckGo HTML search (no API key needed)
    encoded_query = urllib.parse.quote(query)
    url = f"https://html.duckduckgo.com/html/?q={encoded_query}"
    
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
        
        # Parse results from HTML
        results = []
        # Find result links and snippets
        import re
        # Match result blocks
        result_pattern = re.compile(r'<a[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>([^<]*)</a>.*?<a[^>]*class="result__snippet"[^>]*>([^<]*)</a>', re.DOTALL)
        
        for match in result_pattern.finditer(html):
            url_match, title, snippet = match.groups()
            # Clean up the URL (DuckDuckGo wraps URLs)
            if 'uddg=' in url_match:
                actual_url = urllib.parse.unquote(url_match.split('uddg=')[-1].split('&')[0])
            else:
                actual_url = url_match
            title = re.sub(r'<[^>]+>', '', title).strip()
            snippet = re.sub(r'<[^>]+>', '', snippet).strip()
            if title and actual_url:
                results.append(f"**{title}**\n{actual_url}\n{snippet}\n")
        
        if results:
            return "\n".join(results[:5])  # Return top 5 results
        else:
            return f"No results found for: {query}"
    
    except Exception as e:
        return f"Search error: {str(e)}"


def read_url(args):
    """Fetch and read content from a URL."""
    import urllib.request
    
    url = args.get("url", "")
    if not url:
        return "Error: url is required"
    
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
        with urllib.request.urlopen(req, timeout=15) as response:
            content = response.read().decode('utf-8', errors='ignore')
        
        # Strip HTML tags for cleaner output
        import re
        # Remove script and style elements
        content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL)
        content = re.sub(r'<style[^>]*>.*?</style>', '', content, flags=re.DOTALL)
        # Remove HTML tags
        content = re.sub(r'<[^>]+>', ' ', content)
        # Clean up whitespace
        content = re.sub(r'\s+', ' ', content).strip()
        
        # Limit output length
        max_len = 8000
        if len(content) > max_len:
            content = content[:max_len] + f"\n\n... (truncated, {len(content)} chars total)"
        
        return content
    
    except Exception as e:
        return f"Error fetching URL: {str(e)}"


TOOL_DEFINITIONS = [
    {
        "name": "read",
        "description": "Read a file and return its contents with line numbers. Use this to examine source code, config files, or any text file.",
        "parameters": {
            "path": {"type": "string", "description": "Absolute or relative path to the file"},
            "offset": {"type": "integer", "description": "Line number to start from (0-indexed)", "optional": True},
            "limit": {"type": "integer", "description": "Maximum number of lines to return", "optional": True},
        }
    },
    {
        "name": "write",
        "description": "Write content to a file, creating it if it doesn't exist or overwriting if it does.",
        "parameters": {
            "path": {"type": "string", "description": "Path to the file to write"},
            "content": {"type": "string", "description": "Content to write to the file"},
        }
    },
    {
        "name": "edit",
        "description": "Replace a specific string in a file. The old string must exist and be unique (unless all=true).",
        "parameters": {
            "path": {"type": "string", "description": "Path to the file to edit"},
            "old": {"type": "string", "description": "The exact string to find and replace"},
            "new": {"type": "string", "description": "The string to replace it with"},
            "all": {"type": "boolean", "description": "Replace all occurrences (default: false, requires unique match)", "optional": True},
        }
    },
    {
        "name": "glob",
        "description": "Find files matching a glob pattern. Use **/ for recursive search.",
        "parameters": {
            "pat": {"type": "string", "description": "Glob pattern (e.g., '**/*.py', '*.json')"},
            "path": {"type": "string", "description": "Base directory to search from", "optional": True},
        }
    },
    {
        "name": "grep",
        "description": "Search files for lines matching a regex pattern. Returns matching lines with file paths and line numbers.",
        "parameters": {
            "pat": {"type": "string", "description": "Regular expression pattern to search for"},
            "path": {"type": "string", "description": "Directory or file to search in", "optional": True},
        }
    },
    {
        "name": "bash",
        "description": "Run a shell command and return its output. Use for system commands, git, npm, etc.",
        "parameters": {
            "cmd": {"type": "string", "description": "Shell command to execute"},
        }
    },
    {
        "name": "wallet_info",
        "description": "Get the current wallet address and access key address. Use this when the user asks about their wallet, address, or account.",
        "parameters": {}
    },
    {
        "name": "check_balance",
        "description": "Check the token balance of the configured wallet. Use this when the user asks about their balance, funds, or how much money they have.",
        "parameters": {}
    },

    {
        "name": "connect_wallet",
        "description": "Connect a wallet and create an access key. This opens the browser for the user to authenticate with their passkey wallet. Use this when: the user wants to connect a wallet, set up payments, create an access key, or when wallet_info shows no wallet configured.",
        "parameters": {}
    },
    {
        "name": "idxs",
        "description": "Query blockchain data via Index Supply API. Supports SQL-like queries for token balances, transfers, and transactions across chains.",
        "parameters": {
            "query": {"type": "string", "description": "SQL-like query (include chain=X, e.g., chain=1 for Ethereum mainnet)"},
            "signatures": {"type": "string", "description": "Event signatures if querying events", "optional": True},
        }
    },
    {
        "name": "load_skill",
        "description": "Load a specialized skill that provides domain-specific instructions. Available skills include: 1password (retrieve secrets), foundry (Ethereum development), slack (messaging), linear (issue tracking), and many more. Use this when the user needs specialized functionality.",
        "parameters": {
            "name": {"type": "string", "description": "Name of the skill to load (e.g., '1password', 'foundry', 'slack')"},
            "list_only": {"type": "boolean", "description": "If true, just list available skills without loading", "optional": True},
        }
    },
    {
        "name": "web_search",
        "description": "Search the web using DuckDuckGo. Returns top 5 results with titles, URLs, and snippets. Use this when you need to find information online, look up documentation, or research a topic.",
        "parameters": {
            "query": {"type": "string", "description": "Search query"},
        }
    },
    {
        "name": "read_url",
        "description": "Fetch and read content from a URL. Strips HTML and returns plain text. Use this to read web pages, documentation, API docs, etc.",
        "parameters": {
            "url": {"type": "string", "description": "URL to fetch"},
        }
    },
]

# Context set by UI before running tools
_tool_context = {}

# Skills directories
PRESTO_SKILLS_DIR = os.path.dirname(os.path.abspath(__file__)) + "/skills"
USER_SKILLS_DIR = os.path.expanduser("~/.config/agents/skills")

# Callback for loading skills (set by UI)
_skill_loader = None

def set_skill_loader(loader):
    global _skill_loader
    _skill_loader = loader

def set_tool_context(ctx):
    global _tool_context
    _tool_context = ctx

def wallet_info(args):
    """Return wallet and access key addresses."""
    return f"""Wallet Address: {_tool_context.get('account_address', 'not set')}
Access Key Address: {_tool_context.get('access_key_address', 'not set')}

The wallet is the main account (created with passkey).
The access key is used by presto to sign transactions."""

def check_balance(args):
    """Check token balance using shared RPC utilities."""
    from .rpc import get_token_balance, format_balance
    
    address = _tool_context.get('account_address', '')
    if not address:
        return "No wallet address configured"
    
    fee_token = _tool_context.get('fee_token', '')
    fee_token_name = _tool_context.get('fee_token_name', 'tokens')
    rpc_url = _tool_context.get('rpc_url', '')
    
    balance = get_token_balance(address, fee_token, rpc_url, decimals=6)
    return f"Balance: {format_balance(balance, fee_token_name)}\nWallet: {address}"


def idxs(args):
    """Query blockchain data via Index Supply."""
    from .skills.idxs import run_idxs_tool
    return run_idxs_tool(args)


def connect_wallet(args):
    """Connect wallet - signals UI to trigger browser flow."""
    # This is a special tool that the UI intercepts
    return "__CONNECT_WALLET__"


def load_skill(args):
    """Load a skill or list available skills."""
    list_only = args.get("list_only", False)
    skill_name = args.get("name", "")
    
    # Collect available skills
    available = {}
    for skills_dir in [PRESTO_SKILLS_DIR, USER_SKILLS_DIR]:
        if os.path.isdir(skills_dir):
            for name in os.listdir(skills_dir):
                skill_path = os.path.join(skills_dir, name, "SKILL.md")
                if os.path.isfile(skill_path):
                    available[name] = skill_path
    
    if list_only or not skill_name:
        if not available:
            return "No skills available"
        skills_list = sorted(available.keys())
        return f"Available skills ({len(skills_list)}):\n" + "\n".join(f"  - {s}" for s in skills_list[:20])
    
    if skill_name not in available:
        return f"Skill '{skill_name}' not found. Available: {', '.join(sorted(available.keys())[:10])}"
    
    # Load the skill content
    try:
        with open(available[skill_name], 'r') as f:
            content = f.read()
        
        # Use callback to inject into system prompt if available
        if _skill_loader:
            _skill_loader(skill_name, content)
            return f"Loaded skill: {skill_name}\n\nThe skill instructions are now available. Follow them to help the user."
        else:
            # Return content directly for agent to use
            return f"Skill '{skill_name}' loaded:\n\n{content}"
    except Exception as e:
        return f"Error loading skill: {e}"


def run_tool(name, args):
    """Execute a tool by name with the given arguments."""
    tools = {
        "read": read, "write": write, "edit": edit, 
        "glob": glob, "grep": grep, "bash": bash,
        "wallet_info": wallet_info, "check_balance": check_balance,
        "idxs": idxs, "connect_wallet": connect_wallet, "load_skill": load_skill,
        "web_search": web_search, "read_url": read_url,
    }
    
    if name not in tools:
        return f"Error: Unknown tool '{name}'. Available tools: {', '.join(tools.keys())}"
    
    try:
        return tools[name](args)
    except Exception as e:
        return f"Error running {name}: {str(e)}"


def make_schema():
    """Convert TOOL_DEFINITIONS to OpenAI-compatible tool schemas."""
    result = []
    for tool_def in TOOL_DEFINITIONS:
        properties = {}
        required = []
        
        for param_name, param_info in tool_def.get("parameters", {}).items():
            prop = {"type": param_info["type"]}
            if "description" in param_info:
                prop["description"] = param_info["description"]
            properties[param_name] = prop
            
            if not param_info.get("optional", False):
                required.append(param_name)
        
        result.append({
            "name": tool_def["name"],
            "description": tool_def["description"],
            "input_schema": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        })
    return result


def get_tools_summary():
    """Get a concise summary of available tools for the system prompt."""
    lines = []
    for tool_def in TOOL_DEFINITIONS:
        params = ", ".join(tool_def.get("parameters", {}).keys())
        if params:
            lines.append(f"- {tool_def['name']}({params}): {tool_def['description']}")
        else:
            lines.append(f"- {tool_def['name']}(): {tool_def['description']}")
    return "\n".join(lines)
