"""Wallet setup via browser or manual key import.

Wallet Model:
- One master wallet (passkey-based, identified by account_address)
- Multiple access keys (one is always active/default)
- Access keys have expiry and optional spending limits
"""
import http.server
import json
import os
import secrets
import subprocess
import time
import webbrowser
from urllib.parse import urlparse, parse_qs
from typing import Optional

from .auth_server import get_auth_server
from .config import DEFAULT_NETWORK, get_auth_url


class AccessKey:
    """Represents a single access key."""
    
    def __init__(self, private_key: str, key_id: str = "", expiry: int = 0, 
                 public_key: str = "", label: str = "", spending_limit: int = 0):
        self.private_key = private_key
        self.key_id = key_id
        self.expiry = expiry
        self.public_key = public_key
        self.label = label or f"Key {key_id}" if key_id else "Unnamed"
        self.spending_limit = spending_limit
        self._address = None
    
    @property
    def address(self) -> str:
        """Derive address from private key (cached)."""
        if self._address is None:
            try:
                result = subprocess.run(
                    ["cast", "wallet", "address", self.private_key],
                    capture_output=True, text=True, check=True, timeout=5
                )
                self._address = result.stdout.strip()
            except Exception:
                self._address = self.key_id or ""
        return self._address
    
    @property
    def is_expired(self) -> bool:
        """Check if key is expired."""
        if self.expiry <= 0:
            return False
        return int(time.time()) >= self.expiry
    
    @property
    def expires_soon(self) -> bool:
        """Check if key expires within 1 hour."""
        if self.expiry <= 0 or self.is_expired:
            return False
        return (self.expiry - int(time.time())) < 3600
    
    @property
    def time_remaining(self) -> str:
        """Human-readable time remaining."""
        if self.expiry <= 0:
            return "No expiry"
        remaining = self.expiry - int(time.time())
        if remaining <= 0:
            return "EXPIRED"
        if remaining < 3600:
            return f"{remaining // 60}m"
        if remaining < 86400:
            return f"{remaining // 3600}h"
        return f"{remaining // 86400}d"
    
    def to_dict(self) -> dict:
        return {
            "private_key": self.private_key,
            "key_id": self.key_id,
            "expiry": self.expiry,
            "public_key": self.public_key,
            "label": self.label,
            "spending_limit": self.spending_limit,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "AccessKey":
        return cls(
            private_key=data.get("private_key", ""),
            key_id=data.get("key_id", ""),
            expiry=data.get("expiry", 0),
            public_key=data.get("public_key", ""),
            label=data.get("label", ""),
            spending_limit=data.get("spending_limit", 0),
        )


class NetworkWallet:
    """Wallet configuration for a single network."""
    
    def __init__(self, account_address: str = "", access_keys: list = None, 
                 active_key_index: int = 0, direct_signing: bool = False):
        self.account_address = account_address
        self.access_keys: list[AccessKey] = access_keys or []
        self.active_key_index = active_key_index
        self.direct_signing = direct_signing  # If True, sign directly with private key (no access key mode)
    
    @property
    def active_key(self) -> Optional[AccessKey]:
        """Get the currently active access key."""
        if not self.access_keys:
            return None
        idx = min(self.active_key_index, len(self.access_keys) - 1)
        return self.access_keys[idx] if idx >= 0 else None
    
    @property
    def has_valid_key(self) -> bool:
        """Check if there's a non-expired active key."""
        key = self.active_key
        return key is not None and not key.is_expired
    
    def add_key(self, key: AccessKey, make_active: bool = True):
        """Add a new access key."""
        self.access_keys.append(key)
        if make_active:
            self.active_key_index = len(self.access_keys) - 1
    
    def to_dict(self) -> dict:
        result = {
            "account_address": self.account_address,
            "access_keys": [k.to_dict() for k in self.access_keys],
            "active_key_index": self.active_key_index,
        }
        if self.direct_signing:
            result["direct_signing"] = True
        return result
    
    @classmethod
    def from_dict(cls, data: dict) -> "NetworkWallet":
        access_keys = [AccessKey.from_dict(k) for k in data.get("access_keys", [])]
        return cls(
            account_address=data.get("account_address", ""),
            access_keys=access_keys,
            active_key_index=data.get("active_key_index", 0),
            direct_signing=data.get("direct_signing", False),
        )


class WalletConfig:
    """Manages wallet configuration across multiple networks."""
    
    def __init__(self, network: str = None, networks: dict = None):
        self.network = network if network is not None else DEFAULT_NETWORK
        self._networks: dict[str, NetworkWallet] = networks or {}
    
    def _current_wallet(self) -> NetworkWallet:
        """Get or create wallet for current network."""
        if self.network not in self._networks:
            self._networks[self.network] = NetworkWallet()
        return self._networks[self.network]
    
    def get_wallet(self, network: str) -> NetworkWallet:
        """Get or create wallet for a specific network."""
        if network not in self._networks:
            self._networks[network] = NetworkWallet()
        return self._networks[network]
    
    @property
    def account_address(self) -> str:
        """Get account address for current network."""
        return self._current_wallet().account_address
    
    @account_address.setter
    def account_address(self, value: str):
        """Set account address for current network."""
        self._current_wallet().account_address = value
    
    @property
    def access_keys(self) -> list:
        """Get access keys for current network."""
        return self._current_wallet().access_keys
    
    @property
    def active_key_index(self) -> int:
        """Get active key index for current network."""
        return self._current_wallet().active_key_index
    
    @active_key_index.setter
    def active_key_index(self, value: int):
        """Set active key index for current network."""
        self._current_wallet().active_key_index = value
    
    @property
    def active_key(self) -> Optional[AccessKey]:
        """Get the currently active access key for current network."""
        return self._current_wallet().active_key
    
    @property
    def has_valid_key(self) -> bool:
        """Check if there's a non-expired active key for current network."""
        return self._current_wallet().has_valid_key
    
    @property
    def direct_signing(self) -> bool:
        """Check if direct signing mode is enabled for current network."""
        return self._current_wallet().direct_signing
    
    def add_key(self, key: AccessKey, make_active: bool = True):
        """Add a new access key to current network."""
        self._current_wallet().add_key(key, make_active)
    
    def switch_to_key(self, index: int) -> bool:
        """Switch to a different access key by index."""
        wallet = self._current_wallet()
        if 0 <= index < len(wallet.access_keys):
            wallet.active_key_index = index
            return True
        return False
    
    def remove_expired_keys(self) -> int:
        """Remove all expired keys from current network, returns count removed."""
        wallet = self._current_wallet()
        before = len(wallet.access_keys)
        wallet.access_keys = [k for k in wallet.access_keys if not k.is_expired]
        after = len(wallet.access_keys)
        if wallet.active_key_index >= len(wallet.access_keys):
            wallet.active_key_index = max(0, len(wallet.access_keys) - 1)
        return before - after
    
    def switch_network(self, network: str):
        """Switch to a different network."""
        self.network = network
    
    def to_dict(self) -> dict:
        """Convert to dict for saving (new multi-network format)."""
        from .config import get_auth_url
        result = {
            "network": self.network,
            "networks": {name: wallet.to_dict() for name, wallet in self._networks.items()},
            "auth_server": get_auth_url(),  # Track which auth server created the keys
        }
        # For backward compatibility, also store current network's active key at top level
        if self.active_key:
            result["account_address"] = self.account_address
            result["access_key_private_key"] = self.active_key.private_key
            result["key_id"] = self.active_key.key_id
            result["expiry"] = self.active_key.expiry
            result["public_key"] = self.active_key.public_key
        return result
    
    @classmethod
    def from_dict(cls, data: dict) -> "WalletConfig":
        """Load from dict (handles old single-network and new multi-network format)."""
        network = data.get("network", DEFAULT_NETWORK)
        
        # New multi-network format
        if "networks" in data:
            networks = {}
            for net_name, net_data in data["networks"].items():
                networks[net_name] = NetworkWallet.from_dict(net_data)
            return cls(network=network, networks=networks)
        
        # Old format: single network config at top level
        account_address = data.get("account_address", "")
        
        if "access_keys" in data:
            access_keys = [AccessKey.from_dict(k) for k in data["access_keys"]]
            active_idx = data.get("active_key_index", 0)
        elif "access_key_private_key" in data:
            key = AccessKey(
                private_key=data["access_key_private_key"],
                key_id=data.get("key_id", ""),
                expiry=data.get("expiry", 0),
                public_key=data.get("public_key", ""),
            )
            access_keys = [key]
            active_idx = 0
        else:
            access_keys = []
            active_idx = 0
        
        # Migrate old format to new multi-network format
        wallet = NetworkWallet(
            account_address=account_address,
            access_keys=access_keys,
            active_key_index=active_idx,
        )
        return cls(network=network, networks={network: wallet})


def setup_wallet_browser(auth_url: str = None, network: str = None, account_address: str = None):
    """Open browser for passkey wallet creation, returns config dict.
    
    If account_address is provided, skips wallet creation and goes directly to access key creation.
    """
    # Use default network if not specified
    if network is None:
        network = DEFAULT_NETWORK
    
    # Determine auth URL: use production URL or start local server for dev
    auth_url = get_auth_url()
    if auth_url.startswith("http://localhost") or auth_url.startswith("http://127.0.0.1"):
        # Local dev mode - start local auth server
        auth_server = get_auth_server()
        try:
            auth_url = auth_server.ensure_running()
        except RuntimeError:
            pass  # Keep the original auth_url
    
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', 0))
        port = s.getsockname()[1]
    
    received_config = {"done": False, "config": None, "aborted": False}
    
    class AuthHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass
        
        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path == "/abort":
                # Only abort if we haven't received a successful config yet
                if not received_config["config"]:
                    received_config["aborted"] = True
                    received_config["done"] = True
                self.send_response(200)
                self.end_headers()
                return
            if parsed.path == "/callback":
                params = parse_qs(parsed.query)
                if "access_key" in params:
                    expiry = params.get("expiry", ["0"])[0]
                    received_config["config"] = {
                        "access_key_private_key": params["access_key"][0],
                        "account_address": params.get("account_address", [""])[0],
                        "key_id": params.get("key_id", [""])[0],
                        "expiry": int(expiry) if expiry else 0,
                    }
                    received_config["done"] = True
                    
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    html = """<!DOCTYPE html>
<html><head><title>Presto - Connected</title>
<style>body{font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#0a0a0a;color:#fff}
.container{text-align:center}.check{font-size:64px;color:#22c55e;margin-bottom:16px}</style></head>
<body><div class="container"><div class="check">&#10003;</div><h1>Wallet Connected!</h1><p>Return to your terminal.</p></div>
<script>setTimeout(()=>window.close(),2000)</script></body></html>"""
                    self.wfile.write(html.encode('utf-8'))
                else:
                    self.send_error(400, "Missing access_key")
            else:
                self.send_error(404)
        
        def do_POST(self):
            if self.path == "/abort":
                # Only abort if we haven't received a successful config yet
                if not received_config["config"]:
                    received_config["aborted"] = True
                    received_config["done"] = True
                self.send_response(200)
                self.end_headers()
                return
            if self.path == "/faucet":
                # Proxy faucet request through CLI with auth credentials
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                try:
                    data = json.loads(body)
                    address = data.get("address", "")
                    
                    # Get RPC URL with credentials from config
                    from .config import NETWORKS
                    net_config = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
                    rpc_url = net_config["rpc"]
                    
                    # Make RPC call with credentials using subprocess (handles auth in URL)
                    req_body = json.dumps({
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "tempo_fundAddress",
                        "params": [address],
                    })
                    
                    curl_result = subprocess.run(
                        ["curl", "-s", "-X", "POST", rpc_url,
                         "-H", "Content-Type: application/json",
                         "-d", req_body],
                        capture_output=True, text=True, timeout=30
                    )
                    result = json.loads(curl_result.stdout)
                    
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps(result).encode('utf-8'))
                except Exception as e:
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": {"message": str(e)}}).encode('utf-8'))
                return
            if self.path == "/balance":
                # Proxy balance check through CLI with auth credentials
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                try:
                    data = json.loads(body)
                    address = data.get("address", "")
                    token = data.get("token", "")
                    
                    # Get RPC URL with credentials from config
                    from .config import NETWORKS
                    from .rpc import get_token_balance_raw
                    net_config = NETWORKS.get(network, NETWORKS[DEFAULT_NETWORK])
                    rpc_url = net_config["rpc"]
                    
                    balance = get_token_balance_raw(address, token, rpc_url)
                    
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps({"balance": balance}).encode('utf-8'))
                except Exception as e:
                    self.send_response(500)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": {"message": str(e)}}).encode('utf-8'))
                return
            if self.path == "/callback":
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                try:
                    data = json.loads(body)
                    from . import logger
                    logger.info(f"Callback received: account_address={data.get('account_address')}, key_id={data.get('key_id')}, has_access_key={bool(data.get('access_key'))}")
                    received_config["config"] = {
                        "access_key_private_key": data.get("access_key"),
                        "account_address": data.get("account_address", ""),
                        "key_id": data.get("key_id", ""),
                        "expiry": data.get("expiry", 0),
                        "public_key": data.get("public_key", ""),
                    }
                    received_config["done"] = True
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(b'{"ok":true}')
                except Exception as e:
                    from . import logger
                    logger.error(f"Callback error: {e}")
                    self.send_error(400)
            else:
                self.send_error(404)
        
        def do_OPTIONS(self):
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()
    
    server = http.server.HTTPServer(("127.0.0.1", port), AuthHandler)
    server.timeout = 5  # Short timeout so we can check for abort
    
    callback_url = f"http://127.0.0.1:{port}/callback"
    state = secrets.token_urlsafe(16)
    full_auth_url = f"{auth_url}?callback={callback_url}&state={state}&network={network}"
    
    # If account_address is provided, pass it to skip wallet creation step
    if account_address:
        full_auth_url += f"&account={account_address}"
    
    # Open browser silently using subprocess to avoid terminal disruption
    import platform
    import time
    if platform.system() == "Darwin":
        subprocess.Popen(
            ["open", full_auth_url],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL
        )
    else:
        import sys
        import io
        old_stdout, old_stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = io.StringIO(), io.StringIO()
        try:
            webbrowser.open(full_auth_url)
        finally:
            sys.stdout, sys.stderr = old_stdout, old_stderr
    
    # Wait for callback with 5 minute total timeout
    start_time = time.time()
    max_wait = 300  # 5 minutes
    
    while not received_config["done"]:
        if time.time() - start_time > max_wait:
            server.server_close()
            return None
        try:
            server.handle_request()
        except Exception:
            pass
    
    server.server_close()
    
    # Return None if user closed browser window (aborted)
    if received_config["aborted"]:
        return None
    
    return received_config["config"]


def setup_wallet_manual():
    """Prompt user to enter private key manually."""
    print(f"\n\033[1mImport Private Key\033[0m\n")
    
    private_key = input(f"\033[34mEnter your private key (0x...): \033[0m").strip()
    if not private_key.startswith("0x"):
        private_key = "0x" + private_key
    
    try:
        address = subprocess.run(
            ["cast", "wallet", "address", private_key],
            capture_output=True, text=True, check=True
        ).stdout.strip()
    except Exception:
        print(f"\033[31mError: Invalid key or 'cast' not installed\033[0m")
        print(f"\033[2mInstall Foundry: curl -L https://foundry.paradigm.xyz | bash\033[0m")
        return None
    
    return {
        "access_key_private_key": private_key,
        "account_address": address,
    }
