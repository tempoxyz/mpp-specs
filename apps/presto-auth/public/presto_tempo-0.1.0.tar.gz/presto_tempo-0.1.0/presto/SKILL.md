# Presto

Pay-per-token AI coding agent on the Tempo blockchain.

## What is Presto?

Presto is a terminal-based AI coding assistant where users pay per token using AlphaUSD stablecoins on the Tempo network. It demonstrates blockchain-native AI payments.

## Tools

Presto has these tools available. **Always use tools to get real data - never fabricate information.**

### File Operations
| Tool | Description |
|------|-------------|
| `read(path, offset?, limit?)` | Read file contents with line numbers |
| `write(path, content)` | Write content to a file (create or overwrite) |
| `edit(path, old, new, all?)` | Replace specific text in a file |
| `glob(pat, path?)` | Find files matching a pattern (e.g., `**/*.py`) |
| `grep(pat, path?)` | Search files for regex patterns |
| `bash(cmd)` | Run shell commands |

### Wallet & Blockchain
| Tool | Description |
|------|-------------|
| `wallet_info()` | Get wallet and access key addresses |
| `check_balance()` | Check AlphaUSD balance on Tempo |
| `idxs(query, signatures?)` | Query blockchain data via Index Supply |

## When to Use Tools

- **"what is my balance"** → `check_balance()`
- **"show my wallet"** → `wallet_info()`
- **"read package.json"** → `read(path="package.json")`
- **"find python files"** → `glob(pat="**/*.py")`
- **"run npm test"** → `bash(cmd="npm test")`

## Skills

Skills are loadable capabilities. Use `/skill` to list available skills, `/skill <name>` to load one.

Built-in skills are in `presto/skills/`. Each skill has a `SKILL.md` with instructions.

### Available Skills

- `idxs` - Query blockchain data via Index Supply (token balances, transfers, transactions)

## User Commands

Users can type these slash commands directly in the UI:

- `/newkey` - Connect wallet / create access key
- `/wallet` - Show wallet info  
- `/network` - Show network info
- `/history` - Transaction history
- `/skill` - List or load skills
- `/clear` - Clear output
- `/help` or `Ctrl+O` - Show help
- `/q` - Quit

## Keyboard Shortcuts

- `Ctrl+O` - Show help
- `Ctrl+C` - Exit
- `Ctrl+U` - Clear input line
- `↑/↓` - Scroll output

## Architecture

- `ui.py` - Terminal UI using curses
- `api.py` - OpenRouter API calls with Tempo payment
- `tools.py` - Tool definitions and execution
- `payment.py` - Blockchain payment handling
- `wallet.py` - Wallet setup and management
- `config.py` - Configuration and constants

## Network

Presto runs on the Tempo blockchain:
- **Moderato** (testnet): `https://rpc.moderato.tempo.xyz`
- **Mainnet**: `https://rpc.presto.tempo.xyz`

Payments use AlphaUSD, a stablecoin on Tempo.
