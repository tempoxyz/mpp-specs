"""Payment authentication and Tempo transaction signing."""
import base64
import json
import os
import random
import re
import subprocess

from . import logger
from .config import load_config, save_config  # Re-export for backwards compatibility

# Session-unique nonce key for 2D nonce support (allows parallel Presto instances)
# Using a random key per session avoids "replacement transaction underpriced" errors
# when multiple instances try to submit transactions simultaneously.
# See: https://docs.tempo.xyz/guide/payments/send-parallel-transactions
_SESSION_NONCE_KEY = random.randint(1, 2**32 - 1)

# Nonce cache: (wallet_address) -> int
# Reduces RPC calls by caching and incrementing locally
_NONCE_CACHE: dict[str, int] = {}

# Default gas limit for ERC20 transfers (avoids gas estimation RPC call)
# 100k is generous for standard ERC20 transfer (~21k + ~29k for transfer)
_DEFAULT_ERC20_TRANSFER_GAS = 100000

def clear_nonce_cache(wallet_address: str = None):
    """Clear cached nonce (call on nonce-related errors)."""
    global _NONCE_CACHE
    if wallet_address:
        _NONCE_CACHE.pop(wallet_address.lower(), None)
    else:
        _NONCE_CACHE.clear()


def base64url_decode(s: str) -> str:
    s = s.replace("-", "+").replace("_", "/")
    padding = len(s) % 4
    if padding:
        s += "=" * (4 - padding)
    return base64.b64decode(s).decode("utf-8")


def base64url_encode(s: str) -> str:
    return base64.b64encode(s.encode("utf-8")).decode("utf-8").rstrip("=").replace("+", "-").replace("/", "_")


def parse_www_authenticate(header: str) -> dict:
    if not header.startswith("Payment "):
        raise ValueError("Invalid WWW-Authenticate header")
    params = {}
    regex = re.compile(r'(\w+)="([^"]*)"')
    for match in regex.finditer(header[8:]):
        params[match.group(1)] = match.group(2)
    if "request" in params:
        params["request"] = json.loads(base64url_decode(params["request"]))
    return params


def format_authorization(credential: dict) -> str:
    return f"Payment {base64url_encode(json.dumps(credential))}"


def sign_tempo_transaction(access_key_private_key: str, wallet_address: str, amount: str, asset: str, destination: str, rpc_url: str = None, chain_id: int = None, use_direct_signing: bool = False) -> str:
    """
    Sign a Tempo transaction using an access key on behalf of a wallet.
    
    Per Tempo spec (https://docs.tempo.xyz/protocol/transactions/spec-tempo-transaction#access-keys):
    - Access keys authorize a separate key to sign transactions on behalf of a wallet
    - The transaction's `from` is the main wallet address
    - The access key signs the transaction with Keychain signature type (0x03)
    - Funds come from the main wallet, NOT the access key
    
    Uses cast mktx with --access-key and --root-account flags.
    Workaround for cast bug: estimate gas separately with --from wallet_address.
    
    Args:
        access_key_private_key: The access key's private key (held by Presto)
        wallet_address: The main wallet address (passkey wallet) that holds the funds
        amount: Amount to transfer (in wei)
        asset: Token contract address
        destination: Recipient address
        rpc_url: RPC endpoint
        chain_id: Chain ID (4217 for mainnet, 42431 for moderato)
        use_direct_signing: If True, sign directly with private key (for simple EOA wallets in CI)
    """
    if rpc_url is None:
        from .config import NETWORKS, DEFAULT_NETWORK
        rpc_url = os.environ.get("TEMPO_RPC_URL", NETWORKS[DEFAULT_NETWORK]["rpc"])
    
    if chain_id is None:
        from .config import NETWORKS, DEFAULT_NETWORK
        chain_id = NETWORKS[DEFAULT_NETWORK]["chain_id"]
    
    logger.info(f"Signing tx: wallet={wallet_address}, amount={amount}, asset={asset}, dest={destination}")
    logger.info(f"RPC URL: {rpc_url}, chain_id={chain_id}, direct={use_direct_signing}, nonce_key={_SESSION_NONCE_KEY}")
    
    # Build ERC20 transfer calldata: transfer(address,uint256)
    dest_padded = destination[2:].lower().zfill(64)
    amount_hex = hex(int(amount))[2:].zfill(64)
    calldata = f"0xa9059cbb{dest_padded}{amount_hex}"
    
    # Step 1: Estimate gas
    estimate_cmd = [
        "cast", "estimate",
        "--from", wallet_address,
        "--rpc-url", rpc_url,
        asset,
        calldata,
    ]
    
    estimate_result = subprocess.run(estimate_cmd, capture_output=True, text=True, timeout=30)
    if estimate_result.returncode != 0:
        error_msg = estimate_result.stderr.strip() or estimate_result.stdout.strip()
        logger.error(f"Failed to estimate gas: {error_msg}")
        raise subprocess.CalledProcessError(estimate_result.returncode, "cast estimate", stderr=error_msg)
    
    gas_limit = estimate_result.stdout.strip()
    logger.info(f"Estimated gas: {gas_limit}")
    
    # Step 2: Get 2D nonce for this session's nonce key
    # Using 2D nonces allows parallel Presto instances without "replacement transaction underpriced" errors
    # The Nonce precompile is at 0x4E4F4E4345000000000000000000000000000000
    # Function: getNonce(address account, uint256 nonceKey) returns (uint64)
    nonce_precompile = "0x4E4F4E4345000000000000000000000000000000"
    
    # Build calldata for getNonce(address, uint256)
    # Function selector: keccak256("getNonce(address,uint256)")[:4] = 0x89535803
    account_padded = wallet_address[2:].lower().zfill(64)
    nonce_key_hex = hex(_SESSION_NONCE_KEY)[2:].zfill(64)
    get_nonce_calldata = f"0x89535803{account_padded}{nonce_key_hex}"
    
    nonce_cmd = [
        "cast", "call",
        "--rpc-url", rpc_url,
        nonce_precompile,
        get_nonce_calldata,
    ]
    
    nonce_result = subprocess.run(nonce_cmd, capture_output=True, text=True, timeout=30)
    if nonce_result.returncode != 0:
        error_msg = nonce_result.stderr.strip() or nonce_result.stdout.strip()
        logger.error(f"Failed to get 2D nonce: {error_msg}")
        # Fall back to standard nonce if 2D nonce fails
        nonce_cmd = ["cast", "nonce", "--rpc-url", rpc_url, wallet_address]
        nonce_result = subprocess.run(nonce_cmd, capture_output=True, text=True, timeout=30)
        if nonce_result.returncode != 0:
            raise subprocess.CalledProcessError(nonce_result.returncode, "cast nonce", stderr=error_msg)
        nonce = nonce_result.stdout.strip()
        nonce_key_for_tx = None  # Use protocol nonce
    else:
        # Parse the uint64 result from the call
        nonce_hex = nonce_result.stdout.strip()
        nonce = str(int(nonce_hex, 16)) if nonce_hex.startswith("0x") else nonce_hex
        nonce_key_for_tx = _SESSION_NONCE_KEY
    
    logger.info(f"Nonce: {nonce} (key: {nonce_key_for_tx or 'protocol'})")
    
    # Step 3: Sign transaction
    if use_direct_signing:
        # Direct signing mode for simple EOA wallets (CI/testing)
        # The private key IS the wallet key, no access key indirection
        cmd = [
            "cast", "mktx",
            "--private-key", access_key_private_key,
            "--rpc-url", rpc_url,
            "--chain", str(chain_id),
            "--gas-limit", gas_limit,
            "--nonce", nonce,
            "--fee-token", asset,
            asset,
            calldata,
        ]
        # Add nonce-key for 2D nonce support (parallel transactions)
        if nonce_key_for_tx is not None:
            cmd.insert(-2, "--nonce-key")
            cmd.insert(-2, str(nonce_key_for_tx))
    else:
        # Access key mode for passkey wallets (production)
        cmd = [
            "cast", "mktx",
            "--access-key", access_key_private_key,
            "--root-account", wallet_address,
            "--rpc-url", rpc_url,
            "--chain", str(chain_id),
            "--gas-limit", gas_limit,
            "--nonce", nonce,
            "--fee-token", asset,
            asset,
            calldata,
        ]
        # Add nonce-key for 2D nonce support (parallel transactions)
        if nonce_key_for_tx is not None:
            cmd.insert(-2, "--nonce-key")
            cmd.insert(-2, str(nonce_key_for_tx))
    
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    
    if result.returncode != 0:
        error_msg = result.stderr.strip() or result.stdout.strip()
        logger.error(f"Failed to sign transaction: {error_msg}")
        raise subprocess.CalledProcessError(result.returncode, "cast mktx", stderr=error_msg)
    
    signed_tx = result.stdout.strip()
    if not signed_tx.startswith("0x"):
        raise RuntimeError(f"Invalid signed transaction from cast: {signed_tx}")
    
    logger.payment_signed(signed_tx=signed_tx, from_address=wallet_address, nonce=nonce)
    return signed_tx


def handle_402_payment(challenge: dict, private_key: str, from_address: str, rpc_url: str = None, chain_id: int = None, on_step=None, use_direct_signing: bool = False) -> str:
    """Handle 402 payment challenge, returns Authorization header value.
    
    Args:
        challenge: The parsed WWW-Authenticate challenge from the 402 response
        private_key: The private key to sign with
        from_address: The address that will be shown as the payment source
        rpc_url: RPC endpoint
        chain_id: Chain ID for the DID
        on_step: callback(step_name, step_status) for progress updates
        use_direct_signing: If True, sign directly with private key (for simple EOA wallets)
    """
    if chain_id is None:
        from .config import NETWORKS, DEFAULT_NETWORK
        chain_id = NETWORKS[DEFAULT_NETWORK]["chain_id"]
    
    request = challenge["request"]
    amount = request["amount"]
    asset = request["asset"]
    destination = request["destination"]
    challenge_id = challenge.get("id", "unknown")
    
    logger.payment_request(challenge_id=challenge_id, amount=amount, asset=asset, destination=destination, rpc_url=rpc_url)
    
    # Step 1: Sign transaction
    if on_step:
        on_step('signing', 'pending')
    signed_tx = sign_tempo_transaction(private_key, from_address, amount, asset, destination, rpc_url, chain_id, use_direct_signing=use_direct_signing)
    if on_step:
        on_step('signing', 'done')
    
    # Step 2: Build credential
    if on_step:
        on_step('sending', 'pending')
    credential = {
        "id": challenge["id"],
        "source": f"did:pkh:eip155:{chain_id}:{from_address}",
        "payload": {
            "type": "transaction",
            "signature": signed_tx
        }
    }
    
    auth_header = format_authorization(credential)
    
    # Import here to avoid circular dependency
    from . import config
    logger.payment_submitted(auth_header_preview=auth_header[:80] + "...", proxy_url=config.get_proxy_url())
    return auth_header
